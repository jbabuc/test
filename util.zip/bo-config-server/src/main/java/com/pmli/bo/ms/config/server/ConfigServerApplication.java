package com.pmli.bo.ms.config.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.cloud.config.server.EnableConfigServer;

import com.pmli.util.spring.ContextWrapper;

/**
 * Config Server provides an HTTP resource-based API for external configuration (name-value pairs or equivalent YAML and
 * .properties files content). The server is embeddable in a Spring Boot application. Spring Cloud Config provides
 * server and client-side support for externalize configuration in a distributed system. The default implementation of
 * the server storage backend uses git. This is widely used in microservices. A same service or application can be
 * launched many times in different containers, and it is interesting to have a central place where they can read the
 * settings to these services.
 * 
 * @author sbambarse
 * @since 2021
 * @version 1.0.0
 */
@EnableConfigServer
@SpringBootApplication(scanBasePackages = { "com.pmli" }, exclude = { MongoAutoConfiguration.class,
    MongoDataAutoConfiguration.class, DataSourceAutoConfiguration.class })
public class ConfigServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
        ContextWrapper.logAllProperties();
    }

}