package com.pmli.util.json;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.fasterxml.jackson.core.JsonParser.Feature;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.core.JsonProcessingException;

public class JsonUtil {
    public static final String EMPTY_JSON = "{}";
    public static final Logger LOGGER     = MsObject.getSL();

    private JsonUtil() {}

    public static JsonNode readJson(String val, boolean allowSingleQuotes, boolean allowUnquotedFieldNames) {
        try {
            return new ObjectMapper().configure(Feature.ALLOW_SINGLE_QUOTES, allowSingleQuotes)
                .configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, allowUnquotedFieldNames).readValue(val, JsonNode.class);
        } catch (JsonProcessingException ex) {
            LOGGER.error("Failed to read json from {}", val);
            throw new MsRuntimeException(ex);
        }
    }

    public static JsonNode readJson(String val) { return readJson(val, true, true); }

    public static <T> List<T> readArray(String val, boolean failOnUnknownProps, boolean allowSingleQuotes,
        boolean allowUnquotedFieldNames, Class<T> clazz) {
        try {
            ObjectMapper om = new ObjectMapper();
            CollectionType listType = om.getTypeFactory().constructCollectionType(ArrayList.class, clazz);
            return om.configure(Feature.ALLOW_SINGLE_QUOTES, allowSingleQuotes)
                .configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, allowUnquotedFieldNames)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, failOnUnknownProps)
                .readValue(val, listType);
        } catch (JsonProcessingException ex) {
            LOGGER.error("Failed to read array {} from {}", clazz.getName(), val);
            throw new MsRuntimeException(ex);
        }
    }

    public static <T> T readValue(String val, boolean failOnUnknownProps, boolean allowSingleQuotes,
        boolean allowUnquotedFieldNames, Class<T> clazz) {
        try {
            return new ObjectMapper().configure(Feature.ALLOW_SINGLE_QUOTES, allowSingleQuotes)
                .configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, allowUnquotedFieldNames)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, failOnUnknownProps).readValue(val, clazz);
        } catch (JsonProcessingException ex) {
            LOGGER.error("Failed to read value {} from {}", clazz.getName(), val);
            throw new MsRuntimeException(ex);
        }
    }

    public static <T> T readValue(String val, Class<T> clazz) { return readValue(val, false, true, true, clazz); }

    public static String writeValueAsString(Object object) {
        try {
            return new ObjectMapper().setVisibility(PropertyAccessor.FIELD, Visibility.ANY).writeValueAsString(object);
        } catch (JsonProcessingException ex) {
            LOGGER.error("Failed to write value: {}", object);
            throw new MsRuntimeException(ex);
        }
    }

    public static <T> T copy(T t, Class<T> clazz) { return JsonUtil.readValue(JsonUtil.writeValueAsString(t), clazz); }

    // sonar scan showing critical warning on return of generic List<?>, hence returning Object
    public static Object toListOrNull(Object val) {
        if (val == null) return null;
        if (val instanceof List<?>) return val;
        if (!val.getClass().isArray()) return null;
        // primitive arrays cannot be casted to object array
        if (val.getClass().getComponentType().isPrimitive())
            return JsonUtil.readArray(JsonUtil.writeValueAsString(val), false, true, true, Object.class);
        return Arrays.asList((Object[]) val);
    }
}
