package com.pmli.util.bson;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.LongNode;
import com.pmli.util.java.MsRuntimeException;

public class IsoDateDeSerializer extends JsonDeserializer<Date> {
    public static final String  MONGO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    @Override
    public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        try {
            JsonNode node = jp.readValueAsTree();
            JsonNode dateJN = node.get("$date");
            return dateJN instanceof LongNode ? new Date(((LongNode) dateJN).longValue())
                : new SimpleDateFormat(MONGO_DATE_FORMAT).parse(dateJN.asText());
        } catch (ParseException e) {
            throw MsRuntimeException.wrap(e);
        }
    }
}
