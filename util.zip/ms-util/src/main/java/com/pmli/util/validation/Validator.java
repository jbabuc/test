package com.pmli.util.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import static com.pmli.util.java.ReflectUtil.invoke;
import static com.pmli.util.java.ReflectUtil.castOrNull;
import static com.pmli.util.java.ReflectUtil.getClassOrNull;

import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.java.ReflectUtil;
import com.pmli.util.json.JsonUtil;

import io.vavr.Function3;

/**
 * Base class to handle validations with dynamic chaining.<br/>
 * <br/>
 * Child classes can invoke validate method with child class validation methods and arguments with chaining. Child
 * classes can mark methods with annotation @RegisterForQuickAccess for quick access, to avoid looping while finding
 * methods dynamically based on name and signature.<br/>
 * 
 * @see    StringValidator
 * @see    RegisterForQuickAccess
 * @author 3495987jan
 */
@SuppressWarnings("unchecked")
public class Validator extends MsObject {
    public static final boolean DEFAULT_NULLABILITY = true;
    public static final String  ARG_ERRMSG          = "$errmsg:";

    private static Map<String, Method> quickAccessMethodMAP = null;

    /**
     * Annotation to annotate methods to indicate {@link Validator} to register method for quick access
     * 
     * @author 3495987jan
     */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    public static @interface RegisterForQuickAccess {
        boolean value() default true;
    }

    public static final Logger LOGGER = getSL();

    private Object  val;
    private String  displayName;
    private boolean nullable;

    @JsonCreator
    public Validator(@JsonProperty("val") Object val, @JsonProperty("displayName") String displayName,
        @JsonProperty("nullable") boolean nullable) {
        this.val = val;
        this.displayName = displayName;
        this.nullable = nullable;
    }

    public Validator(Object val, String displayName) { this(val, displayName, DEFAULT_NULLABILITY); }

    public boolean isNullable() { return nullable; }

    @JsonIgnore
    public boolean isNullableAndIsNull() { return nullable && val == null; }

    public Object getVal() { return val; }

    public <T> T getVal(Class<T> clazz) { return clazz.cast(val); }

    @RegisterForQuickAccess
    public Void notNull() {
        if (val == null) throw new MsValidationException(getDisplayName() + " cannot be null");
        return null;
    }

    public String getDisplayName() { return displayName; }

    /**
     * register validation function annotated with @RegisterForQuickAccess for quick access. do not use annotation with
     * overloaded methods.
     */
    private static synchronized void loadQuickAccessMethodMAP() {
        if (quickAccessMethodMAP == null) {
            quickAccessMethodMAP = new HashMap<>();

            // notNull validation that belongs to Validator class
            quickAccessMethodMAP.put(Validator.class.getName() + ".notNull",
                ReflectUtil.getMethod(Validator.class, "notNull"));

            ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(
                false);
            provider.addIncludeFilter(new AssignableTypeFilter(Validator.class));

            // scan package
            Set<BeanDefinition> components = provider.findCandidateComponents("com.pmli");
            for (BeanDefinition component : components) {
                Class<?> clazz = getClassOrNull(component.getBeanClassName());
                if (clazz == null) continue;
                Arrays.asList(clazz.getMethods()).stream()
                    .filter(m -> m.getAnnotation(RegisterForQuickAccess.class) != null).forEach(m -> {
                        LOGGER.debug("Registering: {}.{} --> {}", clazz.getName(), m.getName(), m.getName());
                        quickAccessMethodMAP.put(clazz.getName() + "." + m.getName(), m);
                    });
            }
        }
    }

    public static Method getMethod(Class<?> clazz, String name, Object... args) {
        if (quickAccessMethodMAP == null) loadQuickAccessMethodMAP();
        return ofNullable(quickAccessMethodMAP.get(clazz.getName() + "." + name) /* pre-compiled */)
            .orElseGet(() -> ReflectUtil.getMethod(clazz, name, args) /* dynamic expensive */);
    }

    /**
     * This validate method allows custom handling of the failures. Invokes validation method with the arguments, and on
     * failure executes the onFailExecute consumer.
     * 
     * @param  method
     * @param  onFailExecute consumer to process the failure
     * @param  args
     * @return               this
     */
    public Validator validate(Method method, Consumer<Throwable> onFailExecute, Object... args) {
        if (isNullableAndIsNull()) return this; // nullable, pass all

        // log..info("validate: {}, val: {}, args:{}", method.getName(), val, Arrays.asList(args)).

        // for dynamic calling, parameters are strings, try and map them to actual type
        of(method.getParameters()).ifPresent(p -> IntStream.range(0, p.length).forEach(i -> {
            // for comparable use value type for casting
            Class<?> castToType = p[i].getType().equals(Comparable.class) ? val.getClass() : p[i].getType();

            // check if types are equal
            if (castToType.equals(args[i].getClass())) return;
            // try direct casting
            if (ofNullable(castOrNull(args[i], castToType)).map(o -> args[i] = o).orElse(null) != null) return;
            // try mapping
            if (args[i] instanceof String) { args[i] = JsonUtil.readValue((String) args[i], castToType); return; }

            // parameter mismatch
            throw new MsValidationException(String.format("Validation parameter miss match, cannot cast %s to %s.",
                args[i].getClass(), castToType));

        }));

        invoke(method, this, onFailExecute, args);
        return this;
    }

    /**
     * Invokes validation method based on static field method, and throws MsValidationException RuntimeException. Using
     * fields to avoid expensive looping to find methods dynamically based on name and signature.
     * 
     * @param  fieldNameOfMethod
     * @param  args
     * @return                   this
     */
    public Validator validate(String methodName, Consumer<Throwable> onFailExecute, Object... args) {
        return validate(getMethod(this.getClass(), methodName, args), onFailExecute, args);
    }

    /**
     * method name and arguments. if argument at 0 is prefixed with $errmsg, it will be removed and used as error
     * message when validation fails and will not be passed to method
     * 
     * @param  validation
     * @return
     */
    public Validator validate(String methodName, Object... args) {
        if (args.length > 0 && args[0] instanceof String && args[0].toString().startsWith(ARG_ERRMSG)) {
            return validate(methodName,
                t -> { throw new MsValidationException(args[0].toString().substring(ARG_ERRMSG.length())); },
                Arrays.copyOfRange(args, 1, args.length));
        } else {
            return validate(methodName, null, args);
        }
    }

    /**
     * method name and parameters separated by tilde
     * 
     * @param  validation
     * @return
     */
    public Validator validate(String validation) {
        of(new ArrayList<String>(Arrays.asList(validation.split("~"))))
            .ifPresent(l -> validate(l.remove(0), l.toArray()));

        return this;
    }

    /**
     * Helper function to be able to invoke validations iteratively that are separated by comma and method name and
     * parameters separated by tilde
     * 
     * @param  validations
     * @return             this
     */
    public Validator validateAll(String validations) {
        // ignore escaped comma while splitting validations and remove escape
        if (!validations.isEmpty()) Arrays.asList(validations.split("(?<!\\\\),")).stream()
            .map(t -> t.replaceAll("\\\\,", ",")).forEach(this::validate);
        return this;
    }

    /**
     * compile time static method call with unbound method references
     */
    public <T> T validate(Function<T, Void> f) {
        if (!isNullableAndIsNull()) { f.apply((T) this); }
        return (T) this;
    }

    public <T, U> T validate(BiFunction<T, U, Void> f, U u) {
        if (!isNullableAndIsNull()) { f.apply((T) this, u); }
        return (T) this;
    }

    public <T, U, V> T validate(Function3<T, U, V, Void> f, U u, V v) {
        if (!isNullableAndIsNull()) { f.apply((T) this, u, v); }
        return (T) this;
    }

    /**
     * ex compile time static method call with unbound method references, allows for custom error message
     */
    public <T> T validateEx(Function<T, Void> f, String errmsg) {
        try {
            validate(f);
        } catch (Exception ex) {
            throw new MsValidationException(errmsg);
        }
        return (T) this;
    }

    public <T, U> T validateEx(BiFunction<T, U, Void> f, U u, String errmsg) {
        try {
            validate(f, u);
        } catch (Exception ex) {
            throw new MsValidationException(errmsg);
        }
        return (T) this;
    }

    public <T, U, V> T validateEx(Function3<T, U, V, Void> f, U u, V v, String errmsg) {
        try {
            validate(f, u, v);
        } catch (Exception ex) {
            throw new MsValidationException(errmsg);
        }
        return (T) this;
    }
}
