package com.pmli.util.validation;

import com.pmli.util.java.MsValidationException;

/**
 * Validator to compare object that are Comparable.
 * 
 * @author 3495987jan
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ComparableValidator extends Validator {
    Comparable cval;

    public ComparableValidator(Comparable val, String displayName, boolean nullable) {
        super(val, displayName, nullable);
        this.cval = val;
    }

    public ComparableValidator(Comparable cval, String displayName) { this(cval, displayName, DEFAULT_NULLABILITY); }

    @RegisterForQuickAccess
    public Void greaterThan(Comparable c) {
        if (cval.compareTo(c) > 0) return null;
        throw new MsValidationException(String.format("%s=%s, must be greater than %s.", getDisplayName(), cval, c));
    }

    @RegisterForQuickAccess
    public Void lessThan(Comparable c) {
        if (cval.compareTo(c) < 0) return null;
        throw new MsValidationException(String.format("%s=%s, must be less than %s.", getDisplayName(), cval, c));
    }

    @RegisterForQuickAccess
    public Void isBetween(Comparable lowerLimit, Comparable upperLimit) {
        greaterThan(lowerLimit);
        return lessThan(upperLimit);
    }

    @RegisterForQuickAccess
    public Void equalsTo(Comparable c) {
        if (cval.compareTo(c) == 0) return null;
        throw new MsValidationException(String.format("%s=%s, must be equal to %s.", getDisplayName(), cval, c));
    }
    
    @RegisterForQuickAccess
    public Void notEqualsTo(Comparable c) {
        if (cval.compareTo(c) != 0) return null;
        throw new MsValidationException(String.format("%s=%s, must not be equal to %s.", getDisplayName(), cval, c));
    }
}
