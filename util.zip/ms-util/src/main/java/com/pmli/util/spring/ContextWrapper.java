package com.pmli.util.spring;

import java.util.Objects;
import java.util.stream.StreamSupport;

import static java.util.Optional.ofNullable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.stereotype.Component;

import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;

@Component
public class ContextWrapper implements ApplicationContextAware {
    private static final Logger LOGGER = MsObject.getSL();

    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext context) { ContextWrapper.setContext(context); }

    private static void setContext(ApplicationContext context) { ContextWrapper.context = context; }

    public static ApplicationContext getContext() { return context; }

    public static Environment getAppEnv() { return context.getEnvironment(); }

    public static String getAppProperty(String name) { return getAppEnv().getProperty(name); }

    @SuppressWarnings("unchecked")
    public static <R> R getAppProperty(String name, R defaultVal) {//
        return (R) ofNullable(getAppEnv().getProperty(name)).map(s -> {
            if (defaultVal == null || defaultVal.getClass().equals(String.class)) return s;
            return JsonUtil.readValue(s, defaultVal.getClass());
        }).filter(Objects::nonNull).map(o -> (R) o).orElse(defaultVal);
    }

    public static AutowireCapableBeanFactory getAutowireCapableBeanFactory() {
        return context.getAutowireCapableBeanFactory();
    }

    public static <R> R autoWire(R r) { getAutowireCapableBeanFactory().autowireBean(r); return r; }

    public static Map<String, String> getAllProperties() {
        Environment env = getAppEnv();
        Map<String, String> m = new HashMap<>();
        if (context != null) {
            MutablePropertySources propSrcs = ((AbstractEnvironment) env).getPropertySources();
            StreamSupport.stream(propSrcs.spliterator(), false).filter(ps -> ps instanceof EnumerablePropertySource)
                .map(ps -> ((EnumerablePropertySource<?>) ps).getPropertyNames()).flatMap(Arrays::<String>stream)
                .forEach(propName -> m.put(propName, env.getProperty(propName)));
        } else {
            m.putAll(System.getenv());
        }

        return m;
    }

    public static void logAllProperties() { getAllProperties().forEach((k, v) -> LOGGER.info("{}: {}", k, v)); }
}
