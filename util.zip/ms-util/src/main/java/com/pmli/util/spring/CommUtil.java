package com.pmli.util.spring;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;

import org.bson.Document;
import org.slf4j.Logger;

import com.pmli.util.bson.DocUtil.DocPW;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.ThreadUtil.HttpServer;

public class CommUtil {
    public static final Logger LOGGER = MsObject.getSL();

    public static final String PROP_COMM_URL      = "com.pmli.comm.url";
    public static final String PROP_SUPPORT_EMAIL = "com.pmli.comm.support.email";

    public static final String EMAIL_URI = "/api/v2/pmli/communications/send-email";

    public static final String EMAIL_REQUEST_TEMPLATE = "{ clientId: '12345678', loginId: '12345', loginType: 1, communicationContext: 'ABCD', referenceId: '12345678', toEmail: null, ccTo: null, bcc: null, templateId: 'SIMPLE_EMAIL_TEMPLATE', fromEmail: 'accountsupport@pnbmetlife.co.in', attachments:null, base64Content: null, metadata: [], emlReq: 'N' }";

    private CommUtil() {}

    public static void sendEmail(String url, String uri, String requestTemplate, String to, String cc, String subject,
        String body) {

        String payload = new DocPW(Document.parse(requestTemplate)).put("toEmail", to).put("ccTo", cc)
            .put("metadata[0].name", "subject").put("metadata[0].value", subject).put("metadata[1].name", "body")
            .put("metadata[1].value", body).doc().toJson();
        try { // try comm service on local host
            WebClientWrapper.getWCW(url).post(uri, Collections.singletonMap("Content-Type", "application/json"),
                payload);
        } catch (Exception e) {
            LOGGER.error("Failed to send email: {}", payload);
        }
    }

    public static void sendEmail(String to, String cc, String subject, String body) {
        sendEmail(ContextWrapper.getAppProperty(PROP_COMM_URL), EMAIL_URI, EMAIL_REQUEST_TEMPLATE, to, cc, subject,
            body);
    }

    public static void logAndSendError(Throwable th) { LOGGER.error("Error: ", th); sendError(th); }

    public static String prepareErrorBody(Throwable th) {
        final String br = "<br/>";
        return "<html><body>" + th.getClass().getName() + ":" + th.getMessage() + br
            + Arrays.asList(th.getStackTrace()).stream().map(Object::toString).collect(Collectors.joining(br)) + br + br
            + br + ContextWrapper.getAllProperties().entrySet().stream().map(e -> e.getKey() + ": " + e.getValue())
                .collect(Collectors.joining(br))
            + "</body></html>";
    }

    public static void sendError(Throwable th) {
        String to = ContextWrapper.getAppProperty(PROP_SUPPORT_EMAIL, "dspteam@pnbmetlife.com");
        String subject = "Micro-service encountered error - " + JUtil.getHostNameOrDefault(HttpServer.LOCAL_HOST);
        String body = prepareErrorBody(th);
        sendEmail(ContextWrapper.getAppProperty(PROP_COMM_URL, "http://10.168.50.28:2157" /* use uat as default */),
            EMAIL_URI, EMAIL_REQUEST_TEMPLATE, to, null, subject, body);
    }
}
