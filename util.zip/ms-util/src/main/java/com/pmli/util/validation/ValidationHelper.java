package com.pmli.util.validation;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.springframework.beans.BeanUtils;

import static java.util.Optional.ofNullable;

import com.pmli.util.java.ReflectUtil;

import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.pmli.util.java.JUtil;

/**
 * Use following to enable/disable parallel streams, <b>-Dcom.pmli.util.useParallelStreams=true</b> <br/>
 * Use following to set fork join thread pool size,
 * <b>-Djava.util.concurrent.ForkJoinPool.common.parallelism=10</b><br/>
 * 
 * @author 3495987jan
 * @see    validator
 */
public class ValidationHelper extends MsObject {
    public static final int MAX_VALIDATIONS_PER_EXECUTION = 1000;
    public static final int DEFAULT_STR_MAX_LENGTH        = 256;

    public static final String REF_PARENT        = "$parent";
    public static final String UNKNOW_FIELD_NAME = "<Field>";

    // to set thread pool size, -Djava.util.concurrent.ForkJoinPool.common.parallelism=10
    public static final boolean USE_PARALLEL_STREAMS = Boolean
        .parseBoolean(JUtil.getSystemPropertyOrDefault("com.pmli.util.useParallelStreams", "true"));

    public static final Logger LOGGER = getSL();
    static {
        LOGGER.info("useParallelStreams: {}", ValidationHelper.USE_PARALLEL_STREAMS);
        LOGGER.info("ForkJoin common thread pool size : {}", ForkJoinPool.getCommonPoolParallelism());
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private static class ValidationItem {//
        Object                dataObject;
        List<DataValidations> dataValidations;

        public String getParentDisplayName() {
            String displayName = null;
            for (int i = dataValidations.size() - 2; (displayName == null || displayName.equals(REF_PARENT))
                && i > -1; i--) {
                DataValidations dv = dataValidations.get(i);
                // order of preference for choosing display name,
                // $parent.displayName, $parent.fieldName, my.displaName, my.fieldName, unknown field name
                displayName = ofNullable(dv.getDisplayName()).orElse(dv.getFieldName());
                if (displayName == null) displayName = REF_PARENT; // try further up
            }

            return displayName == null || displayName.equals(REF_PARENT) ? "" : displayName;
        }

        public String getDisplayName() {
            DataValidations dv = dataValidations.get(dataValidations.size() - 1);
            String displayName = ofNullable(dv.getDisplayName()).orElse(dv.getFieldName());
            if (displayName == null) displayName = REF_PARENT;

            if (displayName.contains(REF_PARENT)) displayName = displayName.replace(REF_PARENT, getParentDisplayName());

            // if display name is $parent use unknown field name
            if (displayName == null || displayName.isEmpty() || displayName.equals(REF_PARENT))
                displayName = UNKNOW_FIELD_NAME;
            // if val index is present add it, for list elements
            displayName += ofNullable(dv.getValIndex()).map(i -> "[" + i + "]").orElse("");
            // if key is present add it, for hash map element
            displayName += ofNullable(dv.getValKey()).map(o -> "[" + o.toString() + "]").orElse("");

            return displayName.trim();
        }

        @Override
        public String toString() { return JsonUtil.writeValueAsString(this); }
    }

    private Queue<ValidationItem> validationItemQ       = new ConcurrentLinkedQueue<>();
    private Queue<Exception>      exceptionList         = new ConcurrentLinkedQueue<>();
    private AtomicInteger         validationCount       = new AtomicInteger();
    private boolean               processAllValidations = false;
    private boolean               exitProcessing        = false;

    public ValidationHelper(Object dataObject, DataValidations dv) {
        validationItemQ.add(new ValidationItem(dataObject, Arrays.asList(dv)));
    }

    public ValidationHelper(Object dataObject) { this(dataObject, new DataValidations()); }

    public Queue<Exception> getExceptionList() { return exceptionList; }

    public String getConsolidatedExceptionMsg() {
        return exceptionList.stream().map(Exception::getMessage).collect(Collectors.joining(" ")).trim();
    }

    public int getValidationCount() { return validationCount.get(); }

    public void setProcessAllValidations(boolean b) { processAllValidations = b; }

    private int incrementValidationCount() {
        int c = validationCount.incrementAndGet();
        if (c >= MAX_VALIDATIONS_PER_EXECUTION)
            throw new MsValidationException("Max validations count exceeded, " + MAX_VALIDATIONS_PER_EXECUTION + ".");
        return c;
    }

    private static Validator getValidator(Object val, String displayName, boolean nullable) {
        if (val instanceof String) return new StringValidator((String) val, displayName, nullable);
        if (val instanceof Comparable) return new ComparableValidator((Comparable<?>) val, displayName, nullable);
        if (val instanceof List) return new ListValidator((List<?>) val, displayName, nullable);
        if (val.getClass().isArray())
            return new ListValidator((List<?>) JsonUtil.toListOrNull(val), displayName, nullable);
        if (val instanceof Map) return new MapValidator((Map<?, ?>) val, displayName, nullable);
        return new Validator(val, displayName, nullable);
    }

    private boolean isNullableAndNull(boolean nullable, Object dataObject, String displayName) {
        // if not nullable and value is null, throw cannot be null exception, no further validations possible
        if (!nullable && dataObject == null) throw new MsValidationException(displayName + " cannot be null.");

        return nullable && dataObject == null; // nothing to validate, pass all
    }

    private void performDefaultStrValidations(Object dataObject, String displayName, DataValidations dv) {
        if (!(dataObject instanceof String)/* instanceof returns false on null */
            || dv.isIgnoreDefValidations()) return;
        new StringValidator((String) dataObject, displayName).validate(StringValidator::isMaxLength,
            DEFAULT_STR_MAX_LENGTH);
    }

    private List<DataValidations> appendFieldMetaJson(List<DataValidations> dataValidationsList, DataValidations dv) {
        List<DataValidations> newDataValidationsList = new ArrayList<>(dataValidationsList);
        newDataValidationsList.add(dv);
        return newDataValidationsList;
    }

    private List<DataValidations> appendFieldMetaJson(List<DataValidations> dataValidationsList, Field field) {
        DataValidations dv = JsonUtil.readValue(ofNullable(field).map(f -> f.getAnnotation(FieldMetaJson.class))
            .filter(Objects::nonNull).map(FieldMetaJson::value).orElse(JsonUtil.EMPTY_JSON), DataValidations.class);
        dv.setFieldName(ofNullable(field).map(Field::getName).orElse(REF_PARENT));
        return appendFieldMetaJson(dataValidationsList, dv);
    }

    /**
     * queues validations configured via childValidations array
     */
    private void queueChildValidations(ValidationItem vi) {
        if (exitProcessing) return;

        DataValidations viDV = vi.getDataValidations().get(vi.getDataValidations().size() - 1);

        // handle child validations
        ofNullable(viDV.getChildDataValidations()).ifPresent(cdv -> cdv.stream().forEach(dv -> {
            if (dv.getChildPath() == null || dv.getChildPath().isEmpty())
                throw new MsValidationException("Child validations require non empty childPath value.");
            String[] fields = dv.getChildPath().split("\\.");
            Object childDataObject = vi.getDataObject();
            for (int i = 0, n = fields.length; i < n && childDataObject != null; i++)
                childDataObject = ReflectUtil.getFieldValue(childDataObject, fields[i]);
            validationItemQ.add(new ValidationItem(childDataObject, appendFieldMetaJson(vi.getDataValidations(), dv)));
        }));
    }

    private boolean isDefaultValidatableObject(Object o) {
        // primitives like byte, int, float will not need any default validations
        return o instanceof String || !BeanUtils.isSimpleValueType(o.getClass());
    }

    /**
     * queues validations configured of the dataObject fields
     */
    private void queueFieldValidations(ValidationItem vi) {
        if (exitProcessing) return;

        DataValidations viDV = vi.getDataValidations().get(vi.getDataValidations().size() - 1);

        final List<?> objectList = (List<?>) JsonUtil.toListOrNull(vi.dataObject);
        if (objectList != null) {
            DataValidations listElementDV = viDV.getListElementDataValidations();
            if (listElementDV != null) {
                // apply element validations configured on the list/array on each
                StreamSupport.stream(IntStream.range(0, objectList.size()).spliterator(), USE_PARALLEL_STREAMS)
                    .forEach(i -> validationItemQ.add(new ValidationItem(objectList.get(i),
                        appendFieldMetaJson(vi.getDataValidations(), listElementDV.toBuilder().valIndex(i).build()))));
            } else {
                // do queue strings and other objects for default validations
                StreamSupport.stream(IntStream.range(0, objectList.size()).spliterator(), USE_PARALLEL_STREAMS)
                    .filter(i -> isDefaultValidatableObject(objectList.get(i)))
                    .forEach(i -> validationItemQ
                        .add(new ValidationItem(objectList.get(i), appendFieldMetaJson(vi.getDataValidations(),
                            new DataValidations().toBuilder().valIndex(i).build()))));
            }
        } else if (vi.dataObject instanceof Map) { // this applies for non json data objects
            DataValidations mapElementDV = viDV.getMapElementDataValidations();
            if (mapElementDV != null) {
                // apply element validations configured on the map for each value
                StreamSupport.stream(((Map<?, ?>) vi.dataObject).entrySet().spliterator(), USE_PARALLEL_STREAMS)
                    .forEach(e -> validationItemQ
                        .add(new ValidationItem(e.getValue(), appendFieldMetaJson(vi.getDataValidations(),
                            mapElementDV.toBuilder().valKey(e.getKey()).build()))));
            } else {
                // do queue strings and other objects for default validations, values
                StreamSupport.stream(((Map<?, ?>) vi.dataObject).entrySet().spliterator(), USE_PARALLEL_STREAMS)
                    .filter(e -> isDefaultValidatableObject(e.getValue()))
                    .forEach(e -> validationItemQ
                        .add(new ValidationItem(e.getValue(), appendFieldMetaJson(vi.getDataValidations(),
                            new DataValidations().toBuilder().valKey(e.getKey()).build()))));
            }

            // do queue strings and other objects for default validations, keys
            StreamSupport.stream(((Map<?, ?>) vi.dataObject).entrySet().spliterator(), USE_PARALLEL_STREAMS)
                .filter(e -> isDefaultValidatableObject(e.getKey())).forEach(
                    e -> validationItemQ.add(new ValidationItem(e.getKey(), appendFieldMetaJson(vi.getDataValidations(),
                        new DataValidations().toBuilder().valKey(e.getKey()).build()))));
        } else {
            // handle declared field validations
            StreamSupport.stream(ReflectUtil.getAllFields(vi.dataObject.getClass()).spliterator(), USE_PARALLEL_STREAMS)
                .filter(f -> !Modifier.isStatic(f.getModifiers())).filter(f -> !f.getName().equals("this$0"))
                .forEach(f -> validationItemQ
                    .add(new ValidationItem(ReflectUtil.getFieldValueOrDefault(vi.dataObject, f.getName(), null),
                        appendFieldMetaJson(vi.getDataValidations(), f))));
        }

    }

    /**
     * validates data object fields iteratively field based on @FieldMetaJson. displayName $parent will use parents
     * displayName.
     * 
     * @param dataObject data object value to run validations on
     * @param metaDocs   field json meta docs, validates with last object
     */
    private void validateWithMetaJson(ValidationItem vi) {
        if (exitProcessing) return;

        log.debug("{} validateWithMetaJson: {}", incrementValidationCount(), vi);

        DataValidations viDV = vi.getDataValidations().get(vi.getDataValidations().size() - 1);

        final String displayName = vi.getDisplayName();

        // !!! for strings, if ignore default validations is not set, execute default str validations !!!
        performDefaultStrValidations(vi.dataObject, displayName, viDV);

        // parent ignore validations propagate down
        if (vi.dataValidations.stream().anyMatch(DataValidations::isIgnoreValidations)) return;

        if (isNullableAndNull(viDV.isNullable(), vi.dataObject, displayName)) return;

        // execute validations
        ofNullable(viDV.getValidations())
            .ifPresent(v -> getValidator(vi.dataObject, displayName, viDV.isNullable()).validateAll(v));

        if (BeanUtils.isSimpleValueType(vi.dataObject.getClass())) return;

        queueChildValidations(vi);
        queueFieldValidations(vi);
    }

    public void validateWithMetaJson() {
        while (!exitProcessing && !validationItemQ.isEmpty()) { // process queue until empty
            Queue<ValidationItem> copyq = new ConcurrentLinkedQueue<>(validationItemQ);
            validationItemQ.clear(); // empty queue that will be refilled by field and child validation items
            StreamSupport.stream(copyq.spliterator(), USE_PARALLEL_STREAMS).forEach(vi -> {
                try {
                    if (!exitProcessing) validateWithMetaJson(vi);
                } catch (Exception ex) {
                    exceptionList.add(ex);
                    if (!processAllValidations) { // throw, if process all validations is false
                        exitProcessing = true;
                        MsRuntimeException.wrapThrow(ex);
                    }
                }
            });
        }
    }
}
