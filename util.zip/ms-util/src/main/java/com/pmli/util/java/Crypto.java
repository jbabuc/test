package com.pmli.util.java;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;

/**
 * This class hold the methods of Encryption and Decryption.
 * 
 * @author Hemant
 */
public class Crypto extends MsObject {

    private Crypto() {}

    private static final Logger logger = MsObject.getSL();

    public static String getUrlEncodedSha256Hash(byte[] input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(input);
        byte[] hash = digest.digest();
        return new String(java.util.Base64.getUrlEncoder().encode(hash));
    }

    /**
     * <p>
     * This method is use to encrypt data
     * 
     * @param  plainData
     * @param  secretValue
     * @param  initVector
     * @param  algorithm                          AES
     * @param  providerName                       AES/CBC/PKCSSPADDING
     * @throws NoSuchPaddingException
     * @throws InvalidAlgorithmParameterException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws NoSuchAlgorithmException
     * @throws Exception
     */

    public static String encryptAES(Object plainData, String secretValue, String initVector, String algorithm,
        String providerName) throws NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException,
        IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException {
        logger.debug("Start of encrypt() method, Data to be encrypted : {}", plainData);
        String encryptString = null;
        IvParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(initVector));
        SecretKeySpec skeySpec = new SecretKeySpec(Base64.decodeBase64(secretValue), algorithm);
        Cipher cipher = Cipher.getInstance(providerName);
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
        byte[] encrypted = cipher.doFinal(plainData.toString().getBytes());
        encryptString = Base64.encodeBase64String(encrypted);
        logger.debug("End of encrypt() method, encrypted data : {}", encryptString);
        return encryptString;
    }

    /**
     * <p>
     * This method is used for decrypt data into original data
     * 
     * @param  encrypted
     * @param  secretValue  value that is used to encrypt the data
     * @param  initVector   value that is used to encrypt the data
     * @param  algorithm    AES
     * @param  providerName AES/CBC/PKCSSPADDING
     * @return              original string
     * @throws Exception
     */
    public static String decryptAES(String encrypted, String secretValue, String initVector, String algorithm,
        String providerName) throws NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException,
        IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException {
        logger.debug("Start of decrypt() method, Data to be decrypted :- {}", encrypted);
        String decryptedString = null;
        IvParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(initVector));
        SecretKeySpec skeySpec = new SecretKeySpec(Base64.decodeBase64(secretValue), algorithm);
        Cipher cipher = Cipher.getInstance(providerName);
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
        byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
        decryptedString = new String(original);
        logger.debug("End of decrypt() method, decrypted data :- {}", decryptedString);
        return decryptedString;
    }
}
