package com.pmli.util.java;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;

import lombok.Getter;

public class ThreadUtil extends MsObject {
    private static final Logger LOGGER = MsObject.getSL();

    public static void runParallel(int nthreads, int niterations, UnaryOperator<Void> f) {
        final AtomicInteger totalIterations = new AtomicInteger();
        Optional.of(System.currentTimeMillis()).ifPresent(start -> {
            List<Thread> threads = IntStream.range(0, nthreads).mapToObj(iThread -> new Thread(() -> {
                LOGGER.info("Thread started, {}", Thread.currentThread().getName());
                IntStream.range(0, niterations).forEach(iIteration -> {
                    f.apply(null);
                    totalIterations.incrementAndGet();
                });
                LOGGER.info("Thread complete, {}.", Thread.currentThread().getName());
            }, "Thread-" + iThread)).map(t -> (Thread) t).collect(Collectors.toList());
            threads.forEach(Thread::start);
            threads.forEach(t -> {
                try {
                    t.join();
                } catch (Exception ex) {
                    // ignore errors
                }
            });
            LOGGER.info(String.format("All threads completed in %d seconds, %d iterations.",
                (System.currentTimeMillis() - start) / 1000, totalIterations.get()));
        });
    }

    @Getter
    public static class HttpServer implements Runnable {
        public static final String LOCAL_HOST        = "localhost";
        public static final String LOCAL_HOST_URL    = "http://" + LOCAL_HOST;
        public static final String LOCAL_HOST_IP     = "127.0.0.1";
        public static final String LOCAL_HOST_IP_URL = "http://" + LOCAL_HOST_IP;

        ServerSocket             serverSocket;
        List<Socket>             sockets = new ArrayList<>();
        Function<String, byte[]> responseFunc;
        String                   url;
        int                      maxRequestBytes;

        public HttpServer(int maxRequestBytes, Function<String, byte[]> responseFunc) throws IOException {
            this.responseFunc = responseFunc;
            this.maxRequestBytes = maxRequestBytes;
            serverSocket = new ServerSocket(0);
            url = LOCAL_HOST_IP_URL + ":" + serverSocket.getLocalPort();
            new Thread(this).start();
        }

        public void shutdown() throws IOException {
            sockets.stream().forEach(s -> {
                try {
                    if (s.isConnected() || s.isBound()) { s.getInputStream().close(); s.close(); }
                } catch (IOException ex) {
                    LOGGER.error(ex.getMessage());
                }
            });
            if (serverSocket.isBound()) serverSocket.close();
        }

        public void run() {
            try {
                while (serverSocket.isBound()) {
                    Socket s = serverSocket.accept();
                    sockets.add(s);
                    new Thread(() -> {
                        try {
                            InputStream in = s.getInputStream();
                            while (s.isConnected()) {
                                byte[] b = new byte[maxRequestBytes];
                                int nread = in.read(b);
                                s.getOutputStream().write(responseFunc.apply(new String(b, 0, nread)));
                                s.getOutputStream().flush();
                            }
                        } catch (Exception ex) {
                            LOGGER.error(ex.getMessage());
                        }
                        LOGGER.info("Socket exiting");
                    }).start();
                }
                LOGGER.info("Server Socket exiting");
                shutdown();
            } catch (Exception ex) {
                LOGGER.error(ex.getMessage());
            }
            LOGGER.info("Http server exiting");
        }
    }
}
