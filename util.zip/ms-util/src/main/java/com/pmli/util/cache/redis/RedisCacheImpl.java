package com.pmli.util.cache.redis;

import java.time.LocalTime;
import java.util.function.Function;
import com.pmli.util.spring.ContextWrapper;

import org.springframework.core.env.Environment;
import org.springframework.util.SerializationUtils;

import com.pmli.util.cache.MsCache;
import com.pmli.util.cache.MsCacheIntervalCalculator;
import com.pmli.util.java.MsObject;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;

public class RedisCacheImpl extends MsObject implements MsCache {

    private RedisClient redisClient = null;

    public RedisCacheImpl() {
        Environment env = ContextWrapper.getAppEnv();
        log.info("Created Instance of redis cache");
        String hostname = env.getProperty("com.pmli.redis.host");
        String password = env.getProperty("com.pmli.redis.password");
        int port = Integer.parseInt(env.getProperty("com.pmli.redis.port"));

        if (password == null || password.isEmpty()) {
            redisClient = RedisClient.create(RedisURI.Builder.redis(hostname, port).build());
        } else {
            redisClient = RedisClient
                .create(RedisURI.Builder.redis(hostname, port).withPassword(password.toCharArray()).build());
        }
    }

    /**
     * This method returns objcet cache in redis
     * 
     * @param key:           String
     * @param f:             Function
     * @param rInterval:     RefreshInterval
     * @param deleteCurrent: boolean
     * 
     */
    @SuppressWarnings("unchecked")
    @Override
    public <R> R get(String key, Function<String, R> funcToFetchFromSource, ExpireAtTime expireAtTime,
        GetOptions getOptions) {
        StatefulRedisConnection<String, byte[]> connection = null;
        try {
            try {
                connection = redisClient
                    .connect(ContextWrapper.getContext().getBean("serializedObjectCodec", SerializedObjectCodec.class));
            } catch (Exception ex) {
                return getFunctionValue(key, funcToFetchFromSource);
            }

            if (getOptions.equals(GetOptions.DELETE_CURRENT)) {
                connection.async().del(key);
            } else {
                try {
                    byte[] data = connection.async().get(key).get();
                    if (data != null) { return (R) SerializationUtils.deserialize(data); }
                } catch (Exception e) {
                    // Ignore Exception,try to get data from source
                }
            }

            R r = getFunctionValue(key, funcToFetchFromSource);
            if (r != null) {
                try {
                    connection.async().setex(key,
                        new MsCacheIntervalCalculator(LocalTime.now()).getSecondsToExpiration(expireAtTime),
                        SerializationUtils.serialize(r));
                } catch (Exception e) {
                    // Ignore Exception, Failed to cache
                }
            }
            return r;
        } finally {
            if (connection != null) { connection.close(); }
        }
    }

    private <R> R getFunctionValue(String key, Function<String, R> f) {
        if (f == null) {
            return null;
        } else {
            return f.apply(key);
        }
    }
}
