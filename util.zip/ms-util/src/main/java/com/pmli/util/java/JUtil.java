package com.pmli.util.java;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;
import java.util.function.Supplier;

import org.slf4j.Logger;

import ch.qos.logback.classic.Level;

public class JUtil {
    private static final Logger LOGGER = MsObject.getSL();

    private JUtil() {}

    public static String getHostNameOrDefault(String def) {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return def;
        }
    }

    public static String getSystemPropertyOrDefault(String name, String defaultVal) {
        return getOrDefault(() -> System.getProperty(name), defaultVal);
    }

    public static void setLogLevel(Class<?> c, Level level) {
        ((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(c)).setLevel(level);
    }

    /**
     * Helper class to chain and add elements to Map.
     * 
     * @author     3495987jan
     * @param  <K>
     * @param  <V>
     */
    @SuppressWarnings("serial")
    public static class MsMap<K, V> extends HashMap<K, V> {
        public MsMap<K, V> add(K k, V v) { super.put(k, v); return this; }
    }

    /**
     * Helper function to execute supplier and return its result or return default value if an exception is encountered.
     * If supplier returns null, null will be returned.
     * 
     * @param  <T>
     * @param  supplier
     * @param  defaultValue
     * @return              function return value or defaultValue
     */
    public static <T> T getOrDefault(Supplier<T> supplier, T defaultValue) {
        try {
            return supplier.get();
        } catch (Exception ex) {
            LOGGER.trace("Supplier exception in JUtil.getOrDefault(): ", ex);
            return defaultValue;
        }
    }

    public static void safeDelete(File f) {
        try {
            Files.delete(f.toPath());
        } catch (IOException e) {
            // ignore
        }
    }

    /**
     * @param  dateFormat
     * @return            current date
     */
    public static String getCurrentDateTime(String dateFormat) {
        ZonedDateTime current = ZonedDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateFormat);
        return current.format(format);
    }

    /**
     * This method is use get date object for respective format
     * 
     * @param  dateFormat
     * @return                current date
     * @throws ParseException
     */
    public static Date getDate(String dateFormat, String date) throws ParseException {
        return new SimpleDateFormat(dateFormat).parse(date);
    }

    public static String getTmpDirNew(boolean deleteOnExit) {
        String fname = System.getProperty("java.io.tmpdir") + File.separator + UUID.randomUUID();
        File f = new File(fname);
        f.mkdirs();
        if (deleteOnExit) f.deleteOnExit();
        return fname;
    }

    /**
     * @param  date
     * @param  expectedDateTimeFormat
     * @return
     */
    public static String getFormattedDateTime(Date date, String expectedDateTimeFormat) {
        DateFormat dateFormatTemp = new SimpleDateFormat(expectedDateTimeFormat);
        return dateFormatTemp.format(date);
    }

    public static String generateRandomNumber(int len) {
        SecureRandom sr = new SecureRandom();
        String result = "";
        try {
            result = (sr.nextInt(9) + 1) + "";
            for (int i = 0; i < len - 2; i++) result += sr.nextInt(10);
            result += (sr.nextInt(9) + 1);
        } catch (Exception exp) {
            exp.getMessage();
        }
        return result;
    }
}
