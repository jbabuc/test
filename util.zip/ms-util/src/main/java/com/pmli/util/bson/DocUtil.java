package com.pmli.util.bson;

import static java.util.Optional.ofNullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.bson.Document;
import org.slf4j.Logger;

import com.mongodb.lang.NonNull;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;

/**
 * Helper function to fetch and update values using json dot notation.</br>
 * </br>
 * Example: </br>
 * <code>
  {'name':'John','age':30,'male':true,'spouse':null,'cars':['Ford','BMW','Fiat'],
  'addresses':[{'hno':123,'street':'main','city':'ny','state':'ny'},{'hno':234,'street':'22st','city':'philly','state':'pa'}],
  'contacts':{'phone':{'home':'1234','office':'5678'},'post':null,'friends':['',null],'parents':null}}
  </code> </br>
 * get(doc, "address[1].street"); // Throws MsException if field or index is not found. </br>
 * </br>
 * Use getOrDefault function to avoid exceptions. </br>
 * </br>
 * put updates the doc, adds missing elements. </br>
 * </br>
 * put(doc, "name.first", "John"); // on an empty doc, adds name element, adds first element under name and updates
 * value of first to John. </br>
 * </br>
 * put(doc, "name.friends[3]", "John"); // on an empty doc, adds name element, adds friends element array, inserts nulls
 * at indexes 0,1,2 and adds John at index 3.
 * 
 * @author 3495987jan
 */
@SuppressWarnings("unchecked")
public class DocUtil {

    private DocUtil() {}

    private static final String ERR_ELEMENT_NOT_FOUND  = "Element not found: ";
    private static final String ERR_INDEX_OUT_OF_BOUND = "Index out of bounds: ";
    private static final String ERR_NULL_VALUE         = "Null value: ";
    private static final Logger LOGGER                 = MsObject.getSL();

    /**
     * token is an element name. includes index if array.
     */
    private static class Token {
        String key;
        String strIndex;
        int    index;

        public Token(String t) {
            String[] subTokens = t.split("\\[");
            key = subTokens[0];
            if (subTokens.length > 1) {
                strIndex = subTokens[1].replace(']', ' ').trim();
                if (!strIndex.isEmpty()) index = Integer.parseInt(strIndex);
            }
        }

        boolean isArray() { return strIndex != null; }
    }

    /**
     * return element based of the document, else throw @MsValidationException
     * 
     * @param  doc
     * @param  token
     * @return       element value
     */
    private static <T> T getElement(Document doc, String token, @NonNull Class<T> clazz) {
        Token t = new Token(token);

        // if element is not found throw exception
        if (!doc.containsKey(t.key)) throw new MsValidationException(ERR_ELEMENT_NOT_FOUND + t.key);

        // if not an array return value
        if (!t.isArray()) return doc.get(t.key, clazz);

        // handle array
        List<T> list = doc.getList(t.key, clazz);
        if (list != null && list.size() > t.index) return list.get(t.index);
        if (list != null) throw new MsValidationException(ERR_INDEX_OUT_OF_BOUND + t.key + "[" + t.index + "]");
        throw new MsValidationException(ERR_NULL_VALUE + t.key);
    }

    /**
     * find element in the document specified in dotPath notation, cast and return its value.
     * 
     * @param  <T>
     * @param  dotPath element path in dot notation
     * @param  clazz   return type
     * @return         element value
     */
    public static <T> T get(@NonNull Document doc, @NonNull String dotPath, @NonNull Class<T> clazz) {
        LOGGER.trace("get In {} --> {}", dotPath, doc);
        List<String> tokens = Arrays.asList(dotPath.split("\\.")).stream().filter(t -> !t.isEmpty())
            .collect(Collectors.toList());
        String lastToken = tokens.remove(tokens.size() - 1);
        for (String token : tokens) {
            doc = getElement(doc, token, Document.class);
            LOGGER.trace("getElement out {} <-- {}", token, doc);
        }

        return getElement(doc, lastToken, clazz);
    }

    public static Object get(@NonNull Document doc, @NonNull String dotPath) { return get(doc, dotPath, Object.class); }

    public static <T> T getOrDefault(@NonNull Document doc, @NonNull String dotPath, @NonNull Class<T> clazz, T dv) {
        return JUtil.getOrDefault(() -> get(doc, dotPath, clazz), dv);
    }

    public static Object getOrDefault(@NonNull Document doc, @NonNull String dotPath, Object dv) {
        return JUtil.getOrDefault(() -> get(doc, dotPath), dv);
    }

    public static Object getNonNullOrDefault(@NonNull Document doc, @NonNull String dotPath, Object dv) {
        return JUtil.getOrDefault(() -> ofNullable(get(doc, dotPath)).orElse(dv), dv);
    }

    public static boolean contains(@NonNull Document doc, @NonNull String dotPath) {
        return JUtil.getOrDefault(() -> { get(doc, dotPath); return true; }, false);
    }

    public static boolean containsAndNotNull(@NonNull Document doc, @NonNull String dotPath) {
        return JUtil.getOrDefault(() -> get(doc, dotPath) != null, false);
    }

    public static boolean containsAndIsNull(@NonNull Document doc, @NonNull String dotPath) {
        return JUtil.getOrDefault(() -> get(doc, dotPath) == null, false);
    }

    /**
     * if element is present return, else update element with new and return. fills missing array elements with null.
     * 
     * @param  doc   document
     * @param  token element name, include index for arrays
     * @return       updated value at the token
     */
    private static Object getOrNew(Document doc, String token) {
        LOGGER.trace("exGetOrNew In {} --> {}", token, doc);

        Token t = new Token(token);
        Object o;

        if (!t.isArray()) {
            // use existing or new
            doc.put(t.key, ofNullable(doc.get(t.key)).orElse(new Document()));
            o = doc.get(t.key);
        } else {
            // use existing or new
            List<?> list = ofNullable((List<?>) doc.get(t.key)).orElse(new ArrayList<>());
            doc.put(t.key, list); // re-add list, for it may be new

            if (!t.strIndex.isEmpty()) { // fill if index is not empty
                ofNullable(list.size() <= t.index ? list : null)
                    .ifPresent(l -> IntStream.range(l.size(), t.index + 1).forEach(e -> l.add(null)));
                if (list.get(t.index) == null) ((List<Object>) list).set(t.index, new Document());

                o = ((List<?>) doc.get(t.key)).get(t.index); // return element at index
            } else {
                o = list; // return list for empty index
            }
        }

        LOGGER.trace("exGetOrNew Out {} {} <-- {}", o, token, doc);
        return o;
    }

    /**
     * If element is present update, else create any missing elements and update leaf. fill missing array elements with
     * nulls if auto create is true.
     * 
     * @param  docIn      document
     * @param  dotPath    path of the element to update
     * @param  val        value to update to
     * @param  autoCreate true, creates missing elements and fills missing array elements
     * @return            docIn, document that is sent in
     */
    public static Document put(@NonNull Document docIn, @NonNull String dotPath, Object val, boolean autoCreate) {
        Document doc = docIn;
        List<String> tokens = Arrays.asList(dotPath.split("\\.")).stream().collect(Collectors.toList());
        String lastToken = tokens.remove(tokens.size() - 1);

        if (autoCreate) for (String token : tokens) doc = (Document) getOrNew(doc, token);
        else if (!tokens.isEmpty()) doc = get(doc, tokens.stream().collect(Collectors.joining(".")), Document.class);

        Token t = new Token(lastToken);
        if (!t.isArray()) {
            doc.put(t.key, val);
        } else {
            if (autoCreate) getOrNew(doc, lastToken);

            if (!t.strIndex.isEmpty()) ((List<Object>) doc.get(t.key)).set(t.index, val);
            else((List<Object>) doc.get(t.key)).add(val); // append
        }

        return docIn;
    }

    public static Document put(@NonNull Document docIn, @NonNull String dotPath, Object val) {
        return put(docIn, dotPath, val, false);
    }

    public static Document putAll(@NonNull Document docIn, Map<String, ?> dotPathValMap, boolean autoCreate) {
        dotPathValMap.forEach((k, v) -> put(docIn, k, v, autoCreate));
        return docIn;
    }

    /**
     * Document Put Wrapper
     */
    public static class DocPW {
        private Document doc;

        public DocPW(Document doc) { this.doc = doc; }

        public Document doc() { return doc; }

        public DocPW put(@NonNull String dotPath, Object val) { DocUtil.put(doc, dotPath, val, true); return this; }
    }
}
