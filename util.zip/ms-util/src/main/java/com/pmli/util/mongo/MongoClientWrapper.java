package com.pmli.util.mongo;

import java.util.List;
import java.util.Map;
import static java.util.Optional.ofNullable;
import static java.util.Optional.of;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.Arrays;
import java.util.HashMap;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.internal.build.MongoDriverVersion;
import com.pmli.util.java.MsObject;

/**
 * Wrapper class over MongoClient. Maintains MongoClient map with URI key. <br/>
 * Maintains MongoClient database and collection maps. Basic wrapper methods to perform CRUD operations.
 * 
 * @author 3495987jan
 */
public class MongoClientWrapper extends MsObject {
    public static final String QUERY_ALL      = "{}";
    public static final String FIELD_MONGO_ID = "_id";

    public static final String DF_UTC                        = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String DVAR_DEFAULT_MONGO_CLIENT_URI = "DEFAULT_MONGO_CLIENT_URI";

    private static final Map<String, MongoClientWrapper> MCW_MAP = new HashMap<>();

    private MongoClientURI                         uri;
    private MongoClient                            client;
    private Map<String, MongoDatabase>             databases   = new HashMap<>();
    private Map<String, MongoCollection<Document>> collections = new HashMap<>();

    private MongoClientWrapper(String suri) {
        log.info("Connecting to {}.", suri);
        uri = new MongoClientURI(suri);
        this.client = ofNullable(client).orElse(new MongoClient(uri));
        log.info("Using driver version {}, connected to {}", MongoDriverVersion.VERSION, uri);
    }

    public static synchronized MongoClientWrapper getMCW(String mcuri) {
        return ofNullable(MCW_MAP.get(mcuri)).orElseGet(
            () -> of(new MongoClientWrapper(mcuri)).map(w -> { MCW_MAP.put(mcuri, w); return w; }).orElse(null));
    }

    public void ping() {
        // ping to check connection is live
        this.client.getDatabase(this.uri.getDatabase()).runCommand(Document.parse("{ping:1}"));
    }

    /**
     * @return MongoClientWrapper using system property,
     *         -DDEFAULT_MONGO_CLIENT_URI=mongodb://user:password@localhost:27017/admin?options
     */
    public static MongoClientWrapper getMCW() { return getMCW(System.getProperty(DVAR_DEFAULT_MONGO_CLIENT_URI)); }

    public MongoClientURI getURI() { return uri; }

    public MongoClient getClient() { return client; }

    /**
     * removes wrapper from the map and closes the MongoClient.
     */
    public void close() { MCW_MAP.values().removeIf(v -> v.equals(this)); client.close(); }

    public synchronized MongoDatabase getDatabase(String dbname) {
        return ofNullable(databases.get(dbname)).orElse(ofNullable(client.getDatabase(dbname)).map(d -> {
            databases.put(dbname, d);
            return d;
        }).orElse(null));
    }

    public synchronized MongoCollection<Document> getCollection(String dbname, String collname) {
        return ofNullable(collections.get(dbname + "-" + collname))
            .orElse(ofNullable(getDatabase(dbname).getCollection(collname))
                .map(c -> { collections.put(dbname + "-" + collname, c); return c; }).orElse(null));
    }

    public List<Document> getDocuments(String dbname, String collname, Document filter, Document projection,
        Document sort, int skip, int limit) {
        log.debug("Collection: {}, Filter: {}, Projection: {}, Sort: {}, Skip: {}, Limit: {}", collname, filter,
            projection, sort, skip, limit);

        FindIterable<Document> docs = getCollection(dbname, collname).find(filter);
        if (projection != null) docs.projection(projection);
        if (sort != null) docs.sort(sort);
        if (skip > 0) docs.skip(skip);
        if (limit > 0) docs.limit(limit);

        List<Document> results = StreamSupport.stream(docs.spliterator(), false).collect(Collectors.toList());

        log.trace("Results: {}", results);
        return results;
    }

    public List<Document> getAggregatedDocument(String dbname, String collname, List<Document> aggregationFilter) {
        return StreamSupport.stream(getCollection(dbname, collname).aggregate(aggregationFilter).spliterator(), false)
            .collect(Collectors.toList());
    }

    /**
     * Get documents with appropriate settings applied.
     * 
     * @param  dbname   MongoDB database name.
     * @param  collname MongoDB collection name.
     * @param  filter   MongoDB filter query.
     * @param  fields   For default use null. Appends id field if list is not empty and id not already listed.
     * @param  sort     For descend-sort prefix field with -. Appends id field if not already listed . null sorts by id.
     * @param  skip     For default use -1
     * @param  limit    For default use -1
     * @return          List of Document objects
     */
    public List<Document> getDocuments(String dbname, String collname, Document filter, List<String> fields,
        List<String> sort, int skip, int limit) {
        // if asked for specific field projection and id is not specified, add it
        Document dprojection = ofNullable(fields)
            .map(flds -> of(new Document(fields.stream().collect(Collectors.toMap(String::toString, f -> 1))))
                .map(d -> flds.contains(FIELD_MONGO_ID) ? d : d.append(FIELD_MONGO_ID, 1)).orElse(null))
            .orElse(null);

        Document dsort = of(new Document()).map(d -> {
            ofNullable(sort).ifPresent(
                s -> s.forEach(f -> d.append(f.startsWith("-") ? f.substring(1) : f, f.startsWith("-") ? -1 : 1)));
            return d.append(FIELD_MONGO_ID, d.getOrDefault(FIELD_MONGO_ID, 1));
        }).orElse(null);

        return getDocuments(dbname, collname, filter, dprojection, dsort, skip, limit);
    }

    public List<Document> getDocuments(String dbname, String collname, String filter, List<String> fields,
        List<String> sort, int skip, int limit) {
        return getDocuments(dbname, collname, Document.parse(filter), fields, sort, skip, limit);
    }

    public List<Document> getDocuments(String dbname, String collname, String filter, List<String> fields,
        List<String> sort) {
        return getDocuments(dbname, collname, filter, fields, sort, -1, -1);
    }

    public List<Document> getDocuments(String dbname, String collname, String filter) {
        return getDocuments(dbname, collname, filter, null, null);
    }

    public Document getDocumentById(String dbname, String collname, String filter, Document defaultValue) {
        return getDocuments(dbname, collname, filter).stream().findFirst().orElse(defaultValue);
    }

    public List<String> getIds(String dbname, String collname, String filter) {
        return getDocuments(dbname, collname, filter, Arrays.asList(FIELD_MONGO_ID), null).stream()
            .map(d -> "" + d.get(FIELD_MONGO_ID)).collect(Collectors.toList());
    }

    public Map<String, String> getIdValueMap(String dbname, String collname, String filter, String idfield,
        String valfield) {
        return getDocuments(dbname, collname, filter, Arrays.asList(idfield, valfield), null).stream()
            .collect(Collectors.toMap(d -> "" + d.get(idfield), d -> "" + d.get(valfield)));
    }

    public Map<String, Document> getIdDocMap(String dbname, String collname, String filter, String idfield,
        List<String> fields, List<String> sort) {
        return getDocuments(dbname, collname, filter, fields, sort).stream()
            .collect(Collectors.toMap(d -> "" + d.get(idfield), d -> d));
    }

    public Map<String, Document> getIdDocMap(String dbname, String collname, String filter) {
        return getIdDocMap(dbname, collname, filter, FIELD_MONGO_ID, null, null);
    }

    public void insertOne(String dbname, String collname, Document doc) {
        getCollection(dbname, collname).insertOne(doc);
    }

    public void insertOne(String dbname, String collname, String doc) {
        insertOne(dbname, collname, Document.parse(doc));
    }

    public long updateMany(String dbname, String collname, Document filter, Document update, UpdateOptions uopts) {
        return getCollection(dbname, collname).updateMany(filter, update, uopts).getModifiedCount();
    }

    public long updateMany(String dbname, String collname, String filter, String update, boolean upsert) {
        return updateMany(dbname, collname, Document.parse(filter), Document.parse(update),
            new UpdateOptions().upsert(upsert));
    }

    public long deleteMany(String dbname, String collname, Document filter) {
        return getCollection(dbname, collname).deleteMany(filter).getDeletedCount();
    }

    public long deleteMany(String dbname, String collname, String filter) {
        return deleteMany(dbname, collname, Document.parse(filter));
    }

    public long getCount(String dbname, String collname, Document filter) {
        return getCollection(dbname, collname).countDocuments(filter);
    }

    public long getCount(String dbname, String collname, String filter) {
        return getCount(dbname, collname, Document.parse(filter));
    }
}
