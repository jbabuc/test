package com.pmli.util.java;

import static java.util.Optional.ofNullable;

/**
 * Created this class as per sonar code scan suggestion to use custom exception in place of RuntimeException
 * 
 * @author 3495987jan
 */
public class MsRuntimeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public MsRuntimeException(String msg) { super(msg); }

    public MsRuntimeException(String msg, Throwable t) { super(msg, t); }

    public MsRuntimeException(Throwable t) {
        this(ofNullable(getMsException(t)).map(Throwable::getMessage).orElse("Unknown exception")/* use ms message */,
            t);
    }

    private static Throwable getMsException(Throwable t) {
        for (Throwable c = t; c != null; c = c.getCause()) if (c instanceof MsValidationException) return c;
        for (Throwable c = t; c != null; c = c.getCause()) if (c instanceof MsRuntimeException) return c;
        return t;
    }

    public static RuntimeException wrap(Throwable t) {
        // parallel streams are recreating thrown exception, so use the ms message if available
        Throwable ms = getMsException(t);
        if (ms instanceof MsValidationException) return new MsValidationException(ms.getMessage(), t);
        if (ms instanceof MsRuntimeException) return new MsRuntimeException(ms.getMessage(), t);

        if (t instanceof RuntimeException) return (RuntimeException) t;

        return new MsRuntimeException(t);
    }

    public static void wrapThrow(Throwable t) {
        throw ofNullable(wrap(t)).orElseGet(() -> new RuntimeException("Null wrap exception."));
    }
}
