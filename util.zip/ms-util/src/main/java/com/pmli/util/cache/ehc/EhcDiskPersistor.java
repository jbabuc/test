package com.pmli.util.cache.ehc;

import static java.util.Optional.of;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.util.SerializationUtils;

import com.pmli.util.java.Crypto;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

public class EhcDiskPersistor extends MsObject implements EhcPersistance {
    private final Ehcache ehcache;

    private final String  diskLocation;
    private final String  cachePrefix;
    private final boolean loadFromDiskOnInit;
    private final long    cleanupAfterExpireMillis;

    public EhcDiskPersistor(Ehcache ehcache, String diskLocation, String cachePrefix, boolean loadFromDiskOnInit,
        long cleanupAfterExpireMillis) {
        this.ehcache = ehcache;
        this.diskLocation = diskLocation;
        new File(this.diskLocation).mkdirs();
        this.cachePrefix = cachePrefix;
        this.cleanupAfterExpireMillis = cleanupAfterExpireMillis;
        this.loadFromDiskOnInit = loadFromDiskOnInit;
        if (this.loadFromDiskOnInit) loadElements();
        new Thread(this::cleanUp).start();

        log.info("Ehcache is in play. In memory. loadFromDisk={}, cachePrefix={}, diskLocation={} ",
            this.loadFromDiskOnInit, this.cachePrefix, this.diskLocation);
    }

    private Path getKeyDiskPath(String key, String prefix) {
        try {
            return Paths.get(diskLocation + "/" + (prefix != null ? prefix : cachePrefix)
                + Crypto.getUrlEncodedSha256Hash(key.getBytes()));
        } catch (NoSuchAlgorithmException e) {
            // this must not happen, as SHA256 is available with java out of the box
            throw MsRuntimeException.wrap(e);
        }
    }

    @Override
    public void storeElement(Element e) {
        of(getKeyDiskPath(e.getObjectKey().toString(), null)).ifPresent(p -> {
            try {
                Files.write(p, SerializationUtils.serialize(e), StandardOpenOption.WRITE, StandardOpenOption.CREATE);
            } catch (IOException ex) { // do not die, if failed to save
                log.error("Unable to store ehcache to disk: {}, {}", ex.getMessage(), p.toFile().getAbsolutePath());
            }
        });
    }

    @Override
    public void loadElements() {
        AtomicInteger ai = new AtomicInteger();
        for (File f : new File(diskLocation).listFiles((dir, name) -> name.startsWith(cachePrefix))) {
            if (!f.exists() || f.isDirectory()) continue;
            try {
                Element e = (Element) SerializationUtils.deserialize(Files.readAllBytes(f.toPath()));
                if (!e.isExpired()) { ehcache.put(e); ai.addAndGet(1); }
            } catch (IOException ex) {// do not die, if failed to load from disk
                log.error("Unable to process disk cache: {}, {}", ex.getMessage(), f.getAbsolutePath());
            }
        }
        log.info("Ehcache load from disk complete. {}", ai.get());

    }

    @Override
    public Element getElement(String key) {
        return of(getKeyDiskPath(key, null)).filter(p -> p.toFile().exists()).map(p -> {
            try {
                return of(SerializationUtils.deserialize(Files.readAllBytes(p))).orElse(null);
            } catch (IOException ex) { // do not die, if failed to get from disk
                log.error("Unable to get ehcache from disk: {}, {}", ex.getMessage(), p.toFile().getAbsolutePath());
                return null;
            }
        }).filter(Objects::nonNull).map(Element.class::cast).filter(e -> !e.isExpired()).orElse(null);
    }

    @Override
    public void cleanUp() {
        Path p = getKeyDiskPath("lock", "lock-");
        try {
            Files.write(p, "lock".getBytes(), StandardOpenOption.WRITE, StandardOpenOption.CREATE);
            try (RandomAccessFile raf = new RandomAccessFile(p.toFile(), "rw")) {
                FileLock lock = raf.getChannel().tryLock();
                // exit if unable to lock, probably other process acquired lock and processing cleanup
                if (lock == null) return;

                // the process that took the lock will hold it

                for (File f : new File(diskLocation).listFiles((dir, name) -> name.startsWith(cachePrefix))) {
                    if (f.exists() && !f.isDirectory()) checkAndDeleteElementFromDisk(f);
                }
                lock.close();
                log.info("Cache clean up complete.");
            }
        } catch (Exception ex) {
            log.error("Exception on cleanUpDisk: {}, {} ", ex.getMessage(), p.toFile().getAbsolutePath());
        }
    }

    private void checkAndDeleteElementFromDisk(File f) {
        try {
            of((Element) SerializationUtils.deserialize(Files.readAllBytes(f.toPath()))).filter(Element::isExpired)
                .filter(e -> System.currentTimeMillis() > e.getExpirationTime() + cleanupAfterExpireMillis)
                .ifPresent(e -> JUtil.safeDelete(f));
        } catch (Exception ex) {
            JUtil.safeDelete(f); // if failed to process file, force delete it
            log.error("Unable delete disk cache: {}, {}", ex.getMessage(), f.getAbsolutePath());
        }
    }
}
