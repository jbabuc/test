package com.pmli.util.validation;

import java.util.List;

import com.pmli.util.java.MsValidationException;

public class ListValidator extends Validator {
    List<?> lval;

    public ListValidator(List<?> lval, String displayName, boolean nullable) {
        super(lval, displayName, nullable);
        this.lval = lval;
    }

    public ListValidator(List<?> lval, String displayName) { this(lval, displayName, DEFAULT_NULLABILITY); }

    @RegisterForQuickAccess
    public Void isMinLength(Integer length) {
        if (lval.size() >= length) return null;
        throw new MsValidationException(
            String.format("%s=%d, must contain min %d element(s).", getDisplayName(), lval.size(), length));
    }

    @RegisterForQuickAccess
    public Void isMaxLength(Integer length) {
        if (lval.size() <= length) return null;
        throw new MsValidationException(
            String.format("%s=%d, must contain max %d element(s).", getDisplayName(), lval.size(), length));
    }
}
