package com.pmli.util.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.function.Function;

public interface MsCache {

    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    public static @interface CacheForADay {}

    /**
     * Expire at specific time.
     * 
     * @author 3495987jan
     */
    public enum ExpireAtTime {
        AT_HALF_HOUR, AT_HOUR, AT_EVERY_3RD_HOUR, AT_EVERY_4TH_HOUR, AT_EVERY_6TH_HOUR, AT_DAY
    }

    /**
     * DEFAULT get from cache if exists, else fetch from source if function is not null, cache it and return<br/>
     * DELETE_CURRENT delete current, fetch from source if function is not null, cache it and return<br/>
     * ONFAIL_GETLAST for future implementation, return last value when key is expired and source is down
     * 
     * @author 3495987jan
     */
    public enum GetOptions {
        DEFAULT, DELETE_CURRENT, ONFAIL_GETLAST
    }

    /**
     * Get value from cache based on key and return. if value does not exist, run the funcToFetchFromSource if not null,
     * cache the value against key and return. </br>
     * </br>
     * Implementations must return copy of values to avoid over writing cache on return object updates. keys must be
     * unique to avoid over-writing, values must be specific and immediately usable to avoid unwanted serializing and
     * de-serializing. See below example. <br/>
     * </br>
     * The below code caches map, to get value of product 1 you need to fetch whole map and then get value for key 1.
     * this will have an overhead of serializing and de-serializing the whole map on every get. <br/>
     * </br>
     * <code>
     * get("products", (p) -> {"1": "Product 1", "2", "Product 2", "3": "Product 3"}, AT_HOUR, DEFAULT);<br/>
     * </code> </br>
     * The below caches specific values and the value returned is immediately usable. this will only serialize and
     * de-serialize single value specific to product 1.<br/>
     * </br>
     * <code>
     * get("product-1", (p) -> "Product 1", AT_HOUR, DEFAULT);<br/>
     * get("product-2", (p) -> "Product 2", AT_HOUR, DEFAULT);<br/>
     * get("product-3", (p) -> "Product 3", AT_HOUR, DEFAULT);<br/>
     * </code> </br>
     * 
     * @param  key                   key of value in cache
     * @param  funcToFetchFromSource function that takes in key and returns value
     * @param  expireAtTime          {@link expireAtTime}
     * @param  getOptions            {@link GetOptions}
     * @return                       cached value, or value fetched using funcToFetchFromSource, or if
     *                               funcToFetchFromSource is null
     */
    public <R> R get(String key, Function<String, R> funcToFetchFromSource, ExpireAtTime expireAtTime,
        GetOptions getOptions);

}
