package com.pmli.util.db;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BinaryOperator;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import com.pmli.util.spring.ContextWrapper;

/**
 * Wraps DB HibernateSession. Each session is cached in a map based on data source name. <br/>
 * Basic wrapper methods to perform CRUD operations.
 * 
 * @author 3495987jan
 */
public class HibernateSessionWrapper {

    private String         dsName;
    private HikariConfig   config;
    private DataSource     dataSource;
    private SessionFactory sessionFactory;

    private static final Map<String, HibernateSessionWrapper> HSW_MAP = new HashMap<>();

    public HibernateSessionWrapper(String dsName) { this(dsName, ContextWrapper::getAppProperty); }

    public HibernateSessionWrapper(String dsName, Map<String, String> props) { this(dsName, props::getOrDefault); }

    public HibernateSessionWrapper(String dsName, BinaryOperator<String> getOrDefault) {
        this.dsName = dsName;

        config = new HikariConfig();
        config.setPoolName("BuyOnline-" + dsName);
        config.setMaximumPoolSize(Integer.parseInt(getOrDefault.apply(dsName + ".db.maximum.pool.size.conn",
            getOrDefault.apply("db.maximum.pool.size.conn", "5"))));
        config.setMinimumIdle(Integer.parseInt(
            getOrDefault.apply(dsName + ".db.minimum.idle.conn", getOrDefault.apply("db.minimum.idle.conn", "2"))));
        config.setConnectionTimeout(Integer.parseInt(getOrDefault.apply(dsName + ".db.connection.timeout",
            getOrDefault.apply("db.connection.timeout", "100000"))));

        config.setDriverClassName(getOrDefault.apply(dsName + ".db.driver", null));
        config.setJdbcUrl(getOrDefault.apply(dsName + ".db.url", null));
        config.setUsername(getOrDefault.apply(dsName + ".db.username", null));
        config.setPassword(getOrDefault.apply(dsName + ".db.password", null));

        dataSource = new HikariDataSource(config);

        LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
        sessionBuilder.setProperty("hibernate.show_sql",
            getOrDefault.apply(dsName + ".db.hibernate.show_sql", getOrDefault.apply("db.hibernate.show_sql", "true")));
        sessionBuilder.setProperty("hibernate.dialect", getOrDefault.apply(dsName + ".db.hibernate.dialect", null));
        sessionFactory = sessionBuilder.buildSessionFactory();
    }

    /**
     * Return hibernate session wrapper based on the data source name prefix in properties file
     * 
     * @param  dsname
     * @return        HibernateSessionWrapper
     */
    public static HibernateSessionWrapper getHSW(String dsname) {
        return ofNullable(HSW_MAP.get(dsname)).orElseGet(
            () -> of(new HibernateSessionWrapper(dsname)).map(w -> { HSW_MAP.put(dsname, w); return w; }).orElse(null));
    }

    public String getDsName() { return dsName; }

    public HikariConfig getConfig() { return config; }

    public DataSource getDataSource() { return dataSource; }

    public SessionFactory getSessionFactory() { return sessionFactory; }

    /**
     * Executes the query and returns result list
     * 
     * @deprecated
     * @param      query
     * @return           List<Map>
     */
    @Deprecated
    public List<?> getResultsAsMap(String query) {
        Session sess = null;
        try {
            sess = sessionFactory.openSession();
            NativeQuery<?> nq = sess.createNativeQuery(query);
            nq.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
            return nq.getResultList();
        } finally {
            if (sess != null) sess.close();
        }
    }

    /**
     * Executes the query and returns result list
     * 
     * @param  query
     * @return       List<Object[]>
     */
    public List<?> getResults(String query) {
        Session sess = null;
        try {
            sess = sessionFactory.openSession();
            NativeQuery<?> nq = sess.createSQLQuery(query);
            return nq.list();
        } finally {
            if (sess != null) sess.close();
        }
    }

    /**
     * Executes the data update queries
     * 
     * @param  query
     * @return       number of rows affected
     */
    public int executeUpdate(String query) {
        Session sess = null;
        Transaction tx = null;
        try {
            sess = sessionFactory.openSession();
            tx = sess.beginTransaction();
            Query<?> hquery = sess.createSQLQuery(query);
            int ret = hquery.executeUpdate();
            tx.commit();
            return ret;
        } catch (Exception ex) {
            if (tx != null && tx.isActive()) tx.rollback();
            return -1;
        } finally {
            if (sess != null) sess.close();
        }
    }
}
