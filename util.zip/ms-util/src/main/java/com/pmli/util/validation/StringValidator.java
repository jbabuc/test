package com.pmli.util.validation;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.GenericValidator;

import com.pmli.util.java.MsValidationException;

/**
 * Chain validations with validate dynamic method invoker. Accepts validation method pointers or names.
 * 
 * <pre>
 * // compile-time static binding, using method references
 * new StringValidator("abc@metlife.com", "Email field").validate(Validator::notNull)
 *     .validate(StringValidator::notBlank).validate(StringValidator::isEmail)
 *     .validate(StringValidator::isMaxLength, 30);
 * new StringValidator("2020/9/13", "Date of Birth").validate(Validator::notNull).validate(StringValidator::notBlank)
 *     .validate(StringValidator::isDate, "yyyy/mm/dd", false);
 * assertThat(assertThrows(MsValidationException.class, () -> {
 *     new StringValidator("2020/9/13", "Date of Birth").validate(Validator::notNull)
 *         .validate(StringValidator::notBlank).validate(StringValidator::isDate, "yyyy/mm/dd", true);
 * }).getMessage()).isIn("Date of Birth=\"2020/9/13\", has invalid date format, expected format, yyyy/mm/dd.");
 * 
 * // run-time dynamic binding using method names, fails at runtime if method names or parameters does not match
 * new StringValidator("abc@metlife.com", "Email field").validate("notNull").validate("notBlank").validate("isEmail")
 *     .validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 10).validate("endsWith", ".com");
 * assertThrows(MsValidationException.class, () -> {
 *     new StringValidator("abc@metlife.com", "Email field").validate("notNull").validate("notBlank")
 *         .validate("isEmail").validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 20);
 * });
 * 
 * // configurable multi validations, comma to seperate methods and tilde method args
 * new StringValidator("abc@metlife.com", "Email field")
 *     .validateAll("notNull,notBlank,isEmail,matchesRegEx~.*metlife.*,isMinLength~10");
 * 
 * // mix and match
 * new StringValidator("abc@metlife.com", "Email field").validateAll("notNull,notBlank,isEmail")
 *     .validate("matchesRegEx", ".*metlife.*").validate(StringValidator::isMaxLength, 30);
 * 
 * // nullable, passes all if value is null
 * new StringValidator(null, "Email field", true).validateAll("notNull,notBlank,isEmail")
 *     .validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 10).validateAll("isMaxLength~50");
 * // nullable validates if value is not null
 * assertThrows(MsValidationException.class, () -> {
 *     new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
 *         .validate("isEmail").validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 20);
 * });
 * 
 * // custom error handling
 * assertEquals("My custom message", assertThrows(MsValidationException.class, () -> {
 *     new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
 *         .validate("isEmail").validate("matchesRegEx",
 *             (t) -> { throw new MsValidationException("My custom message"); }, ".*pnbmetlife.*");
 * }).getMessage());
 * 
 * // custom error message
 * assertEquals("Email must be of pnbmetlife domain.", assertThrows(MsValidationException.class, () -> {
 *     new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
 *         .validate("matchesRegEx~$errmsg:Email must be of pnbmetlife domain.~.*@pnbmetlife.*");
 * }).getMessage());
 * </pre>
 * 
 * @See Validator
 */
public class StringValidator extends ComparableValidator {

    private String sval;

    /**
     * Parameterized constructor.
     * 
     * @param val         Value to be evaluated.
     * @param displayName Name of the field that should be appended with the error message.
     * @param nullable    true if field can be null, validations will simple pass
     */
    public StringValidator(String val, String displayName, boolean nullable) {
        super(val, displayName, nullable);
        this.sval = val;
    }

    public StringValidator(String val, String displayName) { this(val, displayName, DEFAULT_NULLABILITY); }

    /**
     * Checks if a CharSequence is not empty (""), not null and not whitespace only.<br>
     * 
     * <pre>
     * StringUtils.notBlank(null)      = false
     * StringUtils.notBlank("")        = false
     * StringUtils.notBlank(" ")       = false
     * StringUtils.notBlank("bob")     = true
     * StringUtils.notBlank("  bob  ") = true
     * </pre>
     */
    @RegisterForQuickAccess
    public Void notBlank() {
        if (!StringUtils.isBlank(sval)) return null;
        throw new MsValidationException(String.format("%s=\"%s\", cannot be blank.", getDisplayName(), sval));
    }

    @RegisterForQuickAccess
    public Void notNullNotBlank() { notNull(); notBlank(); return null; }

    @RegisterForQuickAccess
    public Void notNullMatchesRegEx(String regex) { notNull(); return matchesRegEx(regex); }

    /**
     * This method checks the boolean value, true or false.<br>
     */
    @RegisterForQuickAccess
    public Void isBoolean() {
        if (sval.equalsIgnoreCase("true") || sval.equalsIgnoreCase("false")) return null;
        throw new MsValidationException(String.format("%s=\"%s\", should be true or false", getDisplayName(), sval));

    }

    /**
     * Checks the String length. Matches the exact length.
     * 
     * @param length Desired String length.
     */
    @RegisterForQuickAccess
    public Void isLength(Integer length) {
        if (sval.length() == length) return null;
        throw new MsValidationException(
            String.format("%s=\"%s\", length must be %d characters long.", getDisplayName(), sval, length));
    }

    @RegisterForQuickAccess
    public Void isMinLength(Integer length) {
        if (sval.length() >= length) return null;
        throw new MsValidationException(
            String.format("%s=\"%s\", length must be min %d characters long.", getDisplayName(), sval, length));
    }

    @RegisterForQuickAccess
    public Void isMaxLength(Integer length) {
        if (sval.length() <= length) return null;

        throw new MsValidationException(
            String.format("%s=\"%s\", length must be max %d characters long.", getDisplayName(), sval, length));
    }

    @RegisterForQuickAccess
    public Void startsWith(String prefix) {
        if (sval.startsWith(prefix)) return null;

        throw new MsValidationException(
            String.format("%s=\"%s\", must start with prefix, %s.", getDisplayName(), sval, prefix));
    }

    @RegisterForQuickAccess
    public Void endsWith(String suffix) {
        if (sval.endsWith(suffix)) return null;
        throw new MsValidationException(
            String.format("%s=\"%s\", must end with suffix, %s.", getDisplayName(), sval, suffix));
    }

    /**
     * Checks if the value can safely be converted to a primitive integer.
     */
    @RegisterForQuickAccess
    public Void isInt() {
        if (GenericValidator.isInt(sval)) return null;
        throw new MsValidationException(String.format("%s=\"%s\", must be an integer.", getDisplayName(), sval));
    }

    /**
     * Checks if the value is a valid credit card number.
     */
    @RegisterForQuickAccess
    public Void isCreditCard() {
        if (GenericValidator.isCreditCard(sval)) return null;
        throw new MsValidationException(
            String.format("%s=\"%s\", must be a valid credit card number.", getDisplayName(), sval));
    }

    /**
     * Checks if the field is a valid date.
     * <p>
     * The {@link Locale} is used with {@link java.text.DateFormat}. If strict is true, then the length will be checked
     * so '2/12/1999' will not pass validation with the format 'MM/dd/yyyy' because the month isn't two digits.
     * </p>
     *
     * @param datePattern The pattern passed to {@link SimpleDateFormat}.
     * @param strict      Whether or not to have an exact match of the datePattern.
     */
    @RegisterForQuickAccess
    public Void isDate(final String datePattern, final Boolean strict) {
        if (GenericValidator.isDate(sval, datePattern, strict)) return null;
        throw new MsValidationException(String.format("%s=\"%s\", has invalid date format, expected format, %s.",
            getDisplayName(), sval, datePattern));

    }

    /**
     * Checks if a field has a valid e-mail address.
     */
    @RegisterForQuickAccess
    public Void isEmail() {
        if (GenericValidator.isEmail(sval)) return null;
        throw new MsValidationException(String.format("%s=\"%s\", must be a valid email.", getDisplayName(), sval));
    }

    /**
     * Checks if a field is a valid URL address.
     * <p>
     * If you need to modify what is considered valid then consider using the UrlValidator directly.
     * </p>
     */
    @RegisterForQuickAccess
    public Void isUrl() {
        if (GenericValidator.isUrl(sval)) return null;
        throw new MsValidationException(String.format("%s=%s, is invalid url.", getDisplayName(), sval));
    }

    /**
     * Checks if the value matches the regular expression.
     *
     * @param regexp The regular expression.
     */
    @RegisterForQuickAccess
    public Void matchesRegEx(String regexp) {
        if (GenericValidator.matchRegexp(sval, regexp)) return null;
        throw new MsValidationException(
            String.format("%s=\"%s\", must match pattern %s.", getDisplayName(), sval, regexp));
    }
}
