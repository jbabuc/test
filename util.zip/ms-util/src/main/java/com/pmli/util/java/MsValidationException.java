package com.pmli.util.java;

/**
 * Created this class as per sonar code scan suggestion to use custom exception in place of RuntimeException
 * 
 * @author 3495987jan
 */
public class MsValidationException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public MsValidationException(String msg) { super(msg); }

    public MsValidationException(String msg, Throwable t) { super(msg, t); }
}
