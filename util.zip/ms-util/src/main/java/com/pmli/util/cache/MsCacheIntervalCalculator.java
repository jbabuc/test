package com.pmli.util.cache;

import java.time.LocalTime;

import com.pmli.util.cache.MsCache.ExpireAtTime;

public class MsCacheIntervalCalculator {
    LocalTime fromTime;

    public MsCacheIntervalCalculator() { this.fromTime = LocalTime.now(); }

    public MsCacheIntervalCalculator(LocalTime fromTime) { this.fromTime = fromTime; }

    public int getSecondsToExpiration(ExpireAtTime expireAtInterval) {
        int expirationTime = 0;
        int currentTimeInSecond = (fromTime.getHour() * 3600) + (fromTime.getMinute() * 60) + fromTime.getSecond();
        switch (expireAtInterval) {
        case AT_HALF_HOUR:
            int timeInMinutes = fromTime.getMinute();
            if (timeInMinutes > 30) { timeInMinutes = timeInMinutes - 30; }
            // Half Hour have total 1800 seconds
            expirationTime = 1800 - ((timeInMinutes * 60) + fromTime.getSecond());
            break;
        case AT_HOUR:
            // Hour have total 3600 seconds
            expirationTime = 3600 - ((fromTime.getMinute() * 60) + fromTime.getSecond());
            break;
        case AT_EVERY_3RD_HOUR:
            // 3 Hours have total 10800 seconds
            expirationTime = 10800 - (currentTimeInSecond % 10800);
            break;
        case AT_EVERY_4TH_HOUR:
            // 4 Hours have total 10800 seconds
            expirationTime = 14400 - (currentTimeInSecond % 14400);
            break;
        case AT_EVERY_6TH_HOUR:
            // Quarter have total 10800 seconds
            expirationTime = 21600 - (currentTimeInSecond % 21600);
            break;
        case AT_DAY:
            // 24 Hours have 86400
            expirationTime = 86400 - currentTimeInSecond;
            break;
        default:
            // this will not happen, for parameter is enum ExpireAtTime
        }

        return expirationTime;
    }

}
