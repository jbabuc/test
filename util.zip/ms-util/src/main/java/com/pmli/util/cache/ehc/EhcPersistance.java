package com.pmli.util.cache.ehc;

import net.sf.ehcache.Element;

public interface EhcPersistance {
    public void loadElements();

    public void storeElement(Element e);

    public Element getElement(String key);

    public void cleanUp();
}
