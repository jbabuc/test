package com.pmli.util.java;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Base class contains common methods for all subclasses
 * 
 * @author 3495987jan
 */
public abstract class MsObject {
    // for debug logs use -Dorg.slf4j.simpleLogger.log.com.ms.util=debug
    // http://www.slf4j.org/api/org/slf4j/impl/SimpleLogger.html
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    public MsObject() { log.trace("Instance created: {}", this.getClass()); }

    public static Logger getLogger(Class<?> c) { return LoggerFactory.getLogger(c); }

    // convenience method, expensive, use cautiously. do not use with heavy iterative functions
    public static Logger getSL() { return LoggerFactory.getLogger(new Throwable().getStackTrace()[1].getClassName()); }
}
