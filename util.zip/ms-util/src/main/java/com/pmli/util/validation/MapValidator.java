package com.pmli.util.validation;

import java.util.Map;

import com.pmli.util.java.MsValidationException;

public class MapValidator extends Validator {
    Map<?, ?> mval;

    public MapValidator(Map<?, ?> mval, String displayName, boolean nullable) {
        super(mval, displayName, nullable);
        this.mval = mval;
    }

    public MapValidator(Map<?, ?> mval, String displayName) { this(mval, displayName, DEFAULT_NULLABILITY); }

    @RegisterForQuickAccess
    public Void isMinLength(Integer length) {
        if (mval.size() >= length) return null;
        throw new MsValidationException(
            String.format("%s=%d, must contain min %d element(s).", getDisplayName(), mval.size(), length));
    }

    @RegisterForQuickAccess
    public Void isMaxLength(Integer length) {
        if (mval.size() <= length) return null;
        throw new MsValidationException(
            String.format("%s=%d, must contain max %d element(s).", getDisplayName(), mval.size(), length));
    }
}
