package com.pmli.util.java;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.util.Optional.ofNullable;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Helper util to use reflect methods. Wraps exceptions and throws {@link MsValidationException}.
 * 
 * @author 3495987jan
 */
public class ReflectUtil {

    private ReflectUtil() {}

    public static List<Field> getAllFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>();
        for (Class<?> c = clazz; c != null; c = c.getSuperclass()) {
            fields.addAll(Arrays.asList(c.getDeclaredFields()));
        }
        return fields;
    }

    public static Object getStaticFieldValue(Class<?> clazz, String name) {
        try {
            return clazz.getField(name).get(null);
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            throw MsRuntimeException.wrap(e);
        }
    }

    public static Field getFieldOrNull(Class<?> clazz, String name) {
        try {
            return clazz.getDeclaredField(name);
        } catch (Exception e) {
            return null;
        }
    }

    public static Object getFieldValue(Object dataObject, String name) {
        try {
            Class<?> c = dataObject.getClass();
            Field f = getFieldOrNull(c, name);
            Method m = null;

            if (f != null && f.getType().equals(boolean.class))
                m = getMethodOrNull(c, "is" + StringUtils.capitalize(name));
            if (m == null) m = getMethodOrNull(c, "get" + StringUtils.capitalize(name));
            if (m == null) m = getMethodOrNull(c, name);

            return m != null ? invoke(m, dataObject, null) : c.getField(name).get(dataObject);
        } catch (Exception ex) {
            throw MsRuntimeException.wrap(ex);
        }
    }

    public static Object getFieldValueOrDefault(Object dataObject, String name, Object defaultValue) {
        try {
            return getFieldValue(dataObject, name);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public static Method getMethod(Class<?> clazz, String name, Class<?>... types) {
        try {
            return clazz.getMethod(name, types);
        } catch (NoSuchMethodException | SecurityException ex) {
            throw MsRuntimeException.wrap(ex);
        }
    }

    public static Method getMethodOrNull(Class<?> clazz, String name, Class<?>... types) {
        try {
            return getMethod(clazz, name, types);
        } catch (Exception ex) {
            return null;
        }
    }

    public static boolean matchParamData(Class<?> paramClass, Object data, ObjectMapper om) {
        // direct match
        if (paramClass.equals(data.getClass())) return true; // success

        try { // casting
            paramClass.cast(data);
            return true; // success
        } catch (ClassCastException ex) {
            // failed
        }

        if (om == null || !(data instanceof String)) return false;

        try { // mapping
            om.readValue((String) data, paramClass);
            return true; // success
        } catch (JsonProcessingException e) {
            // failed
        }

        return false;
    }

    public static Method getMethod(Class<?> clazz, String name, Object... args) {

        try { // find clazz method based on name and arg types
            return getMethod(clazz, name, Arrays.asList(args).stream().map(Object::getClass)
                .collect(Collectors.toList()).toArray(new Class<?>[0]));
        } catch (Exception ex) {
            // failed to find method using class.getMethod, try casting args
        }

        // get all clazz methods, filter by name and match params with args
        return Arrays.asList(clazz.getMethods()).stream().filter(m -> m.getName().equals(name)).filter(m -> {
            Parameter[] params = m.getParameters();

            // args length mismatch, filter out
            if (params.length != args.length) return false;

            ObjectMapper om = new ObjectMapper();
            for (int i = 0, n = params.length; i < n; i++) {
                // any match fail, filter out
                if (!matchParamData(params[i].getType(), args[i], om)) return false;
            }

            return true; // all match
        }).findFirst().orElseThrow(
            () -> new MsValidationException(String.format("Method not found: %s.%s", clazz.getName(), name)));
    }

    public static <T> Constructor<T> getConstructor(Class<T> clazz, Class<?>... args) {
        try {
            return clazz.getConstructor(args);
        } catch (NoSuchMethodException | SecurityException ex) {
            throw MsRuntimeException.wrap(ex);
        }
    }

    public static <T> T getNewInstance(Constructor<T> constructor, Object... args) {
        try {
            return constructor.newInstance(args);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException
            | InvocationTargetException ex) {
            throw MsRuntimeException.wrap(ex);
        }
    }

    public static Object invoke(Method method, Object o, Consumer<Throwable> onFailExecute, Object... args) {
        try {
            return method.invoke(o, args);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            // execute custom exception handler if available
            ofNullable(onFailExecute).orElseThrow(() -> MsRuntimeException.wrap(ex)).accept(ex);
        }

        return null;
    }

    public static <T> T castOrNull(Object o, Class<T> clazz) {
        try {
            return clazz.cast(o);
        } catch (ClassCastException ex) {
            return null;
        }
    }

    public static Class<?> getClassOrNull(String className) {
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException ex) {
            return null;
        }
    }
}
