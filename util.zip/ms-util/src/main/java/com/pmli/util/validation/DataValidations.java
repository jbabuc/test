package com.pmli.util.validation;

import java.util.List;

import com.pmli.util.java.FieldMetaJson;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * JSON fields for configuring validation in {@link FieldMetaJson} <br/>
 * <br/>
 * <b>nullable</b> true allows value to be null <br/>
 * <b>ignoreValidations</b> ignores validations on whole sub tree, except default validations <br/>
 * <b>ignoreDefValidations</b> ignores default validations just on the element <br/>
 * <b>displayName</b> Name of the field, $parent will be substituted with parent display name<br/>
 * <b>validations</b> comma separated validations and tilde separated params, {@link Validator} <br/>
 * <b>childDataValidations</b> array, each element contains validations with nullable, displaynName, and validations
 * attributes, additionally childPath attribute is required that indicates the data object path in dot notation<br/>
 * <b>listElementDataValidations</b> validations with nullable, displaynName, and validations attributes, additional
 * <b>valIndex</b> field is for runtime use <br/>
 * <b>mapElementDataValidations</b> validations with nullable, displaynName, and validations attributes, additional
 * <b>valKey</b> field is for runtime use <br/>
 * <br/>
 * 
 * @author 3495987jan
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class DataValidations {
    @Builder.Default
    private boolean nullable = Validator.DEFAULT_NULLABILITY;
	private boolean ignoreValidations;
    private boolean ignoreDefValidations;
    private String  displayName;
    private String  validations;

    // for tracking field name at runtime
    private String fieldName;

    // for child validations
    private List<DataValidations> childDataValidations;
    private String                childPath;

    // for lists
    private DataValidations listElementDataValidations;
    // for tracking index at runtime
    private Integer valIndex;

    // for map
    private DataValidations mapElementDataValidations;
    // for tracking key at runtime
    private Object valKey;
}