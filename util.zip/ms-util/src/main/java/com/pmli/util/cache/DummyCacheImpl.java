package com.pmli.util.cache;

import java.util.function.Function;

import com.pmli.util.java.MsObject;

public class DummyCacheImpl extends MsObject implements MsCache {

    public DummyCacheImpl() { log.info("Dummy cache is in play. No caching."); }

    @Override
    public <R> R get(String key, Function<String, R> funcToFetchFromSource, ExpireAtTime expireAtTime,
        GetOptions getOptions) {
        return funcToFetchFromSource.apply(key);
    }
}
