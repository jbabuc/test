package com.pmli.util.cache.redis;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Component;
import io.lettuce.core.codec.RedisCodec;

@Component
public class SerializedObjectCodec implements RedisCodec<String, byte[]>{

	private Charset charset = StandardCharsets.UTF_8;

	@Override
	public String decodeKey(final ByteBuffer bytes) {
		return charset.decode(bytes).toString();
	}

	@Override
	public byte[] decodeValue(final ByteBuffer bytes) {
		return getBytes(bytes);
	}

	@Override
	public ByteBuffer encodeKey(final String key) {
		return charset.encode(key);
	}

	@Override
	public ByteBuffer encodeValue(final byte[] value) {
		return ByteBuffer.wrap(value);
	}

	private static byte[] getBytes(final ByteBuffer buffer) {
		final byte[] b = new byte[buffer.remaining()];
		buffer.get(b);
		return b;
	}
}
