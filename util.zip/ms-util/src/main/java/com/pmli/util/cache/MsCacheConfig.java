package com.pmli.util.cache;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration
public class MsCacheConfig {

    @Value("${com.pmli.util.cache.driver:com.pmli.util.cache.DummyCacheImpl}")
    private String cacheImpClass;

    @Bean
    @DependsOn({ "contextWrapper" })
    public MsCache getCache() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        return (MsCache) Class.forName(cacheImpClass).newInstance();
    }
}
