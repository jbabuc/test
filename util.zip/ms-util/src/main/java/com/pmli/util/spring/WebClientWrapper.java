package com.pmli.util.spring;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

import org.bson.Document;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import com.pmli.util.bson.DocUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.json.JsonUtil;

import io.netty.handler.logging.LogLevel;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

/**
 * Wraps reactive WebClient. Each web client is cached in a map based on the host:port base url. <br/>
 * Further get and post calls will need to send only the relative uri.
 * 
 * @author 3495987jan
 */
public class WebClientWrapper extends MsObject {

    private static final Map<String, WebClientWrapper> MHC_MAP = new HashMap<>();

    private WebClient webClient;

    public WebClient getWebClient() { return webClient; }

    public WebClientWrapper(String baseUrl) {
        HttpClient httpClient = HttpClient.create().wiretap(HttpClient.class.getCanonicalName(), LogLevel.INFO,
            AdvancedByteBufFormat.TEXTUAL);
        webClient = WebClient.builder().baseUrl(baseUrl).clientConnector(new ReactorClientHttpConnector(httpClient))
            .build();
    }

    public static WebClientWrapper getWCW(String baseUrl) {
        return ofNullable(MHC_MAP.get(baseUrl)).orElseGet(
            () -> of(new WebClientWrapper(baseUrl)).map(w -> { MHC_MAP.put(baseUrl, w); return w; }).orElse(null));
    }

    public Mono<byte[]> sendGet(String uri, Map<String, String> headers,
        Function<ClientResponse, ? extends reactor.core.publisher.Mono<byte[]>> crHandler,
        Function<? super RuntimeException, ? extends Throwable> erHandler) {
        return webClient.get().uri(uri).headers(hdrs -> headers.forEach(hdrs::add)).exchangeToMono(crHandler)
            .onErrorMap(WebClientException.class, erHandler);
    }

    public Mono<byte[]> sendPost(String uri, Map<String, String> headers, String body,
        Function<ClientResponse, ? extends reactor.core.publisher.Mono<byte[]>> crHandler,
        Function<? super RuntimeException, ? extends Throwable> erHandler) {
        return webClient.post().uri(uri).headers(hdrs -> headers.forEach(hdrs::add)).body(BodyInserters.fromValue(body))
            .exchangeToMono(crHandler).onErrorMap(WebClientException.class, erHandler);
    }

    public RuntimeException handleError(Throwable th) { return MsRuntimeException.wrap(th); }

    /**
     * Default client response handler. Handles only content as bytes. <br/>
     * To handle response headers and cookies call send method with a custom response handler.
     * 
     * @param  cr
     * @return    Response content as bytes in mono.
     */
    public Mono<byte[]> handleClientResponse(ClientResponse cr) {
        if (!cr.statusCode().isError()) {
            return cr.bodyToMono(ByteArrayResource.class).map(ByteArrayResource::getByteArray);
        } else {
            DocUtil.DocPW dpw = new DocUtil.DocPW(new Document());
            dpw.put("status", cr.rawStatusCode());
            dpw.put("headers", Document.parse(JsonUtil.writeValueAsString(cr.headers())).get("httpHeaders"));
            cr.bodyToMono(String.class).subscribe(b -> dpw.put("body", b));
            return Mono.error(new MsRuntimeException(dpw.doc().toJson()));
        }
    }

    public Mono<byte[]> getAsync(String uri, Map<String, String> headers, Consumer<byte[]> contentBytesHandler) {
        Mono<byte[]> mono = sendGet(uri, headers, this::handleClientResponse, this::handleError);
        if (contentBytesHandler != null) mono.subscribe(contentBytesHandler);
        return mono;
    }

    public Mono<byte[]> postAsync(String uri, Map<String, String> headers, String body,
        Consumer<byte[]> contentBytesHandler) {
        Mono<byte[]> mono = sendPost(uri, headers, body, this::handleClientResponse, this::handleError);
        if (contentBytesHandler != null) mono.subscribe(contentBytesHandler);
        return mono;
    }

    public byte[] get(String uri, Map<String, String> headers) {
        Mono<byte[]> mono = getAsync(uri, headers, null);
        return mono.block();
    }

    public byte[] post(String uri, Map<String, String> headers, String body) {
        Mono<byte[]> m = postAsync(uri, headers, body, null);
        return m.block();
    }
}
