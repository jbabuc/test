package com.pmli.util.cache.ehc;

import java.util.Objects;
import java.util.function.Function;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import org.springframework.util.SerializationUtils;

import com.pmli.util.cache.MsCache;
import com.pmli.util.cache.MsCacheIntervalCalculator;
import com.pmli.util.java.MsObject;
import com.pmli.util.spring.ContextWrapper;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

public class Ehcachelmpl extends MsObject implements MsCache {

    private final Ehcache ehcache;
    EhcPersistance        ehcPersistor;

    public Ehcachelmpl(String name, String diskLocation, String cachePrefix, Boolean loadFromDiskOnInit,
        Boolean persistanceOff) {
        Objects.requireNonNull(name);
        log.info("Adding ehcache with name: {}", name);
        ehcache = CacheManager.getInstance().addCacheIfAbsent(name);

        persistanceOff = persistanceOff != null ? persistanceOff.booleanValue()
            : ContextWrapper.getAppProperty("com.pmli.util.cache.ehPersistanceOff", false);

        if (!persistanceOff.booleanValue()) {
            diskLocation = diskLocation != null ? diskLocation
                : ofNullable(ContextWrapper.getAppProperty("com.pmli.util.cache.ehcacheDiskLocation"))
                    .orElse(System.getProperty("java.io.tmpdir"));
            cachePrefix = cachePrefix != null ? cachePrefix
                : ofNullable(ContextWrapper.getAppProperty("com.pmli.util.cache.ehcachePrefix")).orElse("ehc-");
            loadFromDiskOnInit = loadFromDiskOnInit != null ? loadFromDiskOnInit.booleanValue()
                : ContextWrapper.getAppProperty("com.pmli.util.cache.ehLoadFromDiskOnInit", false);
            // keep expired and un-refreshed cache for 7 days before cleaning up
            long cleanupAfterExpireMillis = ContextWrapper
                .getAppProperty("com.pmli.util.cache.ehCleanupAfterExpireMillis", 7 * 24 * 60 * 60 * 1000);

            ehcPersistor = new EhcDiskPersistor(ehcache, diskLocation, cachePrefix, loadFromDiskOnInit,
                cleanupAfterExpireMillis);
        } else {
            ehcPersistor = new EhcPersistance() {
                public void loadElements() { /* Persistence off, ignore */ }

                public void storeElement(Element e) { /* Persistence off, ignore */ }

                public Element getElement(String key) { return null; }

                public void cleanUp() { /* Persistence off, ignore */ }
            };
        }
    }

    public Ehcachelmpl() {
        // keep this name unique, for ehcache is creating a lock file in /tmp on this name
        this(ContextWrapper.getAppProperty("com.pmli.util.cache.ehName",
            "ehcahe-" + System.getProperty("user.name") + "" + System.currentTimeMillis()), null, null, null, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <R> R get(String key, Function<String, R> funcToFetchFromSource, ExpireAtTime expireAtTime,
        GetOptions getOptions) {

        if (getOptions.equals(GetOptions.DELETE_CURRENT)) {
            ehcache.remove(key);
        } else { // no point in running this, if delete current happened
            R r = ofNullable(ofNullable(ehcache.get(key)).orElse(ehcPersistor.getElement(key)))
                .map(Element::getObjectValue).filter(Objects::nonNull).map(o -> (byte[]) o)
                .map(SerializationUtils::deserialize).map(v -> (R) v).orElse(null);
            if (r != null) return r;
        }

        // fetch and set cache, apply call may throw exception and that we will not catch
        return ofNullable(funcToFetchFromSource).map(f -> f.apply(key)).filter(Objects::nonNull)
            .map(o -> of(SerializationUtils.serialize(o)).map(so -> {
                Element e = new Element(key, so);
                e.setTimeToLive(new MsCacheIntervalCalculator().getSecondsToExpiration(expireAtTime));
                ehcache.put(e);
                ehcPersistor.storeElement(e);
                return (R) o;
            }).orElse((R) o)).orElse(null);
    }
}
