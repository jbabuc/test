package com.pmli.util.cache.ehc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static java.util.Optional.of;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.awaitility.Awaitility;
import org.bson.Document;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.pmli.util.cache.DummyCacheImpl;
import com.pmli.util.cache.MsCache;
import com.pmli.util.cache.MsCache.ExpireAtTime;
import com.pmli.util.cache.MsCache.GetOptions;
import com.pmli.util.java.CryptoTest;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.ThreadUtil;
import com.pmli.util.spring.ContextWrapper;

import net.sf.ehcache.CacheManager;

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class EhcacheImplTest extends MsObject {
    public static List<String> keys          = new ArrayList<>();
    public static Document     dictionaryDoc = CryptoTest.getDictionaryJson();

    // this will load the properties and enable logging
    @SpringBootConfiguration
    @ComponentScan({ "com.pmli.util" })
    public static class TestConfig {}

    @AfterEach
    public void tearDown() { CacheManager.getInstance().removeAllCaches(); }

    @Test
    public void ehcacheImplTest() throws Exception {
        log.info("ehcacheImplTest...");
        final Map<String, String> myMap = new JUtil.MsMap<String, String>().add("One", "One 1").add("Two", "Two 2")
            .add("Three", "Three 3");

        assertNotNull(ContextWrapper.getContext());

        MsCache msCache = new Ehcachelmpl();

        Map<String, String> m = msCache.get("mymap", (k) -> myMap, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
        assertEquals(myMap, m);

        // check object is cached, send null function
        m = msCache.get("mymap", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
        assertEquals(myMap, m);

        // check cache is intact, if I manipulate returned object
        m.remove("One");
        m = msCache.get("mymap", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
        assertEquals(myMap, m);

        // check cache is intact, if I manipulate original object
        myMap.remove("One");
        m = msCache.get("mymap", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
        assertEquals(new JUtil.MsMap<String, String>().add("One", "One 1").add("Two", "Two 2").add("Three", "Three 3"),
            m);
    }

    @Test
    public void ehcacheImplTestPersistance() throws Exception {
        log.info("ehcacheImplTestPersistance ...");

        {
            MsCache mscache = new Ehcachelmpl();
            // check if cache from above test can be refetched
            assertEquals(
                new JUtil.MsMap<String, String>().add("One", "One 1").add("Two", "Two 2").add("Three", "Three 3"),
                mscache.get("mymap", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
            CacheManager.getInstance().removeAllCaches(); // clean cache
        }

        {
            MsCache mscache = new Ehcachelmpl(); // fill dictionary data to disk
            dictionaryDoc.keySet().stream().limit(1000).forEach(key -> {
                keys.add(key);
                mscache.get(key, (k) -> dictionaryDoc.get(k), ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
            });
            CacheManager.getInstance().removeAllCaches(); // clean cache
        }

        {
            MsCache mscache = new Ehcachelmpl();
            of(keys.get(ThreadLocalRandom.current().nextInt(0, 1000))).ifPresent(k -> assertEquals(dictionaryDoc.get(k),
                mscache.get(k, null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT)));
            CacheManager.getInstance().removeAllCaches(); // clean cache
        }

    }

    @Test
    public void ehcacheMultiThread() throws Exception {
        ThreadUtil.runParallel(5, 1, (c) -> {
            MsCache mscache = new Ehcachelmpl(Thread.currentThread().getName(), null, null, null, null);
            // assert key is found
            of(keys.get(ThreadLocalRandom.current().nextInt(0, 1000))).ifPresent(k -> assertEquals(dictionaryDoc.get(k),
                mscache.get(k, null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT)));
            return null;
        });
    }

    @Test
    public void persistanceOffTest() throws Exception {
        log.info("persistanceOfTest ...");

        MsCache mscache = new Ehcachelmpl("persistanceOffTest", null, null, false, true);
        // check if cache from above test can be refetched
        assertEquals("retval", mscache.get("myval", (c) -> "retval", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
        // returns from Ehcache
        assertEquals("retval", mscache.get("myval", (c) -> "retval1", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
        CacheManager.getInstance().removeAllCaches(); // clean cache
    }

    @Test
    public void dummyImpl() throws Exception {
        log.info("dummyImpl ...");

        DummyCacheImpl dc = new DummyCacheImpl();
        assertEquals("xyz", dc.get("abc", (c) -> "xyz", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
    }

    @Test
    public void diskPersistanceTest() throws Exception {
        log.info("diskPersistanceTest ...");

        String cachedir = JUtil.getTmpDirNew(true);
        {
            MsCache mscache = new Ehcachelmpl("ehcdiskTest", cachedir, "ehcdiskTest-", true, false);
            mscache.get("myval1", (c) -> "retval1", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
            mscache.get("myval2", (c) -> "retval2", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
            mscache.get("myval3", (c) -> "retval3", ExpireAtTime.AT_HOUR, GetOptions.DEFAULT);
            CacheManager.getInstance().removeAllCaches(); // clean cache
            Awaitility.await().atMost(1000, TimeUnit.MILLISECONDS);
        }

        MsCache mscache = new Ehcachelmpl("ehcdiskTest_new", cachedir, "ehcdiskTest-", true, false);
        assertEquals("retval1", mscache.get("myval1", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
        assertEquals("retval2", mscache.get("myval2", null, ExpireAtTime.AT_HOUR, GetOptions.DEFAULT));
    }
}
