package com.pmli.util.java;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * @author 3495987jan
 */
@TestMethodOrder(MethodOrderer.MethodName.class)
public class MsObjectTest extends MsObject {

    public static class TestClass extends MsObject {}

    @Test
    public void test() {
        assertEquals(log, getLogger(MsObjectTest.class));

        // assert same logger is used for instance and class
        assertEquals(log, getSL());

        // assert same logger is used for all the objects of the class
        assertEquals(new TestClass().log, new TestClass().log);
    }
}