package com.pmli.util.validation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.pmli.util.java.MsValidationException;

public class StringValidatorTest {
    @Test
    public void endsWith() {
        new StringValidator("abcdef", "fname", false).endsWith("def");
        assertThrows(MsValidationException.class, () -> new StringValidator("abcdef", "fname", false).endsWith("abc"));
    }

    @Test
    public void isBoolean() {
        new StringValidator("true", "fname", false).isBoolean();
        new StringValidator("false", "fname", false).isBoolean();
        assertThrows(MsValidationException.class, () -> new StringValidator("val", "fname", false).isBoolean());
        assertThrows(MsValidationException.class, () -> new StringValidator(null, "fname", false).notNull());
    }

    @Test
    public void isCreditCard() {
        new StringValidator("5105105105105100", "fname", false).isCreditCard();
        assertThrows(MsValidationException.class,
            () -> new StringValidator("1234567890123456", "fname", false).isCreditCard());
    }

    @Test
    public void isDate() {
        new StringValidator("2020/03/01", "fname", false).isDate("yyyy/mm/dd", true);
        assertThrows(MsValidationException.class,
            () -> new StringValidator("2020/3/01", "fname", false).isDate("yyyy/mm/dd", true));
    }

    @Test
    public void isEmail() {
        new StringValidator("abc@xyz.com", "fname", false).isEmail();
        assertThrows(MsValidationException.class, () -> new StringValidator("abc@xyz.", "fname", false).isEmail());
    }

    @Test
    public void isInt() {
        new StringValidator("1234567890", "fname", false).isInt();
        assertThrows(MsValidationException.class, () -> new StringValidator("abc", "fname", false).isInt());
    }

    @Test
    public void isLength() {
        new StringValidator("1234567890", "fname", false).isLength(10);
        assertThrows(MsValidationException.class, () -> new StringValidator("123456789", "fname", false).isLength(8));
    }

    @Test
    public void isMaxLength() {
        new StringValidator("123456789", "fname", false).isMaxLength(10);
        assertThrows(MsValidationException.class,
            () -> new StringValidator("123456789", "fname", false).isMaxLength(8));
    }

    @Test
    public void isMinLength() {
        new StringValidator("123456789", "fname", false).isMinLength(8);
        assertThrows(MsValidationException.class,
            () -> new StringValidator("123456789", "fname", false).isMinLength(10));
    }

    @Test
    public void isUrl() {
        new StringValidator("http://www.pnbmetblife.com", "fname", false).isUrl();
        assertThrows(MsValidationException.class,
            () -> new StringValidator("http://www.pnbmetblife.c om", "fname", false).isUrl());
    }

    @Test
    public void matchesRegEx() {
        new StringValidator("abcdef", "fname", false).matchesRegEx("[a-z]*");
        assertThrows(MsValidationException.class,
            () -> new StringValidator("abcd2ef", "fname", false).matchesRegEx("[a-z]*"));
    }

    @Test
    public void notBlank() {
        new StringValidator("abcdef", "fname", false).notBlank();
        assertThrows(MsValidationException.class, () -> new StringValidator("", "fname", false).notBlank());
    }

    @Test
    public void notNullNotBlank() {
        new StringValidator("abcdef", "fname", false).notBlank();
        assertThrows(MsValidationException.class, () -> new StringValidator(null, "fname", false).notBlank());
        assertThrows(MsValidationException.class, () -> new StringValidator("", "fname", false).notBlank());
    }

    @Test
    public void notNullMatchesRegEx() {
        final String msg = "Id must not be blank with max 10 digits.";
        final String regex = "^[0-9]{1,10}$";
        new StringValidator("1234", "Id", false).validateEx(StringValidator::notNullMatchesRegEx, regex, msg);

        new StringValidator(null, "Id", true).validateEx(StringValidator::matchesRegEx, regex, msg);

        assertEquals(msg, assertThrows(MsValidationException.class, () -> new StringValidator(null, "Id", false)
            .validateEx(StringValidator::notNullMatchesRegEx, regex, msg)).getMessage());
        assertEquals(msg, assertThrows(MsValidationException.class, () -> new StringValidator("", "Id", false)
            .validateEx(StringValidator::notNullMatchesRegEx, regex, msg)).getMessage());
        assertEquals(msg,
            assertThrows(MsValidationException.class, () -> new StringValidator("12345678901", "Id", false)
                .validateEx(StringValidator::notNullMatchesRegEx, regex, msg)).getMessage());
        assertEquals(msg, assertThrows(MsValidationException.class, () -> new StringValidator("1234A", "Id", false)
            .validateEx(StringValidator::notNullMatchesRegEx, regex, msg)).getMessage());

        // escaped comma regex with validateAll
        String vregex = "matchesRegEx~$errmsg:" + msg + "~^[0-9]{1\\,10}$";
        new StringValidator("1234", "Id", false).validateAll(vregex);
        assertEquals(msg,
            assertThrows(MsValidationException.class, () -> new StringValidator(null, "Id", false).validateAll(vregex))
                .getMessage());
        assertEquals(msg, assertThrows(MsValidationException.class,
            () -> new StringValidator("12345678901", "Id", false).validateAll(vregex)).getMessage());
        assertEquals(msg, assertThrows(MsValidationException.class,
            () -> new StringValidator("1234A", "Id", false).validateAll(vregex)).getMessage());
    }

    @Test
    public void startsWith() {
        new StringValidator("abcdef", "fname", false).startsWith("abc");
        assertThrows(MsValidationException.class,
            () -> new StringValidator("abcdef", "fname", false).startsWith("def"));
    }
}
