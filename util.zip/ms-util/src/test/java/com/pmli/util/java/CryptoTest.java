package com.pmli.util.java;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.zip.ZipInputStream;
import static java.util.Optional.of;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.util.StreamUtils;

public class CryptoTest extends MsObject {

    public static Document getDictionaryJson() {
        try {
            return of(Files.readAllBytes(Paths.get("src/test/resources/dictionary.zip"))).map(b -> {
                ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(b));
                try {
                    zin.getNextEntry();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    StreamUtils.copy(zin, baos);
                    return Document.parse(new String(baos.toByteArray()));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testSha256() throws Exception {//
        long start = System.currentTimeMillis();
        Document d = getDictionaryJson();
        d.keySet().forEach(k -> {
            try {
                assertNotNull(Crypto.getUrlEncodedSha256Hash(d.getString(k).getBytes()));
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        });

        log.info("Time take to dictionary on Sha256: " + (System.currentTimeMillis() - start) + "ms");
    }

    @Test
    public void testAES() throws Exception {//
        String plainData = "1234567890123456";
        String secretValue = "PSVJQRk9QTEpNVU1DWUZCRVFGV1VVT0ZOV1RRU1NaWQ=";
        String initVector = "WVdsRkxWRVpaVUZOYVdsaA==";
        String algorithm = "AES";
        String providerName = "AES/CBC/PKCS5PADDING";
        assertEquals(plainData,
            Crypto.decryptAES(Crypto.encryptAES(plainData, secretValue, initVector, algorithm, providerName),
                secretValue, initVector, algorithm, providerName));
    }
}
