package com.pmli.util.java;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Constructor;

import org.junit.jupiter.api.Test;

import lombok.AllArgsConstructor;
import lombok.Data;

public class ReflectUtilTest {

    @Test
    public void castOrNull() {
        assertNotNull(ReflectUtil.castOrNull("test", Object.class));
        assertNull(ReflectUtil.castOrNull("test", Integer.class));
    }

    @Test
    public void getClassOrNull() {
        assertNotNull(ReflectUtil.getClassOrNull("java.lang.String"));
        assertNull(ReflectUtil.getClassOrNull("java.lang.Test"));
    }

    @Data
    @AllArgsConstructor
    public static class MyData {
        public final static String FNAME = "name";

        private String  name;
        private int age;
        private boolean male;

        public boolean retbool() { return true; }

        public String myfunc(String s, int i, boolean b) { return "dummy"; }

        public String myfunc(String s, Integer i) { return "dummy"; }

        public String myfunc(String s, boolean b) { return "dummy"; }

    }

    @Test
    public void getFieldValue() {
        MyData md = new MyData("Test", 10, true);
        assertEquals("Test", ReflectUtil.getFieldValue(md, "name"));
        assertEquals(10, ReflectUtil.getFieldValue(md, "age"));
        assertEquals(true, ReflectUtil.getFieldValue(md, "male"));
        assertEquals(true, ReflectUtil.getFieldValue(md, "retbool"));
        assertThrows(MsRuntimeException.class, () -> ReflectUtil.getFieldValue(md, "unknown"));
    }

    @Test
    public void getFieldValueOrDefault() {
        MyData md = new MyData("Test", 10, true);
        assertEquals("Test", ReflectUtil.getFieldValueOrDefault(md, "name", null));
        assertEquals(10, ReflectUtil.getFieldValueOrDefault(md, "age", null));
        assertEquals(true, ReflectUtil.getFieldValueOrDefault(md, "male", null));
        assertNull(ReflectUtil.getFieldValueOrDefault(md, "unknown", null));
    }

    @Test
    public void getMethod() {
        assertNotNull(ReflectUtil.getMethod(MyData.class, "myfunc", String.class, Integer.class));
        assertNotNull(ReflectUtil.getMethod(MyData.class, "myfunc", "test", new Integer(0)));
        assertNotNull(ReflectUtil.getMethod(MyData.class, "myfunc", "test", "0"));
        assertNotNull(ReflectUtil.getMethod(MyData.class, "myfunc", "test", "true"));
    }

    @Test
    public void getMethodOrNull() {
        assertNotNull(ReflectUtil.getMethodOrNull(MyData.class, "myfunc", String.class, Integer.class));
        assertNull(ReflectUtil.getMethodOrNull(MyData.class, "myfunc", String.class));
    }

    @Test
    public void getStaticFieldValue() {
        assertNotNull(ReflectUtil.getStaticFieldValue(MyData.class, "FNAME"));
        assertThrows(MsRuntimeException.class, () -> ReflectUtil.getStaticFieldValue(MyData.class, "UNKNOWN"));
    }

    @Test
    public void getConstructor() {
        assertNotNull(ReflectUtil.getConstructor(MyData.class, String.class, int.class, boolean.class));
        assertThrows(MsRuntimeException.class,
            () -> ReflectUtil.getConstructor(MyData.class, String.class, Integer.class));
    }

    @Test
    public void getNewInstance() {
        Constructor<MyData> c = ReflectUtil.getConstructor(MyData.class, String.class, int.class, boolean.class);
        assertNotNull(ReflectUtil.getNewInstance(c, "test", new Integer(10), new Boolean(true)));
        assertThrows(IllegalArgumentException.class, () -> ReflectUtil.getNewInstance(c, "test", new Integer(10)));
    }
}
