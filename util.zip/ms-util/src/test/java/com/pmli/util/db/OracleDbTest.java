package com.pmli.util.db;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class OracleDbTest extends MsObject {

    // this will load the properties and enable logging
    @ComponentScan({ "com.pmli.util" })
    @SpringBootConfiguration
    public static class TestConfig {}

    // @org.junit.jupiter.api.Test
    public void execute() {
        // String query = "SELECT 1 A, 2 B FROM DUAL";
        String query = "SELECT * FROM ODS_QA.POL_MSTR WHERE ROWNUM <= 10";
        HibernateSessionWrapper hsw = HibernateSessionWrapper.getHSW("oracle_test");
        System.out.println(JsonUtil.writeValueAsString(hsw.getResultsAsMap(query)));
    }

    @Test // dummy test to fix sonar complaint
    public void dummy() { assertTrue(true); }
}
