package com.pmli.util.java;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.util.UUID;

import org.junit.jupiter.api.Test;

public class JUtilTest {

    @Test
    public void getDate() throws Exception { assertNotNull(JUtil.getDate("yyyy/mm/dd", "2021/01/20")); }

    @Test
    public void getCurretDateTime() throws Exception { assertNotNull(JUtil.getCurrentDateTime("yyyy/mm/dd")); }

    @Test
    public void safeDelete() throws Exception {
        File f = new File(JUtil.getTmpDirNew(false));
        assertTrue(f.exists());
        JUtil.safeDelete(f);
        assertFalse(f.exists());
        JUtil.safeDelete(new File(UUID.randomUUID().toString()));
    }
}
