package com.pmli.util.spring;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.pmli.util.java.ThreadUtil.HttpServer;

public class CommUtilTest {

    private static final String QUIT_SIGNAL = "QUIT_CU_TEST";
    private static HttpServer   HTTP_SERVER;

    @AfterAll
    public static void tearDown() throws IOException { HTTP_SERVER.shutdown(); }

    @BeforeAll
    public static void setUp() throws Exception {
        try {
            HTTP_SERVER = new HttpServer(1024, s -> "HTTP/1.1 200 OK\nContent-Length:7\n\nSuccess".getBytes());
        } catch (Exception ex) {
            ex.printStackTrace();
            System.setProperty("QUIT_HTTP_TEST", "true");
        }
    }

    // @Test
    public void sendError() { CommUtil.logAndSendError(new Exception("Custom exception")); }

    @Test
    public void sendMailMock() throws InterruptedException {
        if (Boolean.parseBoolean(System.getProperty(QUIT_SIGNAL))) return;

        CommUtil.sendEmail(HTTP_SERVER.getUrl(), CommUtil.EMAIL_URI, CommUtil.EMAIL_REQUEST_TEMPLATE,
            "janardhan.chinta@pnbmetlife.com", null, "This is a test subject", "This is a test body " + new Date());

        assertNotNull(CommUtil.prepareErrorBody(new Exception("Custom exception")));
    }
}
