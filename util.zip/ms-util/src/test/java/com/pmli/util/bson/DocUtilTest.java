package com.pmli.util.bson;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import static java.util.Optional.of;

import org.bson.Document;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pmli.util.bson.DocUtil.DocPW;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;

import lombok.Data;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author 3495987jan
 */
@TestMethodOrder(MethodOrderer.MethodName.class)
@SuppressWarnings("unchecked")
public class DocUtilTest extends MsObject {

    private static final Document DEx = Document
        .parse("{'name':'John','age':30,'male':true,'spouse':null,'cars':['Ford','BMW','Fiat'],"
            + "'addresses':[{'hno':123,'street':'main','city':'ny','state':'ny'},"
            + "{'hno':234,'street':'22st','city':'philly','state':'pa'}],"
            + "'contacts':{'phone':{'home':'1234','office':'5678'},'postal':null,'friends':['',null],'parents':null}}");

    @Test
    public void exGet() throws Exception {
        log.info("exGet ...");
        // new DocUtil();

        assertEquals("John", DocUtil.get(DEx, "name"));
        assertEquals(30, DocUtil.get(DEx, "age"));
        assertEquals(true, DocUtil.get(DEx, "male"));
        assertEquals(null, DocUtil.get(DEx, "spouse"));
        assertEquals(Arrays.asList("Ford", "BMW", "Fiat"), DocUtil.get(DEx, "cars"));
        assertEquals(Document.parse("{'hno':123,'street':'main','city':'ny','state':'ny'}"),
            DocUtil.get(DEx, "addresses[0]"));

        assertEquals("John", DocUtil.get(DEx, "name", String.class));
        assertEquals(30, DocUtil.get(DEx, "age", Integer.class).intValue());
        assertEquals(true, DocUtil.get(DEx, "male", Boolean.class));
        assertEquals(null, DocUtil.get(DEx, "spouse", Object.class));
        assertEquals(Arrays.asList("Ford", "BMW", "Fiat"), DocUtil.get(DEx, "cars", List.class));
        assertEquals(Document.parse("{'hno':123,'street':'main','city':'ny','state':'ny'}"),
            DocUtil.get(DEx, "addresses[0]", Document.class));
        assertEquals("22st", DocUtil.get(DEx, "addresses[1].street", String.class));
        assertEquals("1234", DocUtil.get(DEx, "contacts.phone.home", String.class));
    }

    @Test
    public void getOrDefault() throws Exception {
        log.info("getOrDefault ...");

        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.postal.personal", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.postal[0]", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.secondary.phone", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.friends[1].name", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.cousins[1].name", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.parents[1].name", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.friends[2]", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "contacts.cousins[1]", null));
        assertEquals(null, DocUtil.getOrDefault(DEx, "addresses[2].pin", null));

        assertEquals("7890", DocUtil.getNonNullOrDefault(DEx, "contacts.postal", "7890"));
        assertEquals("7890", DocUtil.getNonNullOrDefault(DEx, "contacts.postal[0]", "7890"));
        assertEquals("1234", DocUtil.getNonNullOrDefault(DEx, "contacts.phone.home", "1234"));

        assertEquals("John", DocUtil.getOrDefault(DEx, "name", "NA"));
        assertEquals("John", DocUtil.getOrDefault(DEx, "name", String.class, "NA"));
        assertEquals("NA", DocUtil.getOrDefault(DEx, "surname", "NA"));
        assertEquals("NA", DocUtil.getOrDefault(DEx, "surname", String.class, "NA"));
    }

    @Test
    public void exContains() throws Exception {
        log.info("exContains ...");

        assertEquals(true, DocUtil.contains(DEx, "name"));
        assertEquals(false, DocUtil.contains(DEx, "surname"));

        assertEquals(true, DocUtil.containsAndNotNull(DEx, "name"));
        assertEquals(false, DocUtil.containsAndNotNull(DEx, "surname"));
        assertEquals(false, DocUtil.containsAndNotNull(DEx, "contacts.postal"));

        assertEquals(true, DocUtil.containsAndIsNull(DEx, "spouse"));
        assertEquals(false, DocUtil.containsAndIsNull(DEx, "surname"));
        assertEquals(false, DocUtil.containsAndIsNull(DEx, "contacts.phone"));

    }

    @Test
    public void exPut() throws Exception {
        log.info("exPut ...");

        assertEquals(Document.parse("{'name':'John'}"), DocUtil.put(new Document(), "name", "John", true));

        assertEquals(Document.parse("{'name':{'first':'John'}}"),
            DocUtil.put(new Document(), "name.first", "John", true));

        assertEquals(Document.parse("{'name':{'first':'John'}}"),
            DocUtil.put(Document.parse("{'name':{}}"), "name.first", "John", true));

        assertEquals(Document.parse("{'friends':['John']}"), DocUtil.put(new Document(), "friends[0]", "John", true));

        assertEquals(Document.parse("{'name':{'friends':[null, null, null, {'phone':'1234'}]}}"),
            DocUtil.put(new Document(), "name.friends[3].phone", "1234", true));

        assertEquals(Document.parse("{'name':{'friends':[null, null, null, {'phone':'2222'}]}}"), DocUtil.put(
            DocUtil.put(new Document(), "name.friends[3].phone", "1234", true), "name.friends[3].phone", "2222", true));

        assertEquals(Document.parse("{'name':{'friends':[null, null, null,{'phone':'1234'},null,{'phone':'2222'}]}}"),
            DocUtil.put(DocUtil.put(new Document(), "name.friends[3].phone", "1234", true), "name.friends[5].phone",
                "2222", true));

        assertEquals(Document.parse("{'name':{'friends':['5678', null, null,{'phone':'1234'}]}}"), DocUtil
            .put(DocUtil.put(new Document(), "name.friends[3].phone", "1234", true), "name.friends[0]", "5678", true));
        assertEquals(Document.parse("{'name':{'friends':['Bob']}}"),
            DocUtil.put(Document.parse("{'name':{}}"), "name.friends[]", "Bob", true));
        assertEquals(Document.parse("{'name':{'friends':[null, 'Bob']}}"),
            DocUtil.put(Document.parse("{'name':{'friends':[null]}}"), "name.friends[]", "Bob", true));

        // put multiple
        assertEquals(Document.parse("{'name':{'friends':[null, 'Bob'], 'degrees':['computers']}}"),
            DocUtil.putAll(Document.parse("{'name':{'friends':[null]}}"),
                new JUtil.MsMap<String, String>().add("name.friends[]", "Bob").add("name.degrees[]", "computers"),
                true));

        // fillMissing false tests
        assertEquals(Document.parse("{'name':null}").toString(),
            DocUtil.put(Document.parse("{'name':'John'}"), "name", null).toString());
        assertEquals(Document.parse("{'name':'John'}").toString(),
            DocUtil.put(new Document(), "name", "John").toString());
        assertEquals(Document.parse("{'name':'Bob'}"), DocUtil.put(Document.parse("{'name':null}"), "name", "Bob"));
        assertEquals(Document.parse("{'name':'Bob'}"), DocUtil.put(Document.parse("{'name':'John'}"), "name", "Bob"));
        assertEquals(Document.parse("{'name':{'friends':['Bob']}}"),
            DocUtil.put(Document.parse("{'name':{'friends':['Alice']}}"), "name.friends[0]", "Bob"));
        assertEquals(Document.parse("{'name':{'friends':['Bob']}}"),
            DocUtil.put(Document.parse("{'name':{'friends':[null]}}"), "name.friends[0]", "Bob"));
        assertEquals(Document.parse("{'name':{'friends':[null]}}"),
            DocUtil.put(Document.parse("{'name':{'friends':['Bob']}}"), "name.friends[0]", null));
        assertEquals(Document.parse("{'name':{'friends':[{'name':'Bob','phone':'6789'}]}}"),
            DocUtil.put(Document.parse("{'name':{'friends':[{'name':'Bob'}]}}"), "name.friends[0].phone", "6789"));

        // validate exceptions
        assertThrows(MsValidationException.class, () -> { DocUtil.put(new Document(), "name.first", "John"); });

        assertThrows(NullPointerException.class, () -> {
            DocUtil.put(Document.parse("{'name':{'friends':null}}"), "name.friends[0]", "Bob");
        });
        assertThrows(IndexOutOfBoundsException.class, () -> {
            DocUtil.put(Document.parse("{'name':{'friends':[]}}"), "name.friends[0]", "Bob");
        });
        assertThrows(IndexOutOfBoundsException.class, () -> {
            DocUtil.put(Document.parse("{'name':{'friends':['Alice']}}"), "name.friends[3]", "Bob");
        });

        // get list and add
        assertEquals(Document.parse("{'name':{'friends':['Bob']}}"), of(Document.parse("{'name':{'friends':[]}}"))
            .map(d -> { DocUtil.get(d, "name.friends", List.class).add("Bob"); return d; }).get());
    }

    @Test
    public void large() throws Exception {
        log.info("large ...");

        Document dex = Document.parse(new String(Files.readAllBytes(Paths.get("src/test/resources/sample.json"))));
        assertEquals("RespiratoryDisorder", DocUtil.get(dex, "criticalInfoDetails.criticalInfoDiseaseDetails[2].name"));
        assertEquals("gsgsvsbh", DocUtil.get(dex, "personalInfo.familyInfo[1].details.firstName"));
        assertEquals("Pan Card", DocUtil.get(dex, "documentInfoDetails.piDocuments.details[1].proof"));
    }

    @Test
    public void docPw() throws Exception {
        log.info("docPw ...");
        DocPW dpw = new DocPW(new Document())
            .put("productNotificationSetting.$filter.input", "$productNotificationSetting")
            .put("productNotificationSetting.$filter.as", "$a1")
            .put("productNotificationSetting.$filter.cond.$eq[]", "$$a1.productId")
            .put("productNotificationSetting.$filter.cond.$eq[]", "1234");

        assertEquals(Document.parse(
            "{'productNotificationSetting': {'$filter': {'input': '$productNotificationSetting', 'as': '$a1', 'cond': {'$eq': ['$$a1.productId', '1234']}}}}\r\n"),
            dpw.doc());
    }

    @Data
    public static class MyPojo {
        String name    = "J Chinta";
        int    balance = 50;

        @JsonSerialize(using = IsoDateSerializer.class)
        @JsonDeserialize(using = IsoDateDeSerializer.class)
        Date updatedOn;

        @JsonIgnore
        Date getUpdatedOn() { return updatedOn; }
    }

    @Test
    public void dateSerialize() {
        log.info("dateSerialize ...");

        long now = System.currentTimeMillis();
        MyPojo mypojo1 = new MyPojo();
        mypojo1.updatedOn = new Date(now);
        assertTrue(JsonUtil.writeValueAsString(mypojo1).contains("$date"));

        MyPojo mypojo2 = JsonUtil.readValue("{'name':'J Chinta','balance':50,'updatedOn':{ '$date': '"
            + new SimpleDateFormat(IsoDateDeSerializer.MONGO_DATE_FORMAT).format(now) + "'}}", MyPojo.class);
        assertEquals(new Date(now), mypojo2.updatedOn);

        mypojo2 = JsonUtil.readValue("{'name':'J Chinta','balance':50,'updatedOn':{'$date':" + now + "}}",
            MyPojo.class);
        assertEquals(new Date(now), mypojo2.updatedOn);

        assertThrows(MsRuntimeException.class,
            () -> JsonUtil.readValue("{'name':'J Chinta','balance':50,'updatedOn':{ '$date': ''}}", MyPojo.class));
    }
}
