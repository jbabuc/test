package com.pmli.util.validation;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.java.MsValidationException;

import lombok.AllArgsConstructor;
import lombok.Data;

public class DemoValidationTest {

    @Data
    @AllArgsConstructor
    public static class ChildDetail {
        @FieldMetaJson("{displayName:'Birth Date', nullable:false, validations:'notBlank,isDate~yyyy-MM-dd~false'}")
        private String birthDate;

        @FieldMetaJson("{displayName:'Gender', nullable:false, validations:'notBlank'}")
        private String gender;

        @FieldMetaJson("{displayName:'Aspiration', nullable:false, validations:'greaterThan~-0'}")
        private int aspiration;

        @FieldMetaJson("{displayName:'Age', nullable:false, validations:'greaterThan~-0'}")
        private int age;
    }

    @Data
    @AllArgsConstructor
    public static class Name {
        String fn;
        String mn;
        String ln;
    }

    @Test
    public void demo() throws Exception {
        String s = "Test";
        assertThrows(MsValidationException.class,
            () -> { if (s.length() > 2) { throw new MsValidationException("err"); } });

        {
            StringValidator sv = new StringValidator(s, "My Var", false);
            sv.notNull();
            sv.notBlank();
            assertThrows(MsValidationException.class, () -> sv.isMaxLength(2));
        }

        // compile time or static binding
        Optional.of(new StringValidator(s, "My Var", false)).ifPresent(sv -> {
            sv.notNull();
            sv.notBlank();
            assertThrows(MsValidationException.class, () -> sv.isMaxLength(2));
        });

        assertThrows(MsValidationException.class, () -> new StringValidator(s, "My Var", false)
            .validateAll("notNull,notBlank,isMaxLength~$errmsg:My custom err msg~2"));

        // compile time or static binding with chaining
        assertThrows(MsValidationException.class,
            () -> new StringValidator(s, "My Var", false).validate(StringValidator::notNull)
                .validate(StringValidator::notBlank).validate(StringValidator::isMaxLength, 2));

        // compile time or static binding with chaining and custom error message
        assertThrows(MsValidationException.class,
            () -> new StringValidator(s, "My Var", false).validate(StringValidator::notNull)
                .validate(StringValidator::notBlank).validateEx(StringValidator::isMaxLength, 2, "My custom Error"));

        assertThrows(MsValidationException.class,
            () -> new ValidationHelper(new ChildDetail("2010", "M", 2, 0)).validateWithMetaJson());

        assertThrows(MsValidationException.class,
            () -> new ValidationHelper(new Name(ValidationHelperTest.STR_260, "mname", "lname"))
                .validateWithMetaJson());
    }
}
