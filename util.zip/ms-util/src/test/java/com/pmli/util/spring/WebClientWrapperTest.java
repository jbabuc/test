package com.pmli.util.spring;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import org.awaitility.Awaitility;
import org.bson.Document;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.java.ThreadUtil.HttpServer;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class WebClientWrapperTest extends MsObject {

    private static final String QUIT_SIGNAL = "QUIT_WCW_TEST";
    private static HttpServer   HTTP_SERVER = null;

    private static final String TEST_DOC = Document.parse("{userId:1,id:1,title:'test title',body:'test body'}")
        .toJson();

    @AfterAll
    public static void tearDown() throws IOException { HTTP_SERVER.shutdown(); }

    @BeforeAll
    public static void setUp() throws Exception {
        try {
            HTTP_SERVER = new HttpServer(1024, s -> {
                if (s.contains("ret-err"))
                    return "HTTP/1.1 400 Bad Request\nX-Custom:1234\nContent-Length:4\n\nFail".getBytes();
                return "HTTP/1.1 200 OK\nContent-Length:7\n\nSuccess".getBytes();
            });
            WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).get("", new HashMap<>());
        } catch (Exception ex) {
            ex.printStackTrace();
            System.setProperty(QUIT_SIGNAL, "true");
        }
    }

    @Test
    public void testPerformance() {
        WebClientWrapper wcw = WebClientWrapper.getWCW(HTTP_SERVER.getUrl());
        // WebClientWrapper wcw = WebClientWrapper.getWCW("http://jsonplaceholder.typicode.com");
        byte[] ret = wcw.get("/posts/1", new HashMap<>());
        log.info(new String(ret));
        ret = wcw.post("/posts", new HashMap<>(), TEST_DOC);
        log.info(new String(ret));

        long startTime = System.currentTimeMillis();
        AtomicInteger ai = new AtomicInteger();
        IntStream.range(0, 20).forEach(i -> {
            ai.incrementAndGet();
            wcw.postAsync("/posts", new HashMap<>(), TEST_DOC, (b) -> {
                assertNotNull(b);
                log.info("Response returned ..." + i + "..." + new String(b));
                ai.decrementAndGet();
            });
        });

        log.info("Request submission complete ...");
        Awaitility.await().until(() -> ai.intValue() == 0);
        log.info("All requests completed in - " + (System.currentTimeMillis() - startTime) + "ms");
    }

    @Test
    public void get() {
        if (Boolean.parseBoolean(System.getProperty(QUIT_SIGNAL))) return;

        assertNotNull(WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).getWebClient());
        byte[] ret = WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).get("/todos/1", new HashMap<>());
        assertEquals("Success", new String(ret));

        WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).getAsync("/posts", new HashMap<>(),
            b -> assertEquals("Success", new String(ret)));
    }

    @Test
    public void post() {
        if (Boolean.parseBoolean(System.getProperty(QUIT_SIGNAL))) return;

        byte[] ret = WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).post("/posts", new HashMap<>(), TEST_DOC);
        assertEquals("Success", new String(ret));

        WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).postAsync("/posts", new HashMap<>(), TEST_DOC,
            b -> assertEquals("Success", new String(ret)));
    }

    @Test
    public void errorTest() {
        if (Boolean.parseBoolean(System.getProperty(QUIT_SIGNAL))) return;

        WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).postAsync("/ret-err", new HashMap<>(), TEST_DOC, v -> {
            Assertions.fail();
        });
        assertEquals(Document.parse("{'status': 400, 'headers': {'X-Custom': ['1234'], 'Content-Length': ['4']}}"),
            Document.parse(assertThrows(MsRuntimeException.class,
                () -> WebClientWrapper.getWCW(HTTP_SERVER.getUrl()).post("/ret-err", new HashMap<>(), TEST_DOC))
                    .getMessage()));
        assertThrows(RuntimeException.class,
            () -> WebClientWrapper.getWCW("http://unknown.host.com").post("/ret-err", new HashMap<>(), TEST_DOC));
    }
}
