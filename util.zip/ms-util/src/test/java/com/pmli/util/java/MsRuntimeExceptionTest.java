package com.pmli.util.java;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

public class MsRuntimeExceptionTest {
    @Test
    public void test() {//
        assertNotNull(new MsRuntimeException("test"));
        assertNotNull(new MsRuntimeException(new MsRuntimeException("test")));
    }
}
