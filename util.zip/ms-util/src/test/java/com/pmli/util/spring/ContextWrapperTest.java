package com.pmli.util.spring;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.json.JsonUtil;

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class ContextWrapperTest extends MsObject {

    @Value("#{'${com.test.strs}'.split(',')}")
    private List<String> strs;

    // this will load the properties and enable logging
    @ComponentScan({ "com.pmli.util" })
    @SpringBootConfiguration
    public static class TestConfig {}

    @Test
    void contextWrapperTest() {
        log.info("contextWrapperTest .....");

        assertEquals(strs, Arrays.asList(new String[] { "ABC", "CDE", "EFG" }));
        assertEquals("value", ContextWrapper.getAppProperty("com.test.field", "defval"));
        assertEquals(new Integer(1000), ContextWrapper.getAppProperty("com.test.inte", new Integer(0)));
        assertEquals(JsonUtil.readJson("{'f1':'v1','f2':{'f3':'v3'}}"),
            ContextWrapper.getAppProperty("com.test.json", JsonNodeFactory.instance.objectNode()));

        assertThrows(MsRuntimeException.class, () -> {
            ContextWrapper.getAppProperty("com.test.json.invalid", JsonNodeFactory.instance.objectNode());
        });
            

        ContextWrapper.logAllProperties();

        assertNotNull(ContextWrapper.getContext());
        assertNotNull(ContextWrapper.getAppEnv());
        assertNotNull(ContextWrapper.getContext().getBean(TestBean.class));
        assertEquals("Val 1", ContextWrapper.getContext().getBean(TestBean.class).getField1());

        // test autowire on pojo
        // new instantiation beyond spring framework, will not be autowired
        TestPojo testPojo = new TestPojo();
        assertNull(testPojo.getTestBean());
        assertNull(testPojo.getTestProp());
        ContextWrapper.autoWire(testPojo); // invoke autowire
        assertNotNull(testPojo.getTestBean());
        assertEquals("Val 2", testPojo.getTestBean().getField2());
        assertEquals("testVal", testPojo.getTestProp());
    }
}
