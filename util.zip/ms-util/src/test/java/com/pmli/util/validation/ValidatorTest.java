package com.pmli.util.validation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class ValidatorTest extends MsObject {

    @Test
    public void basic() {
        log.info("basic ...");

        assertNotNull(new Validator("myval", "my field"));
        Validator v = new Validator("myval", "my field", false);
        assertEquals("myval", v.getVal());
        assertEquals("myval", v.getVal(String.class));
        assertEquals(false, v.isNullable());
        v.validate("notNull");
        assertThrows(IllegalArgumentException.class, () -> v.validate("notNull", "123"));
    }

    @Test
    public void chaining() {
        log.info("chaining ...");

        // compile-time static binding, using method references
        new StringValidator("abc@metlife.com", "Email field").validate(Validator::notNull)
            .validate(StringValidator::notBlank).validate(StringValidator::isEmail)
            .validate(StringValidator::isMaxLength, 30);
        new StringValidator("2020/9/13", "Date of Birth").validate(Validator::notNull)
            .validate(StringValidator::notBlank).validate(StringValidator::isDate, "yyyy/mm/dd", false);
        assertThat(assertThrows(MsValidationException.class, () -> {
            new StringValidator("2020/9/13", "Date of Birth").validate(Validator::notNull)
                .validate(StringValidator::notBlank).validate(StringValidator::isDate, "yyyy/mm/dd", true);
        }).getMessage()).isIn("Date of Birth=\"2020/9/13\", has invalid date format, expected format, yyyy/mm/dd.");

        // run-time dynamic binding using method names, fails at runtime if method names or parameters does not match
        new StringValidator("abc@metlife.com", "Email field").validate("notNull").validate("notBlank")
            .validate("isEmail").validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 10)
            .validate("endsWith", ".com");
        assertThrows(MsValidationException.class, () -> {
            new StringValidator("abc@metlife.com", "Email field").validate("notNull").validate("notBlank")
                .validate("isEmail").validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 20);
        });

        // configurable multi validations, comma to seperate methods and tilde method args
        new StringValidator("abc@metlife.com", "Email field")
            .validateAll("notNull,notBlank,isEmail,matchesRegEx~.*metlife.*,isMinLength~10");

        // mix and match
        new StringValidator("abc@metlife.com", "Email field").validateAll("notNull,notBlank,isEmail")
            .validate("matchesRegEx", ".*metlife.*").validate(StringValidator::isMaxLength, 30);

        // nullable, passes all if value is null
        new StringValidator(null, "Email field", true).validateAll("notNull,notBlank,isEmail")
            .validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 10).validateAll("isMaxLength~50");
        // nullable validates if value is not null
        assertThrows(MsValidationException.class, () -> {
            new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
                .validate("isEmail").validate("matchesRegEx", ".*metlife.*").validate("isMinLength", 20);
        });

        // custom error handling
        assertEquals("My custom message", assertThrows(MsValidationException.class, () -> {
            new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
                .validate("isEmail").validate("matchesRegEx",
                    (t) -> { throw new MsValidationException("My custom message"); }, ".*pnbmetlife.*");
        }).getMessage());

        // custom error message
        assertEquals("Email must be of pnbmetlife domain.", assertThrows(MsValidationException.class, () -> {
            new StringValidator("abc@metlife.com", "Email field", true).validate("notNull").validate("notBlank")
                .validate("matchesRegEx~$errmsg:Email must be of pnbmetlife domain.~.*@pnbmetlife.*");
        }).getMessage());

    }

    @Test
    public void validateEx() {
        new StringValidator("a", "Name").validateEx(StringValidator::notBlank, "No blanks please.");
        assertThat(assertThrows(MsValidationException.class, () -> {
            new StringValidator("", "Name").validateEx(StringValidator::notBlank, "No blanks please.");
        }).getMessage()).isIn("No blanks please.");

        new StringValidator("1234567890", "Number").validateEx(StringValidator::isLength, 10,
            "Need at least 10 chars.");
        assertThat(assertThrows(MsValidationException.class, () -> {
            new StringValidator("123", "Number").validateEx(StringValidator::isLength, 10, "Need at least 10 chars.");
        }).getMessage()).isIn("Need at least 10 chars.");

        new StringValidator("2020/09/13", "Date of Birth").validateEx(StringValidator::isDate, "yyyy/mm/dd", true,
            "Your date is not good.");
        assertThat(assertThrows(MsValidationException.class, () -> {
            new StringValidator("2020/9/13", "Date of Birth").validateEx(StringValidator::isDate, "yyyy/mm/dd", true,
                "Your date is not good.");
        }).getMessage()).isIn("Your date is not good.");
    }

    @Test
    public void otherTests() {
        // comparable validator tests
        new ComparableValidator("abc@metlife.com", "Email field").validate("greaterThan", "A").validate("lessThan", "b")
            .validate("equalsTo", "abc@metlife.com");

        new ComparableValidator(1, "Amount").validate("notEqualsTo", 0);

        new ComparableValidator("bc@m.com", "Email").validate("isBetween", "a", "c").validate("equalsTo", "bc@m.com");

        // comparable exception tests
        assertEquals("Email field=abc@metlife.com, must be greater than b.",
            assertThrows(MsValidationException.class, () -> {
                new StringValidator("abc@metlife.com", "Email field").greaterThan("b");
            }).getMessage());
        assertEquals("Email field=abc@metlife.com, must be less than A.",
            assertThrows(MsValidationException.class, () -> {
                new StringValidator("abc@metlife.com", "Email field").lessThan("A");
            }).getMessage());
        assertEquals("Email field=abc@metlife.com, must be equal to _abc@metlife.com.",
            assertThrows(MsValidationException.class, () -> {
                new StringValidator("abc@metlife.com", "Email field").equalsTo("_abc@metlife.com");
            }).getMessage());
        assertEquals("Amount=0, must not be equal to 0.", assertThrows(MsValidationException.class, () -> {
            new ComparableValidator(0, "Amount").validate("notEqualsTo", 0);
        }).getMessage());

        // list validator tests
        new ListValidator(Arrays.asList("val1", "val2"), "My List").validate("isMinLength", 1).validate("isMaxLength",
            2);

        // list validator exceptin tests
        assertEquals("My List=2, must contain min 3 element(s).", assertThrows(MsValidationException.class, () -> {
            new ListValidator(Arrays.asList("val1", "val2"), "My List").validate("isMinLength", 3);
        }).getMessage());
        assertEquals("My List=2, must contain max 1 element(s).", assertThrows(MsValidationException.class, () -> {
            new ListValidator(Arrays.asList("val1", "val2"), "My List").validate("isMaxLength", 1);
        }).getMessage());
    }
}
