package com.pmli.util.spring;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class TestBean { String field1 = "Val 1"; String field2 = "Val 2"; }
