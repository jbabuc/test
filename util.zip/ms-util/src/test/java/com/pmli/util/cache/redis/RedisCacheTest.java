package com.pmli.util.cache.redis;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.SerializationUtils;

import com.pmli.util.cache.MsCache;
import com.pmli.util.cache.MsCache.ExpireAtTime;
import com.pmli.util.cache.MsCache.GetOptions;
import com.pmli.util.java.MsObject;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisFuture;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.async.RedisAsyncCommands;

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class RedisCacheTest extends MsObject {

    @ComponentScan({ "com.pmli.util" })
    @SpringBootConfiguration
    public static class TestConfig {}

    RedisClient                             clientMock;
    StatefulRedisConnection<String, byte[]> statefulConnectionMock;
    RedisAsyncCommands<String, byte[]>      asyncCommondMock;
    RedisFuture<String>                     redisFutureMock;

    @Autowired
    SerializedObjectCodec codec;

    @Autowired
    MsCache msCache;

    @SuppressWarnings("unchecked")
    @BeforeEach
    public void createMocks() throws InterruptedException, ExecutionException {

        assertTrue(msCache instanceof RedisCacheImpl);

        clientMock = mock(RedisClient.class);
        statefulConnectionMock = mock(StatefulRedisConnection.class);
        asyncCommondMock = mock(RedisAsyncCommands.class);
        redisFutureMock = mock(RedisFuture.class);

        Mockito.doReturn(statefulConnectionMock).when(clientMock).connect();
        Mockito.doReturn(statefulConnectionMock).when(clientMock).connect(codec);
        Mockito.doReturn(asyncCommondMock).when(statefulConnectionMock).async();
        Mockito.doReturn(redisFutureMock).when(asyncCommondMock).get("Hello");

        ReflectionTestUtils.setField(msCache, "redisClient", clientMock);
    }

    @Test
    public void setInCacheForHalfHour() throws Exception {
        assertEquals("Hello World", getResponse(ExpireAtTime.AT_HALF_HOUR));
    }

    @Test
    public void setInCacheFor_3_Hour() throws Exception {
        assertEquals("Hello World", getResponse(ExpireAtTime.AT_EVERY_3RD_HOUR));
    }

    @Test
    public void setInCacheAtHour() throws Exception { assertEquals("Hello World", getResponse(ExpireAtTime.AT_HOUR)); }

    @Test
    public void setInCacheFor4Hour() throws Exception {
        assertEquals("Hello World", getResponse(ExpireAtTime.AT_EVERY_4TH_HOUR));
    }

    @Test
    public void setInCacheFor6Hour() throws Exception {
        assertEquals("Hello World", getResponse(ExpireAtTime.AT_EVERY_6TH_HOUR));
    }

    @Test
    public void setInCacheForADay() throws Exception { assertEquals("Hello World", getResponse(ExpireAtTime.AT_DAY)); }

    @Test
    public void deleteFromCache() throws Exception {
        Mockito.doReturn(redisFutureMock).when(asyncCommondMock).del("Hello");
        assertEquals("Hello World",
            msCache.get("Hello", x -> x.concat(" World"), ExpireAtTime.AT_DAY, GetOptions.DEFAULT));
    }

    @Test
    public void returnSource() throws Exception {
        Mockito.doReturn(statefulConnectionMock).when(clientMock).connect();
        assertNull(msCache.get("Hello", null, ExpireAtTime.AT_DAY, GetOptions.DELETE_CURRENT));
    }

    @Test
    public void returnSourceWhenExceptionOccured() throws Exception {
        Mockito.doThrow(NullPointerException.class).when(clientMock).connect();
        assertNull(msCache.get("Hello", null, ExpireAtTime.AT_DAY, GetOptions.DELETE_CURRENT));
    }

    @Test
    public void returnSourceWhenException() throws Exception {
        Mockito.doThrow(NullPointerException.class).when(clientMock).connect(codec);
        assertNull(msCache.get("Hello", null, ExpireAtTime.AT_DAY, GetOptions.DELETE_CURRENT));
    }

    @Test
    public void exceptionOccuredWhenGetFromCache() throws Exception {
        Mockito.doThrow(NullPointerException.class).when(redisFutureMock).get();
        String res = msCache.get("Hello", x -> x.concat(" World"), ExpireAtTime.AT_HALF_HOUR, GetOptions.DEFAULT);
        assertEquals("Hello World", res);
    }

    @Test
    public void getFromCache() throws Exception {
        Mockito.doReturn(SerializationUtils.serialize("Hello World")).when(redisFutureMock).get();
        String res = msCache.get("Hello", x -> x.concat(" World"), ExpireAtTime.AT_HALF_HOUR, GetOptions.DEFAULT);
        assertEquals("Hello World", res);
    }

    private Object getResponse(ExpireAtTime refreshInterval) throws Exception {
        Mockito.doReturn(null).when(redisFutureMock).get();
        Mockito.doReturn(redisFutureMock).when(asyncCommondMock).setex("Hello", 100,
            SerializationUtils.serialize("Hello World"));
        return msCache.get("Hello", x -> x.concat(" World"), refreshInterval, GetOptions.DEFAULT);
    }

}
