package com.pmli.util.mongo;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doNothing;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.pmli.util.java.MsObject;

import static com.pmli.util.mongo.MongoClientWrapper.QUERY_ALL;
import static com.pmli.util.mongo.MongoClientWrapper.FIELD_MONGO_ID;
import static com.pmli.util.mongo.MongoClientWrapper.DVAR_DEFAULT_MONGO_CLIENT_URI;
import static com.pmli.util.mongo.MongoClientWrapper.getMCW;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.bson.Document;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * @author 3495987jan
 */
@TestMethodOrder(MethodOrderer.MethodName.class)
public class MongoClientWrapperMockTest extends MsObject {
    private static final String NAME_DB    = "mydb";
    private static final String NAME_COLL  = "mycoll";
    final static String         DUMMY_URI  = "mongodb://user:password@dummyhost:27017/mydb?authSource=admin&serverSelectionTimeoutMS=2000";
    private static final String FIELD_NAME = "name";

    MongoClient                 mkMongo;
    MongoDatabase               mkMongoDb;
    MongoCollection<Document>   mkMongoColl;
    FindIterable<Document>      mkFindIterDocs;
    AggregateIterable<Document> mkAggregateIterable;
    MongoClientWrapper          mcWrapper;
    MongoClientWrapper          spyWrapper;

    private static final List<Document> getDummyDocs() {
        return Arrays.asList(new Document().append(FIELD_MONGO_ID, "1").append(FIELD_NAME, "name1"),
            new Document().append(FIELD_MONGO_ID, "2").append(FIELD_NAME, "name2"),
            new Document().append(FIELD_MONGO_ID, "3").append(FIELD_NAME, "name3"),
            new Document().append(FIELD_MONGO_ID, "4").append(FIELD_NAME, "name4"));
    }

    private static final List<String> getDummyIds() {
        return getDummyDocs().stream().map(d -> d.getString(FIELD_MONGO_ID)).collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    @BeforeEach
    public void setup() {
        mkMongo = mock(MongoClient.class);
        mkMongoDb = mock(MongoDatabase.class);
        mkMongoColl = mock(MongoCollection.class);
        mkFindIterDocs = mock(FindIterable.class);
        mkAggregateIterable = mock(AggregateIterable.class);

        when(mkMongo.getDatabase("admin")).thenReturn(mkMongoDb);
        // when(mkMongoDb.runCommand(Document.parse("{ping:1}"))).thenReturn(new Document());
        when(mkMongo.getDatabase(NAME_DB)).thenReturn(mkMongoDb);
        when(mkMongoDb.getCollection(NAME_COLL)).thenReturn(mkMongoColl);
        when(mkMongoColl.find(any(Document.class))).thenReturn(mkFindIterDocs);
        when(mkMongoColl.aggregate(any(List.class))).thenReturn(mkAggregateIterable);
        when(mkFindIterDocs.spliterator()).thenReturn(getDummyDocs().spliterator());
        when(mkAggregateIterable.spliterator()).thenReturn(getDummyDocs().spliterator());
        when(mkFindIterDocs.projection(any(Document.class))).thenReturn(mkFindIterDocs);

        mcWrapper = getMCW(DUMMY_URI);
        // inject mkMongo into private field
        ReflectionTestUtils.setField(mcWrapper, "client", mkMongo);

        spyWrapper = spy(mcWrapper);
    }

    @AfterEach
    public void tearDown() { mcWrapper.close(); }

    @Test
    public void getMCW_() {
        log.info("getMCW ...");

        assertEquals(mkMongo, mcWrapper.getClient());
        assertEquals(DUMMY_URI, mcWrapper.getURI().getURI());
        assertEquals(mcWrapper, getMCW(DUMMY_URI));

        System.getProperties().setProperty(DVAR_DEFAULT_MONGO_CLIENT_URI, DUMMY_URI);
        assertEquals(mcWrapper, getMCW());
    }

    @Test
    public void getCollection() {
        log.info("getCollection ...");
        spyWrapper.getCollection(NAME_DB, NAME_COLL);

        verify(mkMongo, times(1)).getDatabase(NAME_DB);
        verify(mkMongoDb).getCollection(NAME_COLL);
    }

    @Test
    public void getDocuments_1() {
        log.info("getDocuments_1 ...");

        List<Document> docs = spyWrapper.getDocuments(NAME_DB, NAME_COLL, QUERY_ALL);
        assertEquals(getDummyDocs(), docs);
    }

    @Test
    public void getDocuments_2() {
        log.info("getDocuments_2 ...");

        List<Document> docs;
        docs = spyWrapper.getDocuments(NAME_DB, NAME_COLL, QUERY_ALL, Arrays.asList(FIELD_NAME), null, -1, -1);

        // must fetch id
        verify(mkFindIterDocs).projection(Document.parse("{'name':1, '_id':1}"));
        // must sort by id
        verify(mkFindIterDocs).sort(Document.parse("{'_id':1}"));

        // id must be present
        assertEquals(getDummyDocs(), docs);

        docs = spyWrapper.getDocuments(NAME_DB, NAME_COLL, QUERY_ALL, Arrays.asList(FIELD_NAME),
            Arrays.asList(FIELD_NAME), -1, -1);
        verify(mkFindIterDocs).sort(Document.parse("{'name':1, '_id':1}"));

        docs = spyWrapper.getDocuments(NAME_DB, NAME_COLL, QUERY_ALL, Arrays.asList(FIELD_NAME),
            Arrays.asList("-" + FIELD_NAME), -1, -1);
        verify(mkFindIterDocs).sort(Document.parse("{'name':-1, '_id':1}"));
    }

    @Test
    public void getDocuments_3() {
        log.info("getDocuments_3 ...");

        List<Document> docs = mcWrapper.getDocuments(NAME_DB, NAME_COLL, QUERY_ALL, Arrays.asList(FIELD_NAME),
            Arrays.asList(FIELD_NAME), 2, 3);

        // verify sort, limit, skip and batchSize calls
        verify(mkMongoColl).find(Document.parse(QUERY_ALL));
        // id field must fetch
        verify(mkFindIterDocs).projection(Document.parse("{'name':1, '_id':1}"));
        // must sort by id
        verify(mkFindIterDocs).sort(Document.parse("{'name':1, '_id':1}"));
        verify(mkFindIterDocs).skip(2);
        verify(mkFindIterDocs).limit(3);
        verify(mkFindIterDocs).spliterator();

        // id must be present
        assertEquals(getDummyDocs(), docs);
    }

    @Test
    public void getDocumentById() {
        log.info("getDocuments_1 ...");
        spyWrapper.ping();
        assertNotNull(spyWrapper.getDocumentById(NAME_DB, NAME_COLL, QUERY_ALL, null));
        assertEquals(null, spyWrapper.getDocumentById(NAME_DB, NAME_COLL, QUERY_ALL, null));
    }
    
    @Test
    public void perform_aggregation_on_document() {
        List<Document> docs = spyWrapper.getAggregatedDocument(NAME_DB, NAME_COLL,
            Arrays.asList(new Document("$match", Document.parse("{'name':'name1'}"))));
        assertEquals(getDummyDocs(), docs);
    }

    @Test
    public void getIds() {
        log.info("getIds ...");

        List<String> ids = spyWrapper.getIds(NAME_DB, NAME_COLL, QUERY_ALL);

        assertEquals(getDummyIds(), ids);
    }

    @Test
    public void getIdDocMap() {
        log.info("getIdDocMap ...");

        Map<String, Document> docs = mcWrapper.getIdDocMap(NAME_DB, NAME_COLL, QUERY_ALL);

        assertEquals(getDummyIds(), docs.keySet().stream().collect(Collectors.toList()));
    }

    @Test
    public void getIdValueMap() {
        log.info("getIdValueMap ...");

        Map<String, String> docs = spyWrapper.getIdValueMap(NAME_DB, NAME_COLL, QUERY_ALL, FIELD_MONGO_ID, FIELD_NAME);

        assertEquals(getDummyDocs().stream()
            .collect(Collectors.toMap(d -> d.getString(FIELD_MONGO_ID), d -> d.getString(FIELD_NAME))), docs);
    }

    @Test
    public void insertOne() {
        log.info("insertOne ...");

        final String str_new_doc = "{'name':'test'}";
        final Document new_doc = Document.parse(str_new_doc);

        doNothing().when(mkMongoColl).insertOne(new_doc);

        spyWrapper.insertOne(NAME_DB, NAME_COLL, str_new_doc);

        verify(spyWrapper).insertOne(NAME_DB, NAME_COLL, new_doc);
        verify(mkMongoColl).insertOne(new_doc);
    }

    @Test
    public void updateMany() {
        log.info("updateMany ...");

        final String filter = "{'name':'test'}";
        final Document filter_doc = Document.parse(filter);
        final String update = "{'name':'test_updated'}";
        final Document update_doc = Document.parse(update);

        UpdateResult mkUpdateResult = mock(UpdateResult.class);
        when(mkMongoColl.updateMany(eq(filter_doc), eq(update_doc), any(UpdateOptions.class) /* equals fails */))
            .thenAnswer(new Answer<UpdateResult>() {
                @Override
                public UpdateResult answer(InvocationOnMock invocation) throws Throwable {
                    Object[] args = invocation.getArguments();
                    assertEquals(filter_doc, args[0]);
                    assertEquals(update_doc, args[1]);
                    assertEquals(false, ((UpdateOptions) args[2]).isUpsert());
                    return mkUpdateResult;
                }
            });
        when(mkUpdateResult.getModifiedCount()).thenReturn(2l);

        final long n = spyWrapper.updateMany(NAME_DB, NAME_COLL, filter, update, false);

        verify(spyWrapper).updateMany(eq(NAME_DB), eq(NAME_COLL), eq(filter_doc), eq(update_doc),
            any(UpdateOptions.class));
        verify(mkMongoColl).updateMany(eq(filter_doc), eq(update_doc), any(UpdateOptions.class));
        assertEquals(2, n);
    }

    @Test
    public void getCount() {
        log.info("getCount ...");

        final String filter = "{'name':'test'}";
        final Document filter_doc = Document.parse(filter);

        when(mkMongoColl.countDocuments(filter_doc)).thenReturn(20l);

        final long n = spyWrapper.getCount(NAME_DB, NAME_COLL, filter);

        verify(spyWrapper).getCount(NAME_DB, NAME_COLL, filter_doc);
        verify(mkMongoColl).countDocuments(filter_doc);
        assertEquals(20, n);
    }

    @Test
    public void deleteMany() {
        log.info("deleteMany ...");

        final String filter = "{'name':'test'}";
        final Document filter_doc = Document.parse(filter);

        DeleteResult mkDeleteResult = mock(DeleteResult.class);
        when(mkMongoColl.deleteMany(filter_doc)).thenReturn(mkDeleteResult);
        when(mkDeleteResult.getDeletedCount()).thenReturn(2l);

        final long n = spyWrapper.deleteMany(NAME_DB, NAME_COLL, filter);

        verify(spyWrapper).deleteMany(NAME_DB, NAME_COLL, filter_doc);
        verify(mkMongoColl).deleteMany(filter_doc);
        assertEquals(2, n);
    }
}