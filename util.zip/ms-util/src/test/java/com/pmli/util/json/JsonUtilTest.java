package com.pmli.util.json;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.pmli.util.java.MsRuntimeException;
import com.pmli.util.validation.ValidationHelperTest.Product;

public class JsonUtilTest {

    @Test
    public void readJsonTest() {
        assertNotNull(JsonUtil.readJson("{'f1':'v1','f2':{'f3':'v3'}}"));
        assertThrows(MsRuntimeException.class, () -> JsonUtil.readJson("{'f1':'v1','f2':{'f3':'v3'}"));
    }

    @Test
    public void readValueTest() {
        assertNotNull(
            JsonUtil.readValue("{'productId':1, 'productName':'pname', 'productDesc':'pdesc'}", Product.class));
        assertThrows(MsRuntimeException.class,
            () -> JsonUtil.readValue("{'productId':1, 'productName':'pname', 'productDesc':'pdesc'", Product.class));
    }

    public static class TestData {
        public String getEx() throws JsonProcessingException { throw new JsonParseException(null, "test"); }
    }

    @Test
    public void writeValueTest() {
        assertEquals(JsonUtil.readJson("{'productId':1, 'productName':'pname', 'productDesc':'pdesc'}"),
            JsonUtil.readJson(JsonUtil.writeValueAsString(new Product(1, "pname", "pdesc"))));
        assertThrows(MsRuntimeException.class, () -> JsonUtil.writeValueAsString(new TestData()));
    }

    @Test
    public void readArrayTest() {
        assertEquals(Arrays.asList(new Product(1, "pname1", "pdesc1"), new Product(2, "pname2", "pdesc2")),
            JsonUtil.readArray(
                "[{'productId':1, 'productName':'pname1', 'productDesc':'pdesc1'}, {'productId':2, 'productName':'pname2', 'productDesc':'pdesc2'}]",
                false, true, true, Product.class));
        assertThrows(MsRuntimeException.class, () -> JsonUtil.readArray(
            "[{'productId':1, 'productName':'pname1', 'productDesc':'pdesc1'}, {'productId':2, 'productName':'pname2', 'productDesc':'pdesc2'}",
            false, true, true, Product.class));
    }
}
