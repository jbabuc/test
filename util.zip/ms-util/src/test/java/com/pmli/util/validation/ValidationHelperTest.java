package com.pmli.util.validation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import static java.util.Optional.of;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.bson.Document;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.pmli.util.bson.DocUtil;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.java.ThreadUtil;
import com.pmli.util.json.JsonUtil;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class ValidationHelperTest extends MsObject {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Product {
        private int    productId;
        @FieldMetaJson("{validations:'notNull,notBlank'}")
        private String productName;
        // nullable but not blank
        @FieldMetaJson("{nullable:true,validations:'notBlank'}")
        private String productDesc;

        @Override
        public boolean equals(Object o) {
            if (o != null && o instanceof Product) {
                Product p = (Product) o;
                return this.productId == p.productId && this.productName.equals(p.productName)
                    && this.productDesc.equals(p.productDesc);
            }
            return false;
        }

        @Override
        public int hashCode() { return super.hashCode(); }
    }

    @Data
    public static class Fund {
        @FieldMetaJson("{displayName:'Fund Id',nullable:false,validations:'notNull,notBlank,isMaxLength~256,matchesRegEx~[0-9]*'}")
        private String fundId;
        @FieldMetaJson("{displayName:'Fund Name',nullable:false,validations:'notNull,notBlank'}")
        private String fundName;
        @FieldMetaJson("{displayName:'Fund Percent',nullable:false,validations:'notNull,greaterThan~-1'}")
        private int    fundPercent;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Amount {
        @FieldMetaJson("{displayName:'$parent currency',validations:'notNull,notBlank'}")
        private String currency;

        @FieldMetaJson("{displayName:'$parent',validations:'greaterThan~-1'}")
        private int amount;
    }

    @Data
    public static class TestData {
        @FieldMetaJson("{validations:'notNull'}")
        private Product    product;
        @FieldMetaJson("{validations:'notNull,isMinLength~1'}")
        private List<Fund> funds;
        @FieldMetaJson("{nullable:true,someOtherField:'someOtherInfo'}")
        public String      comment;
        @FieldMetaJson("{displayName:'Assured Amount'}")
        public Amount      assuredAmount;
        public Amount      bonusAmount;
        @FieldMetaJson("{ignoreValidations:true}")
        public Amount      premiumAmount;
    }

    public static final String STR_260 = "ZXhYpShu1fPuYsoY7jRaQEKI6RWNJ8dgGEbU5P8SJC1vPxjLm3xKD6phhvRxsGVJGuRyG6fufm3khaQ9v8vTSWWD79bk22EWWpKpL0yznsCq5TvptQcoPzkAMRxOkP87ejzzcb0HFZRXRtVsbNyZHXi90Bp22McVEuo4xRAjYyAsxOyPs6GdA3jZYuaPZgnrbbK9jGN9fOFhfJOzlUMhwyAcFcwGBVNENPY8uLNRqU1jvxWLl4r0NEw6ATCdVQielVxe";

    public static final String TEST_DOC = "{product:{productName:'pname'}, funds:[{fundId:'12345',fundName:'Fname1'}, {fundId:'123456',fundName:'Fname2'}], bonusAmount:{amount:100, currency:'INR'}, assuredAmount:{amount:10000, currency:'INR'}, premiumAmount:{amount:1000, currency:'INR'}}";

    @Test
    public void validateWithMetaJson() {
        log.info("validateWithMetaJson ...");

        // !!! TestUtil.setLogLevel(ValidationHelper.class, Level.DEBUG);

        // !!! JsonUtil.readValue is an expensive operation !!!
        { // success
            ValidationHelper vh = new ValidationHelper(JsonUtil.readValue(TEST_DOC, TestData.class));
            vh.validateWithMetaJson();
            assertEquals(22, vh.getValidationCount());
        }

        // nullability true default
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "product", null)).get().toJson(), TestData.class))
                .validateWithMetaJson();

        // no validations on basic type int
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "product.productId", 1)).get().toJson(),
            TestData.class)).validateWithMetaJson();

        // sub element nullability true default
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "product.productName", null)).get().toJson(),
            TestData.class)).validateWithMetaJson();

        // array nullability true default
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "funds", null)).get().toJson(), TestData.class))
                .validateWithMetaJson();

        // sub element blank spaces
        assertEquals("productName=\"  \", cannot be blank.", assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(
                of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "product.productName", "  ")).get().toJson(),
                TestData.class)).validateWithMetaJson();
        }).getMessage());

        // null test on array object sub element
        assertEquals("Fund Id cannot be null.", assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(
                of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "funds[1].fundId", null)).get().toJson(),
                TestData.class)).validateWithMetaJson();
        }).getMessage());

        // blank test on array object sub element
        assertEquals("Fund Name=\"\", cannot be blank.", assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(
                of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "funds[0].fundName", "")).get().toJson(),
                TestData.class)).validateWithMetaJson();
        }).getMessage());

        // no elements array
        assertEquals("funds=0, must contain min 1 element(s).", assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(
                of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "funds", Collections.emptyList())).get().toJson(),
                TestData.class)).validateWithMetaJson();
        }).getMessage());

        assertEquals("Assured Amount=-77, must be greater than -1.", assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(
                of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "assuredAmount.amount", -77)).get().toJson(),
                TestData.class)).validateWithMetaJson();
        }).getMessage());

        // ignore validations
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "premiumAmount", null)).get().toJson(),
            TestData.class)).validateWithMetaJson();

        // ignore validations on sub element
        new ValidationHelper(JsonUtil.readValue(
            of(Document.parse(TEST_DOC)).map(d -> DocUtil.put(d, "premiumAmount.amount", -88)).get().toJson(),
            TestData.class)).validateWithMetaJson();

        // multi validation failures, however, validations are skipped if parents fail
        assertThat(assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(of(Document.parse(TEST_DOC))//
                .map(d -> DocUtil.put(d, "funds", Collections.emptyList()))
                .map(d -> DocUtil.put(d, "product.productName", "  "))
                .map(d -> DocUtil.put(d, "assuredAmount.amount", -77))
                .map(d -> DocUtil.put(d, "assuredAmount.currency", null))
                .map(d -> DocUtil.put(d, "bonusAmount.amount", -77))
                .map(d -> DocUtil.put(d, "bonusAmount.currency", null)).get().toJson(), TestData.class))
                    .validateWithMetaJson();
        }).getMessage()).isIn("funds=0, must contain min 1 element(s).");

        // multi validation failures, any exception could be thrown as all failures are at same level deep and will
        // be processed parallel
        assertThat(assertThrows(MsValidationException.class, () -> {
            new ValidationHelper(JsonUtil.readValue(of(Document.parse(TEST_DOC)) //
                .map(d -> DocUtil.put(d, "assuredAmount.amount", -88))
                .map(d -> DocUtil.put(d, "assuredAmount.currency", null))
                .map(d -> DocUtil.put(d, "bonusAmount.amount", -77))
                .map(d -> DocUtil.put(d, "bonusAmount.currency", null)).get().toJson(), TestData.class))
                    .validateWithMetaJson();
        }).getMessage()).isIn("bonusAmount currency cannot be null.", "bonusAmount=-77, must be greater than -1.",
            "Assured Amount=-88, must be greater than -1.", "Assured Amount currency cannot be null.");

        // multi validation failures, any exception could be thrown as all failures are at same level deep and will
        // be processed parallel. process all validations switched on, all validations will be processed, exceptions
        // will be collected in a queue
        {
            ValidationHelper vh = new ValidationHelper(JsonUtil.readValue(of(Document.parse(TEST_DOC)) //
                .map(d -> DocUtil.put(d, "assuredAmount.amount", -88))
                .map(d -> DocUtil.put(d, "bonusAmount.amount", -77)).get().toJson(), TestData.class));
            vh.setProcessAllValidations(true);
            vh.validateWithMetaJson();
            List<String> exMsgs = vh.getExceptionList().stream().map(Exception::getMessage)
                .collect(Collectors.toList());
            List<String> expectedMsgs = Arrays.asList("bonusAmount=-77, must be greater than -1.",
                "Assured Amount=-88, must be greater than -1.");
            assertTrue(exMsgs.containsAll(expectedMsgs));
            of(vh.getConsolidatedExceptionMsg())
                .ifPresent(cem -> expectedMsgs.stream().forEach(em -> assertTrue(cem.contains(em))));
        }
    }

    @Data
    public static class UknownValidationData {
        // unknown validation
        @FieldMetaJson("{validations:'unknownValidation,notBlank'}")
        private int someId;
    }

    @Data
    public static class ArrayMapData {
        private String[]            strArray = new String[] { "Test Value 1", "Test Value 2" };
        @FieldMetaJson("{validations:'isMinLength~2',mapElementDataValidations:{validations:'isMinLength~3'}}")
        private Map<String, String> myMap    = new JUtil.MsMap<String, String>().add("One", "One 1").add("Two", "Two 2")
            .add("Three", "Three 3");

        // for default validation coverage
        private Map<String, String> myMap2 = new JUtil.MsMap<String, String>().add("One", "One 1").add("Two", "Two 2")
            .add("Three", "Three 3");

        @FieldMetaJson("{validations:'isMinLength~2',listElementDataValidations:{validations:'greaterThan~0'}}")
        private int[]    ia     = { 1, 2, 3 };
        private String[] strs   = { "a", "b", "c" };
        @FieldMetaJson("{validations:'isMinLength~2',listElementDataValidations:{validations:'notBlank,isEmail'}}")
        private String[] emails = { "a@abc.com", "b@abc.com", "c@abc.com" };
    }

    @Test
    public void validateWithMetaJsonDefault() {
        log.info("validateWithMetaJsonDefault ...");

        assertEquals("currency=\"" + STR_260 + "\", length must be max 256 characters long.",
            assertThrows(MsValidationException.class, () -> {
                new ValidationHelper(new Amount(STR_260, 10)).validateWithMetaJson();
            }).getMessage());

        assertEquals("strArray[1]=\"" + STR_260 + "\", length must be max 256 characters long.",
            assertThrows(MsValidationException.class, () -> {
                ArrayMapData amd = new ArrayMapData();
                amd.strArray[1] = STR_260;
                new ValidationHelper(amd).validateWithMetaJson();
            }).getMessage());

        assertEquals("myMap[str260]=\"" + STR_260 + "\", length must be max 256 characters long.",
            assertThrows(MsValidationException.class, () -> {
                ArrayMapData amd = new ArrayMapData();
                amd.myMap.put("str260", STR_260);
                new ValidationHelper(amd).validateWithMetaJson();
            }).getMessage());

        assertEquals("myMap[" + STR_260 + "]=\"" + STR_260 + "\", length must be max 256 characters long.",
            assertThrows(MsValidationException.class, () -> {
                ArrayMapData amd = new ArrayMapData();
                amd.myMap.put(STR_260, "str260");
                new ValidationHelper(amd).validateWithMetaJson();
            }).getMessage());

        assertEquals("strs[2]=\"" + STR_260 + "\", length must be max 256 characters long.",
            assertThrows(MsValidationException.class, () -> {
                ArrayMapData amd = new ArrayMapData();
                amd.strs[2] = STR_260;
                new ValidationHelper(amd).validateWithMetaJson();
            }).getMessage());

    }

    @Test
    public void validateWithMetaJsonArrays() {
        log.info("validateWithMetaJsonArrays ...");

        assertEquals("ia[2]=-1, must be greater than 0.", assertThrows(MsValidationException.class, () -> {
            ArrayMapData amd = new ArrayMapData();
            amd.ia[2] = -1;
            new ValidationHelper(amd).validateWithMetaJson();
        }).getMessage());

        assertEquals("emails[2]=\"c\", must be a valid email.", assertThrows(MsValidationException.class, () -> {
            ArrayMapData amd = new ArrayMapData();
            amd.emails[2] = "c";
            new ValidationHelper(amd).validateWithMetaJson();
        }).getMessage());

        assertEquals("Max validations count exceeded, 1000.", assertThrows(MsValidationException.class, () -> {
            ArrayMapData amd = new ArrayMapData();
            amd.emails = IntStream.range(0, 1002).mapToObj(i -> "abc" + i + "@xyz.com").collect(Collectors.toList())
                .toArray(new String[0]);
            new ValidationHelper(amd).validateWithMetaJson();
        }).getMessage());

        assertEquals("Method not found: com.pmli.util.validation.ComparableValidator.unknownValidation",
            assertThrows(MsValidationException.class, () -> {
                new ValidationHelper(JsonUtil.readValue("{someId:1234}", UknownValidationData.class))
                    .validateWithMetaJson();
            }).getMessage());
    }

    // @Test
    public void zValidateWithMetaJsonPerformance() {//
        List<Method> methods = Arrays.asList(this.getClass().getMethods()).stream().map(m -> (Method) m)
            .filter(m -> m.getAnnotation(Test.class) != null)
            .filter(m -> !m.getName().equals("zValidateWithMetaJsonPerformance")).collect(Collectors.toList());

        ThreadUtil.runParallel(10, 10, (c) -> {
            methods.forEach(m -> {
                try {
                    ((Method) m).invoke(this);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            });
            return null;
        });
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Calc {
        Amount a1;
        @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{displayName:'Amount A2',nullable:false,childPath:'amount',validations:'greaterThan~100'}]}")
        Amount a2;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CCalc {
        @FieldMetaJson("{displayName:'Calc',nullable:false,childDataValidations:[{nullable:false,displayName:'Calc Amount A1',childPath:'a1.amount',validations:'greaterThan~100'}]}")
        Calc c;
    }

    @Test
    public void childDataValidations() {
        log.info("childDataValidations ...");

        JUtil.setLogLevel(ValidationHelper.class, ch.qos.logback.classic.Level.DEBUG);

        assertEquals("Calc Amount A1 cannot be null.", assertThrows(MsValidationException.class,
            () -> new ValidationHelper(new CCalc(new Calc(null, null))).validateWithMetaJson()).getMessage());

        Calc c = new Calc(new Amount("INR", 10), new Amount("INR", 20));
        assertEquals("Amount A2=20, must be greater than 100.",
            assertThrows(MsValidationException.class, () -> new ValidationHelper(c).validateWithMetaJson())
                .getMessage());

        CCalc cc = new CCalc(c);
        assertEquals("Calc Amount A1=10, must be greater than 100.",
            assertThrows(MsValidationException.class, () -> new ValidationHelper(cc).validateWithMetaJson())
                .getMessage());

        assertEquals("Child validations require non empty childPath value.",
            assertThrows(MsValidationException.class, () -> new ValidationHelper(cc, JsonUtil.readValue(
                "{displayName:'Calc',nullable:false,childDataValidations:[{nullable:false,displayName:'Calc Amount A1',childPath_:'a1.amount',validations:'greaterThan~100'}]}",
                DataValidations.class)).validateWithMetaJson()).getMessage());
    }
}
