package com.pmli.util.db;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.pmli.util.java.MsObject;

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class HibernateSessionWrapperTest extends MsObject {

    // this will load the properties and enable logging
    @ComponentScan({ "com.pmli.util" })
    @SpringBootConfiguration
    public static class TestConfig {}

    @Test
    public void execute() {
        HibernateSessionWrapper hsw = HibernateSessionWrapper.getHSW("test");
        hsw.executeUpdate("CREATE TABLE cars(name VARCHAR(255), price INT)");
        hsw.executeUpdate("INSERT INTO cars(name, price) VALUES('Bolero', 10)");
        hsw.executeUpdate("INSERT INTO cars(name, price) VALUES('Baleno', 8)");
        hsw.executeUpdate("INSERT INTO cars(name, price) VALUES('Ciaz', 9)");
        hsw.executeUpdate("INSERT INTO cars(name, price) VALUES('Swift', 7)");

        assertNotNull(hsw.getDsName());
        assertNotNull(hsw.getConfig());
        assertNotNull(hsw.getDataSource());
        assertNotNull(hsw.getSessionFactory());

        List<?> cars = hsw.getResults("SELECT name, price from cars");
        assertEquals(4, cars.size());
        
        cars = hsw.getResults("select name, price from cars where name='Swift'");
        assertEquals("7", ((Object[])cars.get(0))[1].toString());
        
        hsw.executeUpdate("UPDATE cars set price=6 where name='Swift' ");
        cars = hsw.getResults("select name, price from cars where name='Swift'");
        assertEquals("6", ((Object[])cars.get(0))[1].toString());
        
        hsw.executeUpdate("DELETE  from CARS where name='Swift'");
        cars = hsw.getResults("SELECT name, price from cars");
        assertEquals(3, cars.size());
    }
}
