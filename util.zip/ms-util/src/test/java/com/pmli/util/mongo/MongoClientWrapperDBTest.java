package com.pmli.util.mongo;

import com.mongodb.DBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.util.JSON;
import com.pmli.util.java.MsObject;

import static com.pmli.util.mongo.MongoClientWrapper.DF_UTC;
import static com.pmli.util.mongo.MongoClientWrapper.FIELD_MONGO_ID;
import static com.pmli.util.mongo.MongoClientWrapper.getMCW;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.stream.IntStream;

import org.bson.Document;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * @author 3495987jan
 */
@SuppressWarnings("deprecation")
@TestMethodOrder(MethodOrderer.MethodName.class)
public class MongoClientWrapperDBTest extends MsObject {
    private final static String DB    = "msutil-test";
    private final static String COLL  = "books";
    private final static String query = "{authors:/.*Robi.*/}";

    private static boolean isQuit() { return Boolean.parseBoolean(System.getProperty("QUIT_DB_TEST")); }

    @BeforeAll
    public static void setUp() throws Exception {
        getSL().info("setUp ...");
        try {
            getMCW().getURI();
            getMCW().ping(); // quit if this fails
        } catch (Exception ex) {
            getSL().error("DB connection failed", ex);
            System.setProperty("QUIT_DB_TEST", "true");

            getSL().info("Default DB not found, skipping testWithLocalMongoDB ... {}",
                System.getProperty(MongoClientWrapper.DVAR_DEFAULT_MONGO_CLIENT_URI));
            getSL().info("To set default, {}",
                "-DDEFAULT_MONGO_CLIENT_URI=mongodb://user:password@localhost:27017/data-dbname?authSource=auth-dbname");
            return;
        }

        assertEquals(getMCW(), getMCW());

        // setup DB, insert
        File resourceFile = new File(
            MongoClientWrapperDBTest.class.getClassLoader().getResource("books-json.txt").getFile());
        Files.readAllLines(resourceFile.toPath(), StandardCharsets.ISO_8859_1).stream().forEach(l -> {
            DBObject dbo = ((DBObject) JSON.parse(l)); // json parsing to avoid date format issue
            dbo.put("publishedDate", new Date(new Random().nextInt()));
            getSL().trace(dbo.toString());
            getMCW().insertOne(DB, COLL, dbo.toString());
        });
    }

    @AfterAll
    public static void tearDown() throws Exception {
        if (isQuit()) return;

        getSL().info("tearDown ...");
        // drop DB
        getSL().info("Dropping db msutil-test ...");
        getMCW().getDatabase("admin").runCommand(new Document("grantRolesToUser", "admin").append("roles",
            Collections.singletonList(new Document("role", "dbAdmin").append("db", DB))));
        getMCW().getDatabase(DB).drop();
        getMCW().close();
    }

    @Test
    public void dbFind() {
        if (isQuit()) return;
        log.info("dbFind ...");

        FindIterable<Document> docs = getMCW().getCollection(DB, COLL).find(Document.parse(query))
            .projection(Document.parse("{_id:1, title:1, publishedDate: 1}")).sort(Document.parse("{title:-1}")).skip(1)
            .limit(10).batchSize(20);
        // StreamSupport.stream(docs.spliterator(), false).forEach(d -> System.out.println(d));
        assertEquals(6, StreamSupport.stream(docs.spliterator(), false).count());
    }

    @Test
    public void wrapperFind() {
        if (isQuit()) return;
        log.info("wrapperFind ...");

        List<Document> docs = getMCW().getDocuments(DB, COLL, query, null, null, -1, -1);
        assertTrue(0 < docs.size());
        assertTrue(0 < docs.get(0).keySet().size());

        List<Document> docs1 = getMCW().getDocuments(DB, COLL, query, Arrays.asList("_id", "title", "publishedDate"),
            Arrays.asList("-title"), 0, 3);
        assertEquals(3, docs1.size());
        // check sort order descending by title
        assertTrue(0 < docs1.get(0).getString("title").compareTo(docs1.get(1).getString("title")));
        assertTrue(0 < docs1.get(1).getString("title").compareTo(docs1.get(2).getString("title")));

        List<Document> docs2 = getMCW().getDocuments(DB, COLL, query, Arrays.asList("_id", "title", "publishedDate"),
            Arrays.asList("title"), 3, 3);
        assertEquals(3, docs2.size());
        assertNotEquals(docs1, docs2);
        // assert sort order ascending by title
        assertTrue(0 > docs2.get(0).getString("title").compareTo(docs2.get(1).getString("title")));
        assertTrue(0 > docs2.get(1).getString("title").compareTo(docs2.get(2).getString("title")));

        // records between dates
        log.info("Found docs with date search ... {}",
            getMCW().getDocuments(DB, COLL,
                "{publishedDate:{$gte:ISODate('1970-01-01T10:03:46.000Z'),$lte:ISODate('2020-06-31T00:00:00.000Z')}}",
                Arrays.asList("_id", "title", "publishedDate"), Arrays.asList("-title")).size());

        // get
        assertEquals(7, getMCW().getCount(DB, COLL, query));
        assertEquals(7, getMCW().getIds(DB, COLL, query).size());
        assertEquals(7, getMCW().getIdValueMap(DB, COLL, query, FIELD_MONGO_ID, "publishedDate").size());
        assertEquals(7, getMCW().getIdDocMap(DB, COLL, query).size());
    }

    @Test
    public void update() {
        if (isQuit()) return;
        log.info("update ...");

        assertEquals(1, getMCW().updateMany(DB, COLL, "{title:'Unlocking Android'}",
            "{$set:{title:'Unlocking Android 1'}}", false));
    }

    @Test
    public void zperformance() throws Exception {
        if (isQuit()) return;
        log.info("performance ...");
        final int nthreads = 50;
        final int niterations = 100;

        AtomicInteger result_count = new AtomicInteger();
        Optional.of(System.currentTimeMillis()).ifPresent(start -> {
            List<Thread> threads = IntStream.range(0, nthreads).mapToObj(i -> new Thread(new Runnable() {
                public void run() {
                    log.info("Thread started, {}", Thread.currentThread().getName());
                    SimpleDateFormat sdf = new SimpleDateFormat(DF_UTC);
                    IntStream.range(0, niterations).forEach(i -> {
                        long rand_start = new Random().nextInt();
                        long rand_end = rand_start + new Random().nextInt();
                        result_count
                            .addAndGet(
                                getMCW()
                                    .getDocuments(DB, COLL,
                                        "{publishedDate:{$gte:ISODate('" + sdf.format(new Date(rand_start))
                                            + "'),$lte:ISODate('" + sdf.format(new Date(rand_end)) + "')}}",
                                        Arrays.asList("_id", "title", "publishedDate"), Arrays.asList("-title"))
                                    .size());
                    });
                    log.info("Thread complete, {}, result count: {}", Thread.currentThread().getName(), result_count);
                }
            }, "Thread-" + i)).map(t -> (Thread) t).collect(Collectors.toList());
            threads.forEach(t -> t.start());
            threads.forEach(t -> {
                try {
                    t.join();
                } catch (Exception ex) {}
            });
            log.info("All threads completed in {} seconds", (System.currentTimeMillis() - start) / 1000);
        });

        assertTrue(0 < result_count.get());
    }

    @Test
    public void zzdelete() {
        if (isQuit()) return;
        log.info("zdelete ...");

        assertEquals(7, getMCW().deleteMany(DB, COLL, query));
    }
}