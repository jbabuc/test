package com.pmli.util.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import lombok.Data;

@Data
public class TestPojo {

    @Autowired
    TestBean testBean;

    @Value("${com.pmli.util.spring.testProp}")
    String testProp;

    public TestPojo() {}
}
