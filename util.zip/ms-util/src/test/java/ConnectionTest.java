import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.Test;

import com.pmli.util.db.HibernateSessionWrapper;
import com.pmli.util.java.JUtil.MsMap;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.mongo.MongoClientWrapper;
import com.pmli.util.spring.WebClientWrapper;

public class ConnectionTest {

    public static void main(String[] args) {
        switch ("oracle") {
        case "mongo":
            MongoClientWrapper mcw = MongoClientWrapper.getMCW(
                "mongodb://buyonlineUatUser:msDeveloper2021@10.168.50.147:27017/buy-online-uat?authSource=buy-online-uat");
            List<String> ids = mcw.getIds("buy-online-uat", "LeadDetail", "{}");
            ids.forEach(id -> System.out.println(id));
            return;

        case "oracle":
            HibernateSessionWrapper hsw = new HibernateSessionWrapper("myoracle", new MsMap<String, String>() //
                .add("myoracle.db.driver", "oracle.jdbc.OracleDriver") //
                .add("myoracle.db.hibernate.dialect", "org.hibernate.dialect.OracleDialect") //
                .add("myoracle.db.username", "PORTAL_DATA") //
                .add("myoracle.db.password", "PORTAL_DATA_QA123") //
                .add("myoracle.db.url", "jdbc:oracle:thin:@10.168.50.47:1521:EWDSTGQA"));
            String query = "SELECT * FROM ODS_QA.POL_MSTR WHERE ROWNUM <= 5";
            System.out.println(JsonUtil.writeValueAsString(hsw.getResultsAsMap(query)));
            return;

        case "rest":
            WebClientWrapper wcw = WebClientWrapper.getWCW("http://jsonplaceholder.typicode.com");
            wcw.post("/posts", new MsMap<String, String>().add("Content-Type", "application/json"),
                Document.parse("{userId:1,id:1,title:'test title',body:'test body'}").toJson());
            return;
        }
    }

    @Test // dummy test to fix sonar complaint
    public void dummy() { assertTrue(true); }
}
