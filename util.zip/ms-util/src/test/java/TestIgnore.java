
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.bson.DocUtil.DocPW;
import com.pmli.util.db.HibernateSessionWrapper;
import com.pmli.util.java.JUtil.MsMap;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.mongo.MongoClientWrapper;
import com.pmli.util.spring.WebClientWrapper;
import com.pmli.util.validation.ValidationHelper;

import lombok.Data;

public class TestIgnore {

    public static void main(String[] args) {//
        String TEST_DOC = Document.parse("{userId:1,id:1,title:'test title',body:'test body'}").toJson();
        WebClientWrapper wcw = WebClientWrapper.getWCW("http://jsonplaceholder.typicode.com");
        byte[] ret = wcw.post("/posts", new HashMap<>(), TEST_DOC);
        System.out.println("---------" + new String(ret));
        ret = wcw.get("/posts/1", new HashMap<>());
        System.out.println("------------" + new String(ret));
    }

    public static void main11e(String[] args) {//
        HibernateSessionWrapper hsw = new HibernateSessionWrapper("myoracle", new MsMap<String, String>() //
            .add("myoracle.db.driver", "oracle.jdbc.OracleDriver") //
            .add("myoracle.db.hibernate.dialect", "org.hibernate.dialect.OracleDialect") //
            .add("myoracle.db.username", "ODS_QA") //
            .add("myoracle.db.password", "ODS_QA123") //
            .add("myoracle.db.url", "jdbc:oracle:thin:@10.168.50.47:1521:EWDSTGQA"));
        // String query = "SELECT * FROM TABLE (IDS_DMZ.PKG_CRMNEXT.CRMNEXT_POL_JL('', '20383646', '','', '', '', ''))";
        // String query = "SELECT * FROM TABLE ( IDS_DMZ.PKG_CRMNEXT.CRMNEXT_POL_SUMARY('50784152','','','','','',''))";
        String query = "SELECT * FROM ODS_QA.mv_agg_pol_master where POLICY_NO = '00000653'";

        System.out.println(JsonUtil.writeValueAsString(hsw.getResultsAsMap(query)));
        return;
    }

    @Data
    public static class MyData {
        String  name;
        @JsonProperty("isAutoCompleted")
        @JsonAlias("autoCompleted")
        boolean isAutoCompleted;
    }

    public static void mainwee(String[] args) {

        /*
         * MyData m = JsonUtil.readValue("{'name':'abc', 'autoCompleted':true}", MyData.class);
         * System.out.println(JsonUtil.writeValueAsString(m));
         */
        DocPW dpw = new DocPW(new Document())
            .put("productNotificationSetting.$filter.input", "$productNotificationSetting")
            .put("productNotificationSetting.$filter.as", "$a1")
            .put("productNotificationSetting.$filter.cond.$eq[]", "$$a1.productId")
            .put("productNotificationSetting.$filter.cond.$eq[]", "1234");

        System.out.println(dpw.doc().toJson());

    }

    public static void main11(String[] args) {

        String productId = "12007";
        List<Document> docs = Arrays.asList(new Document("$project", Document.parse(
            "{'productNotificationSetting': {'$filter': {'input': '$productNotificationSetting','as': 'a1','cond': {'$eq': ['$$a1.productId','"
                + productId + "']}}}}")),

            new Document("$project", Document.parse(
                "{'productNotificationSetting.productId':true,'productNotificationSetting.productName':true,'productNotificationSetting.uin':true}")),

            new Document("$lookup", Document.parse(
                "{from: 'Prd_ProductConfig',localField: 'productId',foreignField: 'productNotificationSetting.productId',as: 'titleAndMeta'}")),

            new Document("$project", Document.parse(
                "{'productNotificationSetting':1,'titleAndMeta': {'$filter': {'input': '$titleAndMeta','as': 'a1','cond': {'$eq': ['$$a1.productId', "
                    + productId + "]}}}}")),

            new Document("$project", Document.parse(
                "{'productNotificationSetting':1,'titleAndMeta.title':1,'titleAndMeta.utmRedirection':1,'titleAndMeta.meta':1}")),

            Document.parse("{$unwind:'$titleAndMeta'}"));

        System.out.println(docs);

        List<Document> result_docs = MongoClientWrapper
            .getMCW("mongodb://buyonlineqaUser:msDeveloper2021@10.168.50.147:27017/buy-online-qa")
            .getAggregatedDocument("buy-online-qa", "AppConfig", docs);

        System.out.println(result_docs);
    }
}
