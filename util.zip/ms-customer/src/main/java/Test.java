import java.math.BigDecimal;
import java.math.RoundingMode;

public class Test {
    public static void main(String[] args) {
        System.out.println(new BigDecimal(10.0123).setScale(2,RoundingMode.DOWN));
    }
}
