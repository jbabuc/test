package com.pmli.bo.cron.app;

import java.util.List;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.PaymentProps;
import com.pmli.ms.bo.customer.config.SaveApplicationProps;
import com.pmli.ms.bo.customer.helper.ApplicationCrmHelper;
import com.pmli.ms.bo.customer.helper.CreateApplicationHelper;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Body;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Product;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Riders;
import com.pmli.ms.bo.customer.response.ApplicationCrmResponse;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.CommUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

@SpringBootApplication(scanBasePackages = {}, exclude = { MongoAutoConfiguration.class,
    MongoDataAutoConfiguration.class, ErrorMvcAutoConfiguration.class, HibernateJpaAutoConfiguration.class,
    DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class,
    HibernateJpaAutoConfiguration.class })
@ComponentScan("com.pmli")
public class ApplicationNumberRetry extends MsObject {

    public static final String RECORD_STATUS_UPDATE_FAIL = "#UPDATE_FAIL#";

    @Autowired
    private DBClient dbClient;

    @Autowired
    private RestConsumer restConsumer;

    @Autowired
    private PaymentProps paymentProps;

    @Autowired
    private CommonProps commonProps;

    @Autowired
    private SaveApplicationProps saveApplicationProps;

    @Autowired
    private EmailClient emailClient;

    public static void main(String[] args) {
        getSL().info("ApplicationNumberRetry started ... ");
        try {
            ConfigurableApplicationContext ctx = SpringApplication.run(ApplicationNumberRetry.class, args);
            ContextWrapper.logAllProperties();

            ContextWrapper.autoWire(new ApplicationNumberRetry()).execute();
            ctx.close();
        } catch (Exception th) {
            getSL().info("Error encountered", th);
        }
        getSL().info("Execution complete, exiting !!!");
        System.exit(1);
    }

    /**
     * fetch failed application number. call save application for getting application number. update application number.
     */
    public void execute() {
        String query = String.format(
            "{ $or: [ { %1$s: { $exists: false } }, { %1$s: null }, { %s: '' }, { %s: /%s/ }]}",
            FieldConstants.LD_APPLICATIONUMBER, FieldConstants.LD_RECORD_STATUS, RECORD_STATUS_UPDATE_FAIL);
        log.info("Executing query: {}", query);
        List<Document> docs = dbClient.getBuyOnlineMCW().getDocuments(dbClient.getDbName(),
            dbClient.getCollectionLeadDetail(), query);

        docs.stream().forEach(d -> {
            try {

                LeadDetail ld = JsonUtil.readValue(d.toJson(), LeadDetail.class);
                Body body = new Body(d.getString(FieldConstants.LD_QUOTATIONID),
                    CreateApplicationHelper.getIspiposame(Integer.parseInt(d.getString("buyType"))),
                    ld.getApplicationNumber());
                Product product = new Product(ld.getPremiumCalculation(), ld.getFunds());
                Riders riders = new Riders(CreateApplicationHelper.getCrmRidersFromModel(ld.getRiders(), product));
                product.setRiders(riders);
                body.setProduct(product);
                body.getModuleStatus();
                ApplicationCrmRequest saveApplicationRequest = new ApplicationCrmRequest();
                saveApplicationRequest.setBody(body);
                if (saveApplicationRequest.getBody().getQuoteId() != null) {
                    ApplicationCrmHelper applicationCrmHelper = new ApplicationCrmHelper(dbClient, emailClient,
                        commonProps, restConsumer, saveApplicationProps, paymentProps, saveApplicationRequest);
                    log.debug("SaveApplicationRequest: {}", JsonUtil.writeValueAsString(saveApplicationRequest));
                    ApplicationCrmResponse response = applicationCrmHelper.saveApplicationToCrm();
                    if (null != response && response.getBody().getApplicationNumber() != null
                        && !response.getBody().getApplicationNumber().isEmpty()) {
                        log.info("SaveApplicationResponse: {}", response.getBody().getApplicationNumber());
                        ld.setApplicationNumber(response.getBody().getApplicationNumber());
                        applicationCrmHelper.updateApplicationNumber(ld);
                    }
                } else {
                    log.warn("Missing quotation Id on LeadDetail: {}", ld.getLeadId());
                }
            } catch (Exception ex) {
                log.error("Unable to process record: ", ex);
                CommUtil.sendError(ex);
            }
        });
    }
}
