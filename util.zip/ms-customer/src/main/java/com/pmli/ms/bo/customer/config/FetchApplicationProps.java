package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;
@Getter
@Component
public class FetchApplicationProps {
	@Value("${" + Constants.BASE_PATH + "fetch.application.error.msg.detail}")
	private String errorMsgDetail;

	@Value("${" + Constants.BASE_PATH + "fetch.application.error.msg.data.not.found}")
	private String errorMsgDataNotFound;

	@Value("${" + Constants.BASE_PATH + "fetch.application.error.msg.blank.id}")
	private String errorMsgBlankId;

	@Value("${" + Constants.BASE_PATH + "fetch.application.error.msg.mandatory.field}")
	private String errorMsgMandatoryField;

}
