package com.pmli.ms.bo.customer.helper;

import org.apache.commons.lang3.StringUtils;

import com.pmli.ms.bo.customer.request.CreateBasicLeadRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;

import lombok.NoArgsConstructor;

/**
 * <p>
 * This class consists of the helper methods required for the implementation of the Create basic lead detail API.
 * </p>
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */

@NoArgsConstructor
public class CreateBasicLeadHelper extends MsObject {
    
    
    
    /**
     * This method is use validate request for create basic lead details API
     * 
     * @param request
     */
    public void validateCreateBasicLeadRequest(CreateBasicLeadRequest request) {
        new ValidationHelper(request).validateWithMetaJson();

        request.getPhones().stream().filter(p -> StringUtils.isNotEmpty(p.getTypeCode()))
            .forEach(p -> new StringValidator(p.getTypeCode(), "Phone Type Code", false)
                .validateAll("matchesRegEx~$errmsg:Invalid Phone Type Code.~(MOBILE|LANDLINE|OFFICE)$"));
    }
    
    
    
    /**
     * This method is use return integer for boolean value
     * 
     * @param  suitabilityAnalysis
     * @return                     the String contains the integer value
     */
    public String getSuitabilityAnalysis(String suitabilityAnalysis) {
        if (suitabilityAnalysis.equalsIgnoreCase("true")) { return "1"; }
        return "2";
    }
}
