package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * This class holds the response details for create-lead API
 * 
 * @author 3448466ami
 */

@Data
@AllArgsConstructor
@ApiModel(description = "This is the response bean for create-lead operation")
public class LeadDetailBiResponse {
	@ApiModelProperty(value = "Lead Id", example = "09032021145852676")
	private String leadId;
	@ApiModelProperty(value = "Continue Journey Link", example = "https://uat-ebranchnxt.pnbmetlife.com/buy-online/Pre-Payment/trackapplication/navigation?leadid=20210920113050862619")
	private String continueJourneyLink;
}
