package com.pmli.ms.bo.customer.request;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.config.SaveApplicationProps;
import com.pmli.ms.bo.customer.helper.CreateApplicationHelper;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.model.LeadDetailPremium;
import com.pmli.util.spring.ContextWrapper;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class ApplicationCrmRequest {
    static SaveApplicationProps saveProps;
    static {
        saveProps = ContextWrapper.getContext().getBean(SaveApplicationProps.class);
    }
    private Body body;
    private static final String CURRENCY_CODE_INR = "INR";

    @Data
    public static class ModuleStatus {
        private int product;
        private int policyInsured;
        private int policyOwner;
        private int nominees;
        private int medical;
        private int lifestyle;
        private int payment;
        private int jointLife;
        private int agentAndSpecifiedPerson;
        private int agentDeclaration;
        private int document;
        private int saveOrSubmit;
        @JsonProperty("eSignature")
        private int signature;
        private int panDetails;
        private int circleOfLife;

        public ModuleStatus() {
            this.product = 1;
            this.policyInsured = 0;
            this.policyOwner = 0;
            this.nominees = 0;
            this.medical = 0;
            this.lifestyle = 0;
            this.payment = 0;
            this.jointLife = 0;
            this.agentAndSpecifiedPerson = 0;
            this.agentDeclaration = 0;
            this.document = 0;
            this.saveOrSubmit = 0;
            this.signature = 0;
            this.panDetails = 0;
            this.circleOfLife = 0;
        }

    }

    @Data
    @AllArgsConstructor
    public static class Money {
        private String amount;
        private String currencyCode;

        public Money(com.pmli.util.model.Money m) {
            amount = m.getAmount() != null ? "" + m.getAmount() : null;
            currencyCode = m.getCurrencyCode();
        }
    }

    @Data
    public static class SaveRider {
        private Money  sumAssured;
        private int    termInYears;
        private String name;
        private int    healthExtra;
        private String id;
    }

    public static class Riders {
        private List<SaveRider> rider;

        public List<SaveRider> getRider() { return rider; }

        public Riders(List<SaveRider> rider) { this.rider = rider; }
    }

    @Data
    public static class Product {
        private String     channelName;
        private String     productName;
        private String     productCode;
        private String     coverageTermInYears;
        private String     premiumTermInYears;
        private String     frequency;
        private Money      premiumAmount;
        private Money      sumAssured;
        private String     deathBenefit;
        private Riders     riders;
        private int        isBackdation;
        private String     backdationDate;
        private String     paymentType;
        private String     calculationType;
        private String     planOption;
        private String     multiple;
        private String     autoRebalance;
        private String     staticTransferOption;
        private String     rebalancePercentage;
        private String     sourceFund;
        private String     destinationFund;
        private String     regularIncomeOption;
        private Money      incomeAmount;
        private String     payoutFrequency;
        private String     paymentMode;
        private Money      seriousIllnessRiderPremium;
        private Money      seriousIllnessRiderPremiumWithoutTax;
        private String     paymentOption;
        private String     bonusOption;
        private String     returnOfPremium;
        private String     benefitPayoutDate;
        private String     defermentPeriod;
        private String     incomePayoutMode;
        private String     annuityOption;
        private String     annuityType;
        private String     annuityPaymentMode;
        private List<Fund> funds;
        private Money      modalPremiumTax;
        private Money      premiumAmountWsTax;
        private Money      metSmartPremium;
        private String     premiumPayFreq;
        private String     sumAssuredofThePrimaryLifeAssured;
        private Money      accidentalDeathBenefitRiderPremium;
        private Money      accidentalDeathBenefitRiderPremiumWithoutTax;

        public Product(CreateApplicationRequest car, DBClient dbClient) {
            this.channelName = saveProps.getChannelName();
            this.productName = car.getPremiumCalculation().getProductName();
            this.productCode = CreateApplicationHelper.getProductCode(dbClient,
                car.getPremiumCalculation().getProductId());
            this.coverageTermInYears = "" + car.getPremiumCalculation().getCoverTerm();
            this.premiumTermInYears = "" + car.getPremiumCalculation().getPaymentTerm();
            this.frequency = CreateApplicationHelper.getFrequencyValue(car.getPremiumCalculation().getFrequencyCode());
            this.premiumAmount = new Money(car.getPremiumCalculation().getPremiumAmount());
            this.sumAssured = new Money(car.getPremiumCalculation().getSumAssuredAmount());
            this.isBackdation = Integer.parseInt(saveProps.getIsbackdation());
            this.paymentType = CreateApplicationHelper
                .getFrequencyValue(car.getPremiumCalculation().getFrequencyCode());
            this.calculationType = CreateApplicationHelper
                .getCalculationType(car.getPremiumCalculation().getFrequencyCode());
            this.planOption = CreateApplicationHelper.getPlanOption(car.getPremiumCalculation().getPlanName(),
                car.getPremiumCalculation().getProductId(), car.getPremiumCalculation().getPlanId());
            this.multiple = saveProps.getMultiple();
            this.autoRebalance = saveProps.getAutoRebalance();
            this.staticTransferOption = saveProps.getStaticTransferOption();
            this.incomeAmount = new Money("0", saveProps.getCurrencyCode());
            this.paymentOption = CreateApplicationHelper.getPaymentOption(car.getPremiumCalculation().getPaymentTerm(),
                car.getPremiumCalculation().getCoverTerm());
            this.bonusOption = CreateApplicationHelper.getBonusOption(dbClient,
                car.getPremiumCalculation().getProductId(), car.getPremiumCalculation().getCashBonusOption());
            this.returnOfPremium = saveProps.getReturnOfPremium();
            this.defermentPeriod = CreateApplicationHelper.getDefermentPeriod(
                car.getPremiumCalculation().getProductId(), car.getPremiumCalculation().getDeferment());
            this.incomePayoutMode = CreateApplicationHelper.getIncomePayoutMode(dbClient,
                car.getPremiumCalculation().getProductId(), car.getPremiumCalculation().getCashBonusOption());
            this.annuityOption = CreateApplicationHelper.getAnnuityOption(car.getPremiumCalculation().getProductId(),
                car.getPremiumCalculation().getPlanId(), car.getPremiumCalculation().getPaymentTerm());
            ofNullable(car.getFunds()).ifPresent(rdlist -> funds = rdlist.stream()
                .map(r -> new Fund(r.getFundId(), r.getFundPercent())).collect(Collectors.toList()));
            this.modalPremiumTax = new Money(car.getPremiumCalculation().getModalPremiumAmount());
            this.premiumAmountWsTax = new Money(car.getPremiumCalculation().getModalPremiumAmount());
            this.metSmartPremium = getMetSmartPremiumAmount(
                car.getPremiumCalculation().getModalPremiumAmount().getAmount(),
                car.getPremiumCalculation().getServiceTaxAmount().getAmount());
            this.premiumPayFreq = CreateApplicationHelper
                .getFrequencyValue(car.getPremiumCalculation().getFrequencyCode());
            this.benefitPayoutDate = "";
            setDefaultValues();
        }

        public Product(LeadDetailPremium premium, List<Fund> funds) {
            this.channelName = saveProps.getChannelName();
            this.productName = premium.getProductName();
            this.productCode = premium.getProductName();
            this.coverageTermInYears = "" + premium.getCoverTerms();
            this.premiumTermInYears = "" + premium.getPaymentTerms();
            this.frequency = premium.getFrequency();
            this.premiumAmount = new Money(premium.getPremium(), CURRENCY_CODE_INR);
            this.sumAssured = new Money(premium.getSumAssured(), CURRENCY_CODE_INR);
            this.isBackdation = Integer.parseInt(saveProps.getIsbackdation());
            this.paymentType = premium.getFrequency();
            this.calculationType = ""; //
            this.planOption = ""; //
            this.multiple = saveProps.getMultiple();
            this.autoRebalance = saveProps.getAutoRebalance();
            this.staticTransferOption = saveProps.getStaticTransferOption();
            this.incomeAmount = new Money("0", saveProps.getCurrencyCode());
            this.bonusOption = premium.getCashBonusOptions();
            this.returnOfPremium = saveProps.getReturnOfPremium();
            this.benefitPayoutDate = premium.getBenefitPayoutDate();
            this.defermentPeriod = "" + premium.getDeferment();
            this.incomePayoutMode = premium.getIncomePayoutMode();
            ofNullable(funds).ifPresent(fds -> this.funds = fds.stream()
                .map(f -> new Fund(f.getFundId(), f.getFundPercent())).collect(Collectors.toList()));
            this.modalPremiumTax = new Money(premium.getModalPremium(), CURRENCY_CODE_INR);
            this.premiumAmountWsTax = new Money(premium.getAnnualPremium(), CURRENCY_CODE_INR);
            this.metSmartPremium = null;
            this.paymentOption = "";//
            this.annuityOption = "";
            this.premiumPayFreq = "";
            setDefaultValues();
        }

        public Product(LeadDetail ld, DBClient dbClient) {
            this.channelName = saveProps.getChannelName();
            this.productName = ld.getPremiumCalculation().getProductName();
            this.productCode = String.valueOf(ld.getPremiumCalculation().getProductId());
            this.coverageTermInYears = "" + ld.getPremiumCalculation().getCoverTerms();
            this.premiumTermInYears = "" + ld.getPremiumCalculation().getPaymentTerms();
            this.frequency = ld.getPremiumCalculation().getFrequency();
            ofNullable(ld.getPremiumCalculation().getPremium())
                .ifPresent(n -> this.premiumAmount = new Money(ld.getPremiumCalculation().getPremium(),
                    CURRENCY_CODE_INR));
            this.premiumAmount = new Money(ld.getPremiumCalculation().getPremium(), CURRENCY_CODE_INR);
            this.sumAssured = new Money(ld.getPremiumCalculation().getSumAssured(), CURRENCY_CODE_INR);
            this.isBackdation = Integer.parseInt(saveProps.getIsbackdation());
            this.paymentType = ld.getPremiumCalculation().getFrequency();
            this.calculationType = CreateApplicationHelper
                .getCalculationType(Integer.parseInt(ld.getPremiumCalculation().getFrequency()));
            this.planOption = CreateApplicationHelper.getPlanOption(ld.getPremiumCalculation().getPlanName(),
                ld.getPremiumCalculation().getProductId(), ld.getPremiumCalculation().getPlanId());
            this.multiple = saveProps.getMultiple();
            this.autoRebalance = saveProps.getAutoRebalance();
            this.staticTransferOption = saveProps.getStaticTransferOption();
            this.incomeAmount = new Money("0", saveProps.getCurrencyCode());
            this.paymentOption = CreateApplicationHelper.getPaymentOption(
                Integer.parseInt(ld.getPremiumCalculation().getPaymentTerms()),
                Integer.parseInt(ld.getPremiumCalculation().getCoverTerms()));
            this.bonusOption = CreateApplicationHelper.getBonusOption(dbClient,
                ld.getPremiumCalculation().getProductId(),
                Integer.parseInt(ld.getPremiumCalculation().getCashBonusOptions()));
            this.returnOfPremium = saveProps.getReturnOfPremium();
            this.defermentPeriod = ld.getPremiumCalculation().getDefermentValue();
            this.incomePayoutMode = ld.getPremiumCalculation().getIncomePayoutMode();
            this.annuityOption = CreateApplicationHelper.getAnnuityOption(ld.getPremiumCalculation().getProductId(),
                ld.getPremiumCalculation().getPlanId(), Integer.parseInt(ld.getPremiumCalculation().getPaymentTerms()));
            this.modalPremiumTax = new Money(String.valueOf(ld.getPremiumCalculation().getModalPremium()),
                CURRENCY_CODE_INR);
            this.premiumAmountWsTax = new Money(String.valueOf(ld.getPremiumCalculation().getModalPremium()),
                CURRENCY_CODE_INR);
            this.metSmartPremium = getMetSmartPremiumAmount(
                new BigDecimal(ld.getPremiumCalculation().getModalPremium()),
                new BigDecimal(ld.getPremiumCalculation().getServiceTax()));
            this.premiumPayFreq = ld.getPremiumCalculation().getFrequency();
            this.benefitPayoutDate = "";
            setDefaultValues();
        }

        /**
         * This method get met smartpremium Amount WsTax from createApplicationRequest
         * 
         * @param  modelPremiumAmt
         * @param  serviceTaxAmt
         * @return
         */
        public Money getMetSmartPremiumAmount(BigDecimal modelPremiumAmt, BigDecimal serviceTaxAmt) {
            BigDecimal totalRiderPremium = new BigDecimal(0);
            totalRiderPremium = totalRiderPremium.add(modelPremiumAmt != null ? modelPremiumAmt : new BigDecimal(0));
            totalRiderPremium = totalRiderPremium.add(serviceTaxAmt != null ? serviceTaxAmt : new BigDecimal(0));
            return new Money("" + totalRiderPremium, CURRENCY_CODE_INR);
        }

        private void setDefaultValues() {
            this.deathBenefit = "";
            this.backdationDate = "";
            this.rebalancePercentage = "";
            this.sourceFund = "";
            this.destinationFund = "";
            this.regularIncomeOption = "";
            this.payoutFrequency = "";
            this.paymentMode = "";
            this.annuityType = "";
            this.annuityPaymentMode = "";
            this.sumAssuredofThePrimaryLifeAssured = "";
        }
    }

    @Data
    public static class Body {
        private String       applicationNo;
        private String       quoteId;
        private String       emailSent;
        private String       smsSent;
        private String       sellOnlineType;
        private String       fnaId;
        private int          isPiPoSame;
        private int          isJointLife;
        private int          nomineeCount;
        private String       lastSavedQuestion;
        private String       transactionType;
        private String       channelName;
        private ModuleStatus moduleStatus;
        private Product      product;

        public Body(String quoteId, int isPiPoSame, String applicationNo) {
            this.quoteId = quoteId;
            this.applicationNo = ofNullable(applicationNo).orElse("");
            this.emailSent = null;
            this.smsSent = null;
            this.sellOnlineType = saveProps.getSaleOnlineType();
            this.fnaId = "";
            this.isPiPoSame = isPiPoSame;
            this.isJointLife = 0;
            this.nomineeCount = 0;
            this.lastSavedQuestion = "";
            this.transactionType = saveProps.getTrasactionType();
            this.channelName = saveProps.getChannelName();
            this.moduleStatus = new ModuleStatus();
        }

        public Body(LeadDetail leadDetail, int isPiPoSame) {
            this.quoteId = leadDetail.getQuotationId();
            this.applicationNo = ofNullable(leadDetail.getApplicationNumber()).orElse("");
            this.emailSent = null;
            this.smsSent = null;
            this.sellOnlineType = saveProps.getSaleOnlineType();
            this.fnaId = "";
            this.isPiPoSame = isPiPoSame;
            this.isJointLife = 0;
            this.nomineeCount = 0;
            this.lastSavedQuestion = "";
            this.transactionType = saveProps.getTrasactionType();
            this.channelName = saveProps.getChannelName();
            this.moduleStatus = new ModuleStatus();
        }
    }
}
