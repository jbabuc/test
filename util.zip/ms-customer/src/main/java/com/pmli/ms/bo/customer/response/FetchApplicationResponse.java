package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * This class holds the response details for Fetch Application
 * 
 * @author Snehal Shimpi
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
public class FetchApplicationResponse {
	@ApiModelProperty(value = "Lead Id", example = "09032021145852676")
	private String leadId;
	@ApiModelProperty(value = "Quotation Id", example = "79876677")
	private String quotationId;
	@ApiModelProperty(value = "Application Id", example = "150039151")
	private String applicationNumber;
	
	public FetchApplicationResponse() {
		//Default Constructor
	}

}
