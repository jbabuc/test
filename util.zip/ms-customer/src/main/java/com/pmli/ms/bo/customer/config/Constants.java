package com.pmli.ms.bo.customer.config;

public class Constants {

    private Constants() {
        // Default Constructor
    }
    public static final String BIRTH_DATE_FORMAT = "yyyy-MM-dd";

    public static final String DIGITS_1_32_REGEX             = "^[0-9]{1,32}$";
    public static final String VALIDATIONS_DIGITS_1_32_REGEX = "validations:'matchesRegEx~^[0-9]{1\\\\,32}$'";

    // Plan Constants
    public static final String  BASE_PATH       = "com.pmli.bo.customer.";
    private static final String ERROR_BASE_PATH = BASE_PATH + "error.msg.";
    private static final String HYSTRIX_ERROR   = BASE_PATH + "hystrix.error.";

    // Hystrix error message constants
    public static final String HYSTRIX_ERROR_INFO     = HYSTRIX_ERROR + "info";
    public static final String HYSTRIX_ERROR_MESSAGE  = HYSTRIX_ERROR + "msg";
    public static final String VALIDATIONS            = BASE_PATH + "validations.";
    public static final String PRODUCT_CHANNEL        = BASE_PATH + "product.channel";
    public static final String COLLECTION_LEAD_DETAIL = BASE_PATH + "collection.lead.detail";
    public static final String DATABASE_BUY_ONLINE    = BASE_PATH + "mongodb.dbname";
    public static final String CLIENT_ADDRESS         = BASE_PATH + "client.ip";

    // Add Payment Constant
    public static final String DATE_FORMAT                      = BASE_PATH + "date.format";
    public static final String ERROR_MSG_INTERNAL_SERVER_ERROR  = ERROR_BASE_PATH + "internal.server.error";
    public static final String PAYMENT_SUCCESS_MSG              = BASE_PATH + "success.msg.payment";
    public static final String PROPOSAL_FORM_LINK               = BASE_PATH + "proposal.form.link";
    public static final String ERROR_MSG_LEADID_APPNUMBER_BLANK = ERROR_BASE_PATH + "blank.leadid.appNumber";

    public static final String NVEST_TOKEN               = BASE_PATH + "premium.token";
    public static final String LEAD_ID_GENERATION_FORMAT = BASE_PATH + "leadId.generation.format";

    // AES Constant
    public static final String AES_ALGORTHIM   = BASE_PATH + "algorithm.name";
    public static final String AES_PROVIDER    = BASE_PATH + "provider.name";
    public static final String AES_INIT_VECTOR = BASE_PATH + "init.vector";
    public static final String SECRET_KEY      = BASE_PATH + "secret.key";

    // Create Application Constants
    public static final String CREATE_APPLICATION             = BASE_PATH + "create.application";
    public static final String ERROR_MSG_FALLBACK             = BASE_PATH + "error.msg.fallback";
    public static final String ERROR_MSG_RECORD_ALREADY_FOUND = BASE_PATH + "create.application.already.exits";
    public static final String ERROR_MSG_ALREADY_QUATATION_ID = BASE_PATH
        + "create.application.quotation-id.already.exits";
    public static final String AUTHORIZATION                  = BASE_PATH + "authorization";
    public static final String X_IBM_CLIENT_ID                = BASE_PATH + "x-ibm-client-id";
    public static final String REQUEST_ID                     = BASE_PATH + "requestId";
    public static final String CHANNEL                        = BASE_PATH + "channel";
    public static final String USERID                         = BASE_PATH + "userId";
    public static final String SOURCE                         = BASE_PATH + "source";

    public static final String SAVE_APPLICATION = BASE_PATH + "save.application";
    public static final String EMAIL            = BASE_PATH + "send.email.";
    public static final String DOWNLOAD_APP_FORM = BASE_PATH + "download.app.form";
}
