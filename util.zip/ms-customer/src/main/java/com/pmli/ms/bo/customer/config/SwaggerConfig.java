
package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.pmli.util.web.MsBaseConfig;

import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {

    @Value("${com.pmli.bo.customer.swagger.api.v1.version}")
    public String version;

    @Value("${com.pmli.bo.customer.swagger.api.v1.groupname}")
    public String groupName;

    @Value("${com.pmli.bo.customer.swagger.api.title}")
    public String title;

    @Value("${com.pmli.bo.customer.swagger.api.desc}")
    public String desc;

    @Value("${com.pmli.bo.customer.swagger.api.basepackage}")
    public String basePackage;

    @Bean
    public Docket callproductApi() { return MsBaseConfig.productApi(basePackage, title, desc, groupName, version); }

}
