package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class HeightWeightDetails {
    private String heightInFeet;
    private String heightInInch;
    private String weight;
}
