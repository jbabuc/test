package com.pmli.ms.bo.customer.request;

import java.util.List;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Address;
import com.pmli.util.model.Email;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Add Customer Details
 * 
 * @author 3483784san
 */
@Data
public class CustomerRequest {
	@ApiModelProperty(required = true, value = "Buy Type Code", example = "2")
	@FieldMetaJson("{displayName:'Buy Type Code',validations:'greaterThan~0,lessThan~3'}")
	protected int buyTypeCode;

	@ApiModelProperty(required = true, value = "Educational Qualification", example = "2")
	protected int educationalQualification;

	@ApiModelProperty(required = true, value = "Occupation", example = "1")
	@FieldMetaJson("{displayName:'Occupation',nullable:false,validations:'greaterThan~0'}")
	protected int occupation;

	@ApiModelProperty(required = true, value = "Gender", example = "Male")
	@FieldMetaJson("{displayName:'Gender',nullable:false,validations:'notBlank'}")
	protected String gender;

	@ApiModelProperty(required = true, value = "Age", example = "21")
	@FieldMetaJson("{displayName:'Age',nullable:false,validations:'greaterThan~$errmsg:Age must be greater than or equal to 18.~17,lessThan~$errmsg:Age must be greater than or equal to 65.~66'}")
	protected int age;

	@ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
	@FieldMetaJson("{displayName:'Birth Date',nullable:false,validations:'notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$'}")
	protected String birthDate;

	@ApiModelProperty(required = true, value = "Suitability Analysis", example = "2")
	@FieldMetaJson("{displayName:'Suitability Analysis',validations:'greaterThan~0,lessThan~3'}")
	protected int suitabilityAnalysis;

	@ApiModelProperty(required = false, value = "Quotation Id", example = "")
	protected String quotationId;

	protected String proposalNumber;

	@ApiModelProperty(required = true, value = "Step", example = "2")
	@FieldMetaJson("{displayName:'Suitability Analysis',validations:'greaterThan~0,lessThan~7'}")
	protected int step;

	@ApiModelProperty(required = true, value = "Application Number", example = "")
	protected String applicationNumber;

	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
	protected Address address;

	@FieldMetaJson("{nullable:false,childDataValidations:[{childPath:'title',displayName:'title',validations:'notBlank,notNull'},{childPath:'firstName',displayName:'firstName',validations:'notBlank,notNull'},{childPath:'lastName',displayName:'lastName',validations:'notBlank,notNull'}]}")
	protected Name name;

	protected FamilyMember familyMember;

	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'address',displayName:'Email Address',validations:'notBlank,notNull,isEmail'}]}")
	protected Email email;

	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'Annual Income Amount',validations:'greaterThan~$errmsg:Annual income should be >=100000.~99999'}]}")
	protected Money annualIncomeAmount;

	@FieldMetaJson("{nullable:false,validations:'notNull',listElementDataValidations:{childDataValidations:[{childPath:'number',displayName:'Phone Number',validations:'notNull,notBlank,matchesRegEx~$errmsg:Mobile Number length should be 10 digits.~^([0-9]{10})$'}]}}")
	protected List<PhoneNumber> phoneNumbers;

}
