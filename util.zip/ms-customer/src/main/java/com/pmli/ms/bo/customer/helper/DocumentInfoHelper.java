package com.pmli.ms.bo.customer.helper;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest.Details;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest.DocumentInfoDetails;
import com.pmli.util.validation.Validator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class DocumentInfoHelper {
    DBClient            dbClient;
    CommonProps         commonProps;
    DocumentInfoRequest request;

    public DocumentInfoRequest validate(String quotationId) {

        new Validator(request, "Document Info Request", false).notNull();
        new Validator(request.getDocumentInfoDetails(), "Document Info Details", false).notNull();
        DocumentInfoDetails dd = request.getDocumentInfoDetails();

        if (dd.getPoDocuments() != null) {
            List<Details> po = request.getDocumentInfoDetails().getPoDocuments().getDetails();
            po.stream().forEach(a -> pathChecker(a, quotationId, "Data not found for PoDocuments"));
        }
        if (dd.getPiDocuments() != null) {
            List<Details> pi = request.getDocumentInfoDetails().getPiDocuments().getDetails();
            pi.stream().forEach(a -> pathChecker(a, quotationId, "Data not found for PiDocuments"));
        }
        if (dd.getBankDocuments() != null) {
            List<Details> pi = request.getDocumentInfoDetails().getBankDocuments().getDetails();
            pi.stream().forEach(a -> pathChecker(a, quotationId, "Data not found for BankDocuments"));
        }
        if (dd.getJointLifeDocuments() != null) {
            List<Details> pi = request.getDocumentInfoDetails().getJointLifeDocuments().getDetails();
            pi.stream().forEach(a -> pathChecker(a, quotationId, "Data not found for JointLifeDocuments"));
        }
        if (dd.getBankJointLifeDocuments() != null) {
            List<Details> pi = request.getDocumentInfoDetails().getBankJointLifeDocuments().getDetails();
            pi.stream().forEach(a -> pathChecker(a, quotationId, "Data not found for BankJointLifeDocuments"));
        }
        return request;
    }

    public void pathChecker(Details d, String quotationId, String modeDetail) {
        if (!dbClient.isFileRefs(quotationId, d.getPath()).isEmpty()) {
            d.setPath(dbClient.isFileRefs(quotationId, d.getPath()));
        } else {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                commonProps.getErrMsgDataNotFound(), modeDetail);
        }
    }
}
