package com.pmli.ms.bo.customer.request;

import java.util.List;

import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.util.java.FieldMetaJson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the Add Riders request details
 * 
 * @author  Snehal Shimpi
 * @version 1.0.0
 */

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class RidersRequest extends LeadRequest {
    @FieldMetaJson("{nullable:false}")
    private List<PremiumCalculation> riders;
}
