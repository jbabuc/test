package com.pmli.ms.bo.customer.helper;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.AppointeeInfo;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Basic;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Contact;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.DocumentProof;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.EducationOccupation;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Family;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Nationality;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Nominee;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.PersonalInfo;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.DataValidations;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.validation.Validator;

/**
 * @author 3483784san
 *         <p>
 *         Validation
 *         </p>
 *         <ul>
 *         <li>All Mandatory Validation Required</li>
 *         <li>All PO Validation Depends On BuyType {buyTpe=2}</li>
 *         <li>All JointLife Validation Depends On ProductId
 *         {productId=12029}</li>
 *         </ul>
 */
public class PersonalInfoHelper extends MsObject {
	private DBClient dbClient;
	private CommonProps commonProps;
	private PersonalInfoRequest piRequest;

	public PersonalInfoHelper(DBClient dbClient, CommonProps commonProps, PersonalInfoRequest request) {
		this.dbClient = dbClient;
		this.commonProps = commonProps;
		this.piRequest = request;
	}

	public void validate() {
		PersonalInfo p = piRequest.getPersonalInfo();
		new Validator(p, "Personal Info", false).notNull();
		validateBasic(p.getBasicInfo(), "Basic Info");
		validateNationality(p.getNationalityInfo(), "Nationality Info");
		validateContactInfo(p.getContactInfo(), "Contact Info");
		validateTaxResident(p.getNationalityInfo());

		if (isValidBuyType()) {
			validateBasic(p.getBasicInfoPO(), "Basic Info PO");
			validateNationality(p.getNationalityInfoPO(), "Nationality Info PO");
			validateTaxResident(p.getNationalityInfoPO());
			validateContactInfo(p.getContactInfoPO(), "Contact Info PO");

			new ComparableValidator(p.getContactInfoPO().getProposerMailingAddressSameAs(),
					"Proposer MailingAddress SameAs", false).equalsTo(1);
			new ComparableValidator(p.getContactInfoPO().getProposerPermanentAddressSameAs(),
					"Proposer PermanentAddress SameAs", false).equalsTo(2);
			new ComparableValidator(p.getContactInfoPO().getProposerJurisdictionAddressSameAs(),
					"Proposer Jurisdiction AddressSameAs", false).equalsTo(3);
		}

		if (isValidationProductId()) {
			validateBasic(p.getBasicInfoJointLife(), "Basic Info JointLife");
			validateNationality(p.getNationalityInfoJointLife(), "Nationality Info JointLife");
			validateTaxResident(p.getNationalityInfoJointLife());
			validateContactInfo(p.getContactInfoJointLife(), "Contact Info Life");

			new ComparableValidator(p.getContactInfoJointLife().getProposerMailingAddressSameAs(),
					"Proposer MailingAddress SameAs", false).equalsTo(1);
			new ComparableValidator(p.getContactInfoJointLife().getProposerPermanentAddressSameAs(),
					"Proposer PermanentAddress SameAs", false).equalsTo(2);
			new ComparableValidator(p.getContactInfoJointLife().getProposerJurisdictionAddressSameAs(),
					"Proposer Jurisdiction AddressSameAs", false).equalsTo(3);
		}

		validateFamilyDetails();
		new ComparableValidator(p.getMaritalStatus(), "Marital Status", false).greaterThan(-1);

		validateEducationDetails();
		validateDocumentProofInfo();
		validateNominees();
	}

	public void validateTaxResident(Nationality nationality) {
		if (nationality.getTaxResident() == 1) {
			new StringValidator(nationality.getBirthPlace(), "Birth Place").notNullNotBlank();
		}
	}

	private void validateContactInfo(Contact contact, String display) {
		new Validator(contact, display, false).notNull();
		validateWithMetaJson(contact.getMailingAddress(), commonProps.getAddressValidations());
		validateWithMetaJson(contact.getPermanentAddress(), commonProps.getAddressValidations());
		validateWithMetaJson(contact.getJurisdictionAddress(), commonProps.getAddressValidations());
	}

	private void validateFamilyDetails() {
		new Validator(piRequest.getPersonalInfo().getFamilyDetails(), "Family Details", false).notNull();
		validateFamily(piRequest.getPersonalInfo().getFamilyDetails());
		if (isValidBuyType()) {
			new Validator(piRequest.getPersonalInfo().getFamilyDetailsPO(), "Family Details PO", false).notNull();
			validateFamily(piRequest.getPersonalInfo().getFamilyDetailsPO());
		}
	}

	private void validateFamily(List<Family> familyList) {
		familyList.forEach(f -> {
			new Validator(f.getDetail(), "Family Name Details", false).notNull();
			new StringValidator(f.getMember(), "Member").notNullNotBlank();
		});
	}

	private void validateBasic(Basic basic, String displayName) {
		new Validator(basic, displayName, false).notNull();
		validateWithMetaJson(basic.getName(), commonProps.getNameValidations());
		validateWithMetaJson(basic.getBirthDate(), commonProps.getDateCheckValidations());
		validateWithMetaJson(basic.getGender(), commonProps.getGenderValidations());
		validateWithMetaJson(basic.getEmail(), commonProps.getEmailValidations());
		validateWithMetaJson(basic.getPhoneNumbers(), commonProps.getPhoneNumberValidations());

		new ComparableValidator(basic.getRegisterCommunicationEmailId(), "Register Communication EmailId", false)
				.isBetween(-1, 2);

	}

	private void validateNationality(Nationality nationality, String displayName) {
		new Validator(nationality, displayName, false).notNull();
		new ComparableValidator(nationality.getCitizenship(), "Citizenship", false).greaterThan(-1);
		new ComparableValidator(nationality.getResidentialStatus(), "Residential Status", false).greaterThan(-1);
		new ComparableValidator(nationality.getTaxResident(), "TaxResident", false).greaterThan(-1);
	}

	private void validateEducationDetails() {
		new Validator(piRequest.getPersonalInfo().getEducationOccupationInfo(), "Education Details", false).notNull();
		validateEducation(piRequest.getPersonalInfo().getEducationOccupationInfo());

		if (isValidationProductId()) {
			new Validator(piRequest.getPersonalInfo().getEducationOccupationInfoPO(), "Education Details PO", false)
					.notNull();
			validateEducation(piRequest.getPersonalInfo().getEducationOccupationInfoPO());
		}
		if (isValidationProductId()) {
			new Validator(piRequest.getPersonalInfo().getEducationOccupationInfoJointLife(),
					"Education Details JointLife", false).notNull();
			validateEducation(piRequest.getPersonalInfo().getEducationOccupationInfoJointLife());
		}
	}

	private void validateEducation(EducationOccupation educationOccupation) {
		validateWithMetaJson(educationOccupation,
				"{nullable:false, childDataValidations:[ {childPath:'organizationName',displayName:'Organization Name',validations:'notNull'},{childPath:'occupation',displayName:'Occupation',nullable:false,validations:'greaterThan~0'}, {childPath:'natureOfDuties',displayName:'lastName',validations:'notNull'}, {childPath:'designation',displayName:'Designation',nullable:false,validations:'greaterThan~0'}, {childPath:'natureOfBusiness',displayName:'Nature Of Bussiness',validations:'notNull'}, {childPath:'yearOfService',displayName:'Year Of Service',nullable:false,validations:'greaterThan~0'},{childPath:'educationalQualification',displayName:'Educational Qualification',nullable:false,validations:'greaterThan~0'},{childPath:'status',displayName:'Status',validations:'notNull'} ]}");
		new Validator(educationOccupation.getAnnualIncomeAmount(), "Annual Income Amount", false).notNull();
		validateWithMetaJson(educationOccupation.getAnnualIncomeAmount(),
				"{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'Annual Income Amount',validations:'greaterThan~$errmsg:Annual income should be >=100000.~99999'}]}");

	}

	private void validateNominees() {
		List<Nominee> nominees = piRequest.getPersonalInfo().getNominees();
		new Validator(nominees, "Nominee Details", false).notNull();
		new ComparableValidator(nominees.size(), "Nominee Details", false).isBetween(0, 5);
		nominees.forEach(n -> {
			new ComparableValidator(n.getIndex(), "Index", false).greaterThan(-1);
			new ComparableValidator(n.getNomineeIndex(), "Nominee Index", false).greaterThan(-1);
			validateWithMetaJson(n.getDetail(), "{ nullable:false, childDataValidations:["
					+ commonProps.getChildDateCheckValidations()
					+ ", {childPath:'relationShip',displayName:'Relationship',nullable:false,validations:'greaterThan~0'}, {childPath:'maritalStatus',displayName:'Marrital Status',nullable:false,validations:'greaterThan~-1'}, {childPath:'precentageEntitlement',displayName:'Percentage Entitlemnt',nullable:false,validations:'greaterThan~0'}, {childPath:'nomineeAddressSameAs',displayName:'Nominee Address Same as',nullable:false,validations:'greaterThan~0'} ]}");
			validateWithMetaJson(n.getDetail().getName(), commonProps.getNameValidations());
			validateWithMetaJson(n.getDetail().getMailingAddress(), commonProps.getAddressValidations());
			if (isAgeLessThan18(n.getDetail().getBirthDate()))
				validateAppointeeInfo();
		});
	}

	private void validateAppointeeInfo() {
		AppointeeInfo appointeeInfo = piRequest.getPersonalInfo().getAppointeeInfo();
		new Validator(appointeeInfo, "Appointee Info", false).notNull();
		validateWithMetaJson(appointeeInfo.getName(), commonProps.getNameValidations());
		validateWithMetaJson(appointeeInfo.getBirthDate(), commonProps.getDateCheckValidations());
	}

	private void validateDocumentProofInfo() {
		new Validator(piRequest.getPersonalInfo().getDocumentProofInfo(), "Document Proof Info", false).notNull();
		validateDocumentProof(piRequest.getPersonalInfo().getDocumentProofInfo());
		if (isValidBuyType()) {
			new Validator(piRequest.getPersonalInfo().getDocumentProofInfoPO(), "Document Proof PO", false).notNull();
			validateDocumentProof(piRequest.getPersonalInfo().getDocumentProofInfoPO());
		}
		if (isValidationProductId()) {
			new Validator(piRequest.getPersonalInfo().getDocumentProofInfoJointLife(), "Document Proof JointLife",
					false).notNull();
			validateDocumentProof(piRequest.getPersonalInfo().getDocumentProofInfoJointLife());
		}
	}

	private void validateDocumentProof(DocumentProof documentProof) {
		validateWithMetaJson(documentProof,
				"{ nullable:false, childDataValidations:[{childPath:'idProof',displayName:'Id Proof',validations:'greaterThan~0'}, {childPath:'addressProof',displayName:'Address Proof',validations:'greaterThan~0'}, {childPath:'ageProof',displayName:'Age Proof',validations:'greaterThan~0'}]}");
		validateWithMetaJson(documentProof.getPanCard(), commonProps.getPanCheckValidations());
		validateWithMetaJson(documentProof.getAadharCard() + "", commonProps.getAadharCheckValidations());
	}

	/*
	 * All PO Related validation depends on BuyType-2
	 */
	public boolean isValidBuyType() {
		boolean isValid = false;
		LeadDetail ld = dbClient.getLeadDetail(piRequest.getLeadId());
		if (null != ld && null != ld.getBuyType() && ld.getBuyType().equals("2")) {
			isValid = true;
		}
		return isValid;
	}

	/*
	 * ProductId (12029) check for given leadId All JointLife validation related to
	 * ProductId 12029
	 */
	public boolean isValidationProductId() {
		boolean isValid = false;
		LeadDetail ld = dbClient.getLeadDetail(piRequest.getLeadId());
		if (null != ld && null != ld.getPremiumCalculation()
				&& ProductId.isValidProductId(ld.getPremiumCalculation().getProductId())
				&& ld.getPremiumCalculation().getProductId() == 12029) {
			isValid = true;
		}
		return isValid;
	}

	/*
	 * calculate age from given date of birth
	 */
	private boolean isAgeLessThan18(String dob) {
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
			Instant instant = date.toInstant();
			ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
			LocalDate givenDate = zone.toLocalDate();
			Period period = Period.between(givenDate, LocalDate.now());
			return period.getYears() <= 18;
		} catch (Exception e) {
			log.error("Date Parsing Exception inside calculateAge method. {}", e.getMessage());
		}
		return false;
	}

	/*
	 * validation helper call
	 */
	private void validateWithMetaJson(Object object, String json) {
		new ValidationHelper(object, JsonUtil.readValue(json, DataValidations.class)).validateWithMetaJson();
	}
}
