package com.pmli.ms.bo.customer.request;

import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.util.java.FieldMetaJson;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class holds the Fetch Application request details
 * 
 * @author  Snehal Shimpi
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class FetchApplicationRequest extends LeadRequest {
    @ApiModelProperty(value = "Quotation Id", example = "8080123456")
    @FieldMetaJson("{displayName:'Quotation Id'," + Constants.VALIDATIONS_DIGITS_1_32_REGEX + "}")
    private String quotationId;
    @ApiModelProperty(value = "Application Number", example = "150040158")
    @FieldMetaJson("{displayName:'Application Number'," + Constants.VALIDATIONS_DIGITS_1_32_REGEX + "}")
    private String applicationNumber;

}
