package com.pmli.ms.bo.customer.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public enum ProductId {

    SSP(12007), GFP(12020), SPP(12025), IAP(12029);

    public static final List<ProductId> PRODUCT_ID_LIST = Collections
        .unmodifiableList(Arrays.asList(ProductId.values()));

    public static final List<Integer> PRODUCT_ID_INT_LIST = Collections.unmodifiableList(
        Arrays.asList(ProductId.values()).stream().map(ProductId::getValue).collect(Collectors.toList()));

    private final int value;

    ProductId(int value) { this.value = value; }

    public int getValue() { return value; }

    public static boolean isSuperSaverPlan(int planId) { return SSP.getValue() == planId; }

    public static boolean isSuperSaverPlan(String planId) { return isSuperSaverPlan(Integer.parseInt(planId)); }

    public static boolean isGuaranteedFuturePlan(int planId) { return GFP.getValue() == planId; }

    public static boolean isGuaranteedFuturePlan(String planId) {
        return isGuaranteedFuturePlan(Integer.parseInt(planId));
    }

    public static boolean isSmartPlatinumPlusPlan(int planId) { return SPP.getValue() == planId; }

    public static boolean isSmartPlatinumPlusPlan(String planId) {
        return isSmartPlatinumPlusPlan(Integer.parseInt(planId));
    }

    public static boolean isImmediataeAnuityPlan(int planId) { return IAP.getValue() == planId; }

    public static boolean isImmediataeAnuityPlan(String planId) {
        return isImmediataeAnuityPlan(Integer.parseInt(planId));
    }

    public static boolean isValidProductId(ProductId id) { return PRODUCT_ID_LIST.contains(id); }

    public static boolean isValidProductId(int id) { return PRODUCT_ID_INT_LIST.contains(id); }

    public static boolean isValidProductId(String id) { return isValidProductId(Integer.parseInt(id)); }
}
