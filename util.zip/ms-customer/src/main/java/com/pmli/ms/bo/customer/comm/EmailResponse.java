package com.pmli.ms.bo.customer.comm;

import lombok.Data;
/*
 * 
 * @return EmailResponse for email 
 */
@Data
public class EmailResponse {

	private String responseCode;
	private String responseMessage;
}
