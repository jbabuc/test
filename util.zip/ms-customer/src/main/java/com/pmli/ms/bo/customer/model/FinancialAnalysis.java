package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.request.FnaRequest.ChildDetail;
import com.pmli.ms.bo.customer.request.FnaRequest.FinacialGoal;
import com.pmli.ms.bo.customer.request.FnaRequest.Fna;
import com.pmli.ms.bo.customer.request.FnaRequest.FnaBase;
import com.pmli.ms.bo.customer.request.FnaRequest.FnaDetail;
import com.pmli.ms.bo.customer.request.FnaRequest.GoalDetail;
import com.pmli.ms.bo.customer.request.FnaRequest.LongTerm;
import com.pmli.ms.bo.customer.request.FnaRequest.Summary;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the request details of add-fna to store in mongodb.
 * 
 * @author suvarna bambarse
 */
@Data
@NoArgsConstructor
public class FinancialAnalysis {
    private List<Base>      financial = new ArrayList<>();
    private String          plan;
    private String          risk;
    private String          stage;
    private String          selectedGoal;
    private FnaSummary      summary;
    private List<ChildInfo> child     = new ArrayList<>();
    private LongTermSave    longTermSaving;

    public FinancialAnalysis(Fna fna) {
        if (fna == null) return;

        ofNullable(fna.getFinancials()).ifPresent(f -> f.forEach(o -> financial.add(new Base(o))));
        plan = CommonHelper.getStrFromIntOrZero(fna.getPlanId());
        risk = String.valueOf(fna.getRisk());
        stage = String.valueOf(fna.getStage());
        selectedGoal = fna.getSelectedGoal();
        summary = new FnaSummary(fna.getSummary());
        longTermSaving = new LongTermSave(fna.getLongTermSavingInformation());
        ofNullable(fna.getChildren()).ifPresent(c -> c.forEach(cf -> child.add(new ChildInfo(cf))));
    }

    @Data
    @NoArgsConstructor
    public static class ChildInfo {
        private String firstName;
        private String lastName;
        private String dateOfBirth;
        private String gender;
        private String aspiration;
        private String age;

        public ChildInfo(ChildDetail childDetail) {
            if (childDetail == null) return;

            firstName = childDetail.getName().getFirstName();
            lastName = childDetail.getName().getLastName();
            dateOfBirth = childDetail.getBirthDate();
            gender = childDetail.getGender();
            aspiration = String.valueOf(childDetail.getAspiration());
            age = String.valueOf(CommonHelper.getAge(childDetail.getBirthDate()));
        }
    }

    @Data
    @EqualsAndHashCode(callSuper = false)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @NoArgsConstructor
    public static class FnaGoal {
        private String             key;
        private FinacialGoalDetail details;

        public FnaGoal(FinacialGoal goal) {
            if (goal == null) return;
            key = goal.getKey();
            details = new FinacialGoalDetail(goal.getDetail());
        }
    }

    @Data
    @NoArgsConstructor
    public static class Base {
        protected String key;
        protected String value;

        public Base(FnaBase fb) {
            if (fb == null) return;

            key = fb.getKey();
            value = CommonHelper.getStrFromIntOrZero(fb.getValue());
        }
    }

    @Data
    @NoArgsConstructor
    public static class FinacialGoalDetail {

        private List<String>    goalNames = new ArrayList<>();
        private List<ChildInfo> otherInfo = new ArrayList<>();

        public FinacialGoalDetail(GoalDetail detail) {
            if (detail == null) return;

            goalNames = detail.getGoalNames();
            if (detail.getOtherInformations() != null) {
                detail.getOtherInformations().forEach(info -> otherInfo.add(new ChildInfo(info)));
            }
        }
    }

    @Data
    @NoArgsConstructor
    public static class FnaSummary {
        private FinancialAnalysisDetail stage;
        private FinancialAnalysisDetail risk;
        private List<FnaGoal>           goals = new ArrayList<>();

        public FnaSummary(Summary sum) {
            if (sum == null) return;

            stage = new FinancialAnalysisDetail(sum.getStage());
            risk = new FinancialAnalysisDetail(sum.getRisk());
            sum.getGoals().forEach(goal -> goals.add(new FnaGoal(goal)));
        }
    }

    @Data
    @NoArgsConstructor
    public static class LongTermSave {

        private String longTermSaving;
        private String longTermSavingDetails;

        public LongTermSave(LongTerm longTerm) {
            if (longTerm == null) return;

            longTermSaving = longTerm.getLongTermSaving();
            longTermSavingDetails = longTerm.getLongTermSavingDetail();
        }
    }

    @Data
    @NoArgsConstructor
    public static class FinancialAnalysisDetail {
        private boolean active;
        private String  code;
        private String  description;
        private String  key;
        private int     order;
        private String  icon;
        private String  value;

        public FinancialAnalysisDetail(FnaDetail detail) {
            if (detail == null) return;

            active = detail.isActive();
            code = String.valueOf(detail.getCode());
            description = detail.getDescription();
            key = String.valueOf(detail.getKey());
            order = detail.getOrder();
            icon = detail.getIcon();
            value = detail.getValue();
        }
    }
}
