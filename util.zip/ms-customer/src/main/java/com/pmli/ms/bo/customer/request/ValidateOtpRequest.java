package com.pmli.ms.bo.customer.request;

import com.pmli.util.java.FieldMetaJson;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ValidateOtpRequest extends LeadRequest {

	@ApiModelProperty(value = "transaction id", example = "TRAN12320153744", notes = "TXN+<ClientID>+<(Time)SSMS>")
	@FieldMetaJson("{displayName:'Transaction Id', nullable:false,validations:'notBlank,notNull,isMaxLength~32,matchesRegEx~[A-Z0-9]*'}")
	private String transactionId;
	@ApiModelProperty(value = "OTP", example = "123456")
	@FieldMetaJson("{displayName:'OTP', nullable:false,validations:'notBlank,notNull,isLength~6,matchesRegEx~[0-9]*'}")
	private String otp;

}
