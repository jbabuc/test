package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * 
 * @author 3483784san
 *
 */
@Data
@AllArgsConstructor
public class MessageResponse {
    @ApiModelProperty(required = true, value = "message", example = "Operation completed successfully.")
    private String message;
}
