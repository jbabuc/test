package com.pmli.ms.bo.customer.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FileDetail {
	private String base64;
	private String fileName;
}
