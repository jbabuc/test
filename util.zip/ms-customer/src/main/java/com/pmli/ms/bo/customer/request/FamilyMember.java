package com.pmli.ms.bo.customer.request;

import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.LeadDetail.LovedOne;
import com.pmli.util.model.Name;
import static java.util.Optional.ofNullable;

import java.util.Objects;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FamilyMember {

	private Name name;

	@ApiModelProperty(required = false, value = "Gender", example = "Male")
	private String gender;

	@ApiModelProperty(required = false, value = "Age", example = "52")
	private int age;

	@ApiModelProperty(required = false, value = "Birth Date", example = "1964-12-21")
	private String birthDate;

	public FamilyMember(LovedOne lovedOne) {
		if(!Objects.isNull(lovedOne)) {
			ofNullable(lovedOne).ifPresent(n->this.name = new Name(lovedOne.getTitle(), lovedOne.getFirstName(), "",lovedOne.getLastName()) );
			ofNullable(lovedOne.getGender()).ifPresent(g->this.gender = lovedOne.getGender());
			ofNullable(lovedOne.getAge()).ifPresent(a->this.age = CommonHelper.parseIntOrDef(lovedOne.getAge(), 0));
			ofNullable(lovedOne.getDateOfBirth()).ifPresent(dob->this.birthDate = lovedOne.getDateOfBirth());
		}
	}
}
