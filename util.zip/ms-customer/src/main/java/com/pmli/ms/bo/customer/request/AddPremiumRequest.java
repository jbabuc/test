package com.pmli.ms.bo.customer.request;

import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the Add Premium request details
 * 
 * @author  Deepak Ingle
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class AddPremiumRequest extends LeadRequest {

    @ApiModelProperty(required = true, value = "Quotation Id", example = "450")
    @FieldMetaJson("{displayName:'Quotation Id',nullable:false,validations:'notBlank,notNull,isMaxLength~32,matchesRegEx~[0-9]*'}")
    private String quotationId;

    @ApiModelProperty(required = false, value = "Joint Life Age", example = "52")
    private int jointLifeAge;

    @ApiModelProperty(required = false, value = "Joint Life Birth Date", example = "1968-12-12")
    private String jointLifeBirthDate;
    private Name   jointLifeName;

    @FieldMetaJson("{nullable:false}")
    private PremiumCalculation premiumCalculation;
}
