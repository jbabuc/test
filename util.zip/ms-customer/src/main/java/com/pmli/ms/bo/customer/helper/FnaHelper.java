package com.pmli.ms.bo.customer.helper;

import java.util.List;

import com.pmli.ms.bo.customer.request.FnaRequest;
import com.pmli.ms.bo.customer.request.FnaRequest.ChildDetail;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.ListValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.validation.Validator;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class FnaHelper {

	FnaRequest fnaRequest;

	/**
	 * This method validates input request of add-fna
	 * 
	 * @param req Request details for add-fna encapsulated in {@link FnaRequest}.
	 */
	public void validate() {
		new ValidationHelper(fnaRequest).validateWithMetaJson();
		fnaRequest.getFna().getFinancials().forEach(goal -> {
			if (goal.getKey().equals("ChildEducation")) {
				new ListValidator(fnaRequest.getFna().getChildren(), "Children ", false).validate(Validator::notNull)
						.validate(ListValidator::isMinLength, 1);
				validateChildDetails(fnaRequest.getFna().getChildren());
				fnaRequest.getFna().getSummary().getGoals().forEach(child -> {
					new ListValidator(child.getDetail().getOtherInformations(), "ChildrenInfo ", false)
							.validate(Validator::notNull).validate(ListValidator::isMinLength, 1);
					validateChildDetails(child.getDetail().getOtherInformations());
				});
			} else if (goal.getKey().equals("LongTermSavings")) {
				new Validator(fnaRequest.getFna().getLongTermSavingInformation(), "LongTermSaving", false).notNull();
				new StringValidator(fnaRequest.getFna().getLongTermSavingInformation().getLongTermSaving(),
						"LongTermSaving", false).notNullNotBlank();
			}
		});

	}

	/**
	 * This method validates child detail of add-fna request
	 * 
	 * @param req Request details for child encapsulated in {@link ChildDetail}.
	 */
	private void validateChildDetails(List<ChildDetail> children) {
		children.forEach(child -> {
			new Validator(child.getName(), "Name", false).notNull();
			new StringValidator(child.getName().getFirstName(), "First Name", false).notNullNotBlank();
			new StringValidator(child.getName().getLastName(), "Last Name", false).notNullNotBlank();
			new StringValidator("2020-09-13", "Date of Birth", false).validate(Validator::notNull)
					.validate(StringValidator::notBlank).validate(StringValidator::isDate, "yyyy-MM-dd", true);
			new StringValidator(child.getGender(), "Gender", false).notNullNotBlank();
			new ComparableValidator(child.getAspiration(), "Aspiration", false).greaterThan(0);
		});
	}

}
