package com.pmli.ms.bo.customer.helper;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.comm.EmailRequest;
import com.pmli.ms.bo.customer.comm.Metadata;
import com.pmli.ms.bo.customer.comm.SmsClient;
import com.pmli.ms.bo.customer.comm.SmsRequest;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.PaymentProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.model.LeadDetailPayment;
import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.ms.bo.customer.response.PaymentResponse;
import com.pmli.util.java.Crypto;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

/**
 * <p>
 * This class consists of the helper methods required for the implementation of the Payment service.
 * </p>
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@AllArgsConstructor
public class PaymentServiceHelper extends MsObject {

    DBClient             dbClient;
    private PaymentProps paymentProps;
    private CommonProps  commonProps;
    private SmsClient    smsClient;
    private EmailClient  emailClient;
    PaymentRequest       paymentRequest;

    /**
     * This method validate the payment request object
     * 
     * @param paymentRequest Request details for 'Add Payment', encapsulated in {@link PaymentRequest}.
     */
    public void validate() {
        new ValidationHelper(paymentRequest).validateWithMetaJson();
        if (StringUtils.isEmpty(paymentRequest.getLeadId())
            && StringUtils.isEmpty(paymentRequest.getApplicationNumber())) {
            throw new MsValidationException(paymentProps.getErrorMsgLeadIdAppNumberBlank());
        }
    }

    /**
     * This method is use to send SMS after payment is saved in DB
     * 
     * @param doc the document fetch from DB
     */
    public void paymentSendSMS(Document doc) {
        log.debug("Start of paymentSendSMS() method");
        List<Metadata> metadataList = null;
        String mobileNumber = doc.getString(commonProps.getDbTagMobileNum());
        if (!ObjectUtils.isEmpty(mobileNumber) && StringUtils.isNotEmpty(paymentRequest.getPayment().getAuthStatus())) {
            if (paymentRequest.getPayment().getAuthStatus().equalsIgnoreCase("0300")) {
                // Payment Success SMS
                metadataList = preparePaymentSuccSmsMetaData(doc);
                SmsRequest smsRequest = new SmsRequest(commonProps.getMsCustomer(), mobileNumber,
                    paymentProps.getTemplateIdPaymentSuccSms(), metadataList, commonProps.getSmsFlag());
                smsClient.sendSms(smsRequest);
            } else {
                // Payment Failure SMS
                metadataList = preparePaymentFailSmsMetaData(doc);
                SmsRequest smsRequest = new SmsRequest(commonProps.getMsCustomer(), mobileNumber,
                    paymentProps.getTemplateIdPaymentFailSms(), metadataList, commonProps.getSmsFlag());
                smsClient.sendSms(smsRequest);
            }
        } else {
            log.info("Mobile Number is not available in record. No SMS is sent to user");
            throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_NOT_FOUND_105,
                paymentProps.getErrorMsgMobileNotAvailable(), paymentProps.getErrorMsgMobileNotAvailable());

        }
        log.debug("End of paymentSendSMS() method");
    }

    /**
     * This method is use to prepare metaData for payment success SMS
     * 
     * @param  doc
     * @return     List of Metadata
     */
    private List<Metadata> preparePaymentSuccSmsMetaData(Document doc) {
        log.debug("Start of preparePaymentSuccSmsMetaData() method");
        List<Metadata> metadataList = new ArrayList<>();
        Document premCalc = (Document) doc.get(commonProps.getDbTagpremCalc());
        metadataList
            .add(new Metadata(commonProps.getProductName(), premCalc.getString(commonProps.getDbTagProductName())));
        metadataList
            .add(new Metadata(commonProps.getPlanCode(), premCalc.get(commonProps.getDbTagPlanId()).toString()));
        metadataList.add(new Metadata(commonProps.getAppNo(), doc.getString(commonProps.getDbTagAppNum())));
        log.debug("End of preparePaymentSuccSmsMetaData() method");
        return metadataList;
    }

    /**
     * This method is use to prepare metaData for payment fail SMS
     * 
     * @param  doc
     * @return     List of Metadata
     */
    private List<Metadata> preparePaymentFailSmsMetaData(Document doc) {
        log.debug("Start of preparePaymentFailSmsMetaData() method");
        List<Metadata> metadataList = new ArrayList<>();
        metadataList.add(new Metadata(commonProps.getCustomerName(), doc.getString(commonProps.getDbTagName())));
        metadataList.add(new Metadata(commonProps.getAppNo(), doc.getString(commonProps.getDbTagAppNum())));
        log.debug("End of preparePaymentFailSmsMetaData() method");
        return metadataList;
    }

    /**
     * This method is use to send email after payment is saved in DB
     * 
     * @param doc the document fetch from DB
     */
    public void paymentSendEmail(Document doc, LeadDetailPayment paymentLeadDetail) {
        log.debug("Start of paymentSendEmail() method");
        List<Metadata> metadataList = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String toEmail = doc.getString((commonProps.getDbTagEmailId()));
        if (StringUtils.isNotEmpty(toEmail)
            && StringUtils.isNotEmpty(paymentLeadDetail.getPayment().getPaymentMoreInfo().getAuthStatus())) {
            if (paymentLeadDetail.getPayment().getPaymentMoreInfo().getAuthStatus().equalsIgnoreCase("0300")) {
                metadataList = preparePaymentSuccEmailMetaData(doc, paymentLeadDetail);
                EmailRequest emailRequest = new EmailRequest(commonProps.getMsCustomer(), toEmail,
                    commonProps.getFromEmail(), paymentProps.getTemplateIdPaymentSuccSms(), metadataList,
                    commonProps.getEmailReq());
                emailClient.sendEmail(emailRequest);
            } else {
                metadataList = preparePaymentFailEmailaData(doc, paymentLeadDetail);
                EmailRequest emailRequest = new EmailRequest(commonProps.getMsCustomer(), toEmail,
                    commonProps.getFromEmail(), paymentProps.getTemplateIdPaymentFailSms(), metadataList,
                    commonProps.getEmailReq());
                emailClient.sendEmail(emailRequest);
            }
        } else {
            log.info("Email ID is not available in record. No email is sent to user");
            throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_NOT_FOUND_105,
                paymentProps.getErrorMsgEmailNotAvailable(), paymentProps.getErrorMsgEmailNotAvailable());
        }
        log.debug("End of paymentSendEmail() method");
    }

    /**
     * This method is use to prepare metaData for payment success SMS
     * 
     * @param  doc
     * @return     List of Metadata
     */
    private List<Metadata> preparePaymentSuccEmailMetaData(Document doc, LeadDetailPayment paymentLeadDetail) {
        log.debug("Start of preparePaymentSuccEmailMetaData() method");
        List<Metadata> metadataList = new ArrayList<>();
        Document premCalc = (Document) doc.get(commonProps.getDbTagpremCalc());
        metadataList
            .add(new Metadata(commonProps.getProductName(), premCalc.getString(commonProps.getDbTagProductName())));
        metadataList
            .add(new Metadata(commonProps.getPlanCode(), premCalc.get(commonProps.getDbTagPlanId()).toString()));
        metadataList.add(new Metadata(commonProps.getAppNo(), doc.getString(commonProps.getDbTagAppNum())));
        metadataList.add(new Metadata(commonProps.getCustomerName(), doc.getString(commonProps.getDbTagName())));
        metadataList.add(new Metadata("premium", getPremium(doc)));
        metadataList.add(new Metadata("premium_frequency", dbClient.getFrequencyFromPremiumCalc(premCalc)));
        metadataList.add(new Metadata("riders_opted", getProductName(doc)));
        metadataList.add(new Metadata("policy_term", premCalc.getString("coverTerms")));
        metadataList.add(new Metadata("premium_payment_term", premCalc.getString("paymentTerms")));
        metadataList.add(new Metadata("bank_name", paymentLeadDetail.getPayment().getPaymentMoreInfo().getBankID()));
        metadataList
            .add(new Metadata("reference_id", paymentLeadDetail.getPayment().getPaymentMoreInfo().getTxnReferenceNo()));
        metadataList.add(new Metadata("transaction_date",
            paymentLeadDetail.getPayment().getPaymentMoreInfo().getTxnDate().toString()));
        metadataList.add(new Metadata("amount", paymentLeadDetail.getPayment().getPaymentMoreInfo().getTxnAmount()));
        metadataList.add(new Metadata("mobile_number", doc.getString(commonProps.getDbTagMobileNum())));
        metadataList.add(new Metadata("url_path", commonProps.getEmailUrlPath()));
        metadataList.add(new Metadata("continue_url",
            prepareUpdatePaymentResponse(paymentProps, commonProps, doc.getString("leadId")).getProposalFormLink()));
        setAppConfig(metadataList, premCalc.get(FieldConstants.LD_PREMIUM_CALC_PRODUCT_ID).toString());
        metadataList.add(new Metadata("proposed_owner", doc.getString(commonProps.getDbTagName())));
        metadataList.add(new Metadata("proposed_insured", getProposedInsured(doc)));
        metadataList.add(new Metadata("payment_mode", getPaymentMode(paymentLeadDetail)));
        log.debug("End of preparePaymentSuccEmailMetaData() method");
        return metadataList;
    }

    /**
     * This method is use to prepare metaData for payment fail SMS
     * 
     * @param  doc
     * @return     List of Metadata
     */
    private List<Metadata> preparePaymentFailEmailaData(Document doc, LeadDetailPayment paymentLeadDetail) {
        log.debug("Start of preparePaymentFailEmailaData() method");
        List<Metadata> metadataList = new ArrayList<>();
        Document premCalc = (Document) doc.get(commonProps.getDbTagpremCalc());
        metadataList.add(new Metadata(commonProps.getCustomerName(), doc.getString(commonProps.getDbTagName())));
        metadataList
            .add(new Metadata("reference_id", paymentLeadDetail.getPayment().getPaymentMoreInfo().getTxnReferenceNo()));
        metadataList.add(new Metadata("transaction_date",
            paymentLeadDetail.getPayment().getPaymentMoreInfo().getTxnDate().toString()));
        metadataList.add(new Metadata("url_path", commonProps.getEmailUrlPath()));
        metadataList.add(new Metadata("continue_url",
            prepareUpdatePaymentResponse(paymentProps, commonProps, doc.getString("leadId")).getProposalFormLink()));
        setAppConfig(metadataList, premCalc.get(FieldConstants.LD_PREMIUM_CALC_PRODUCT_ID).toString());
        log.debug("End of preparePaymentFailEmailaData() method");
        return metadataList;
    }

    /**
     * This method is use to calculate the premium
     * 
     * @param  doc
     * @return     List of Metadata
     */
    private String getPremium(Document doc) {
        log.debug("Start of getPremium() method");
        String totalPremium = "";
        Document premCalc = (Document) doc.get(commonProps.getDbTagpremCalc());
        BigDecimal premAmt = null;
        BigDecimal pa = null;
        if (null != premCalc) {
            pa = new BigDecimal(premCalc.getString("modalPremium"))
                .add(new BigDecimal(premCalc.getString("serviceTax")));
            List<Document> riderList = doc.getList("riders", Document.class);
            BigDecimal ra = new BigDecimal("0");
            if (!riderList.isEmpty()) {
                for (Document riderDoc : riderList) {
                    ra = ra.add(new BigDecimal(riderDoc.getString("modalPremium")));
                    ra = ra.add(new BigDecimal(riderDoc.getString("serviceTax")));
                }
            }
            premAmt = pa.add(ra).setScale(2, BigDecimal.ROUND_UP);
        }
        if (premAmt != null) { return premAmt.toString(); }
        log.debug("End of getPremium() method, premium :- {}", totalPremium);
        return totalPremium;
    }

    /**
     * This method is use to get product name by concating of riders product name
     * 
     * @param  doc
     * @return     the String product name
     */
    private String getProductName(Document doc) {
        log.debug("Start of getProductName() method");
        StringBuilder sb = new StringBuilder("");
        String prefix = "";
        List<Document> riderList = doc.getList("riders", Document.class);
        if (!riderList.isEmpty()) {
            for (Document riderDoc : riderList) {
                sb.append(prefix);
                prefix = ",";
                sb = sb.append(riderDoc.getString("productName"));
            }
        }
        log.debug("End of getProductName() method");
        return sb.toString();
    }

    /**
     * This method is use to get the payment mode
     * 
     * @param  doc
     * @return     the String payment mode
     */
    private String getPaymentMode(LeadDetailPayment pld) {
        log.debug("Start of getPaymentMode() method");
        String cardTypeText = "Credit Card";
        if (pld.getPayment().getCreditCardType() != null) {
            String crd = pld.getPayment().getCreditCardType().trim().toUpperCase();
            if (crd.equals("DEBIT")) { cardTypeText = "Debit Card"; }
            if (crd.equals("AMEX")) { cardTypeText = "Amex Card"; }
            if (crd.equals("VISA")) { cardTypeText = "Visa Card"; }
            if (crd.equals("DEBIT")) { cardTypeText = "Debit Card"; }
            if (!StringUtils.isEmpty(pld.getPayment().getCreditCardType()) && crd.equals("NET BANKING")) {
                cardTypeText = pld.getPayment().getCreditCardType() + "Card";
            }
        }
        log.debug("End of getPaymentMode() method :- {}", cardTypeText);
        return cardTypeText;
    }

    /**
     * This method is use to get the proposed Insured name
     * 
     * @param  doc
     * @return     the proposed Insured name
     */
    private String getProposedInsured(Document doc) {
        log.debug("Start of getProposedInsured() method");
        Document lovedDoc = doc.get("lovedOne", Document.class);
        String piName = "";
        if (null != lovedDoc) {
            String fName = lovedDoc.getString("firstName") != null ? lovedDoc.getString("firstName") : "";
            String lName = lovedDoc.getString("lastName") != null ? lovedDoc.getString("lastName") : "";
            piName = fName.concat(" ").concat(lName);
        }
        log.debug("End of getProposedInsured() method");
        return piName;
    }

    /**
     * This method is use set the product info in meta data
     * 
     * @param  metaData  list of metaData
     * @param  productId the product Id
     * @return           list of metaData
     */
    private List<Metadata> setAppConfig(List<Metadata> metaData, String productId) {
        log.debug("Start of setAppConfig() method");
        List<Document> appConfigLst = dbClient.getAppConfigDocs();
        Document acDoc = appConfigLst.get(0);
        List<Document> pnsDoclst = acDoc.getList("productNotificationSetting", Document.class);
        for (Document document : pnsDoclst) {
            if (document.getString(FieldConstants.LD_PREMIUM_CALC_PRODUCT_ID).equals(productId)) {
                metaData.add(new Metadata("product_url", document.getString("image")));
                metaData.add(new Metadata("product_image", document.getString("image")));
                metaData.add(new Metadata("product_description", document.getString("description")));
            }
        }
        log.debug("End of setAppConfig() method");
        return metaData;
    }

    /**
     * This method prepare the payment response and encryption of leadId
     * 
     * @param  leadId the String contains leadId
     * @return        Response details of 'Add Payment', encapsulated in type {@link PaymentResponse}.
     */
    public static PaymentResponse prepareUpdatePaymentResponse(PaymentProps paymentProps, CommonProps commonProps,
        String leadId) {
        PaymentResponse response = new PaymentResponse();
        String encryptLead;
        try {
            encryptLead = Crypto.encryptAES(leadId, paymentProps.getPaymentSecretKey(), commonProps.getInitVector(),
                commonProps.getAlgorithmName(), commonProps.getProviderName());
            String encodeLead = URLEncoder.encode(encryptLead, "UTF-8");
            String proposalFormLink = paymentProps.getProposalFormLink() + encodeLead;
            response.setMessage(paymentProps.getPaymentSuccessMsg());
            response.setProposalFormLink(proposalFormLink);
            return response;
        } catch (Exception e) {
            throw new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.INTERNAL_SERVER_ERROR_109,
                commonProps.getInternalServerError(), commonProps.getInternalServerError());
        }
    }
}
