
package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.AppointeeInfo;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.AppointeeRelationship;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Basic;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Contact;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.DocumentProof;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.EducationOccupation;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Family;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Nationality;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.Nominee;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.NomineeDetail;
import com.pmli.util.model.Address;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author 3483784san
 */

@Data
public class PersonalInfo {
	private static final String TITLE = "title";
	private BasicInfo basicInfo;
	private BasicInfo basicInfoPO;
	private BasicInfo basicInfoJointLife;
	private NationalityInfo nationalityInfo;
	private NationalityInfo nationalityInfoPO;
	private NationalityInfo nationalityJointLife;
	private List<FamilyInfo> familyInfo;
	private List<FamilyInfo> familyInfoPO;
	private String maritalStatus;
	private String relationWithPO;
	private ContactInfo contactInfo;
	private ContactInfo contactInfoPO;
	private ContactInfo contactInfoPOJointLife;
	private EducationOccupationInfo educationOccupationInfo;
	private EducationOccupationInfo educationOccupationInfoPO;
	private EducationOccupationInfo educationOccupationInfoJointLife;
	private DocumentProofInfo documentProofInfo;
	private DocumentProofInfo documentProofInfoPO;
	private DocumentProofInfo documentProofInfoJointLife;
	private String maritalStatusPO;
	private List<NomineeInfo> nomineeInfo;
	private Appointee appointeeInfo;

	public PersonalInfo() {
	}

	public PersonalInfo(PersonalInfoRequest.PersonalInfo personalInfo, DBClient dbClient) {
		ofNullable(personalInfo.getBasicInfo()).ifPresent(n -> this.basicInfo = new BasicInfo(n, dbClient));
		ofNullable(personalInfo.getBasicInfoPO()).ifPresent(n -> this.basicInfoPO = new BasicInfo(n, dbClient));
		ofNullable(personalInfo.getBasicInfoJointLife())
				.ifPresent(n -> this.basicInfoJointLife = new BasicInfo(n, dbClient));

		ofNullable(personalInfo.getNationalityInfo()).ifPresent(n -> this.nationalityInfo = new NationalityInfo(n));
		ofNullable(personalInfo.getNationalityInfoPO()).ifPresent(n -> this.nationalityInfoPO = new NationalityInfo(n));
		ofNullable(personalInfo.getNationalityInfoJointLife())
				.ifPresent(n -> this.nationalityJointLife = new NationalityInfo(n));

		ofNullable(personalInfo.getFamilyDetails()).ifPresent(
				r -> this.familyInfo = r.stream().map(f -> new FamilyInfo(f, dbClient)).collect(Collectors.toList()));
		ofNullable(personalInfo.getFamilyDetailsPO()).ifPresent(
				r -> this.familyInfoPO = r.stream().map(f -> new FamilyInfo(f, dbClient)).collect(Collectors.toList()));

		ofNullable(personalInfo.getContactInfo()).ifPresent(n -> this.contactInfo = new ContactInfo(n));
		ofNullable(personalInfo.getContactInfoPO()).ifPresent(n -> this.contactInfoPO = new ContactInfo(n));
		ofNullable(personalInfo.getContactInfoJointLife())
				.ifPresent(n -> this.contactInfoPOJointLife = new ContactInfo(n));

		this.maritalStatus = personalInfo.getMaritalStatus() + "";
		this.relationWithPO = personalInfo.getRelationWithPO();
		this.maritalStatusPO = personalInfo.getMaritalStatusPO();

		ofNullable(personalInfo.getEducationOccupationInfo())
				.ifPresent(n -> this.educationOccupationInfo = new EducationOccupationInfo(n));
		ofNullable(personalInfo.getEducationOccupationInfoPO())
				.ifPresent(n -> this.educationOccupationInfoPO = new EducationOccupationInfo(n));
		ofNullable(personalInfo.getEducationOccupationInfoJointLife())
				.ifPresent(n -> this.educationOccupationInfoJointLife = new EducationOccupationInfo(n));

		ofNullable(personalInfo.getDocumentProofInfo())
				.ifPresent(n -> this.documentProofInfo = new DocumentProofInfo(n));
		ofNullable(personalInfo.getDocumentProofInfoPO())
				.ifPresent(n -> this.documentProofInfoPO = new DocumentProofInfo(n));
		ofNullable(personalInfo.getDocumentProofInfoJointLife())
				.ifPresent(n -> this.documentProofInfoJointLife = new DocumentProofInfo(n));

		ofNullable(personalInfo.getNominees()).ifPresent(
				r -> this.nomineeInfo = r.stream().map(n -> new NomineeInfo(n, dbClient)).collect(Collectors.toList()));
		ofNullable(personalInfo.getAppointeeInfo()).ifPresent(n -> this.appointeeInfo = new Appointee(n, dbClient));
	}

	@Data
	public static class BasicInfo {
		private String title;
		private String firstName;
		private String lastName;
		private String gender;
		private String dateOfBirth;
		private String mobileNumber;
		private String emailId;
		private boolean status;

		public BasicInfo() {
		}

		public BasicInfo(Basic basicInfo, DBClient dbClient) {

			ofNullable(basicInfo.getName()).ifPresent(n -> {
				this.title = dbClient.getMasterKeyByTypeValue(TITLE, n.getTitle());
				this.firstName = n.getFirstName();
				this.lastName = n.getLastName();
			});
			this.gender = basicInfo.getGender();
			this.dateOfBirth = basicInfo.getBirthDate();
			this.mobileNumber = basicInfo.getPhoneNumbers().get(0).getNumber();
			this.emailId = basicInfo.getEmail().getAddress();
			this.status = basicInfo.isStatus();

		}

	}

	@Data
	public static class NationalityInfo {
		private String citizenship;
		private String residentialStatus;
		private String taxResident;
		private String birthOfPlace;
		private boolean status;

		public NationalityInfo() {
		}

		public NationalityInfo(Nationality nationalityInfo) {
			this.citizenship = nationalityInfo.getCitizenship() + "";
			this.residentialStatus = nationalityInfo.getResidentialStatus() + "";
			this.taxResident = nationalityInfo.getTaxResident() + "";
			this.birthOfPlace = nationalityInfo.getBirthPlace();
			this.status = nationalityInfo.isStatus();

		}
	}

	@Data
	@AllArgsConstructor
	public static class Details {
		private String title;
		private String firstName;
		private String lastName;

		public Details() {
			super();
		}
	}

	@Data
	public static class FamilyInfo {
		private String member;
		private boolean status;
		private Details details;

		public FamilyInfo() {
		}

		public FamilyInfo(Family family, DBClient dbClient) {
			this.member = family.getMember();
			this.status = family.isStatus();
			ofNullable(family.getDetail()).ifPresent(
					n -> this.details = new Details(dbClient.getMasterKeyByTypeValue(TITLE, n.getName().getTitle()),
							n.getName().getFirstName(), n.getName().getLastName()));
		}

	}

	@Data
	public static class AddressInfo {
		private String landmark;
		private String street;
		@JsonInclude(Include.NON_NULL)
		private String pinCode;
		private String city;
		private String state;
		@JsonInclude(Include.NON_NULL)
		private String district;
		private String country;
		private String locality;
		@JsonInclude(Include.NON_NULL)
		private String nriPinCode;
		private String address;

		public AddressInfo() {

		}

		public AddressInfo(Address address, String type) {
			this.address = address.getAddressLine1();
			this.landmark = address.getLandmark();
			this.street = address.getAddressLine2();
			this.city = address.getCity();
			this.state = address.getState();
			this.district = address.getDistrict();
			this.country = address.getCountry();
			this.locality = address.getLocality();
			this.pinCode = address.getPostalCode();
			if (type.equals("nri")) {
				this.district = null;
				this.pinCode = null;
				this.nriPinCode = ofNullable(address.getPostalCode()).orElse(null);
			}
		}
	}

	@Data
	public static class ContactInfo {
		private AddressInfo mailingAddress;
		private AddressInfo permanentAddress;
		private String isPermanentAddress;
		private AddressInfo jurisdictionAddress;

		public ContactInfo() {
		}

		public ContactInfo(Contact contact) {
			ofNullable(contact.getMailingAddress()).ifPresent(c -> this.mailingAddress = new AddressInfo(c, ""));
			ofNullable(contact.getPermanentAddress()).ifPresent(c -> this.permanentAddress = new AddressInfo(c, ""));
			ofNullable(contact.getJurisdictionAddress())
					.ifPresent(c -> this.jurisdictionAddress = new AddressInfo(c, "nri"));
			this.isPermanentAddress = contact.getIsPermanentAddress() + "";
		}
	}

	@Data
	public static class EducationOccupationInfo {
		private String occupation;
		private String natureOfDuties;
		private String designation;
		private String natureOfBusiness;
		private String yearOfService;
		private String annualIncome;
		private String educationalQualification;
		private boolean status;
		private String organizationName;

		public EducationOccupationInfo() {
		}

		public EducationOccupationInfo(EducationOccupation educationOccupation) {
			this.organizationName = educationOccupation.getOrganizationName();
			this.occupation = educationOccupation.getOccupation() + "";
			this.natureOfDuties = educationOccupation.getNatureOfDuties();
			this.designation = educationOccupation.getDesignation() + "";
			this.natureOfBusiness = educationOccupation.getNatureOfBusiness();
			this.yearOfService = educationOccupation.getYearOfService() + "";
			ofNullable(educationOccupation.getAnnualIncomeAmount())
					.ifPresent(a -> this.annualIncome = "" + new BigDecimal(a.getAmount().toString()));
			this.educationalQualification = educationOccupation.getEducationalQualification() + "";
			this.status = educationOccupation.isStatus();
		}
	}

	@Data
	public static class DocumentProofInfo {
		private String idProof;
		private String addressProof;
		private String ageProof;
		private String panCard;
		private String aadharCard;
		private boolean status;
		private String incomeProof;

		public DocumentProofInfo() {
		}

		public DocumentProofInfo(DocumentProof documentProof) {
			this.idProof = documentProof.getIdProof() + "";
			this.addressProof = documentProof.getAddressProof() + "";
			this.ageProof = documentProof.getAgeProof() + "";
			this.panCard = documentProof.getPanCard();
			this.aadharCard = documentProof.getAadharCard() + "";
			this.status = documentProof.isStatus();
			this.incomeProof = documentProof.getIncomeProof() + "";
		}
	}

	@Data
	public static class NomineeInfo {
		private int index;
		private int nomineeIndex;
		private NomineeDetails details;
		private boolean status;

		public NomineeInfo() {
		}

		public NomineeInfo(Nominee nominee, DBClient dbClient) {
			this.index = nominee.getIndex();
			this.nomineeIndex = nominee.getNomineeIndex();
			ofNullable(nominee.getDetail()).ifPresent(n -> this.details = new NomineeDetails(n, dbClient));
			this.status = nominee.isStatus();
		}
	}

	@Data
	public static class NomineeDetails {
		private String title;
		private String firstName;
		private String lastName;
		private String relationShip;
		private String bornOn;
		private String maritalStatus;
		private String precentageEntitlement;
		private AddressInfo mailingAddress;
		private boolean status;
		private int nomineeAddressSameAs;

		public NomineeDetails() {
		}

		public NomineeDetails(NomineeDetail detail, DBClient dbClient) {
			ofNullable(detail).ifPresent(n -> {
				this.title = dbClient.getMasterKeyByTypeValue(TITLE, n.getName().getTitle());
				this.firstName = n.getName().getFirstName();
				this.lastName = n.getName().getLastName();
			});
			this.relationShip = detail.getRelationShip() + "";
			this.bornOn = detail.getBirthDate();
			this.maritalStatus = detail.getMaritalStatus() + "";
			this.precentageEntitlement = detail.getPrecentageEntitlement() + "";
			this.status = detail.isStatus();
			this.mailingAddress = new AddressInfo(detail.getMailingAddress(), "");
		}

	}

	@Data
	public static class Appointee {
		private String firstName;
		private String lastName;
		private String title;
		private String birthDate;
		private int maritalStatus;
		private List<AppointeeRelation> appointeeRelationships;
		private boolean status;

		public Appointee() {
		}

		public Appointee(AppointeeInfo appointeeInfo, DBClient dbClient) {
			ofNullable(appointeeInfo.getName()).ifPresent(n -> {
				this.firstName = n.getFirstName();
				this.lastName = n.getLastName();
				this.title = dbClient.getMasterKeyByTypeValue(TITLE, n.getTitle());
			});
			this.birthDate = appointeeInfo.getBirthDate();
			this.maritalStatus = appointeeInfo.getMaritalStatus();
			ofNullable(appointeeInfo.getAppointeeRelationships()).ifPresent(r -> this.appointeeRelationships = r
					.stream().map(AppointeeRelation::new).collect(Collectors.toList()));
			this.status = appointeeInfo.isStatus();
		}
	}

	@Data
	public static class AppointeeRelation {
		private int nomineeIndex;
		private int relationship;

		public AppointeeRelation() {
		}

		public AppointeeRelation(AppointeeRelationship appointeeRelationship) {
			this.nomineeIndex = appointeeRelationship.getNomineeIndex();
			this.relationship = appointeeRelationship.getRelationship();
		}
	}

}
