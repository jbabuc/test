package com.pmli.ms.bo.customer.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CreateApplicationResponse {
    
	private String leadId; 
	private String applicationNumber; 
}
