package com.pmli.ms.bo.customer.model;

import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest.PremiumCalculationBi;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LeadDetailPremium {
    private String premium;
    private String frequency;
    private String coverTerms;
    private String paymentTerms;
    private String cashBonusOptions;
    private int    productId;
    private String modeDisc;
    private String productName;
    private int    planId;
    private String planName;
    private String sumAssured;
    private String annualPremium;
    private String modalPremium;
    private String serviceTax;
    private String revisionaryBonus;
    private String terminalBonus;
    private String maturityBenefit;
    private String guaranteedIncome;
    private String accruedReversionaryBonuses;
    private String incomePayoutMode;
    private String maturityAge;
    private int    deferment;
    private String defermentValue;
    private String guaranteedDeathBenefit;
    private String totalPayout;
    private String multiple;
    private String fundStrategy;
    private String benefitPayoutDate;
    private String option;
    private String fundAtEndOfTheYear;
    private String investmentType;

    private String familyCareBenefit;
    private String returnOfPremium;
    
    private String fundAtEndOfTheYearFour;
    private String maturityBenefitFour;
    private String survivalBenefit;

    public LeadDetailPremium(PremiumCalculation pc) {
        // int to str
        this.frequency = CommonHelper.getStrFromIntOrZero(pc.getFrequencyCode());
        this.coverTerms = CommonHelper.getStrFromIntOrZero(pc.getCoverTerm());
        this.paymentTerms = CommonHelper.getStrFromIntOrZero(pc.getPaymentTerm());
        this.cashBonusOptions = CommonHelper.getStrFromIntOrZero(pc.getCashBonusOption());
        this.familyCareBenefit = CommonHelper.getStrFromIntOrZero(pc.getFamilyCareBenefit());
        this.returnOfPremium = CommonHelper.getStrFromIntOrZero(pc.getReturnOfPremium());
        this.investmentType = CommonHelper.getStrFromIntOrZero(pc.getInvestmentType());
        this.option = CommonHelper.getStrFromIntOrZero(pc.getOption());
        this.multiple = CommonHelper.getStrFromBigDecimalOrZero(pc.getMultiple(),"0.00");
        this.maturityAge = CommonHelper.getStrFromIntOrZero(pc.getMaturityAge());
        this.incomePayoutMode = CommonHelper.getStrFromIntOrZero(pc.getIncomePayoutMode());
        this.fundStrategy = CommonHelper.getStrFromIntOrZero(pc.getFundStrategy());

        // int to int
        this.deferment = pc.getDeferment();
        this.productId = pc.getProductId();
        this.planId = pc.getPlanId();

        // strings
        this.modeDisc = pc.getModeDisc();
        this.productName = pc.getProductName();
        this.planName = pc.getPlanName();
        this.defermentValue = pc.getDefermentValue();
        this.benefitPayoutDate = pc.getBenefitPayoutDate();

        // amounts
        premium = CommonHelper.getStrFromMoneyOrZero(pc.getPremiumAmount());
        sumAssured = CommonHelper.getStrFromMoneyOrZero(pc.getSumAssuredAmount());
        annualPremium = CommonHelper.getStrFromMoneyOrZero(pc.getAnnualPremiumAmount());
        modalPremium = CommonHelper.getStrFromMoneyOrZero(pc.getModalPremiumAmount());
        serviceTax = CommonHelper.getStrFromMoneyOrZero(pc.getServiceTaxAmount());
        revisionaryBonus = CommonHelper.getStrFromMoneyOrZero(pc.getRevisionaryBonusAmount());
        terminalBonus = CommonHelper.getStrFromMoneyOrZero(pc.getTerminalBonusAmount());
        maturityBenefit = CommonHelper.getStrFromMoneyOrZero(pc.getMaturityBenefitAmount());
        guaranteedIncome = CommonHelper.getStrFromMoneyOrZero(pc.getGuaranteedIncomeAmount());
        accruedReversionaryBonuses = CommonHelper.getStrFromMoneyOrZero(pc.getAccruedReversionaryBonusAmount());
        guaranteedDeathBenefit = CommonHelper.getStrFromMoneyOrZero(pc.getGuaranteedDeathBenefitAmount());
        totalPayout = CommonHelper.getStrFromMoneyOrZero(pc.getTotalPayoutAmount());
        fundAtEndOfTheYear = CommonHelper.getStrFromMoneyOrZero(pc.getFundAtEndOfTheYearAmount());
    }

    /**
     * Added one arg constructor to LeadDetailPremium for web bi to save basic lead details
     * 
     * @param premiumCalculationWebBi
     */
    public LeadDetailPremium(PremiumCalculationBi premiumCalculationBi) {
    	//int to string
        this.frequency = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getFrequencyCode());
        this.coverTerms = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getCoverTerm());
        this.paymentTerms = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getPaymentTerm());
        this.familyCareBenefit = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getFamilyCareBenefit());
        this.fundStrategy = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getFundStrategy());
        this.investmentType = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getInvestmentType());
        this.maturityAge = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getMaturityAge());
        this.incomePayoutMode = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getIncomePayoutMode());
        this.multiple = CommonHelper.getStrFromBigDecimalOrZero(premiumCalculationBi.getMultiple(),"0.00");
        this.option = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getOption());
        this.returnOfPremium = CommonHelper.getStrFromIntOrZero(premiumCalculationBi.getReturnOfPremium());
        //int to int
        this.productId = premiumCalculationBi.getProductId();
        this.planId = premiumCalculationBi.getPlanId();
        this.deferment = premiumCalculationBi.getDeferment();
        //strings
        this.modeDisc = premiumCalculationBi.getModeDescription();
        this.productName = premiumCalculationBi.getProductName();
        this.planName = premiumCalculationBi.getPlanName();
        this.benefitPayoutDate = premiumCalculationBi.getBenefitPayoutDate();
        this.defermentValue = premiumCalculationBi.getDefermentValue();
        //amounts
        this.premium = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getPremiumAmount());
        this.sumAssured = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getSumAssuredAmount());
        this.annualPremium = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getAnnualPremiumAmount());
        this.serviceTax = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getServiceTaxAmount());
        this.fundAtEndOfTheYearFour = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getFundAtEndOfTheYearFour());
        this.maturityBenefitFour = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getMaturityBenefitFour());
        this.survivalBenefit = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getSurvivalBenefit());
        this.accruedReversionaryBonuses = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getAccruedReversionaryBonusAmount());
        this.guaranteedDeathBenefit = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getGuaranteedDeathBenefitAmount());
        this.guaranteedIncome = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getGuaranteedIncomeAmount());
        this.maturityBenefit = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getMaturityBenefitAmount());
        this.modalPremium = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getModalPremiumAmount());
        this.revisionaryBonus = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getRevisionaryBonusAmount());
        this.terminalBonus = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getTerminalBonusAmount());
        this.totalPayout = CommonHelper.getStrFromMoneyOrZero(premiumCalculationBi.getTotalPayoutAmount());
        
    }
}
