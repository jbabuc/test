package com.pmli.ms.bo.customer.response;

import lombok.Data;

@Data
public class ApplicationCrmResponse {
	private Head head;
	private Body body;

	@Data
	public class Head {
		private int statusCode;
	}

	@Data
	public class Body {
		private String message;
		private String applicationNumber;
	}
}
