package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class SaveApplicationProps {

	@Value("${" + Constants.CREATE_APPLICATION + ".channel.name}")
	private String channelName;

	@Value("${" + Constants.CREATE_APPLICATION + ".transaction.type}")
	private String trasactionType;

	@Value("${" + Constants.CREATE_APPLICATION + ".sale.online.type}")
	private String saleOnlineType;

	@Value("${" + Constants.CREATE_APPLICATION + ".currency.code}")
	private String currencyCode;

	@Value("${" + Constants.CREATE_APPLICATION + ".product.code}")
	private String productCode;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".ReturnOfPremium}")
	private String returnOfPremium;

	@Value("${" + Constants.CREATE_APPLICATION + ".StaticTransferOption}")
	private String staticTransferOption;

	@Value("${" + Constants.CREATE_APPLICATION + ".AutoRebalance}")
	private String autoRebalance;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".multiple}")
	private String multiple;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".isbackdation}")
	private String isbackdation;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".authorization}")
	private String authorization;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".x-ibm-client-id}")
	private String xIbmClientId;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".requestId}")
	private String requestId;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".channel}")
	private String channel;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".userId}")
	private String userId;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".source}")
	private String source;
	
	@Value("${" + Constants.SAVE_APPLICATION + ".url}")
	private String saveUrl;
}
