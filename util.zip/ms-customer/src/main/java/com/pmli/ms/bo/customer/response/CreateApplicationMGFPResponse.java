package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;


/**
 * This class holds the response details for MGFP 'Create-Application' API
 * 
 * @author Hemant Solanki
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
public class CreateApplicationMGFPResponse {

    @ApiModelProperty(required = true, value = "Application Number", example = "15006789")
    private String applicationNumber;
    @ApiModelProperty(required = true, value = "Proposal Form Link", example = "https://uat-ebranchnxt.pnbmetlife.com/buy-online/Pre-Payment/#/trackapplication/navigation?leadid=XPGX6OU1+jYTsz5hApXR5Q6IXThHn+POEQ1GhfQxxA8=")
    private String uri;

}
