package com.pmli.ms.bo.customer.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BranchDetail {
	private String branchCode;
	private String branchName;
}
