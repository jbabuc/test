package com.pmli.ms.bo.customer.model;

import java.util.List;

import lombok.Data;

@Data
public class CustomerHealth {
	 private String  isSmoker;
	 private int healthCoverId;
	 private String healthCover;
	 private int numberOfAdult;
	 private int numberOfChildren;
	 private List<HealthFamilyAge> familyMembers;
	 private int healthSumInsuredId;
	 private String healthSumInsured;
	 private HealthAddOns addOns;
}
