package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class DownloadAppFormProps {
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".error.message.key.length}")
	private String errMsgKeyLength;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".error.message.data.not.found.for.key.more.info}")
	private String errMsgDataNotFoundKey;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".error.message.app.num.not.present.more.info}")
	private String errMsgAppNumNotPresent;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".x-ibm-client-id}")
	private String xIbmClientId;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".x-ibm-client-secret}")
	private String xIbmClientSecret;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".requestId}")
	private String requestId;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".channel}")
	private String channel;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".userId}")
	private String userId;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".source}")
	private String source;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".url}")
	private String downloadAppFormUrl;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".documentclass}")
	private String documentClass;
	
	@Value("${" + Constants.DOWNLOAD_APP_FORM + ".iswrite}")
	private int isWrite;
}
