package com.pmli.ms.bo.customer.model;

public class FieldConstants {

    private FieldConstants() {}

    public static final String LD_LEADID = "leadId";

    public static final String LD_CREATED_ON = "createdOn";

    public static final String LD_LAST_UPDATED_ON = "lastUpdatedOn";
    
    public static final String LD_LAST_UPDATE_ON = "lastUpdateOn";

    public static final String LD_EXPIRED_ON = "expiredOn";

    public static final String LD_APPLICATIONUMBER = "applicationNumber";

    public static final String LD_QUOTATIONID = "quotationId";

    public static final String LD_RECORD_STATUS = "recordStatus";

    public static final String LD_PAYMENT = "payment";

    public static final String LD_PAYMENT_PAYMENT_DATE = "paymentDate";

    public static final String LD_MOBILE_NUMBER = "mobileNumber";

    public static final String LD_PREMIUM_CALC_PRODUCT_ID = "productId";
}
