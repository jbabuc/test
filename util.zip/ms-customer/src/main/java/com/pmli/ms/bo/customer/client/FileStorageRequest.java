package com.pmli.ms.bo.customer.client;

import lombok.Data;

@Data
public class FileStorageRequest {
	private String loginId;
	private int loginType;
	private String clientId;
	private String fileContent;
	private String fileName;
}
