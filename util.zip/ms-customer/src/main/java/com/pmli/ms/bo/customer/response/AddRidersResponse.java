package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * This class holds the response details for Add Riders
 * 
 * @author Snehal Shimpi
 * @version 1.0.0
 */

public class AddRidersResponse {
	@ApiModelProperty(required = true, value = "Message", example = "Rider(s) added successfully")
	private String message;
}
