package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class AddPremiumProps {

	@Value("${" + Constants.BASE_PATH + "add.premium.success}")
	private String addPremiumSuccess;
}
