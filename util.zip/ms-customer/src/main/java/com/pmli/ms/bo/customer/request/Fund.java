package com.pmli.ms.bo.customer.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Fund {
    @ApiModelProperty(required = false, value = "Fund Id", example = "1")
    private int fundId;
    @ApiModelProperty(required = false, value = "Fund Percent", example = "0")
    private int fundPercent;
}
