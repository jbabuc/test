package com.pmli.ms.bo.customer.response;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * This class holds the response details from the external service - 'nvest service'.
 * 
 * @author snehal shimpi
 *
 */

@Data
public class PremiumCalculationNvestResponse {
    @JsonProperty("BIJson")
    private String biJson;
    
    @JsonProperty("BIJson2")
    private String biJson2;

    private List<BIJson> biJsonList;
    private List<BIJson> biJson2List;

    @JsonProperty("InputValidationStatus")
    private List<InputValidationStatus> inputValidationStatus;

    @JsonProperty("Message")
    private String message;

    @JsonProperty("QuotationId")
    private String quotationId;

    @JsonProperty("Status")
    private String status;
    
    @JsonProperty("Step")
	private String step;
	
	@JsonProperty("TransactionId")
	private String transactionId;
	
	@JsonProperty("balic_Quoteid")
	private String balicQuoteid;	
	
	@JsonProperty("RiderBIJson")
	private String riderBiJson;

    @Data
    public static class BIJson {
        @JsonProperty("PolicyYear")
        private int policyYear;

        @JsonProperty("LI_ATTAINED_AGE")
        private int ageLifeAssured;

        @JsonProperty("SA")
        private BigDecimal sumAssuredAmount;

        @JsonProperty("POLICYTERM")
        private int policyTerm;

        @JsonProperty("SB_G")
        private BigDecimal maturityBenefitAmount;

        @JsonProperty("CASH_BONUS_BS_1")
        private BigDecimal cashBonus1Amount;

        @JsonProperty("CASH_BONUS_BS_2")
        private BigDecimal cashBonus2Amount;

        @JsonProperty("ACCRUED_REV_BONUS_BS_1")
        private BigDecimal accruedReversionaryBonuses1Amount;

        @JsonProperty("ACCRUED_REV_BONUS_BS_2")
        private BigDecimal accruedReversionaryBonuses2Amount;

        @JsonProperty("TERMINAL_BONUS_BS_1")
        private BigDecimal terminalBonus1Amount;

        @JsonProperty("TERMINAL_BONUS_BS_2")
        private BigDecimal terminalBonus2Amount;

        @JsonProperty("TOTAL_SB_G_BS_1")
        private BigDecimal totalMaturityBenefitAmount;

        @JsonProperty("DB_G")
        private BigDecimal guaranteedDeathBenefit;

        @JsonProperty("GUAR_INCOME")
        private BigDecimal guaranteedIncomeAmount;

        @JsonProperty("DEATH_BEN")
        private BigDecimal deathBenifitAmount;

    }

    @Data
    public static class ErrorMessage {

        private String key;
        private String value;
    }

    @Data
    public static class InputValidationStatus {

        @JsonProperty("AnnualPremium")
        private BigDecimal annualPremiumAmount;

        @JsonProperty("ErrorMessage")
        private List<ErrorMessage> errorMessages;

        @JsonProperty("GeneralError")
        private String generalError;

        @JsonProperty("ModalPremium")
        private BigDecimal modelPremiumAmount;

        @JsonProperty("ModeDisc")
        private BigDecimal modeDescription;

        @JsonProperty("PPT")
        private int policyTerm;

        @JsonProperty("PT")
        private int payTerm;

        @JsonProperty("ProductId")
        private int productId;

        @JsonProperty("SA")
        private BigDecimal sumAssuredAmount;

        @JsonProperty("SumAssured")
        private BigDecimal sumAssured;

        @JsonProperty("Tax")
        private BigDecimal serviceTaxAmount;
    }
}