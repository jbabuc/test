package com.pmli.ms.bo.customer.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.pmli.ms.bo.customer.model.FileDetail;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.client.RestConsumer;

import lombok.Data;

public class FileStorageHelper extends MsObject {
    RestConsumer restConsumer;
    String       fileStorageUploadUrl;
    List<FileRef> fileRefs = new ArrayList<>();
    
    public List<FileRef> getFileRefs() {
		return fileRefs;
	}
    
   @Data
   public static class FileRefDetails{
	    private String quotationId;
    	private List<FileRef> fileRefs;
    	public FileRefDetails(String quotationId,List<FileRef> fileRefs ){
    		this.quotationId=quotationId;
    		this.fileRefs = fileRefs;
    	}
    }
	@Data
    public static class FileRef{
    	private String name;
    	private String ref;
		public FileRef(String name, String ref) {
			this.name = name;
			this.ref = ref;
		}
    	
    }
	public FileStorageHelper(RestConsumer restConsumer, String fileStorageUploadUrl) {
        this.restConsumer = restConsumer;
        this.fileStorageUploadUrl = fileStorageUploadUrl;
    } 
	public FileStorageResponse storeFile(FileDetail fileDetail)  {
		FileStorageRequest fileStorageRequest = new FileStorageRequest();
		fileStorageRequest.setFileContent(fileDetail.getBase64());
		fileStorageRequest.setFileName(fileDetail.getFileName());
		fileStorageRequest.setLoginType(1);
		fileStorageRequest.setLoginId("5645236");
		fileStorageRequest.setClientId("869554585982");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String ret = restConsumer.callClientEndPoint(fileStorageUploadUrl, headers,JsonUtil.writeValueAsString(fileStorageRequest));
		FileStorageResponse fileStorageResponse = JsonUtil.readValue(ret, FileStorageResponse.class);
		fileRefs.add(new FileRef(fileDetail.getFileName(),fileStorageResponse.getFileRef()));
		return fileStorageResponse;
	}
	
}
