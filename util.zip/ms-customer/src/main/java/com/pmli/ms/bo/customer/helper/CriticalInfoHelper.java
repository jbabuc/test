package com.pmli.ms.bo.customer.helper;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.pmli.ms.bo.customer.request.CriticalInfoRequest;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.validation.StringValidator;

public class CriticalInfoHelper {

    public void validate(CriticalInfoRequest criticalInfoRequest) { validateDate(criticalInfoRequest); }

    private void validateDate(CriticalInfoRequest criticalInfoRequest) {
        if (!ObjectUtils.isEmpty(criticalInfoRequest.getCriticalInfoDetails().getCriticalInfoDiseaseDetails())) {
            criticalInfoRequest.getCriticalInfoDetails().getCriticalInfoDiseaseDetails().forEach(c -> {
                if (ObjectUtils.isNotEmpty(c.getCovidDetails())
                    && StringUtils.isNotEmpty(c.getCovidDetails().getCountryVisited())) {
                    validateDateFormat(c.getCovidDetails().getDurationFrom(), "duration from");
                    validateDateFormat(c.getCovidDetails().getDurationTo(), "duration to");
                }
            });
        }
    }

    /**
     * This method validate Date Time "yyyy-MM-dd'T'HH:mm:ss.SSSXXX". And ignore the Null and Empty value.
     * 
     * @param date
     * @param displayName
     */
    private void validateDateFormat(String date, String displayName) {
        if (StringUtils.isNotBlank(date)) {
            new StringValidator(date, displayName).validate(StringValidator::isDate,
                IsoDateDeSerializer.MONGO_DATE_FORMAT, false);
        }
    }

}
