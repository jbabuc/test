package com.pmli.ms.bo.customer.comm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.client.RestConsumer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class holds the functionality to generate and Validate OTP.
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */

@Component
public class OtpClient extends MsObject {
    @Autowired
    private CommonProps commonProps;

    @Autowired
    private RestConsumer restConsumer;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class GenerateOtpRequest {
        private String loginId;
        private int    loginType;
        private String clientId;
        private String templateId;
        private String transactionId;
        private String mobileNo;
        private String emailId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class GenerateOtpResponse {
        private String transactionId;
        private String counter;
        private String allowedAttempts;
    }

    /**
     * This method is use to generate the OTP
     * 
     * @param  mobile the String contains the mobile number
     * @param  email  the String contains the email Id
     * @return        the Obj of GenerateOtpResponse
     */
    public ResponseEntity<String> generateOtp(String mobile, String email) {
        GenerateOtpRequest otpRequest = new GenerateOtpRequest(commonProps.getLoginId(),
            Integer.parseInt(commonProps.getLoginType()), commonProps.getClientId(), commonProps.getOtpTemplateId(), "",
            mobile, email);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        log.info("SMS/Email is triggered on: {}/{} ", otpRequest.getMobileNo(), otpRequest.getEmailId());
        return restConsumer.callClientEndPoint(HttpMethod.POST, commonProps.getGenerateOtpUrl(), headers,
            JsonUtil.writeValueAsString(otpRequest));
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ValidateOtpRequest {
        private String loginId;
        private int    loginType;
        private String clientId;
        private String transactionId;
        private String otp;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ValidateOtpResponse {
        private String transactionId;
        private String counter;
        private String allowedAttempts;
    }

    /**
     * This method is use validate the OTP
     * 
     * @param  transactionId the String contains the transaction ID
     * @param  otp           the String contains the OTP
     * @return               the Obj of ValidateOtpResponse
     */
    public ResponseEntity<String> validateOtp(String transactionId, String otp) {
        ValidateOtpRequest validateOtpReq = new ValidateOtpRequest();
        validateOtpReq.setClientId(commonProps.getClientId());
        validateOtpReq.setLoginId(commonProps.getLoginId());
        validateOtpReq.setLoginType(Integer.parseInt(commonProps.getLoginType()));
        validateOtpReq.setTransactionId(transactionId);
        validateOtpReq.setOtp(otp);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return restConsumer.callClientEndPoint(HttpMethod.POST, commonProps.getOtpValidateUrl(), headers,
            JsonUtil.writeValueAsString(validateOtpReq));
    }
}
