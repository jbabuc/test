package com.pmli.ms.bo.customer.request;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class holds the Add ACHADM request details
 * 
 * @author Snehal Shimpi
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class ACHADMRequest extends LeadRequest {
	@ApiModelProperty(required = true, value = "ACHADM", example = "false")
	private boolean achadm;
}
