package com.pmli.ms.bo.customer.response;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.LeadListRequest;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.java.JUtil;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * This class holds the response details of 'get-leads-list' API.
 * 
 * @author  Snehal Shimpi
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
public class LeadListResponse {
    @ApiModelProperty(required = true, value = "mobileNumber", example = "9029199934")
    private String            mobileNumber;
    private List<BasicDetail> leads;

    public LeadListResponse(LeadListRequest requestPayload, List<LeadDetail> leadList, DBClient dbClient,
        CommonProps commonProps) {
        this.mobileNumber = requestPayload.getMobileNumber();
        this.leads = leadList.stream().map(l -> new BasicDetail(l, dbClient, commonProps)).collect(Collectors.toList());
    }

    @AllArgsConstructor
    @Data
    public static class BasicDetail {
        @ApiModelProperty(required = true, value = "leadId", example = "20210914192951870295")
        private String leadId;
        @ApiModelProperty(required = true, value = "quotationNumber", example = "98723442")
        private String quotationNumber;
        @ApiModelProperty(required = true, value = "applicationNumber", example = "8123442")
        private String applicationNumber;
        private Name   name;
        @ApiModelProperty(required = true, value = "planName", example = "PNB MetLife Super Saver Plan")
        private String planName;
        @ApiModelProperty(required = true, value = "lastActionPerformed", example = "2")
        private int    lastActionPerformed;
        @ApiModelProperty(required = true, value = "lastUpdateDate", example = "2021-09-03T16:15:57.700+05:30")
        private String lastUpdateDate;

        public BasicDetail(LeadDetail ld, DBClient dbClient, CommonProps commonProps) {

			this.leadId = ld.getLeadId();
			this.quotationNumber = ld.getQuotationId();
			this.applicationNumber = ld.getApplicationNumber();
			if (!Objects.isNull(ld.getName())) {
				this.name = new Name(
						dbClient.getMasterValueByTypeKey(commonProps.getMasterKeyDataTypeTitle(), ld.getTitle()),
						ld.getFirstName(), of(ld.getName().split(" ")).map(ns -> ns.length > 3 ? ns[2] : "").get(),
						ld.getLastName());
			}
			ofNullable(ld.getPremiumCalculation()).ifPresent(pc -> this.planName = pc.getPlanName());
			this.lastActionPerformed = CommonHelper.parseIntOrZero(ld.getStep());
			ofNullable(ld.getLastUpdatedOn()).ifPresent(pd -> this.lastUpdateDate = JUtil
					.getFormattedDateTime(ld.getLastUpdatedOn(), IsoDateDeSerializer.MONGO_DATE_FORMAT));
		}
    }
}
