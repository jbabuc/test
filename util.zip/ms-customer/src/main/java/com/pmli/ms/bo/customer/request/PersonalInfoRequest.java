package com.pmli.ms.bo.customer.request;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.pmli.ms.bo.customer.model.PersonalInfo.Appointee;
import com.pmli.ms.bo.customer.model.PersonalInfo.AppointeeRelation;
import com.pmli.ms.bo.customer.model.PersonalInfo.BasicInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.ContactInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.Details;
import com.pmli.ms.bo.customer.model.PersonalInfo.DocumentProofInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.EducationOccupationInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.FamilyInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.NationalityInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo.NomineeDetails;
import com.pmli.ms.bo.customer.model.PersonalInfo.NomineeInfo;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Address;
import com.pmli.util.model.Email;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Request for Add Personal Info
 * 
 * @author 3483784san
 *
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class PersonalInfoRequest extends LeadRequest {
	private PersonalInfo personalInfo;
	@JsonIgnoreProperties
	private static final String TITLE = "title";
	@Data
	@NoArgsConstructor
	public static class PersonalInfo {

		private Basic basicInfo;
		private Basic basicInfoPO;
		private Basic basicInfoJointLife;
		private Nationality nationalityInfo;
		private Nationality nationalityInfoJointLife;
		private Nationality nationalityInfoPO;
		private Contact contactInfo;
		private Contact contactInfoPO;
		private Contact contactInfoJointLife;
		private List<Family> familyDetails;
		private List<Family> familyDetailsPO;
		private String maritalStatusPO;
		private int maritalStatus;
		private String relationWithPO;
		private EducationOccupation educationOccupationInfo;
		private EducationOccupation educationOccupationInfoPO;
		private EducationOccupation educationOccupationInfoJointLife;
		private DocumentProof documentProofInfo;
		private DocumentProof documentProofInfoPO;
		private DocumentProof documentProofInfoJointLife;
		private List<Nominee> nominees;
		private AppointeeInfo appointeeInfo;

		public PersonalInfo(com.pmli.ms.bo.customer.model.PersonalInfo personalInfo) {
			ofNullable(personalInfo.getBasicInfo()).ifPresent(b -> this.basicInfo = new Basic(b));
			ofNullable(personalInfo.getBasicInfoPO()).ifPresent(b -> this.basicInfoPO = new Basic(b));
			ofNullable(personalInfo.getBasicInfoJointLife())
					.ifPresent(b -> this.basicInfoJointLife = new Basic(b));

			ofNullable(personalInfo.getNationalityInfo()).ifPresent(n -> this.nationalityInfo = new Nationality(n));
			ofNullable(personalInfo.getNationalityInfoPO()).ifPresent(n -> this.nationalityInfoPO = new Nationality(n));
			ofNullable(personalInfo.getNationalityJointLife())
					.ifPresent(n -> this.nationalityInfoJointLife = new Nationality(n));

			ofNullable(personalInfo.getContactInfo()).ifPresent(n -> this.contactInfo = new Contact(n));
			ofNullable(personalInfo.getContactInfoPO()).ifPresent(n -> this.contactInfoPO = new Contact(n));
			ofNullable(personalInfo.getContactInfoPOJointLife())
					.ifPresent(n -> this.contactInfoJointLife = new Contact(n));

			ofNullable(personalInfo.getFamilyInfo()).ifPresent(f -> this.familyDetails = f.stream()
					.map(Family::new).collect(Collectors.toList()));
			ofNullable(personalInfo.getFamilyInfoPO()).ifPresent(f -> this.familyDetailsPO = f.stream()
					.map(Family::new).collect(Collectors.toList()));

			this.maritalStatusPO = personalInfo.getMaritalStatusPO();
			this.maritalStatus = Integer.parseInt(personalInfo.getMaritalStatus());
			this.relationWithPO = personalInfo.getRelationWithPO();

			ofNullable(personalInfo.getEducationOccupationInfo())
					.ifPresent(n -> this.educationOccupationInfo = new EducationOccupation(n));
			ofNullable(personalInfo.getEducationOccupationInfoPO())
					.ifPresent(n -> this.educationOccupationInfoPO = new EducationOccupation(n));
			ofNullable(personalInfo.getEducationOccupationInfoJointLife())
					.ifPresent(n -> this.educationOccupationInfoJointLife = new EducationOccupation(n));

			ofNullable(personalInfo.getDocumentProofInfo())
					.ifPresent(n -> this.documentProofInfo = new DocumentProof(n));
			ofNullable(personalInfo.getDocumentProofInfoPO())
					.ifPresent(n -> this.documentProofInfoPO = new DocumentProof(n));
			ofNullable(personalInfo.getDocumentProofInfoJointLife())
					.ifPresent(n -> this.documentProofInfoJointLife = new DocumentProof(n));

			ofNullable(personalInfo.getNomineeInfo()).ifPresent(
					f -> this.nominees = f.stream().map(Nominee::new).collect(Collectors.toList()));

			ofNullable(personalInfo.getAppointeeInfo())
					.ifPresent(n -> this.appointeeInfo = new AppointeeInfo(n));
		}
	}

	@Data
	@NoArgsConstructor
	public static class AppointeeInfo {
		private Name name;
		@ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
		private String birthDate;
		@ApiModelProperty(required = true, value = "Marital Status", example = "1")
		private int maritalStatus;
		private List<AppointeeRelationship> appointeeRelationships;
		@ApiModelProperty(required = false, value = "Status", example = "true")
		private boolean status;

		public AppointeeInfo(Appointee a) {
			this.name = new Name(a.getTitle(), a.getFirstName(),"",
					a.getLastName());
			this.birthDate = a.getBirthDate();
			this.maritalStatus = a.getMaritalStatus();
			this.status = a.isStatus();
			ofNullable(a.getAppointeeRelationships()).ifPresent(f -> this.appointeeRelationships = f.stream()
					.map(AppointeeRelationship::new).collect(Collectors.toList()));
		}
	}

	@Data
	@NoArgsConstructor
	public static class AppointeeRelationship {
		@ApiModelProperty(required = false, value = "Nominee Index", example = "1")
		private int nomineeIndex;
		@ApiModelProperty(required = false, value = "Relationship", example = "1")
		private int relationship;

		public AppointeeRelationship(AppointeeRelation o) {
			this.nomineeIndex = o.getNomineeIndex();
			this.relationship = o.getRelationship();
		}
	}

	@Data
	@NoArgsConstructor
	public static class DocumentProof {

		@ApiModelProperty(required = false, value = "Id Proof", example = "1")
		private int idProof;
		@ApiModelProperty(required = false, value = "Address Proof", example = "1")
		private int addressProof;
		@ApiModelProperty(required = false, value = "Age Proof", example = "1")
		private int ageProof;
		@ApiModelProperty(required = false, value = "Income Proof", example = "1")
		private int incomeProof;
		@ApiModelProperty(required = false, value = "Pan Card", example = "DFCDF5645P")
		private String panCard;
		@ApiModelProperty(required = false, value = "Aadhar Card", example = "123456768965")
		private long aadharCard;
		@ApiModelProperty(required = false, value = "status", example = "true")
		private boolean status;

		public DocumentProof(DocumentProofInfo d) {
		    ofNullable(d.getIdProof()).ifPresent(i -> this.idProof = Integer.parseInt(i));
		    ofNullable(d.getAddressProof()).ifPresent(addProof -> this.addressProof = Integer.parseInt(addProof));
		    ofNullable(d.getAgeProof()).ifPresent(a -> this.ageProof = Integer.parseInt(a));
		    ofNullable(d.getIncomeProof()).ifPresent(inProof -> this.incomeProof = Integer.parseInt(inProof));
			this.panCard = d.getPanCard();
			ofNullable(d.getAadharCard()).ifPresent(aadhar -> {
			    if(!StringUtils.isEmpty(aadhar)) this.aadharCard = Long.valueOf(aadhar);
			});
			this.status = d.isStatus();

		}
	}

	@Data
	@NoArgsConstructor
	public static class Nominee {
		private int index;
		private int nomineeIndex;
		private boolean status;
		private NomineeDetail detail;

		public Nominee(NomineeInfo o) {
			this.index = o.getIndex();
			this.nomineeIndex = o.getNomineeIndex();
			this.detail = new NomineeDetail(o.getDetails());
		}

	}

	@Data
	@NoArgsConstructor
	public static class NomineeDetail {
		private Name name;
		@ApiModelProperty(required = true, value = "RelationShip", example = "1")
		private int relationShip;
		@ApiModelProperty(required = true, value = "BirthDate", example = "1999-10-10")
		private String birthDate;
		@ApiModelProperty(required = true, value = "Marital Status", example = "1")
		private int maritalStatus;
		@ApiModelProperty(required = true, value = "PrecentageEntitlement", example = "1")
		private int precentageEntitlement;
		private Address mailingAddress;
		private int nomineeAddressSameAs;
		private boolean status;

		public NomineeDetail(NomineeDetails n) {
			this.name = new Name(n.getTitle(), n.getFirstName(),"",
					n.getLastName());
			this.relationShip = Integer.parseInt(n.getRelationShip());
			this.birthDate = n.getBornOn();
			this.maritalStatus = Integer.parseInt(n.getMaritalStatus());
			this.precentageEntitlement = Integer.parseInt(n.getPrecentageEntitlement());
            ofNullable(n.getMailingAddress()).ifPresent(mail -> 
                this.mailingAddress = new Address("", "", "", "", "", mail.getCity(), "", mail.getDistrict(),
                    mail.getPinCode(), mail.getState(), mail.getCountry())
            );
			this.nomineeAddressSameAs = n.getNomineeAddressSameAs();
			this.status = n.isStatus();
		}
	}

	@Data
	@NoArgsConstructor
	public static class EducationOccupation {

		@ApiModelProperty(required = true, value = "Organization Name", example = "ICIC Bank")
		private String organizationName;
		@ApiModelProperty(required = true, value = "Occupation", example = "11")
		private int occupation;
		@ApiModelProperty(required = true, value = "Nature Of Duties", example = "Banker")
		private String natureOfDuties;
		@ApiModelProperty(required = true, value = "Designation", example = "31")
		private int designation;
		@ApiModelProperty(required = true, value = "Tax Resident", example = "abc")
		private String natureOfBusiness;
		@ApiModelProperty(required = true, value = "Nature Of Business", example = "10")
		private int yearOfService;
		private Money annualIncomeAmount;
		@ApiModelProperty(required = true, value = "Educational Qualification", example = "2")
		private int educationalQualification;
		@ApiModelProperty(required = true, value = "Status", example = "true")
		private boolean status;

		public EducationOccupation(EducationOccupationInfo e) {
			if (!Objects.isNull(e)) {
				ofNullable(e.getOrganizationName()).ifPresent(on->this.organizationName = e.getOrganizationName());
				ofNullable(e.getOccupation()).ifPresent(o -> this.occupation = Integer.parseInt(e.getOccupation()));
				ofNullable(e.getNatureOfDuties()).ifPresent(nob-> this.natureOfDuties = e.getNatureOfDuties());
				ofNullable(e.getDesignation())
						.ifPresent((d -> this.designation = Integer.parseInt(e.getDesignation())));
				ofNullable(e.getNatureOfBusiness()).ifPresent(nob-> this.natureOfBusiness = e.getNatureOfBusiness());
				if(!StringUtils.isEmpty(e.getYearOfService())) {
					ofNullable(e.getYearOfService())
					.ifPresent(yos -> this.yearOfService = Integer.parseInt(e.getYearOfService()));
				}
				
				if (!StringUtils.isEmpty(e.getAnnualIncome())) {
					ofNullable(e.getAnnualIncome()).ifPresent(ai -> this.annualIncomeAmount = new Money(new BigDecimal(e.getAnnualIncome())));
				}
				 
				ofNullable(e.getEducationalQualification()).ifPresent(
						eq -> this.educationalQualification = Integer.parseInt(e.getEducationalQualification()));
				ofNullable(e.isStatus()).ifPresent(s-> this.status = e.isStatus());
			}
		}
	}

	@Data
	@NoArgsConstructor
	public static class Family {
		@ApiModelProperty(required = true, value = "Member", example = "father")
		private String member;
		@ApiModelProperty(required = true, value = "Status", example = "true")
		private boolean status;
		private Detail detail;

		public Family(FamilyInfo family) {
			this.member = family.getMember();
			this.status = family.isStatus();
			this.detail = new Detail(family.getDetails());
		}
	}

	@Data
	@NoArgsConstructor
	public static class Detail {
		private Name name;

		public Detail(Details details) {
			this.name = new Name(details.getTitle(), details.getFirstName(),"",
					details.getLastName());
		}
	}

	@Data
	@NoArgsConstructor
	public static class Contact {

		@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
		private Address mailingAddress;
		@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
		private Address permanentAddress;
		@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
		private Address jurisdictionAddress;
		@JsonIgnoreProperties
		private int isPermanentAddress;
		@JsonIgnoreProperties
		private int proposerMailingAddressSameAs;
		@JsonIgnoreProperties
		private int proposerPermanentAddressSameAs;
		@JsonIgnoreProperties
		private int proposerJurisdictionAddressSameAs;

		public Contact(ContactInfo c) {
			this.mailingAddress = new Address("", "", "", "", "", c.getMailingAddress().getCity(),
					c.getMailingAddress().getLocality(), c.getMailingAddress().getDistrict(),
					c.getMailingAddress().getPinCode(), c.getMailingAddress().getState(),
					c.getMailingAddress().getCountry());
			this.permanentAddress = new Address("", "", "", "", "", c.getPermanentAddress().getCity(),
					c.getPermanentAddress().getLocality(), c.getPermanentAddress().getDistrict(),
					c.getPermanentAddress().getPinCode(), c.getPermanentAddress().getState(),
					c.getPermanentAddress().getCountry());
			this.jurisdictionAddress = new Address("", "", "", "", "", c.getJurisdictionAddress().getCity(),
					c.getJurisdictionAddress().getLocality(), c.getJurisdictionAddress().getDistrict(),
					c.getJurisdictionAddress().getNriPinCode(), c.getJurisdictionAddress().getState(),
					c.getJurisdictionAddress().getCountry());
			ofNullable(c.getIsPermanentAddress()).ifPresent(permAddress -> this.isPermanentAddress = Integer.parseInt(permAddress));
			this.proposerMailingAddressSameAs = 1;
			this.proposerPermanentAddressSameAs = 2;
			this.proposerJurisdictionAddressSameAs = 3;

		}

	}

	@Data
	@NoArgsConstructor
	public static class Nationality {
		@ApiModelProperty(required = true, value = "Citizenship", example = "1")
		private int citizenship;

		@ApiModelProperty(required = true, value = "Residential Status", example = "1")
		private int residentialStatus;

		@ApiModelProperty(required = true, value = "Tax Resident", example = "1")
		private int taxResident;
		@ApiModelProperty(required = true, value = "Birth Place", example = "2018-02-10")
		private String birthPlace;
		@ApiModelProperty(required = true, value = "Status", example = "true")
		private boolean status;

		public Nationality(NationalityInfo b) {
			this.citizenship = Integer.parseInt(b.getCitizenship());
			this.residentialStatus = Integer.parseInt(b.getResidentialStatus());
			this.taxResident = Integer.parseInt(b.getTaxResident());
			this.birthPlace = b.getBirthOfPlace();
			this.status = b.isStatus();
		}
	}

	@Data
	@NoArgsConstructor
	public static class Basic {
		public Basic(BasicInfo b) {
			this.name = new Name(b.getTitle(), b.getFirstName(), "",
					b.getLastName());
			this.gender = b.getGender();
			this.birthDate = b.getDateOfBirth();
			this.email = new Email(b.getEmailId(), "", true);
			List<PhoneNumber> phoneList = new ArrayList<>();
			PhoneNumber phNum = new PhoneNumber();
			phNum.setNumber(b.getMobileNumber());
			phoneList.add(phNum);
			this.phoneNumbers = phoneList;
			this.registerCommunicationEmailId = 1;
			this.status = b.isStatus();

		}

		private Name name;
		@ApiModelProperty(required = true, value = "Gender", example = "M")
		private String gender;
		@ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
		private String birthDate;
		private List<PhoneNumber> phoneNumbers;
		private Email email;
		@JsonIgnoreProperties
		private int registerCommunicationEmailId;
		@ApiModelProperty(required = true, value = "Status", example = "true")
		private boolean status;
	}
}
