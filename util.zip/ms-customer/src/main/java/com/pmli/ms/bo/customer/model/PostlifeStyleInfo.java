package com.pmli.ms.bo.customer.model;

import com.pmli.ms.bo.customer.model.LifeStyleInfo.EInsuranceAccountDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.FamilyDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.InsuranceDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.LifeStyleDetails;

import lombok.Data;

@Data
public class PostlifeStyleInfo {
    private LifeStyleDetails lifeStyleDetails;
    private InsuranceDetails insuranceDetails;
    private FamilyDetails familyDetails;
    private EInsuranceAccountDetails eInsuranceAccountDetails;
}
