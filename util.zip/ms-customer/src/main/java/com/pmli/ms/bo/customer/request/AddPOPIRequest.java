/**
 * 
 */
package com.pmli.ms.bo.customer.request;

import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Name;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 3483784san
 * @since 25 August 2021
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AddPOPIRequest extends LeadRequest {

	@ApiModelProperty(required = true, value = "Buy for Self", example = "false")
	private boolean buyForSelf;

	@FieldMetaJson("{nullable:false,displayName: 'Name Detail',validations:'notNull',childDataValidations:[{childPath:'title',displayName:'title',nullable:false,validations:'notBlank'},{childPath:'firstName',displayName:'firstName',nullable:false,validations:'notBlank'},{childPath:'lastName',displayName:'lastName',nullable:false,validations:'notBlank'}]}")
	private Name name;

	@ApiModelProperty(required = true, value = "Gender", example = "Male")
	@FieldMetaJson("{displayName:'Gender',nullable:false,validations:'notBlank'}")
	private String gender;

	@ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
	@FieldMetaJson("{displayName:'Birth Date',nullable:false,validations:'notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$'}")
	private String birthDate;

	private FamilyMember familyMember;
}
