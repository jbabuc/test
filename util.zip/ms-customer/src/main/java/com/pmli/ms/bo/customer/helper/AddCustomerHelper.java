package com.pmli.ms.bo.customer.helper;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.Validator;

import lombok.AllArgsConstructor;

/**
 * @author 3483784san
 */
@AllArgsConstructor
public class AddCustomerHelper extends MsObject {

    DBClient dbClient;

    CommonProps commProps;

    CustomerRequest addCustomerDetails;

    CommonHelper commonHelper;

    public LeadDetail prepare() {
        final String otherValidations = "notBlank";
        final String dateValidations = "notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$";
        String familyTitle = null;

        if (addCustomerDetails.getBuyTypeCode() == 2) {
            new Validator(addCustomerDetails.getFamilyMember(), "Family Member", false).notNull();
            new Validator(addCustomerDetails.getFamilyMember().getName(), "Family Member Name", false).notNull();
            new StringValidator(addCustomerDetails.getFamilyMember().getName().getTitle(), "Family Member Title", false)
                .notNullNotBlank();
            familyTitle = addCustomerDetails.getFamilyMember().getName().getTitle();
            new ComparableValidator(addCustomerDetails.getFamilyMember().getAge(), "Family Member Age", false)
                .greaterThan(0);
            new StringValidator(addCustomerDetails.getFamilyMember().getName().getFirstName(),
                "Family Member First Name", false).notNullNotBlank();
            new StringValidator(addCustomerDetails.getFamilyMember().getName().getLastName(), "Family Member Last Name",
                false).notNullNotBlank();
            new StringValidator(addCustomerDetails.getFamilyMember().getGender(), "Family Member Gender", false)
                .validateAll(otherValidations);
            new StringValidator(addCustomerDetails.getFamilyMember().getBirthDate(), "Family Member BirthDate", false)
                .validateAll(dateValidations);

            new ComparableValidator(addCustomerDetails.getFamilyMember().getAge(), "Age", false)
                .validate(ComparableValidator::greaterThan, -1).validate(ComparableValidator::lessThan, 61);
        } else {
            new ComparableValidator(addCustomerDetails.getAge(), "Age", false)
                .validate(ComparableValidator::greaterThan, 17).validate(ComparableValidator::lessThan, 61);
        }

        return new LeadDetail(addCustomerDetails, commonHelper.generateLeadId(),
            addCustomerDetails.getName().getTitle(), familyTitle);
    }

    /*
     * @param addCustomer
     * @return
     */
    public String save(LeadDetail leadDetail) { dbClient.saveLeadDetail(leadDetail); return leadDetail.getLeadId(); }
}
