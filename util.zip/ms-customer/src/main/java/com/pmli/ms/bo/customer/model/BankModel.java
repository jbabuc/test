package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class BankModel {
    private String bankName;
    private String micrCode;
    private String accountNumber;
    private String ifscCode;
    private String bankProof;
    private String accountType;
}
