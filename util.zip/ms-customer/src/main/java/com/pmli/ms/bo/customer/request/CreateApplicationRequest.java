package com.pmli.ms.bo.customer.request;

import java.math.BigDecimal;
import java.util.List;

import static java.util.Optional.ofNullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.LeadDetailPremium;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Address;
import com.pmli.util.model.Email;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreateApplicationRequest {

    @Data
    @NoArgsConstructor
    public static class PremiumCalculation {
        @ApiModelProperty(required = false, value = "Maturity Age", example = "1")
        private int maturityAge;

        @ApiModelProperty(required = false, value = "Fund Strategy", example = "1")
        private int fundStrategy;
        private Money guaranteedDeathBenefitAmount;
        private Money totalPayoutAmount;

        @ApiModelProperty(required = false, value = "Deferment Value", example = "1")
        private String defermentValue;

        @ApiModelProperty(required = true, value = "Frequency Code", example = "12")
        private int frequencyCode;

        @ApiModelProperty(required = true, value = "Cover Term", example = "1")
        private int coverTerm;

        @ApiModelProperty(required = false, value = "Payment Term", example = "1")
        private int paymentTerm;

        @ApiModelProperty(required = false, value = "Cash Bonus Option", example = "1")
        private int cashBonusOption;

        @ApiModelProperty(required = true, value = "Product Id", example = "12007")
        private int productId;

        @ApiModelProperty(required = true, value = "Product Name", example = "PNB MetLife Super Saver Plan")
        private String productName;

        @ApiModelProperty(required = false, value = "Plan Id", example = "11")
        private int planId;

        @ApiModelProperty(required = true, value = "Plan Name", example = "Joint Life Last Survivor Annuity with Return of Purchase Price")
        private String planName;

        @ApiModelProperty(required = true, value = "Mode Disc", example = "1.0272")
        private String modeDisc;
        private Money  annualPremiumAmount;
        private Money  revisionaryBonusAmount;
        private Money  terminalBonusAmount;
        private Money  maturityBenefitAmount;

        private Money modalPremiumAmount;
        private Money serviceTaxAmount;
        private Money sumAssuredAmount;
        private Money premiumAmount;
        private int    option;
        private BigDecimal    multiple;
        private int    familyCareBenefit;
        private int    returnOfPremium;
        private int    investmentType;
        private String benefitPayoutDate;
        private Money  monthlyPremiumAmount;
        private Money  fundAtEndOfTheYearAmount;

        @ApiModelProperty(required = true, value = "Deferment", example = "1")
        private int deferment;

        @ApiModelProperty(required = false, value = "Income Payout Mode", example = "9")
        private int   incomePayoutMode;
        private Money guaranteedIncomeAmount;
        private Money accruedReversionaryBonusAmount;

        public PremiumCalculation(LeadDetailPremium p) {
            // str to int
            this.frequencyCode = CommonHelper.parseIntOrZero(p.getFrequency());
            this.coverTerm = CommonHelper.parseIntOrZero(p.getCoverTerms());
            this.paymentTerm = CommonHelper.parseIntOrZero(p.getPaymentTerms());
            this.cashBonusOption = CommonHelper.parseIntOrZero(p.getCashBonusOptions());
            this.familyCareBenefit = CommonHelper.parseIntOrZero(p.getFamilyCareBenefit());
            this.returnOfPremium = CommonHelper.parseIntOrZero(p.getReturnOfPremium());
            this.investmentType = CommonHelper.parseIntOrZero(p.getInvestmentType());
            this.option = CommonHelper.parseIntOrZero(p.getOption());
            ofNullable(p.getMultiple()).ifPresent(m-> this.multiple = new BigDecimal(p.getMultiple()));
            this.maturityAge = CommonHelper.parseIntOrZero(p.getMaturityAge());
            this.fundStrategy = CommonHelper.parseIntOrZero(p.getFundStrategy());
            this.incomePayoutMode = CommonHelper.parseIntOrZero(p.getIncomePayoutMode());

            // int to int
            this.deferment = p.getDeferment();
            this.productId = p.getProductId();
            this.planId = p.getPlanId();

            // strings
            this.defermentValue = p.getDefermentValue();
            this.productName = p.getProductName();
            this.planName = p.getPlanName();
            this.modeDisc = p.getModeDisc();
            this.benefitPayoutDate = p.getBenefitPayoutDate();

            // amounts
            this.annualPremiumAmount = CommonHelper.parseMoneyOrZero(p.getAnnualPremium());
            this.modalPremiumAmount = CommonHelper.parseMoneyOrZero(p.getModalPremium());
            this.serviceTaxAmount = CommonHelper.parseMoneyOrZero(p.getServiceTax());
            this.sumAssuredAmount = CommonHelper.parseMoneyOrZero(p.getSumAssured());
            this.premiumAmount = CommonHelper.parseMoneyOrZero(p.getPremium());
            this.revisionaryBonusAmount = CommonHelper.parseMoneyOrZero(p.getRevisionaryBonus());
            this.terminalBonusAmount = CommonHelper.parseMoneyOrZero(p.getTerminalBonus());
            this.maturityBenefitAmount = CommonHelper.parseMoneyOrZero(p.getMaturityBenefit());
            this.guaranteedIncomeAmount = CommonHelper.parseMoneyOrZero(p.getGuaranteedIncome());
            this.accruedReversionaryBonusAmount = CommonHelper.parseMoneyOrZero(p.getAccruedReversionaryBonuses());
            this.guaranteedDeathBenefitAmount = CommonHelper.parseMoneyOrZero(p.getGuaranteedDeathBenefit());
            this.totalPayoutAmount = CommonHelper.parseMoneyOrZero(p.getTotalPayout());
            this.fundAtEndOfTheYearAmount = CommonHelper.parseMoneyOrZero(p.getFundAtEndOfTheYear());
        }
    }

    @ApiModelProperty(required = true, value = "Buy Type Code", example = "2")
    @FieldMetaJson("{displayName:'Buy Type Code',validations:'greaterThan~0,lessThan~3'}")
    private int buyTypeCode;

    @ApiModelProperty(required = true, value = "Lead ID", example = "10032021162838868")
    @JsonIgnoreProperties
    private String leadId;

    private Name name;

    @ApiModelProperty(required = true, value = "Gender", example = "Male")
    @FieldMetaJson("{displayName:'Gender',nullable:false,validations:'notBlank'}")
    private String gender;

    @ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
    @FieldMetaJson("{displayName:'Birth Date',nullable:false,validations:'notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$'}")
    private String birthDate;

    @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'Annual Income Amount',validations:'greaterThan~$errmsg:Annual income should be >=100000.~99999'}]}")
    private Money annualIncomeAmount;

    @FieldMetaJson("{nullable:false,validations:'notNull',listElementDataValidations:{childDataValidations:[{childPath:'number',displayName:'Phone Number',validations:'notNull,notBlank,matchesRegEx~$errmsg:Mobile Number length should be 10 digits.~^([0-9]{10})$'}]}}")
    private List<PhoneNumber> phoneNumbers;
    @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'address',displayName:'Email Address',validations:'notBlank,notNull,isEmail'}]}")
    private Email             email;

    @ApiModelProperty(required = true, value = "Age", example = "21")
    private int age;

    @ApiModelProperty(required = true, value = "Suitability Analysis", example = "2")
    @FieldMetaJson("{displayName:'Suitability Analysis',validations:'greaterThan~0,lessThan~3'}")
    private int suitabilityAnalysis;

    private FamilyMember familyMember;

    @ApiModelProperty(required = true, value = "Quotation Id", example = "450")
    @JsonIgnoreProperties
    private String quotationId;

    @ApiModelProperty(required = true, value = "Educational Qualification", example = "2")
    @FieldMetaJson("{displayName:'Educational Qualification',nullable:false,validations:'notBlank'}")
    private String educationalQualification;

    @ApiModelProperty(required = true, value = "Occupation", example = "1")
    @FieldMetaJson("{displayName:'Occupation',nullable:false,validations:'greaterThan~0'}")
    private int     occupation;
    @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
    private Address address;

    @ApiModelProperty(required = false, value = "Application Number", example = "")
    private String applicationNumber;

    @ApiModelProperty(required = true, value = "Utm Source", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Source',nullable:false,validations:'notBlank'}")
    private String utmSource;

    @ApiModelProperty(required = true, value = "Utm Medium", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Medium',nullable:false,validations:'notBlank'}")
    private String utmMedium;

    @ApiModelProperty(required = true, value = "Utm Campaign", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Campaign',nullable:false,validations:'notBlank'}")
    private String utmCampaign;

    @ApiModelProperty(required = true, value = "Plan Id", example = "12029")
    @FieldMetaJson("{displayName:'Plan Id',nullable:false,validations:'greaterThan~0'}")
    private int                      planId;
    private List<PremiumCalculation> riders;
    private List<Fund>               funds;
    @FieldMetaJson("{nullable:false}")
    private PremiumCalculation       premiumCalculation;

    @ApiModelProperty(required = false, value = "Joint Life Age", example = "52")
    private int jointLifeAge;

    @ApiModelProperty(required = false, value = "Joint Life Birth Date", example = "1968-12-12")
    private String jointLifeBirthDate;
    private Name   jointLifeName;
}