package com.pmli.ms.bo.customer.response;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.pmli.util.model.Money;

import lombok.Data;

/**
 * This class holds the response details
 * 
 * @author snehal shimpi
 */
@Data
public class PremiumCalculationResponse {

    @JsonIgnore
    PremiumCalculationNvestResponse nvestResponse;

    private String message;
    private String quotationId;
    private String status;

    public PremiumCalculationResponse(PremiumCalculationNvestResponse nvestResponseTemp) {
        this.nvestResponse = nvestResponseTemp;
        this.message = nvestResponse.getMessage();
        this.quotationId = nvestResponse.getQuotationId();
        this.status = nvestResponse.getStatus();
    }

    public List<YearlyBenefitIllustration> getYearlyBenefitIllustration1() {
        return Optional
            .ofNullable(nvestResponse.getBiJsonList()).map(bijsonList -> bijsonList.stream()
                .map(PremiumCalculationResponse.YearlyBenefitIllustration::new).collect(Collectors.toList()))
            .orElseGet(Collections::emptyList);
    }

    public List<YearlyBenefitIllustration> getYearlyBenefitIllustration2() {
        return Optional
            .ofNullable(nvestResponse.getBiJson2List()).map(bijson2List -> bijson2List.stream()
                .map(PremiumCalculationResponse.YearlyBenefitIllustration::new).collect(Collectors.toList()))
            .orElseGet(Collections::emptyList);
    }

    public List<InputValidationStatus> getInputValidationStatus() {
        return Optional
            .ofNullable(nvestResponse.getInputValidationStatus()).map(inputStatusList -> inputStatusList.stream()
                .map(PremiumCalculationResponse.InputValidationStatus::new).collect(Collectors.toList()))
            .orElseGet(Collections::emptyList);
    }

    public static class YearlyBenefitIllustration {

        PremiumCalculationNvestResponse.BIJson bijson;

        public YearlyBenefitIllustration(PremiumCalculationNvestResponse.BIJson bijson) { this.bijson = bijson; }

        public int getPolicyYear() { return bijson.getPolicyYear(); }

        public int getAgeLifeAssured() { return bijson.getAgeLifeAssured(); }

        public int getPolicyTerm() { return bijson.getPolicyTerm(); }

        public Money getSumAssuredAmount() { return toMoney(bijson.getSumAssuredAmount()); }

        public Money getGuaranteedIncomeAmount() { return toMoney(bijson.getGuaranteedIncomeAmount()); }

        public Money getGuaranteedDeathBenefitAmount() { return toMoney(bijson.getGuaranteedDeathBenefit()); }

        public Money getMaturityBenefitAmount() { return toMoney(bijson.getMaturityBenefitAmount()); }

        public Money getCashBonus1Amount() { return toMoney(bijson.getCashBonus1Amount()); }

        public Money getCashBonus2Amount() { return toMoney(bijson.getCashBonus2Amount()); }

        public Money getAccruedReversionaryBonuses1Amount() {
            return toMoney(bijson.getAccruedReversionaryBonuses1Amount());
        }

        public Money getAccruedReversionaryBonuses2Amount() {
            return toMoney(bijson.getAccruedReversionaryBonuses2Amount());
        }

        public Money getTerminalBonus1Amount() { return toMoney(bijson.getTerminalBonus1Amount()); }

        public Money getTerminalBonus2Amount() { return toMoney(bijson.getTerminalBonus2Amount()); }

        public Money getTotalMaturityBenefitAmount() { return toMoney(bijson.getTotalMaturityBenefitAmount()); }

        public Money getDeathBenifitAmount() { return toMoney(bijson.getDeathBenifitAmount()); }

    }

    public static class InputValidationStatus {

        PremiumCalculationNvestResponse.InputValidationStatus inputStatus;

        public InputValidationStatus(PremiumCalculationNvestResponse.InputValidationStatus ivs) {
            this.inputStatus = ivs;
        }

        public int getPayTerm() { return inputStatus.getPayTerm(); }

        public int getPolicyTerm() { return inputStatus.getPolicyTerm(); }

        public int getProductId() { return inputStatus.getProductId(); }

        public List<ErrorMessage> getErrorMessages() {
            return inputStatus.getErrorMessages().stream().map(PremiumCalculationResponse.ErrorMessage::new)
                .collect(Collectors.toList());
        }

        public String getGeneralError() { return inputStatus.getGeneralError(); }

        public Money getModeDescription() { return toMoney(inputStatus.getModeDescription()); }

        public Money getModelPremiumAmount() { return toMoney(inputStatus.getModelPremiumAmount()); }

        public Money getAnnualPremiumAmount() { return toMoney(inputStatus.getAnnualPremiumAmount()); }

        public Money getSumAssuredAmount() { return toMoney(inputStatus.getSumAssuredAmount()); }

        public Money getServiceTaxAmount() { return toMoney(inputStatus.getServiceTaxAmount()); }
    }

    public static class ErrorMessage {
        PremiumCalculationNvestResponse.ErrorMessage error;

        public ErrorMessage(PremiumCalculationNvestResponse.ErrorMessage errorMessage) { this.error = errorMessage; }

        public String getKey() { return error.getKey(); }

        public String getValue() { return error.getValue(); }
    }

    private static Money toMoney(BigDecimal amount) { return new Money(amount); }
}
