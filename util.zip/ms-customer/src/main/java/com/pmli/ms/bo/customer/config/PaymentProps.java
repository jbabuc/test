package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class PaymentProps {

	@Value("${" + Constants.BASE_PATH + "error.msg.invalid.lead.id.app.num}")
    private String errorMsgInvalidLeadIdAppnum;

    @Value("${" + Constants.BASE_PATH + "db.tag.payment}")
    private String dbTagPayment;
    
    @Value("${" + Constants.BASE_PATH + "error.msg.payment.already.present}")
    private String errorMsgPaymentAlreadyPresent;
    
    @Value("${" + Constants.PAYMENT_SUCCESS_MSG + "}")
    private String paymentSuccessMsg;
    
    @Value("${" + Constants.PROPOSAL_FORM_LINK + "}")
    private String proposalFormLink;
    
    @Value("${com.pmli.bo.customer.payment.secret.key}")
    private String paymentSecretKey;
    
    @Value("${" + Constants.ERROR_MSG_LEADID_APPNUMBER_BLANK + "}")
    private String errorMsgLeadIdAppNumberBlank;
    
    @Value("${com.pmli.bo.customer.std.date.format}")
    private String stdDateFormat;
    
    @Value("${com.pmli.bo.customer.sms.templateId.payment.success}")
    private String templateIdPaymentSuccSms;
    
    @Value("${com.pmli.bo.customer.sms.templateId.payment.fail}")
    private String templateIdPaymentFailSms;
    
    @Value("${com.pmli.bo.customer.error.msg.mobileNumber.not.available}")
    private String errorMsgMobileNotAvailable;
    
    @Value("${com.pmli.bo.customer.error.msg.email.not.available}")
    private String errorMsgEmailNotAvailable;
    
    @Value("${com.pmli.bo.customer.payment.secret.key}")
    private String secretKey;
}
