package com.pmli.ms.bo.customer.model;

import static com.pmli.util.mongo.MongoClientWrapper.getMCW;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.mongodb.client.model.UpdateOptions;
import com.pmli.ms.bo.customer.client.FileStorageHelper;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.ms.bo.customer.config.CreateApplicationProps;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.cache.MsCache.CacheForADay;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.mongo.MongoClientWrapper;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;
import com.pmli.util.web.client.RestConsumer;

import lombok.Getter;

@Getter
@Component
public class DBClient {

    @Value("${" + Constants.BASE_PATH + "mongodb.uri}")
    private String uri;

    @Value("${" + Constants.BASE_PATH + "mongodb.dbname}")
    private String dbName;

    @Value("${com.pmli.bo.customer.mongodb.collection.prdProductPlanDetails}")
    private String mongoProductPlanDetails;

    @Value("${com.pmli.bo.customer.mongodb.collection.mstMaster}")
    private String mongoMstMaster;

    @Value("${com.pmli.bo.customer.mongodb.collection.appConfig}")
    private String appConfig;

    @Value("${" + Constants.BASE_PATH + "date.format}")
    private String dateFormat;

    @Value("${com.pmli.bo.customer.mongodb.collection.leadDetail}")
    private String collectionLeadDetail;

    @Value("${" + Constants.BASE_PATH + "productUrl}")
    private String productUrl;

    @Autowired
    private RestConsumer consumer;

    @Autowired
    private CreateApplicationProps cap;

    @Autowired
    private MongoClientWrapper buyOnlineMCW;
    @Value("${" + Constants.BASE_PATH + "mongodb.collection.merge.pdf}")
    private String             collectionMergePdf;

    @Bean
    public MongoClientWrapper getBuyOnlineMCW() { return buyOnlineMCW != null ? buyOnlineMCW : getMCW(uri); }

    @Autowired
    private CommonProps commonProps;

    /**
     * @param  id
     * @return
     */
    public boolean quotationExists(String id) {
        Document doc = buyOnlineMCW.getDocumentById(dbName, collectionLeadDetail,
            String.format("{%s:'%s'}", FieldConstants.LD_QUOTATIONID, id), null);
        return doc != null;
    }

    @CacheForADay
    public String getProductId(String productName) {
        List<Document> docs = buyOnlineMCW.getDocuments(dbName, mongoMstMaster,
            Document.parse("{'type':'recommendations'}"),
            Document.parse("{'list':{'$elemMatch':{'value':'" + productName + "'}}}"), null, -1, -1);
        return docs.isEmpty() ? null : DocUtil.getOrDefault(docs.get(0), "list[0].key", String.class, null);
    }
    
    public String stateExist(String state) {
        List<Document> docs = buyOnlineMCW.getDocuments(dbName, mongoMstMaster, Document.parse("{'type':'State'}"),
            Document.parse("{'list':{'$elemMatch':{'value':'" + state + "'}}}"), null, -1, -1);
        return docs.isEmpty() ? null : DocUtil.getOrDefault(docs.get(0), "list[0].key", String.class, null);
    }
    
    @CacheForADay
    public String getProductShortName(int productId) {
        Document doc = buyOnlineMCW.getDocumentById(dbName, mongoProductPlanDetails,
            String.format("{productId:%d}", productId), null);
        return doc == null ? null : doc.getString("productShortName");
    }

    public String isFileRefs(String quotationId, String path) {
        Document doc = buyOnlineMCW.getDocumentById(dbName, collectionMergePdf,
            String.format("{quotationId:'%s'}", quotationId), null);
        return doc.getList("fileRefs", Document.class).stream().filter(m -> m.getString("name").equals(path))
            .findFirst().map(p -> p.getString("ref")).orElse("");

    }

    @SuppressWarnings("unchecked")
    @CacheForADay
    public String getProductOptionName(ProductId productId, int levelId, int bonusId) {
        List<Document> docs = buyOnlineMCW.getDocuments(dbName, mongoProductPlanDetails,
            Document.parse("{productId:" + productId.getValue() + "}"),
            Document.parse("{'productDetail.optionMaster':1}"), null, -1, -1);
        return ((List<Document>) docs.get(0).get("productDetail", Document.class).get("optionMaster")).stream()
            .filter(d -> d.getInteger("LevelId") == levelId).findFirst().map(o -> (List<Document>) o.get("options"))
            .map(options -> options.stream().filter(opt -> bonusId == opt.getInteger("optionId")).findFirst()
                .map(opt -> opt.getString("optionName")).orElse(""))
            .orElse("");
    }

    public Document appendLastUpdatedOn(Document doc) { doc.put("lastUpdatedOn", LocalDateTime.now()); return doc; }

    /**
     * @param leadId
     * @param Request LeadDetail
     */
    public LeadDetail getLeadDetail(String leadId) {
        Document doc = buyOnlineMCW.getDocumentById(dbName, collectionLeadDetail,
            new Document(FieldConstants.LD_LEADID, leadId).toJson(), null);
        return doc == null ? null : JsonUtil.readValue(doc.toJson(), LeadDetail.class);
    }

    /**
     * This method gets the Lead Details encapsulated in {@link LeadDetail}.
     * 
     * @param applicationNumber
     * @return LeadDetail
     */
    public LeadDetail getLeadDetailByApplicationNumber(String applicationNumber) {
        Document doc = buyOnlineMCW.getDocumentById(dbName, collectionLeadDetail,
            new Document(FieldConstants.LD_APPLICATIONUMBER, applicationNumber).toJson(), null);
        return doc == null ? null : JsonUtil.readValue(doc.toJson(), LeadDetail.class);

    }

    public LeadDetail getLeadDetailByIdOrAppNo(String leadId, String applicationNumber) {
        LeadDetail ld = null;
        if (!StringUtils.isEmpty(leadId)) ld = getLeadDetail(leadId);
        if (null == ld && !StringUtils.isEmpty(applicationNumber))
            ld = getLeadDetailByApplicationNumber(applicationNumber);
        return ld;
    }

    /**
     * @param insertion & update
     */
    public long saveLeadDetail(LeadDetail ld) {
        Date now = new Date();
        if (ld.getCreatedOn() == null) ld.setCreatedOn(now);
        ld.setLastUpdatedOn(now);
        return buyOnlineMCW.updateMany(dbName, collectionLeadDetail, new Document("leadId", ld.getLeadId()),
            new Document("$set", Document.parse(JsonUtil.writeValueAsString(ld))), new UpdateOptions().upsert(true));
    }

    /**
     * @param update sub elements
     */
    public long saveLeadDetail(String leadId, Document subElements) {
        return buyOnlineMCW.updateMany(dbName, collectionLeadDetail, new Document("leadId", leadId),
            new Document("$set", appendLastUpdatedOn(subElements)), new UpdateOptions().upsert(false));
    }

    /**
     * @param  KEY
     * @return     value
     */
    @CacheForADay
    public String getMasterValueByTypeKey(String type, String key) {
        List<Document> docs = buyOnlineMCW.getDocuments(dbName, mongoMstMaster, String.format("{type:'%s'}", type),
            null, null, 0, 1);
        if (docs.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                commonProps.getErrMsgDataNotFound(),
                String.format("Master type/key not found, type: %s, key: %s", type, key));
        }
        return docs.get(0).getList("list", Document.class).stream()
            .filter(e -> e.getBoolean("active") && key.equals(e.getString("key"))).findFirst()
            .map(mapper -> mapper.getString("value")).orElse("");

    }

    /**
     * @param  value
     * @return       key
     */
    @CacheForADay
    public String getMasterKeyByTypeValue(String type, String value) {
        List<Document> docs = buyOnlineMCW.getDocuments(dbName, mongoMstMaster, String.format("{type:'%s'}", type),
            null, null, 0, 1);
        if (docs.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                commonProps.getErrMsgDataNotFound(),
                String.format("Master type/value not found, type: %s, value: %s", type, value));
        }
        return docs.get(0).getList("list", Document.class).stream()
            .filter(e -> e.getBoolean("active") && value.equals(e.getString("value"))).findFirst()
            .map(mapper -> mapper.getString("key")).orElse("");
    }

    /**
     * @param  productId
     * @return           response field name
     */
    public String getAppConfigFieldValById(String productId, String responseFieldName) {
        List<Document> docs = getAppConfigDocs();
        if (docs.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                commonProps.getErrMsgDataNotFound(),
                String.format("Master product val not found, productId: %s, field: %s", productId, responseFieldName));
        }
        return docs.get(0).getList("productNotificationSetting", Document.class).stream()
            .filter(e -> productId.equals(e.getString("productId"))).findFirst()
            .map(mapper -> mapper.getString(responseFieldName)).orElse("");
    }

    /**
     * @param  id
     * @return
     */
    public List<Document> getAppConfigDocs() {
        return buyOnlineMCW.getDocuments(dbName, appConfig, "{}", null, null, 0, 1);
    }

    /**
     * This method is use to get the frequency
     * 
     * @param  premiumCalcdoc
     * @return                the frequency
     */
    public String getFrequencyFromPremiumCalc(Document premiumCalcdoc) {
        String frequencyValue = "";
        int freqCode = Integer.parseInt(premiumCalcdoc.getString("frequency"));
        switch (freqCode) {
        case 12:
            frequencyValue = cap.getAnnualPremium();
            break;
        case 6:
            frequencyValue = cap.getHalfPremium();
            break;
        case 1:
            frequencyValue = cap.getMonthlyPremium();
            break;
        default:
        }
        return frequencyValue;
    }

    /**
     * This method is use to get the Lead Detail Object based on key
     * 
     * @param  key   the String contains the key base on which details is fetch
     * @param  value the String contains the value for key
     * @return       List of LeadDetail
     */
    public List<LeadDetail> getLeadDetailsByAnyField(String key, String value) {
        List<Document> docList = buyOnlineMCW.getDocuments(dbName, collectionLeadDetail,
            new Document(key, value).toJson());
        return docList.stream().map(doc -> JsonUtil.readValue(doc.toJson(), LeadDetail.class))
            .collect(Collectors.toList());
    }

    public Document fetchApplication(String filter) {
        return buyOnlineMCW.getDocumentById(getDbName(), getCollectionLeadDetail(), filter, null);
    }

    public void saveMergePdfFileRef(FileStorageHelper.FileRefDetails fileRefs) {
        buyOnlineMCW.insertOne(dbName, collectionMergePdf, Document.parse(JsonUtil.writeValueAsString(fileRefs)));
    }
	 
}
