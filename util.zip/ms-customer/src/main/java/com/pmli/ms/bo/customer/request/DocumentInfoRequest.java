package com.pmli.ms.bo.customer.request;

import static java.util.Optional.ofNullable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.model.DocumentInfo;
import com.pmli.util.bson.IsoDateDeSerializer;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
public class DocumentInfoRequest extends LeadRequest {
    private DocumentInfoDetails documentInfoDetails;

    @Data
    @NoArgsConstructor
    public static class Documents {
        private List<Details> details = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    public static class DocumentInfoDetails {
        private Documents poDocuments;
        private Documents piDocuments;
        private Documents jointLifeDocuments;
        private Documents bankDocuments;
        private Documents bankJointLifeDocuments;

        public DocumentInfoDetails(DocumentInfo documentInfo) {
            poDocuments = new Documents();
            piDocuments = new Documents();
            jointLifeDocuments = new Documents();
            bankDocuments = new Documents();
            bankJointLifeDocuments = new Documents();

            ofNullable(documentInfo.getPoDocuments()).ifPresent(r -> documentInfo.getPoDocuments().getDetails().stream()
                    .forEach(d -> poDocuments.getDetails().add(new Details(d))));
            
            ofNullable(documentInfo.getPiDocuments()).ifPresent(r -> documentInfo.getPiDocuments().getDetails().stream()
                    .forEach(d -> piDocuments.getDetails().add(new Details(d))));
            
            ofNullable(documentInfo.getJointLifeDocuments()).ifPresent(r -> documentInfo.getJointLifeDocuments().getDetails().stream()
                    .forEach(d -> jointLifeDocuments.getDetails().add(new Details(d))));       
            
            ofNullable(documentInfo.getBankDocuments()).ifPresent(r -> documentInfo.getBankDocuments().getDetails().stream()
                    .forEach(d -> bankDocuments.getDetails().add(new Details(d))));       
            
            ofNullable(documentInfo.getBankJointLifeDocuments()).ifPresent(r -> documentInfo.getBankJointLifeDocuments().getDetails().stream()
                    .forEach(d -> bankJointLifeDocuments.getDetails().add(new Details(d))));       
        }
    }

    @Data
    @NoArgsConstructor
    public static class Details {
        public Details(com.pmli.ms.bo.customer.model.DocumentInfo.Details details) {
            this.name = details.getName();
            this.value = details.getValue();
            this.proof = details.getProof();
            this.isFile = details.isFile();
            this.fileCount = details.getFileCount();
            this.isVerified = details.isVerified();
            this.isDocPushed = details.isDocPushed();
            this.status = details.getStatus();
            this.message = details.getMessage();
            this.path = details.getPath();
            this.uploadedOn = new SimpleDateFormat(IsoDateDeSerializer.MONGO_DATE_FORMAT)
                .format(details.getUploadedOn());
            /*
             * try { this.uploadedOn = new SimpleDateFormat(IsoDateDeSerializer.MONGO_DATE_FORMAT).format(details.
             * getUploadedOn()); } catch (ParseException e) { uploadedOn = new Date(); }
             */
        }

        @ApiModelProperty(required = false, value = "Name of ID Proof", example = "")
        private String  name;
        @ApiModelProperty(required = false, value = "value", example = "")
        private String  value;
        @ApiModelProperty(required = false, value = "Proof", example = "")
        private String  proof;
        @ApiModelProperty(required = false, value = "File", example = "false")
        @JsonProperty("isFile")
        private boolean isFile;
        @ApiModelProperty(required = false, value = "fileCount", example = "200")
        private int     fileCount;
        @ApiModelProperty(required = false, value = "isVerified", example = "false")
        @JsonProperty("isVerified")
        private boolean isVerified;
        @ApiModelProperty(required = false, value = "isDocPushed", example = "false")
        @JsonProperty("isDocPushed")
        private boolean isDocPushed;
        @ApiModelProperty(required = false, value = "status", example = "")
        private String  status;
        @ApiModelProperty(required = false, value = "message", example = "")
        private String  message;
        @ApiModelProperty(required = false, value = "path", example = "80000262429_PhotoGraph.jpg")
        private String  path;
        @ApiModelProperty(required = false, value = "uploaded On", example = "")
        private String  uploadedOn;
    }
}