package com.pmli.ms.bo.customer.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public enum RiderId {

    DEATH_BENEFIT(13001), SERIOUS_ILLNESS(13002);

    RiderId(int value) { this.value = value; }

    private final int value;

    public int getValue() { return value; }

    public static final List<RiderId> RIDER_ID_LIST = Collections.unmodifiableList(Arrays.asList(RiderId.values()));

    public static final List<Integer> RIDER_ID_INT_LIST = Collections
        .unmodifiableList(Arrays.asList(RiderId.values()).stream().map(RiderId::getValue).collect(Collectors.toList()));

    public static boolean isDeathBenefit(int riderId) { return DEATH_BENEFIT.getValue() == riderId; }

    public static boolean isSeriousIllness(int riderId) { return SERIOUS_ILLNESS.getValue() == riderId; }

    public static boolean isDeathBenefit(String riderId) { return isDeathBenefit(Integer.parseInt(riderId)); }

    public static boolean isSeriousIllness(String riderId) { return isSeriousIllness(Integer.parseInt(riderId)); }

    public static boolean isValidRiderId(RiderId id) { return RIDER_ID_LIST.contains(id); }

    public static boolean isValidRiderId(int id) { return RIDER_ID_INT_LIST.contains(id); }

    public static boolean isValidRiderId(String id) { return isValidRiderId(Integer.parseInt(id)); }
}
