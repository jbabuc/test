package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author 3484656dee
 *
 */

public class AddPremiumResponse {
	@ApiModelProperty(required = true, value = "Message", example = "Premium added successfully")
	private String message;

}
