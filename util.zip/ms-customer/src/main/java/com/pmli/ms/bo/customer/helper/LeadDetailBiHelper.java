package com.pmli.ms.bo.customer.helper;

import static java.util.Optional.ofNullable;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;


import lombok.NoArgsConstructor;

/**
 * <p>
 * This class consists of the helper methods required for the implementation of
 * the Create lead detail for Web BI API.
 * </p>
 * 
 * @author 3448466ami
 */
@NoArgsConstructor
public class LeadDetailBiHelper extends MsObject {
	
	public static final String MOBILE_NUMBER = "Mobile Number";
	public static final String MOBILE_NUMBER_REGEX = "matchesRegEx~$errmsg:Mobile Number length should be 10 digits.~^([0-9]{10})$";
	public static final String EMAIL_ADDRESS = "Email Address";
	
	DBClient dbClient;

	/**
	 * This method is to validate request for create lead details of Web BI API
	 * 
	 * @param request
	 */
	public void validateLeadDetailBiRequest(LeadDetailBiRequest request) {
		// validate the common request payload
		new ValidationHelper(request).validateWithMetaJson();
		// validate the mobile number
		if (ObjectUtils.isNotEmpty(request.getPhones()))
			request.getPhones().stream().filter(p -> StringUtils.isNotEmpty(p.getNumber())).forEach(
					p -> new StringValidator(p.getNumber(), MOBILE_NUMBER, true).validateAll(MOBILE_NUMBER_REGEX));
		// validate the email address
		if (ObjectUtils.isNotEmpty(request.getEmail()) && StringUtils.isNoneBlank(request.getEmail().getAddress()))
			ofNullable(request.getEmail().getAddress()).ifPresent(
					a -> new StringValidator(request.getEmail().getAddress(), EMAIL_ADDRESS, true).isEmail());
		//product validations
		/*
		 * new Validator(request.getPremiumCalculation().getAnnualPremiumAmount(),
		 * AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT, false).notNull(); new
		 * Validator(request.getPremiumCalculation().getAnnualPremiumAmount().getAmount(
		 * ), AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT, false).notNull(); new
		 * ComparableValidator(request.getPremiumCalculation().getAnnualPremiumAmount().
		 * getAmount().doubleValue(), AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT,
		 * false).greaterThan(0.00); new
		 * StringValidator(request.getPremiumCalculation().getAnnualPremiumAmount().
		 * getCurrencyCode(), "Annual Premium Amount Currency",
		 * false).notNullNotBlank(); new
		 * ComparableValidator(request.getPremiumCalculation().getCoverTerm(),
		 * "Cover Term", false).greaterThan(0); new
		 * ComparableValidator(request.getPremiumCalculation().getFrequencyCode(),
		 * "Frequency Code", false) .greaterThan(0); new
		 * ComparableValidator(request.getPremiumCalculation().getProductId(),
		 * "Product Id", false).greaterThan(0); new
		 * StringValidator(request.getPremiumCalculation().getProductName(),
		 * "Product Name", false).notNullNotBlank(); new
		 * ComparableValidator(request.getPremiumCalculation().getPlanId(), "Plan Id",
		 * false).greaterThan(0); new
		 * StringValidator(request.getPremiumCalculation().getPlanName(), "Plan Name",
		 * false).notNullNotBlank(); new
		 * StringValidator(request.getPremiumCalculation().getModeDescription(),
		 * "Mode Description", false) .notNullNotBlank(); new
		 * Validator(request.getPremiumCalculation().getModalPremiumAmount(),
		 * AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).notNull(); new
		 * Validator(request.getPremiumCalculation().getModalPremiumAmount().getAmount()
		 * , AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).notNull(); new
		 * ComparableValidator(request.getPremiumCalculation().getModalPremiumAmount().
		 * getAmount().doubleValue(), AddPremiumHelper.MODAL_PREMIUM_AMOUNT,
		 * false).greaterThan(0.00); new
		 * StringValidator(request.getPremiumCalculation().getModalPremiumAmount().
		 * getCurrencyCode(), "modal Premium Amount Currency", false).notNullNotBlank();
		 * 
		 * new Validator(request.getPremiumCalculation().getServiceTaxAmount(),
		 * AddPremiumHelper.SERVICE_TAX_AMOUNT, false) .notNull(); new
		 * Validator(request.getPremiumCalculation().getServiceTaxAmount().getAmount(),
		 * AddPremiumHelper.SERVICE_TAX_AMOUNT, false).notNull(); new
		 * ComparableValidator(request.getPremiumCalculation().getServiceTaxAmount().
		 * getAmount().doubleValue(), AddPremiumHelper.SERVICE_TAX_AMOUNT,
		 * false).greaterThan(0.00); new
		 * StringValidator(request.getPremiumCalculation().getServiceTaxAmount().
		 * getCurrencyCode(), "service Tax Amount Currency", false).notNullNotBlank();
		 * 
		 * new Validator(request.getPremiumCalculation().getSumAssuredAmount(),
		 * AddPremiumHelper.SUM_ASSURED_AMOUNT, false) .notNull(); new
		 * Validator(request.getPremiumCalculation().getSumAssuredAmount().getAmount(),
		 * AddPremiumHelper.SUM_ASSURED_AMOUNT, false).notNull(); new
		 * ComparableValidator(request.getPremiumCalculation().getSumAssuredAmount().
		 * getAmount().doubleValue(), AddPremiumHelper.SUM_ASSURED_AMOUNT,
		 * false).greaterThan(0.00); new
		 * StringValidator(request.getPremiumCalculation().getSumAssuredAmount().
		 * getCurrencyCode(), "sum Assured Amount Currency", false).notNullNotBlank();
		 */
		
		//validate riders
		/*
		 * new Validator(request.getRiders(), "Riders", false).notNull();
		 * request.getRiders().forEach(rd -> { new Validator(rd.getModalPremiumAmount(),
		 * AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).notNull(); new
		 * Validator(rd.getModalPremiumAmount().getAmount(),
		 * AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false) .notNull(); new
		 * StringValidator(rd.getModalPremiumAmount().getCurrencyCode(),
		 * "Rider Modal Premium Amount Currency", false).notNullNotBlank(); new
		 * ComparableValidator(rd.getModalPremiumAmount().getAmount().doubleValue(),
		 * AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).greaterThan(0.00);
		 * 
		 * new Validator(rd.getServiceTaxAmount(), AddPremiumHelper.SERVICE_TAX_AMOUNT,
		 * false).notNull(); new Validator(rd.getServiceTaxAmount().getAmount(),
		 * AddPremiumHelper.SERVICE_TAX_AMOUNT, false).notNull(); new
		 * StringValidator(rd.getServiceTaxAmount().getCurrencyCode(),
		 * "Rider ServiceTaxAmount Currency", false) .notNullNotBlank(); new
		 * ComparableValidator(rd.getServiceTaxAmount().getAmount().doubleValue(),
		 * AddPremiumHelper.SERVICE_TAX_AMOUNT, false).greaterThan(0.00);
		 * 
		 * new Validator(rd.getSumAssuredAmount(), AddPremiumHelper.SUM_ASSURED_AMOUNT,
		 * false).notNull(); new Validator(rd.getSumAssuredAmount().getAmount(),
		 * AddPremiumHelper.SUM_ASSURED_AMOUNT, false).notNull(); new
		 * StringValidator(rd.getSumAssuredAmount().getCurrencyCode(),
		 * "Rider SumAssuredAmount Currency", false) .notNullNotBlank(); new
		 * ComparableValidator(rd.getSumAssuredAmount().getAmount().doubleValue(),
		 * AddPremiumHelper.SUM_ASSURED_AMOUNT, false).greaterThan(0.00); new
		 * ComparableValidator(rd.getFrequencyCode(), "Rider FrequencyCode",
		 * false).greaterThan(0); new StringValidator(rd.getModeDescription(),
		 * "Rider Mode Description", false).notNullNotBlank();
		 * 
		 * if (!RiderId.isValidRiderId(rd.getProductId())) { throw new
		 * ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
		 * caprops.getErrorRiderProductId(), caprops.getErrorRiderProductId()); } if
		 * (null != dbClient.getMasterValueByTypeKey("riderShortNames",
		 * rd.getProductId() + "") && !dbClient
		 * .getMasterValueByTypeKey("riderShortNames", rd.getProductId() +
		 * "").equals(rd.getProductName())) { throw new
		 * ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
		 * caprops.getInvalidProductName(), caprops.getErrorProductName()); } });
		 */
	}

}
