package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class FamilyCriticalInfoDetails {
    private CriticalInfo criticalInfoDetails;
    private HealthFamilyAge familyMember;
}
