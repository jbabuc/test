package com.pmli.ms.bo.customer.comm;

import java.util.List;

import com.pmli.ms.bo.customer.config.CommonProps;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * common property for email or sms
 * 
 * @author 3483784san
 *
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EmailRequest extends EmailSmsRequest {
	private String toEmail;
	private String ccTo;
	private String bcc;
	private String fromEmail;
	private String attachments;
	private String base64Content;
	private String emlReq;

	public EmailRequest(String communicationContext, String toEmail, String fromEmail, String templateId,
			List<Metadata> metadata, String emlReq) {
		super();
		this.communicationContext = communicationContext;
		this.toEmail = toEmail;
		this.fromEmail = fromEmail;
		this.templateId = templateId;
		this.metadata = metadata;
		this.emlReq = emlReq;
	}

	public EmailRequest(List<Metadata> metadata, String toEmail, String fromEmail, String ccEmail,
			CommonProps commProps) {
		this.clientId = commProps.getClientId();
		this.loginId = commProps.getLoginId();
		this.communicationContext = commProps.getCommunicationContext();
		this.emlReq = commProps.getEmailReq();
		this.loginType = 1;
		this.toEmail = toEmail;
		this.fromEmail = fromEmail;
		this.ccTo = ccEmail;
		this.templateId = commProps.getTemplateId();
		this.metadata = metadata;
	}
}
