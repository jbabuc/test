package com.pmli.ms.bo.customer.request;

import com.pmli.util.java.FieldMetaJson;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class LeadRequest {
    @ApiModelProperty(required = true, value = "Lead Id", example = "26032021105140445")
    @FieldMetaJson("{displayName:'Lead Id',nullable:false,validations:'notNullMatchesRegEx~$errmsg:Lead Id must not be blank with max 32 digits.~^[0-9]{1\\\\,32}$'}")
    public String leadId;
}
