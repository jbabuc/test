package com.pmli.ms.bo.customer.model;

import java.util.List;
import lombok.Data;

@Data
public class CriticalInfoDiseaseDetails {
    private int value;
    private String specifyDetails;

    private List<CriticalinfoDetails> details;
    private int key;
    private String name;
    private List<AlcohalTobaccoDrug> alcohalDetails;
    private CovidDetails covidDetails;
    private PregnantDetails pregnantDetails;
}
