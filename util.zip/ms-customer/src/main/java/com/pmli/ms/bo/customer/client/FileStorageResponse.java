package com.pmli.ms.bo.customer.client;

import lombok.Data;

@Data
public class FileStorageResponse {
    private String fileRef;
}
