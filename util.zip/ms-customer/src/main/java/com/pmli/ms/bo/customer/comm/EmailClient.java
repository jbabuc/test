
package com.pmli.ms.bo.customer.comm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.client.RestConsumer;

/**
 * 
 * @author Deepak Ingle
 * @version 1.0.0
 * @since FEB 2021
 *
 *        Email client for mailing
 */

@Component
public class EmailClient extends MsObject {
	
	@Autowired
	private RestTemplate restTemplate;

	@Value("${com.pmli.bo.customer.send.email.uri}")
	private String sendEmailURI;

	@Autowired
	RestConsumer restConsumer;

	@Autowired
	CommonProps commProps;

	/**
	 * This method will call send email service API.
	 * 
	 * @param metadata
	 */
	@Async("send-email")
	public void sendEmail(List<Metadata> metadata, String fromEmail, String toEmail, String ccEmail) {
		ResponseEntity<EmailResponse> res = null;
		EmailRequest emailRequest = null;
		try {
			emailRequest = new EmailRequest(metadata, toEmail, fromEmail, ccEmail, commProps);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailRequest> request = new HttpEntity<>(emailRequest, headers);

			res = restTemplate.exchange(sendEmailURI, HttpMethod.POST, request, EmailResponse.class);
			if (HttpStatus.OK.value() == res.getStatusCodeValue()) {
				log.info("Email sent successfully : response >> {}" , res.getBody());
			}
			log.info("Email sent successfully ");
		} catch (Exception exp) {
			log.info("Error occured while sending email  {}" , exp.getMessage());
		}
	}
	
	/**
     * This method will call send email service API.
     * 
     * @param metadata
     */
    @Async
    public void sendEmail(EmailRequest emailRequest) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        try {
            restConsumer.callClientEndPoint(sendEmailURI, headers,
                JsonUtil.writeValueAsString(emailRequest));
            log.info("Email is trigger to mail ID :- {}", emailRequest.getToEmail());
        } catch (Exception e) {
            log.error("Exception occur while sending Email :- {}", e.getMessage());
        }
    }
}
