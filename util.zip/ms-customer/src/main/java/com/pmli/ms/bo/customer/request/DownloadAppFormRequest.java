package com.pmli.ms.bo.customer.request;

import lombok.Data;

@Data
public class DownloadAppFormRequest {
	private Head head;
	private Body body;

	public DownloadAppFormRequest(String applicationNumber, String documentClass, int isWrite) {
		this.body = new Body(applicationNumber, documentClass);
		this.head = new Head(isWrite);
	}

	@Data
	public static class Head {
		private int isWrite;

		public Head(int isWrite) {
			this.isWrite = isWrite;
		}
	}

	@Data
	public static class Body {
		public Body(String applicationNumber, String documentClass) {
			this.applicationNumber = applicationNumber;
			this.documentClass = documentClass;
		}

		private String applicationNumber;
		private String documentClass;
	}

}
