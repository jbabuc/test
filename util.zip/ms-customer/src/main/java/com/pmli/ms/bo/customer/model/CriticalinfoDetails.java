package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class CriticalinfoDetails {
    private String key;
    private String details;
}
