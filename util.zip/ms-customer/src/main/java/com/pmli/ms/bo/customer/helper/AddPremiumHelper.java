package com.pmli.ms.bo.customer.helper;

import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.CreateApplicationProps;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetailPremium;
import com.pmli.ms.bo.customer.request.AddPremiumRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.model.Money;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.validation.Validator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class AddPremiumHelper {

    public static final String PREMIUM_AMOUNT             = "Premium Amount";
    public static final String ANNUAL_PREMIUM_AMOUNT      = "Annual Premium Amount";
    public static final String MODAL_PREMIUM_AMOUNT       = "Modal Premium Amount";
    public static final String MONTHLY_PREMIUM_AMOUNT     = "Monthly Premium Amount";
    public static final String SERVICE_TAX_AMOUNT         = "Service Tax Amount";
    public static final String SUM_ASSURED_AMOUNT         = "Sum Assured Amount";
    public static final String GUARANTEED_INCOME_AMOUNT   = "Guaranteed Income Amount";
    public static final String MATURITY_BENIFIT           = "Maturity Benefit Amount";
    public static final String GUARANTEED_DEATH_BENEFIT   = "Guaranteed Death Benefit Amount";
    public static final String TOTAL_PAYOUT               = "TotalPayout Amount";
    public static final String FUND_AT_YEAR               = "Fund At End Of The Year Amount";
    public static final String ACCRUED_REVERSIONARY_BONUS = "Accrued Reversionary Bonus Amount";
    public static final String REVERSIONARY_BONUS         = "Reversionary Bonus Amount";
    public static final String TERMINAL_BONUS             = "Terminal Bonus Amount";

    private DBClient               dbClient;
    private CreateApplicationProps caProps;
    private AddPremiumRequest      addPremiumRequest;

    public void validate() {
        new ValidationHelper(addPremiumRequest).validateWithMetaJson();
        PremiumCalculation pd = addPremiumRequest.getPremiumCalculation();
        validateMandatoryAmountFields(pd);
        String productId = String.valueOf(pd.getProductId());
        String dbProductName = dbClient.getAppConfigFieldValById(pd.getProductId() + "", "productName");
        if (!ProductId.isValidProductId(productId)) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                caProps.getErrorProductId(), caProps.getErrorProductId());
        }
        if (null != dbProductName && !dbProductName.equals(pd.getProductName())) {
            throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
                caProps.getInvalidProductName(), caProps.getErrorProductName());
        }
        // Validation for MSSP plan
        if (ProductId.isSuperSaverPlan(pd.getProductId())) { validateMsspPlanFields(addPremiumRequest); }
        // Validation for MGFP plan
        if (ProductId.isGuaranteedFuturePlan(pd.getProductId())) { validateMgfpPlanFields(addPremiumRequest); }
        // Validation for MIAP plan
        if (ProductId.isImmediataeAnuityPlan(pd.getProductId())) { validateMiapPlanFields(addPremiumRequest); }
        // Validation for MSPP plan
        if (ProductId.isSmartPlatinumPlusPlan(pd.getProductId())) { validateMsppPlanFields(addPremiumRequest); }
        // validation only for MGFP, MSSP and MSPP only.
        if (ProductId.isSuperSaverPlan(pd.getProductId()) || ProductId.isGuaranteedFuturePlan(pd.getProductId())
            || ProductId.isSmartPlatinumPlusPlan(pd.getProductId())) {
            validateMgfpMsspMsppFields();
        }
        // validation only for MGFP, MSSP and MIAP only.
        if (ProductId.isSuperSaverPlan(productId) || ProductId.isGuaranteedFuturePlan(productId)
            || ProductId.isImmediataeAnuityPlan(productId)) {
            validateMgfpMsspMiapFields();
        }
        // validation only for MSSP And MGFP plan
        if (ProductId.isSuperSaverPlan(productId) || ProductId.isGuaranteedFuturePlan(productId)) {
            validateMsspMgfpFields();
        }
    }

    private void validateMandatoryAmountFields(PremiumCalculation pd) {
        Money premiumAmount = pd.getPremiumAmount();
        Money annualPremiumAmount = pd.getAnnualPremiumAmount();
        Money modalPremiumAmount = pd.getModalPremiumAmount();
        Money monthlyPremiumAmount = pd.getMonthlyPremiumAmount();
        Money serviceTaxAmount = pd.getServiceTaxAmount();
        Money sumAssuredAmount = pd.getSumAssuredAmount();

        new Validator(premiumAmount, PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new Validator(premiumAmount.getAmount(), PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(premiumAmount.getAmount().doubleValue(), PREMIUM_AMOUNT, false).greaterThan(0.00);
        new StringValidator(premiumAmount.getCurrencyCode(), "Premium Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);

        new Validator(annualPremiumAmount, ANNUAL_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new Validator(annualPremiumAmount.getAmount(), ANNUAL_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(annualPremiumAmount.getAmount().doubleValue(), ANNUAL_PREMIUM_AMOUNT, false)
            .greaterThan(0.00);
        new StringValidator(annualPremiumAmount.getCurrencyCode(), "annual Premium Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);

        new Validator(modalPremiumAmount, MODAL_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new Validator(modalPremiumAmount.getAmount(), MODAL_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(modalPremiumAmount.getAmount().doubleValue(), MODAL_PREMIUM_AMOUNT, false)
            .greaterThan(0.00);
        new StringValidator(modalPremiumAmount.getCurrencyCode(), "modal Premium Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);

        new Validator(monthlyPremiumAmount, MONTHLY_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new Validator(monthlyPremiumAmount.getAmount(), MONTHLY_PREMIUM_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(monthlyPremiumAmount.getAmount().doubleValue(), MONTHLY_PREMIUM_AMOUNT, false)
            .greaterThan(0.00);
        new StringValidator(monthlyPremiumAmount.getCurrencyCode(), "monthly Premium Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);

        new Validator(serviceTaxAmount, SERVICE_TAX_AMOUNT, false).validate(Validator::notNull);
        new Validator(serviceTaxAmount.getAmount(), SERVICE_TAX_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(serviceTaxAmount.getAmount().doubleValue(), SERVICE_TAX_AMOUNT, false)
            .greaterThan(0.00);
        new StringValidator(serviceTaxAmount.getCurrencyCode(), "service Tax Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);

        new Validator(sumAssuredAmount, SUM_ASSURED_AMOUNT, false).validate(Validator::notNull);
        new Validator(sumAssuredAmount.getAmount(), SUM_ASSURED_AMOUNT, false).validate(Validator::notNull);
        new ComparableValidator(sumAssuredAmount.getAmount().doubleValue(), SUM_ASSURED_AMOUNT, false)
            .greaterThan(0.00);
        new StringValidator(sumAssuredAmount.getCurrencyCode(), "sum Assured Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(pd.getOption(), "Option", false).greaterThan(0);
    	new StringValidator(pd.getModeDisc(), "Mode Description", false)
    	.validateAll("notNull,matchesRegEx~$errmsg:Invalid Deferment Value.~^[0-9]+$|^$");
    }

    private void validateMsspMgfpFields() {
        Money guaranteedIncomeAmount = addPremiumRequest.getPremiumCalculation().getGuaranteedIncomeAmount();
        Money maturityBenefitAmount = addPremiumRequest.getPremiumCalculation().getMaturityBenefitAmount();
        new Validator(guaranteedIncomeAmount, GUARANTEED_INCOME_AMOUNT, false).validate(Validator::notNull);
        new Validator(guaranteedIncomeAmount.getAmount(), GUARANTEED_INCOME_AMOUNT, false).validate(Validator::notNull);
        new StringValidator(guaranteedIncomeAmount.getCurrencyCode(), "Guaranteed Income Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new Validator(addPremiumRequest.getPremiumCalculation().getMaturityBenefitAmount(), MATURITY_BENIFIT, false)
            .notNull();
        new Validator(maturityBenefitAmount.getAmount(), MATURITY_BENIFIT, false).validate(Validator::notNull);
        new StringValidator(maturityBenefitAmount.getCurrencyCode(), "MaturityBenefit Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(guaranteedIncomeAmount.getAmount().doubleValue(), GUARANTEED_INCOME_AMOUNT, false)
            .greaterThan(0.00);
        new ComparableValidator(maturityBenefitAmount.getAmount().doubleValue(), MATURITY_BENIFIT, false)
            .greaterThan(0.00);

    }

    private void validateMgfpMsspMiapFields() {
        Money guaranteedDeathBenefitAmount = addPremiumRequest.getPremiumCalculation()
            .getGuaranteedDeathBenefitAmount();
        new Validator(guaranteedDeathBenefitAmount, GUARANTEED_DEATH_BENEFIT, false).validate(Validator::notNull);
        new Validator(guaranteedDeathBenefitAmount.getAmount(), GUARANTEED_DEATH_BENEFIT, false)
            .validate(Validator::notNull);
        new StringValidator(guaranteedDeathBenefitAmount.getCurrencyCode(), "Guaranteed DeathBenefit Amount Currency",
            false).validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(guaranteedDeathBenefitAmount.getAmount().doubleValue(), GUARANTEED_DEATH_BENEFIT, false)
            .greaterThan(0.00);
    }

    private void validateMgfpMsspMsppFields() {
        Money totalPayoutAmount = addPremiumRequest.getPremiumCalculation().getTotalPayoutAmount();
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getCoverTerm(), "Cover Term", false)
            .greaterThan(0);
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getPaymentTerm(), "Payment Term", false)
            .greaterThan(0);
        new Validator(totalPayoutAmount, TOTAL_PAYOUT, false).validate(Validator::notNull);
        new Validator(totalPayoutAmount.getAmount(), TOTAL_PAYOUT, false).validate(Validator::notNull);
        new StringValidator(totalPayoutAmount.getCurrencyCode(), "TotalPayout Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(totalPayoutAmount.getAmount().doubleValue(), TOTAL_PAYOUT, false).greaterThan(0.00);
    }

    private void validateMsppPlanFields(AddPremiumRequest addPremiumRequest) {
        Money fundAtEndOfTheYearAmount = addPremiumRequest.getPremiumCalculation().getFundAtEndOfTheYearAmount();
        new Validator(fundAtEndOfTheYearAmount, FUND_AT_YEAR, false).validate(Validator::notNull);
        new Validator(fundAtEndOfTheYearAmount.getAmount(), FUND_AT_YEAR, false).validate(Validator::notNull);
        new Validator(fundAtEndOfTheYearAmount.getCurrencyCode(), "FundAtEndOfTheYearAmount Currency", false)
            .validate(Validator::notNull);
        new ComparableValidator(fundAtEndOfTheYearAmount.getAmount().doubleValue(), FUND_AT_YEAR, false)
            .greaterThan(0.00);
    }

    private void validateMgfpPlanFields(AddPremiumRequest addPremiumRequest) {
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getDeferment(), "Deferment", false)
            .greaterThan(0);
        new StringValidator(addPremiumRequest.getPremiumCalculation().getDefermentValue(), "DefermentValue", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getIncomePayoutMode(), "IncomePayoutMode",
            false).greaterThan(0);
    }

    private void validateMiapPlanFields(AddPremiumRequest addPremiumRequest) {
        new ComparableValidator(addPremiumRequest.getJointLifeAge(), "JointLifeAge", false).greaterThan(0);
        new StringValidator(addPremiumRequest.getJointLifeBirthDate(), "JointLifeBirthDate", false).validateAll(
            "notNull,notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$");
        new Validator(addPremiumRequest.getJointLifeName(), "JointLifeName", false).validate(Validator::notNull);
        new ComparableValidator(addPremiumRequest.getJointLifeAge(), "Joint Life Age", false)
            .validate(ComparableValidator::greaterThan, 39).validate(ComparableValidator::lessThan, 76);
    }

    private void validateMsspPlanFields(AddPremiumRequest addPremiumRequest) {
        Money revisionaryBonusAmount = addPremiumRequest.getPremiumCalculation().getRevisionaryBonusAmount();
        Money terminalBonusAmount = addPremiumRequest.getPremiumCalculation().getTerminalBonusAmount();
        Money accruedReversionaryBonusAmount = addPremiumRequest.getPremiumCalculation()
            .getAccruedReversionaryBonusAmount();
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getFrequencyCode(), "FrequencyCode", false)
            .greaterThan(0);
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getFundStrategy(), "FundStrategy", false)
            .greaterThan(0);
        new Validator(accruedReversionaryBonusAmount, ACCRUED_REVERSIONARY_BONUS, false).validate(Validator::notNull);
        new Validator(accruedReversionaryBonusAmount.getAmount(), ACCRUED_REVERSIONARY_BONUS, false)
            .validate(Validator::notNull);
        new StringValidator(accruedReversionaryBonusAmount.getCurrencyCode(),
            "Accrued Reversionary Bonus Amount Currency", false).validate(Validator::notNull)
                .validate(StringValidator::notBlank);
        new Validator(revisionaryBonusAmount, REVERSIONARY_BONUS, false).validate(Validator::notNull);
        new Validator(revisionaryBonusAmount.getAmount(), REVERSIONARY_BONUS, false).validate(Validator::notNull);
        new StringValidator(revisionaryBonusAmount.getCurrencyCode(), "Reversionary Bonus Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new Validator(terminalBonusAmount, TERMINAL_BONUS, false).validate(Validator::notNull);
        new Validator(terminalBonusAmount.getAmount(), TERMINAL_BONUS, false).validate(Validator::notNull);
        new StringValidator(terminalBonusAmount.getCurrencyCode(), "Terminal Bonus Amount Currency", false)
            .validate(Validator::notNull).validate(StringValidator::notBlank);
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getMaturityAge(), "MaturityAge", false)
            .greaterThan(0);
        new ComparableValidator(addPremiumRequest.getPremiumCalculation().getCashBonusOption(), "CashBonusOption",
            false).greaterThan(0);
        new ComparableValidator(accruedReversionaryBonusAmount.getAmount().doubleValue(), ACCRUED_REVERSIONARY_BONUS,
            false).greaterThan(0.00);
        new ComparableValidator(revisionaryBonusAmount.getAmount().doubleValue(), REVERSIONARY_BONUS, false)
            .greaterThan(0.00);
        new ComparableValidator(terminalBonusAmount.getAmount().doubleValue(), TERMINAL_BONUS, false).greaterThan(0.00);
    }

    public String preparePremiumJson() {
        String jointLifeName = "";
        String premiumJson = "";
        LeadDetailPremium leadPremium = new LeadDetailPremium(addPremiumRequest.getPremiumCalculation());
        if (null != addPremiumRequest.getJointLifeName()) {
            jointLifeName = addPremiumRequest.getJointLifeName().getFirstName().concat(" ")
                .concat(addPremiumRequest.getJointLifeName().getMiddleName()).concat(" ")
                .concat(addPremiumRequest.getJointLifeName().getLastName().trim());
        }
        if (ProductId.isImmediataeAnuityPlan(addPremiumRequest.getPremiumCalculation().getProductId())) {
            String jointLifeDetails = "'jointLifeName': " + "'" + jointLifeName + "'" + ",'jointLifeAge': "
                + addPremiumRequest.getJointLifeAge() + ", 'jointLifeDateOfBirth':  " + "'"
                + addPremiumRequest.getJointLifeBirthDate() + "'" + "";
            premiumJson = ("{" + jointLifeDetails + ",'premiumCalculation':" + JsonUtil.writeValueAsString(leadPremium)
                + "}");
        } else {
            premiumJson = ("{'premiumCalculation':" + JsonUtil.writeValueAsString(leadPremium) + "}");
        }
        return premiumJson;
    }
}
