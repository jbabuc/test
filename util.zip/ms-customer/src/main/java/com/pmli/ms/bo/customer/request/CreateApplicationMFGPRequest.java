package com.pmli.ms.bo.customer.request;

import java.util.List;

import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Address;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class holds the request details of MGFP 'create-Application' API.
 * 
 * @author Hemant Solanki
 * @version 1.0.0
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class CreateApplicationMFGPRequest extends LeadRequest {

	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'Annual Income Amount',validations:'greaterThan~$errmsg:Annual income should be >=100000.~99999'}]}")
	private Money annualIncomeAmount;

	@ApiModelProperty(required = true, value = "Quotation Id", example = "450")
	private String quotationId;

	@ApiModelProperty(required = true, value = "Educational Qualification", example = "2")
	@FieldMetaJson("{displayName:'Educational Qualification',nullable:false,validations:'notBlank'}")
	private String educationalQualification;

	@ApiModelProperty(required = true, value = "Occupation", example = "1")
	@FieldMetaJson("{displayName:'Occupation',nullable:false,validations:'greaterThan~0'}")
	private int occupation;

	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'addressLine1',displayName:'addressLine1',validations:'notBlank,notNull'},{childPath:'city',displayName:'city',validations:'notBlank,notNull'},{childPath:'district',displayName:'district',validations:'notBlank,notNull'},{childPath:'postalCode',displayName:'postalCode',validations:'notBlank,notNull'},{childPath:'state',displayName:'state',validations:'notBlank,notNull'},{childPath:'country',displayName:'country',validations:'notBlank,notNull'}]}")
	private Address address;

	@ApiModelProperty(required = true, value = "Utm Source", example = "Direct")
	@FieldMetaJson("{displayName:'Utm Source',nullable:false,validations:'notBlank'}")
	private String utmSource;

	@ApiModelProperty(required = true, value = "Utm Medium", example = "Direct")
	@FieldMetaJson("{displayName:'Utm Medium',nullable:false,validations:'notBlank'}")
	private String utmMedium;

	@ApiModelProperty(required = true, value = "Utm Campaign", example = "Direct")
	@FieldMetaJson("{displayName:'Utm Campaign',nullable:false,validations:'notBlank'}")
	private String utmCampaign;

	@ApiModelProperty(required = true, value = "Plan Id", example = "12020")
	@FieldMetaJson("{displayName:'Plan Id',nullable:false,validations:'greaterThan~0'}")
	private int planId;

	private List<PremiumCalculation> riders;

	private List<Fund> funds;

	@FieldMetaJson("{nullable:false}")
	private PremiumCalculation premiumCalculation;

	@ApiModelProperty(required = false, value = "Joint Life Birth Date", example = "1968-12-12")
	private String jointLifeBirthDate;
	private Name jointLifeName;
}
