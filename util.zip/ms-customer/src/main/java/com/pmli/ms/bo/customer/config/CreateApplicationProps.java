package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class CreateApplicationProps {

	@Value("${" + Constants.CREATE_APPLICATION + ".frequency.value.annual}")
	private String annualFrequencyValue;

	@Value("${" + Constants.CREATE_APPLICATION + ".frequency.value.half.yearly}")
	private String halfFrequencyValue;

	@Value("${" + Constants.CREATE_APPLICATION + ".frequency.value.monthly}")
	private String monthlyFrequencyValue;

	@Value("${" + Constants.CREATE_APPLICATION + ".calculation.type.annual.premium}")
	private String annualPremium;

	@Value("${" + Constants.CREATE_APPLICATION + ".calculation.type.half.yearly.premium}")
	private String halfPremium;

	@Value("${" + Constants.CREATE_APPLICATION + ".calculation.type.monthly.premium}")
	private String monthlyPremium;

	@Value("${" + Constants.CREATE_APPLICATION + ".payment.option.single.pay}")
	private String singlePay;

	@Value("${" + Constants.CREATE_APPLICATION + ".payment.option.regular.pay}")
	private String regularPay;

	@Value("${" + Constants.CREATE_APPLICATION + ".payment.option.limited.pay}")
	private String limitedPay;

	@Value("${" + Constants.CREATE_APPLICATION + ".annuity.option.limited.pay}")
	private String annuityLimitedPay;

	@Value("${" + Constants.CREATE_APPLICATION + ".quotation-id.already.exits}")
	private String quotationIdExits;

	@Value("${" + Constants.CREATE_APPLICATION + ".already.exits}")
	private String recordAlready;

	@Value("${" + Constants.CREATE_APPLICATION + ".currency.code}")
	private String currencyCode;

	@Value("${" + Constants.CREATE_APPLICATION + ".rider.name.serious.illness}")
	private String seriousIllness;

	@Value("${" + Constants.CREATE_APPLICATION + ".rider.id.si}")
	private String riderIdSi;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".rider.name.accidental.death.benifit}")
	private String accidentalDeathBenifit;

	@Value("${" + Constants.CREATE_APPLICATION + ".rider.id.adbr}")
	private String riderIdAdbr;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.product.id}")
	private String errorProductId;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.product.name}")
	private String errorProductName;

	@Value("${" + Constants.CREATE_APPLICATION + ".invalid.product.name}")
	private String invalidProductName;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".product.code}")
	private String productCode;
		
	@Value("${" + Constants.DATE_FORMAT +"}")
	private String dateFromat;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.plan.id}")
	private String errorPlanId;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.modal.premium.amount}")
	private String errorModalPremiumAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.service.tax.amount}")
	private String errorServiceTaxAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.sum.assuared.amount}")
	private String errorSumAssuaredAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.mode.description}")
	private String errorModeDescription;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.product.id}")
	private String errorRiderProductId;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.rider.frequency.code}")
	private String errorRiderFrequencyCode;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.annual.premium.amount}")
	private String errorAnnualPremiumAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.modal.premium.amount}")
	private String errorPremiumModalPremiumAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.service.tax.amount}")
	private String errorPremiumServiceTaxAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.sum.assuared.amount}")
	private String errorPremiumSumAssuaredAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.premium.amount}")
	private String errorPremiumAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.accrued.reversionary.bonus.amount}")
	private String errorPremiumAccruedReversionaryBonusAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.reversionary.bonus.amount}")
	private String errorPremiumRevisionaryBonusAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.terminal.bonus.amount}")
	private String errorPremiumTerminalBonusAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.guaranteed.income.amount}")
	private String errorPremiumGuaranteedIncomeAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.maturity.benifit.amount}")
	private String errorPremiumMaturityBenefitAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.total.payout.amount}")
	private String errorPremiumTotalPayoutAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".error.premium.guaranteed.death.benefit.amount}")
	private String errorPremiumGuaranteedDeathBenefitAmount;
	
	@Value("${" + Constants.CREATE_APPLICATION + ".update.application.success.msg}")
	private String updateApplicationSuccessMessage;
	
	@Value("${" +  Constants.CREATE_APPLICATION + ".error.msg.blank.leadid.appNumber}")
	private String errorMsgLeadIdAppNumberBlank;
	
	@Value("${" + Constants.BASE_PATH + "create.application.error.msg.invalid.state" + "}")
    private String errMsgInvalidState;
    
    @Value("${" + Constants.BASE_PATH + "create.application.invalid.state" + "}")
    private String errInvalidSate;
    
    @Value("${" + Constants.BASE_PATH + "create.application.error.mgfp.product.id" + "}")
    private String errMgfproductId;
    
    @Value("${" + Constants.BASE_PATH + "create.application.error.mgfp.plan.id" + "}")
    private String errMgfplanId;

}
