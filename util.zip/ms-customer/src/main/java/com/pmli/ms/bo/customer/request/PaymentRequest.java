package com.pmli.ms.bo.customer.request;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.util.Objects;

import com.pmli.ms.bo.customer.model.LeadDetailPayment;
import com.pmli.ms.bo.customer.model.LeadDetailPayment.Enach;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.java.JUtil;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the request details of 'Add Payment' API.
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@ApiModel(description = "This is the request bean for Add-Payment operation")
@Data
@EqualsAndHashCode(callSuper = true)
public class PaymentRequest extends LeadRequest {

    @ApiModelProperty(value = "Application Number", example = "100501173")
    @FieldMetaJson("{displayName:'Application Number',validations:'isMaxLength~32,matchesRegEx~[0-9]*'}")
    private String  applicationNumber;
    @FieldMetaJson("{displayName:'payment',nullable:false,validations:'notNull'}")
    private Payment payment;

    @ApiModel(description = "This class contains the Bank details")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Bank {
        @ApiModelProperty(required = true, value = "Bank ID", example = "ICICI Bank")
        @FieldMetaJson("{displayName:'Bank ID',nullable:false,validations:'notNull,notBlank'}")
        private String bankId;
        @ApiModelProperty(value = "Currency Code", example = "NA")
        private String bankMerchantId;
    }

    @ApiModel(description = "This class contains the Security details")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Security {
        @ApiModelProperty(value = "Security Type", example = "NA")
        private String securityType;
        @ApiModelProperty(value = "Security ID", example = "NA")
        private String securityID;
        @ApiModelProperty(value = "Security Password", example = "0.00")
        private String securityPassword;
    }

    @ApiModel(description = "This class contains the payment details")
    @Data
    @NoArgsConstructor
    public static class Payment {
        @ApiModelProperty(required = true, value = "Credit Card Type", example = "Debit")
        private String       creditCardType;
        @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'totalAmount',validations:'greaterThan~$errmsg:totalAmount should be >=-1.~-1'},{childPath:'currencyCode',displayName:'totalAmount currencyCode',validations:'notNull,notBlank'}]}")
        private Money        totalAmount;
        @ApiModelProperty(required = true, value = "Payment Date Time", example = "2021-03-18T16:09:26+05:30")
        @FieldMetaJson("{displayName:'Payment Date Time',nullable:false,validations:\"notNull,notBlank,isDate~"
            + IsoDateDeSerializer.MONGO_DATE_FORMAT + "~false\"}")
        private String       paymentDateTime;
        @ApiModelProperty(required = true, value = "Merchant ID", example = "METLIFSALE")
        @FieldMetaJson("{displayName:'Merchant Id',nullable:false,validations:'notNull,notBlank'}")
        private String       merchantId;
        @ApiModelProperty(required = true, value = "Customer ID", example = "637469424188783830")
        @FieldMetaJson("{displayName:'Customer Id',nullable:false,validations:'notNull,notBlank'}")
        private String       customerId;
        @ApiModelProperty(required = true, value = "Transaction Reference Number", example = "Jan252021040926")
        @FieldMetaJson("{displayName:'Transaction Reference Number',nullable:false,validations:'notNull,notBlank'}")
        private String       transactionReferenceNumber;
        @ApiModelProperty(value = "Bank Reference Number", example = "NA")
        private String       bankReferenceNumber;
        @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'Annual Income Amount',validations:'greaterThan~$errmsg:Annual income should be >=-1.~-1'},{childPath:'currencyCode',displayName:'Annual Income currencyCode',validations:'notNull,notBlank'}]}")
        private Money        transactionAmount;
        @FieldMetaJson("{displayName:'Bank',nullable:false}")
        private Bank         bank;
        @ApiModelProperty(value = "Transaction Type", example = "NA")
        private String       transactionType;
        @ApiModelProperty(value = "Item Code", example = "NA")
        private String       itemCode;
        @ApiModelProperty(hidden = true)
        private Security     security;
        @ApiModelProperty(required = true, value = "Transaction Date Time", example = "2021-03-19T16:09:26+05:30")
        @FieldMetaJson("{displayName:'Transaction Date Time',nullable:false,validations:\"notNull,notBlank,isDate~"
            + IsoDateDeSerializer.MONGO_DATE_FORMAT + "~false\"}")
        private String       transactionDateTime;
        @ApiModelProperty(required = true, value = "Auth Status", example = "0300")
        @FieldMetaJson("{displayName:'Auth Status',nullable:false,validations:'notNull,notBlank'}")
        private String       authStatus;
        @ApiModelProperty(value = "Settlement Type", example = "NA")
        private String       settlementType;
        @ApiModelProperty(value = "Additional Information 1", example = "NA")
        private String       additionalInformation1;
        @ApiModelProperty(required = true, value = "Additional Information 2", example = "150002305")
        @FieldMetaJson("{displayName:'Additional Information 2',nullable:false,validations:'notNull,notBlank'}")
        private String       additionalInformation2;
        @ApiModelProperty(value = "Additional Information 3", example = "NEWBS")
        private String       additionalInformation3;
        @ApiModelProperty(required = true, value = "Additional Information 4", example = "8800482645")
        @FieldMetaJson("{displayName:'Additional Information 4',nullable:false,validations:'notNull,notBlank'}")
        private String       additionalInformation4;
        @ApiModelProperty(required = true, value = "Additional Information 5", example = "krishnagupta@zphin.com")
        @FieldMetaJson("{displayName:'Additional Information 5',nullable:false,validations:'notNull,notBlank'}")
        private String       additionalInformation5;
        @ApiModelProperty(required = true, value = "Additional Information 6", example = "80000131427")
        @FieldMetaJson("{displayName:'Additional Information 6',nullable:false,validations:'notNull,notBlank'}")
        private String       additionalInformation6;
        @ApiModelProperty(value = "Additional Information 7", example = "MPEMAIL")
        private String       additionalInformation7;
        private ErrorBean    error;
        @ApiModelProperty(value = "Check Sum", hidden = true, example = "C0820D0991CEB3622185830795E825E6D76F83D1FC7D3EA9664E2D1F107DA76C")
        private String       checkSum;
        @ApiModelProperty(required = true, value = "Status Code", example = "true")
        @FieldMetaJson("{displayName:'$parent Status Code',nullable:false,validations:'notNull,notBlank,isBoolean'}")
        private String       statusCode;
        @ApiModelProperty(value = "Response Message", example = "NA")
        private String       responseMessage;
        @ApiModelProperty(hidden = true)
        private EnachRequest enachResponse;

        public Payment(LeadDetailPayment.Payment payment) {
            if (!Objects.isNull(payment)) {
                this.creditCardType = payment.getCreditCardType();
                ofNullable(payment.getTotalAmount())
                    .ifPresent(amt -> this.totalAmount = new Money(new BigDecimal(amt)));
                ofNullable(payment.getPaymentDate()).ifPresent(
                    pd -> this.paymentDateTime = JUtil.getFormattedDateTime(pd, IsoDateDeSerializer.MONGO_DATE_FORMAT));
                if (!Objects.isNull(payment.getPaymentMoreInfo())) {
                    this.merchantId = payment.getPaymentMoreInfo().getBankMerchantID();
                    this.customerId = payment.getPaymentMoreInfo().getCustomerID();
                    this.transactionReferenceNumber = payment.getPaymentMoreInfo().getTxnReferenceNo();
                    this.bankReferenceNumber = payment.getPaymentMoreInfo().getBankReferenceNo();
                    this.transactionAmount = new Money(new BigDecimal(payment.getPaymentMoreInfo().getTxnAmount()));
                    this.bank = new Bank(payment.getPaymentMoreInfo().getBankID(),
                        payment.getPaymentMoreInfo().getBankMerchantID());
                    this.transactionType = payment.getPaymentMoreInfo().getTxnType();
                    this.itemCode = payment.getPaymentMoreInfo().getItemCode();
                    this.security = new Security(payment.getPaymentMoreInfo().getSecurityType(),
                        payment.getPaymentMoreInfo().getSecurityID(),
                        payment.getPaymentMoreInfo().getSecurityPassword());
                    this.transactionDateTime = JUtil.getFormattedDateTime(payment.getPaymentDate(),
                        IsoDateDeSerializer.MONGO_DATE_FORMAT);
                    this.authStatus = payment.getPaymentMoreInfo().getAuthStatus();
                    this.settlementType = payment.getPaymentMoreInfo().getSettlementType();
                    this.additionalInformation1 = payment.getPaymentMoreInfo().getAdditionalInfo1();
                    this.additionalInformation2 = payment.getPaymentMoreInfo().getAdditionalInfo2();
                    this.additionalInformation3 = payment.getPaymentMoreInfo().getAdditionalInfo3();
                    this.additionalInformation4 = payment.getPaymentMoreInfo().getAdditionalInfo4();
                    this.additionalInformation5 = payment.getPaymentMoreInfo().getAdditionalInfo5();
                    this.additionalInformation6 = payment.getPaymentMoreInfo().getAdditionalInfo6();
                    this.additionalInformation7 = payment.getPaymentMoreInfo().getAdditionalInfo7();
                    this.checkSum = payment.getPaymentMoreInfo().getCheckSum();
                }

                this.statusCode = String.valueOf(payment.isStatusCode());
                this.responseMessage = payment.getResponseMessage();
                ofNullable(payment.getEnachResponse())
                    .ifPresent(p -> this.enachResponse = new EnachRequest(payment.getEnachResponse()));
            }

        }
    }

    @ApiModel(description = "This class contains the Payment Error details")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ErrorBean {
        @ApiModelProperty(value = "Error Status", example = "NA")
        private String errorStatus;
        @ApiModelProperty(value = "Error Description", example = "Mandate Registration Failed")
        private String errorDescription;
    }

    @ApiModel(description = "This class contains the Payment Enach details")
    @Data
    @NoArgsConstructor
    public static class EnachRequest {
        @ApiModelProperty(value = "Merchant ID", example = "PNBMLB")
        private String    merchantId;
        @ApiModelProperty(value = "Customer ID", example = "318c45c0-ecdf-4513-b734-940d89054448")
        private String    customerId;
        @ApiModelProperty(value = "Transaction Reference Number", example = "44752")
        private String    transactionReferenceNumber;
        @ApiModelProperty(value = "Bank Reference Number", example = "NA")
        private String    bankReferenceNumber;
        @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'transactionAmount',validations:'greaterThan~$errmsg:transactionAmount should be >=0.~-1'},{childPath:'currencyCode',displayName:'transactionAmount currencyCode',validations:'notNull,notBlank'}]}")
        private Money     transactionAmount;
        @FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'sumInsuredAmount',validations:'greaterThan~$errmsg:sumInsuredAmount should be >=0.~-1'},{childPath:'currencyCode',displayName:'sumInsuredAmount currencyCode',validations:'notNull,notBlank'}]}")
        private Money     sumInsuredAmount;
        private BankEnach bank;
        @ApiModelProperty(value = "Transaction Date Time", example = "2/2/2021 3:30:14 PM")
        private String    transactionDateTime;
        @ApiModelProperty(value = "Auth Status", example = "399")
        private String    authStatus;
        @ApiModelProperty(value = "Unique Member Number", example = "YESB7010311200008058")
        private String    uniqueMemberNumber;
        @ApiModelProperty(value = "Policy Number", example = "150004063")
        private String    policyNumber;
        @ApiModelProperty(value = "Application Number", example = "150004063")
        private String    applicationNumber;
        private ErrorBean error;
        @ApiModelProperty(value = "Check Sum", example = "C0820D0991CEB3622185830795E825E6D76F83D1FC7D3EA9664E2D1F107DA76C")
        private String    checksum;
        @ApiModelProperty(value = "Item Code", example = "Direct")
        private String    itemCode;
        @ApiModelProperty(value = "Additional Information 3", example = "637478734480139000")
        private String    additionalInformation3;
        @ApiModelProperty(value = "Additional Information 4", example = "NA")
        private String    additionalInformation4;
        @ApiModelProperty(value = "Additional Information 5", example = "NA")
        private String    additionalInformation5;
        @ApiModelProperty(value = "Additional Information 6", example = "NA")
        private String    additionalInformation6;
        @ApiModelProperty(value = "Additional Information 7", example = "NA")
        private String    additionalInformation7;

        public EnachRequest(Enach enach) {
            this.merchantId = enach.getMerchantId();
            this.customerId = enach.getCustomerId();
            this.transactionReferenceNumber = enach.getTxnReferenceNo();
            this.bankReferenceNumber = enach.getBankReferenceNo();
            ofNullable(enach.getTxnAmount())
                .ifPresent(o -> this.transactionAmount = new Money(new BigDecimal(o)));
            ofNullable(enach.getSiAmount()).ifPresent(o -> this.sumInsuredAmount = new Money(new BigDecimal(o)));

            this.bank = new BankEnach(enach.getAccountType(), enach.getAccountNumber(), enach.getBankName(),
                enach.getBankId(), new Name("", enach.getAccountHolderName(), "", ""));
            this.transactionDateTime = enach.getTxnDate();
            this.authStatus = enach.getAuthStatus();
            this.uniqueMemberNumber = enach.getUmrn();
            this.policyNumber = enach.getPolicyNo();
            this.applicationNumber = enach.getAccountNumber();
            this.error = new ErrorBean(enach.getErrorStatus(), enach.getErrorDescription());
            this.checksum = enach.getChecksum();
            this.itemCode = enach.getItemCode();
            this.additionalInformation3 = enach.getAdditionalInfo3();
            this.additionalInformation4 = enach.getAdditionalInfo4();
            this.additionalInformation5 = enach.getAdditionalInfo5();
            this.additionalInformation6 = enach.getAdditionalInfo6();
            this.additionalInformation7 = enach.getAdditionalInfo7();
        }
    }

    @ApiModel(description = "This class contains the Payment Bank Enach details")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class BankEnach {
        @ApiModelProperty(value = "Account Type", example = "Savings")
        private String accountType;
        @ApiModelProperty(value = "Account Number", example = "25199000004061")
        private String accountNumber;
        @ApiModelProperty(value = "Bank Name", example = "YES BANK LTD")
        private String bankName;
        @ApiModelProperty(value = "Bank ID", example = "PNBMLAPIEMN")
        private String bankId;
        private Name   accountHolderName;
    }
}
