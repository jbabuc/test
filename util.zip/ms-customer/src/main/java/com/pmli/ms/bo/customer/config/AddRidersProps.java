package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class AddRidersProps {
	@Value("${" + Constants.BASE_PATH + "add.rider.success}")
	private String addRiderSuccess;

	@Value("${" + Constants.BASE_PATH + "add.rider.lead.not.found}")
	private String leadNotFound;

	@Value("${" + Constants.BASE_PATH + "add.rider.invalid.product.Id}")
	private String errorProductId;

	@Value("${" + Constants.BASE_PATH + "add.rider.invalid.product.name}")
	private String invalidProductName;

	@Value("${" + Constants.BASE_PATH + "add.rider.error.product.name}")
	private String errorProductName;

}
