package com.pmli.ms.bo.customer.helper;

import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.AddRidersProps;
import com.pmli.ms.bo.customer.config.RiderId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.request.RidersRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class AddRidersHelper extends MsObject {
    DBClient dbClient;

    AddRidersProps rdProps;

    RidersRequest addRidersRequest;
   /**
    * This method is used to validate the rider request.
    */
    public void validate() {
        new ValidationHelper(addRidersRequest).validateWithMetaJson();
        addRidersRequest.getRiders().forEach(rd -> {
        	new StringValidator(rd.getDefermentValue(), "Deferment Value", false)
        	.validateAll("notNull,matchesRegEx~$errmsg:Invalid Deferment Value.~^[0-9]+$|^$");
            if (!RiderId.isValidRiderId(rd.getProductId())) {
                throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                    rdProps.getErrorProductId(), rdProps.getErrorProductId());
            }
            
            if (!rd.getProductName()
                .equals(dbClient.getMasterValueByTypeKey("riderShortNames", rd.getProductId() + ""))) {
                throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
                    rdProps.getInvalidProductName(), rdProps.getErrorProductName());
            }
        });
    }
}
