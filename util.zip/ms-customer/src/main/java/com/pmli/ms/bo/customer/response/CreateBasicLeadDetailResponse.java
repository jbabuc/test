package com.pmli.ms.bo.customer.response;

import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.java.JUtil;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class holds the response details for create-basic-lead-detail API
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "This is the response bean for create-basic-lead-detail operation")
public class CreateBasicLeadDetailResponse {
    @ApiModelProperty(value = "Lead Id", example = "20210920130704333911")
    private String leadId;
    @ApiModelProperty(value = "Transaction Id", example = "TXN9151632123091423")
    private String transactionId;
    @ApiModelProperty(value = "Lead Creation Time Stamp", example = "2021-09-20T13:07:04.334+05:30")
    private String leadCreationTimestamp;

    public CreateBasicLeadDetailResponse(String leadId, String transactionId, LeadDetail ld) {
        super();
        this.leadId = leadId;
        this.transactionId = transactionId;
        this.leadCreationTimestamp = JUtil.getFormattedDateTime(ld.getCreatedOn(),
            IsoDateDeSerializer.MONGO_DATE_FORMAT);
    }

}
