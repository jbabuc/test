package com.pmli.ms.bo.customer.request;

import com.pmli.util.java.FieldMetaJson;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the request details of 'get-leads-list' API.
 * 
 * @author Snehal Shimpi
 * @version 1.0.0
 */

@Data
public class LeadListRequest {
	
	@ApiModelProperty(required = true, value = "Mobile Number", example = "9029199934")
	@FieldMetaJson("{displayName:'Mobile No',nullable:false,validations:'notNullMatchesRegEx~$errmsg:Mobile Number must not be blank with max 10 digits.~^[0-9]{10}$'}")
	private String mobileNumber;
}
