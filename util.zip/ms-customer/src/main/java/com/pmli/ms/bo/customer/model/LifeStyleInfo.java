package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;

import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.helper.AddLifestyleInfoHelper;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LifeStyleInfo {
	private LifeStyleDetails lifeStyleDetails;
	private InsuranceDetails insuranceDetails;
	private FamilyDetails familyDetails;
	@JsonProperty("eInsuranceAccountDetails")
	private EInsuranceAccountDetails eInsuranceAccountDetails;

	public LifeStyleInfo(LifeStyleInfoRequest.LifeStyleInfo lifeStyleInfo, AddLifestyleInfoHelper helper) {
		ofNullable(lifeStyleInfo.getLifeStyleDetail()).ifPresent(n -> this.lifeStyleDetails = new LifeStyleDetails(n,helper));
		ofNullable(lifeStyleInfo.getFamilyDetail()).ifPresent(n -> this.familyDetails = new FamilyDetails(n,helper));
		ofNullable(lifeStyleInfo.getInsuranceDetail()).ifPresent(n -> this.insuranceDetails = new InsuranceDetails(n,helper));
		ofNullable(lifeStyleInfo.getEInsuranceAccountDetail())
				.ifPresent(n -> this.eInsuranceAccountDetails = new EInsuranceAccountDetails(n,helper));
	}

	@Data
	@NoArgsConstructor
	public static class LifeStyleDetails {
		private IsFlyDetails isFlyDetails;
		private EngageInAutoMobile isEngageInAutoMobile;
		private CriminalOffence isCriminalOffence;
		private ExposedPersonPEP exposedPersonPEP;
		private PayerOfTrustcharityNGO payerOfTrustcharityNGO;
		private MilitaryorPoliceForce militaryorPoliceForce;
		private Hazards hazards;

		public LifeStyleDetails(LifeStyleInfoRequest.LifeStyleDetail lifeStyleDetail, AddLifestyleInfoHelper helper) {
			ofNullable(lifeStyleDetail.getFlyDetail()).ifPresent(n -> this.isFlyDetails = new IsFlyDetails(n,helper));
			ofNullable(lifeStyleDetail.getEngageInAutoMobile())
					.ifPresent(n -> this.isEngageInAutoMobile = new EngageInAutoMobile(n,helper));
			ofNullable(lifeStyleDetail.getCriminalOffence())
					.ifPresent(n -> this.isCriminalOffence = new CriminalOffence(n,helper));
			ofNullable(lifeStyleDetail.getExposedPersonPEP())
					.ifPresent(n -> this.exposedPersonPEP = new ExposedPersonPEP(n,helper));
			ofNullable(lifeStyleDetail.getPayerOfTrustcharityNGO())
					.ifPresent(n -> this.payerOfTrustcharityNGO = new PayerOfTrustcharityNGO(n,helper));
			ofNullable(lifeStyleDetail.getMilitaryorPoliceForce())
					.ifPresent(n -> this.militaryorPoliceForce = new MilitaryorPoliceForce(n,helper));
			ofNullable(lifeStyleDetail.getHazard()).ifPresent(n -> this.hazards = new Hazards(n,helper));
		}
	}

	@Data
	@NoArgsConstructor
	public static class IsFlyDetails {
		@JsonProperty("isFly")
		private String isFly;
		private String detail;

		public IsFlyDetails(LifeStyleInfoRequest.FlyDetail fd,AddLifestyleInfoHelper helper) {
			this.isFly = helper.boolToStr(fd.isFly());
			this.detail = fd.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class EngageInAutoMobile {
		@JsonProperty("isEngageInAutoMobile")
		private String isEngageInAutoMobile;
		private String detail;

		public EngageInAutoMobile(LifeStyleInfoRequest.EngageInAutoMobile e,AddLifestyleInfoHelper helper) {
			this.isEngageInAutoMobile = helper.boolToStr(e.isEngageInAutoMobile());
			this.detail = e.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class CriminalOffence {
		@JsonProperty("isCriminalOffence")
		private String isCriminalOffence;
		private String detail;

		public CriminalOffence(LifeStyleInfoRequest.CriminalOffence c,AddLifestyleInfoHelper helper) {
			this.isCriminalOffence = helper.boolToStr(c.isCriminalOffence());
			this.detail = c.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class ExposedPersonPEP {
		@JsonProperty("exposedPersonPEP")
		private String isExposedPersonPEP;
		private String detail;

		public ExposedPersonPEP(LifeStyleInfoRequest.ExposedPersonPEP n,AddLifestyleInfoHelper helper) {
			this.isExposedPersonPEP = helper.boolToStr(n.isExposedPersonPEP());
			this.detail = n.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class PayerOfTrustcharityNGO {
		@JsonProperty("payerOfTrustCharityNGO")
		private String isPayerOfTrustCharityNGO;
		private String detail;

		public PayerOfTrustcharityNGO(LifeStyleInfoRequest.PayerOfTrustcharityNGO p,AddLifestyleInfoHelper helper) {
			this.isPayerOfTrustCharityNGO = helper.boolToStr(p.isPayerOfTrustCharityNGO());
			this.detail = p.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class ArmedServicesQuestionnaire {
		@JsonProperty("armedServicesQuestionnaire")
		private String isArmedServicesQuestionnaire;
		private String fullnameOfTheApplicant;
		private int branchOfArmedForces;
		private int rank;
		private String exactNatureOfDuty;

		public ArmedServicesQuestionnaire(LifeStyleInfoRequest.ArmedServicesQuestionnaire a,AddLifestyleInfoHelper helper) {
			this.isArmedServicesQuestionnaire = helper.boolToStr(a.isArmedServicesQuestionnaire());
			this.fullnameOfTheApplicant = a.getFullnameOfTheApplicant();
			this.branchOfArmedForces = a.getBranchOfArmedForces();
			this.rank = a.getRank();
			this.exactNatureOfDuty = a.getExactNatureOfDuty();
		}
	}

	@Data
	@NoArgsConstructor
	public static class EngagedBombDisposalDriving {
		@JsonProperty("engagedBombDisposalDriving")
		private String isEngagedBombDisposalDriving;
		private String engagedinBombDisposalDrivingInfo;

		public EngagedBombDisposalDriving(LifeStyleInfoRequest.EngagedBombDisposalDriving a,AddLifestyleInfoHelper helper) {
			this.isEngagedBombDisposalDriving = helper.boolToStr(a.isEngagedBombDisposalDriving());
			this.engagedinBombDisposalDrivingInfo = a.getEngagedinBombDisposalDrivingInfo();
		}
	}

	@Data
	@NoArgsConstructor
	public static class HazardeousActivity {
		@JsonProperty("hazardeousActivity")
		private String isHazardeousActivity;
		private String hazardeousActivityInfo;

		public HazardeousActivity(LifeStyleInfoRequest.HazardeousActivity a,AddLifestyleInfoHelper helper) {
			this.isHazardeousActivity = helper.boolToStr(a.isHazardeousActivity());
			this.hazardeousActivityInfo = a.getHazardeousActivityInfo();
		}
	}

	@Data
	@NoArgsConstructor
	public static class CurrentlServingIn {
		@JsonProperty("currentlServingIn")
		private String isCurrentlServingIn;
		private String troubledAreasInfo;

		public CurrentlServingIn(LifeStyleInfoRequest.CurrentlyServingIn a,AddLifestyleInfoHelper helper) {
			this.isCurrentlServingIn =helper.boolToStr(a.isCurrentlyServingIn());
			this.troubledAreasInfo = a.getTroubledAreasInfo();
		}
	}

	@Data
	@NoArgsConstructor
	public static class DetailsActivites {
		@JsonProperty("detailsActivites")
		private String detailsActivite;

		public DetailsActivites(LifeStyleInfoRequest.DetailedActivitesInvolvedIn a) {
			this.detailsActivite = a.getDetailedActivites();
		}
	}

	@Data
	@NoArgsConstructor
	public static class BasedLocation {
		@JsonProperty("basedLocation")
		private String basedLocationDetail;

		public BasedLocation(LifeStyleInfoRequest.BasedLocation a) {
			this.basedLocationDetail = a.getBasedLocationDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class MilitaryorPoliceForce {
		private ArmedServicesQuestionnaire armedServicesQuestionnaire;
		private EngagedBombDisposalDriving engagedBombDisposalDriving;
		private HazardeousActivity hazardeousActivity;
		private CurrentlServingIn currentlServingIn;
		@JsonProperty("detailsActivites")
		private DetailsActivites detailsActivites;
		private BasedLocation basedLocation;

		public MilitaryorPoliceForce(LifeStyleInfoRequest.MilitaryorPoliceForce n,AddLifestyleInfoHelper helper) {
			ofNullable(n.getArmedServicesQuestionnaire())
			.ifPresent(a -> this.armedServicesQuestionnaire = new ArmedServicesQuestionnaire(a,helper));
			ofNullable(n.getEngagedBombDisposalDriving())
					.ifPresent(a -> this.engagedBombDisposalDriving = new EngagedBombDisposalDriving(a,helper));
			ofNullable(n.getHazardeousActivity()).ifPresent(a -> this.hazardeousActivity = new HazardeousActivity(a,helper));
			ofNullable(n.getCurrentlyServingIn()).ifPresent(a -> this.currentlServingIn = new CurrentlServingIn(a,helper));
			ofNullable(n.getDetailedActivitesInvolvedIn())
					.ifPresent(a -> this.detailsActivites = new DetailsActivites(a));
			ofNullable(n.getBasedLocation()).ifPresent(a -> this.basedLocation = new BasedLocation(a));

		}
	}

	@Data
	@NoArgsConstructor
	public static class Hazards {
		private String corrosiveChemicalsAndHTVDrivers;
		private String detail;

		public Hazards(LifeStyleInfoRequest.Hazard h,AddLifestyleInfoHelper helper) {
			this.corrosiveChemicalsAndHTVDrivers = helper.boolToStr(h.isHasCorrosiveChemicalsAndHTVDrivers());
			this.detail = h.getDetail();
		}
	}

	@Data
	@NoArgsConstructor
	public static class InsuranceDetails {
		@JsonProperty("isInsurancePolicies")
		private String isInsurancePolicies;
		private List<Insurance> insurance;

		public InsuranceDetails(LifeStyleInfoRequest.InsuranceDetail insuranceDetail, AddLifestyleInfoHelper helper) {
			this.isInsurancePolicies = helper.boolToStr(insuranceDetail.isHasInsurancePolicies());
			ofNullable(insuranceDetail.getInsurances())
					.ifPresent(i -> this.insurance = i.stream().map(Insurance::new).collect(Collectors.toList()));
		}
	}

	@Data
	@NoArgsConstructor
	public static class Insurance {
		private int index;
		@JsonProperty("details")
		private InsurancesDetail detail;

		public Insurance(LifeStyleInfoRequest.Insurance f) {
			this.index = f.getIndex();
			ofNullable(f.getDetail()).ifPresent(d -> this.detail = new InsurancesDetail(d));
		}
	}

	@Data
	@NoArgsConstructor
	public static class InsurancesDetail {
		private int insurer;
		private String coverType;
		private String lifeCover;
		@JsonProperty("yearofIssue")
		private int yearOfIssue;
		@JsonProperty("acceptanceTerms")
		private String acceptedTerms;
		@JsonProperty("applicationNo")
		private String applicationNumber;
		@JsonProperty("annualisedPremium")
		private String annualisedPremiumAmount;
		private String typeOfPolicy;
		private int policyNumber;
		private String applicationDate;
		private int relationshipProposerInsured;
		private String annualisedPremiumStatus;

		public InsurancesDetail(LifeStyleInfoRequest.InsurancesDetail d) {
			this.insurer = d.getInsurer();
			this.coverType = d.getCoverType();
			ofNullable(d.getLifeCoverAmount())
			.ifPresent(a -> this.lifeCover = a.getAmount().toString());
			this.yearOfIssue = d.getYearOfIssue();
			this.acceptedTerms = d.getAcceptedTerms();
			this.applicationNumber = d.getApplicationNumber();
			ofNullable(d.getAnnualisedPremiumAmount())
			.ifPresent(a -> this.annualisedPremiumAmount = a.getAmount().toString());
			this.typeOfPolicy = d.getTypeOfPolicy();
			this.policyNumber = d.getPolicyNumber();
			this.applicationDate = d.getApplicationDate();
			this.relationshipProposerInsured = d.getRelationshipProposerInsured();
			this.annualisedPremiumStatus = d.getAnnualisedPremiumStatus();
		}
	}

	@Data
	@NoArgsConstructor
	public static class FamilyDetails {
		@JsonProperty("isFamilyMedicalStatus")
		private String isFamilyMedicalStatus;
		private List<FamilyMember> familyMembers;

		public FamilyDetails(LifeStyleInfoRequest.FamilyDetail familyDetail, AddLifestyleInfoHelper helper) {
			this.isFamilyMedicalStatus = helper.boolToStr(familyDetail.isFamilyMedicalStatus());
			ofNullable(familyDetail.getFamilyMembers()).ifPresent(
					n -> this.familyMembers = n.stream().map(FamilyMember::new).collect(Collectors.toList()));
		}
	}

	@Data
	@NoArgsConstructor
	public static class FamilyMember {
		private int index;
		@JsonProperty("details")
		private Detail detail;

		public FamilyMember(LifeStyleInfoRequest.FamilyMemberDetails f) {
			this.index = f.getIndex();
			ofNullable(f.getDetail()).ifPresent(d -> this.detail = new Detail(d));
		}
	}

	@Data
	@NoArgsConstructor
	public static class Detail {
		private int parentsOrSiblings;
		private int currentLiveStatus;
		private int age;
		private int diseaseSufferingFrom;
		private String causeOfDeath;
		private int ageOnSet;

		public Detail(LifeStyleInfoRequest.FamilyMemberDetail d) {
			this.parentsOrSiblings = d.getParentsOrSiblings();
			this.currentLiveStatus = d.getCurrentLiveStatus();
			this.age =d.getAge();
			this.diseaseSufferingFrom = d.getDiseaseSufferingFrom();
			this.causeOfDeath = d.getCauseOfDeath();
			this.ageOnSet = d.getAgeOnSet();
		}
	}

	@Data
	@NoArgsConstructor
	public static class EInsuranceAccountDetails {
		@JsonProperty("isEInsurance")
		private String isEInsurance;
		private int repository;
		private String accountNumber;

		public EInsuranceAccountDetails(LifeStyleInfoRequest.EInsuranceAccountDetail eInsuranceAccountDetail, AddLifestyleInfoHelper helper) {
			this.isEInsurance = helper.boolToStr(eInsuranceAccountDetail.isEInsurance());
			this.repository = eInsuranceAccountDetail.getRepository();
			this.accountNumber = eInsuranceAccountDetail.getAccountNumber();
		}
	}
}
