package com.pmli.ms.bo.customer.helper;

import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.request.PremiumCalcClientReq;
import com.pmli.ms.bo.customer.request.PremiumCalcNvestRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.model.Name;
import com.pmli.util.validation.ListValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.Validator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

/**
 * This is the service implementation helper class.
 * <p>
 * This class consists of the helper methods required for the implementation of the Calculate Premium service.
 * </p>
 * 
 * @author suvarna bambarse
 */
@AllArgsConstructor
public class PremiumCalculationReqHelper extends MsObject {

    private String   errorProductId;
    private DBClient dbClient;

    /**
     * This method prepares nvest request of calculate premium
     * 
     * @param  req          Request details for calculate premium, encapsulated in {@link PremiumCalcClientReq}.
     * @param  sameProposer
     * @return              PremiumCalcNvestRequest Is a Nvest request of premium calculation, encapsulated in
     *                      {@link PremiumCalcNvestRequest}.
     */
    public PremiumCalcNvestRequest preparePremiumCalculationRequest(PremiumCalcClientReq req) {
        // Validation of Request
        validatePremiumCalcutionRequest(req);
        if (req.getLiName() == null) {
            processRequest(req);
            return new PremiumCalcNvestRequest(req, dbClient.getProductId(req.getProduct()), "True");
        }
        return new PremiumCalcNvestRequest(req, dbClient.getProductId(req.getProduct()), "False");
    }

    /**
     * This method process calculate calculate premium
     * 
     * @param req          Request details for calculate premium, encapsulated in {@link PremiumCalcClientReq}.
     * @param sameProposer
     */
    private void processRequest(PremiumCalcClientReq req) {
        req.setLiAge(req.getAge());
        req.setLiBirthDate(req.getBirthDate());
        req.setLiGender(req.getGender());
        Name liName = new Name();
        req.setLiName(liName);
        req.getLiName().setTitle(req.getName().getTitle());
        req.getLiName().setFirstName(req.getName().getFirstName());
        req.getLiName().setMiddleName(req.getName().getMiddleName());
        req.getLiName().setLastName(req.getName().getLastName());
    }

    /**
     * This method validates input request of calculate premium
     * 
     * @param req Request details for calculate premium encapsulated in {@link PremiumCalcClientReq}.
     */
    private void validatePremiumCalcutionRequest(PremiumCalcClientReq req) {
        String planId = dbClient.getProductId(req.getProduct());

        if (planId == null || !ProductId.isValidProductId(planId)) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105, errorProductId,
                errorProductId);
        }

        // Validation for smart platinum plus plan
        if (ProductId.isSmartPlatinumPlusPlan(planId)) {
            new StringValidator(req.getMultiple(), "multiple", false).notNullNotBlank();
            new StringValidator(req.getFundStrategyId(), "fundStrategyId", false).notNullNotBlank();
            new ListValidator(req.getFunds(), "Funds ", false).validate(Validator::notNull)
                .validate(ListValidator::isMinLength, 1);
        }

        // Rider validation only for SSP plan GFP plan
        if (ProductId.isSuperSaverPlan(planId) || ProductId.isGuaranteedFuturePlan(planId)) {
            new ListValidator(req.getRiders(), "Riders ", false).validate(Validator::notNull)
                .validate(ListValidator::isMinLength, 1);
        }

    }
}
