package com.pmli.ms.bo.customer.request;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.pmli.ms.bo.customer.model.BankBranchDetails;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Email;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the request details of 'create-lead' API.
 * @author 3448466ami
 *
 */
@Data
public class LeadDetailBiRequest {

	@Data
    public static class PremiumCalculationBi {
        @ApiModelProperty(required = false, value = "Maturity Age", example = "1")
        private int maturityAge;

        @ApiModelProperty(required = true, value = "Frequency Code", example = "12")
        private int frequencyCode;

        @ApiModelProperty(required = true, value = "Cover Term", example = "1")
        private int coverTerm;

        @ApiModelProperty(required = false, value = "Payment Term", example = "1")
        private int paymentTerm;

        @ApiModelProperty(required = true, value = "Product Id", example = "12007")
        private int productId;

        @ApiModelProperty(required = true, value = "Product Name", example = "PNB MetLife Super Saver Plan")
        private String productName;

        @ApiModelProperty(required = true, value = "Plan Id", example = "11")
        private int planId;

        @ApiModelProperty(required = true, value = "Plan Name", example = "Joint Life Last Survivor Annuity with Return of Purchase Price")
        private String planName;

        @ApiModelProperty(required = true, value = "Mode Description", example = "1.0272")
        private String modeDescription;
        
        @ApiModelProperty(required = true, value = "Deferment", example = "1")
        private int deferment;
        
        @ApiModelProperty(required = false, value = "Deferment Value", example = "1")
        private String defermentValue;
        
        @ApiModelProperty(required = false, value = "Family Care Benefit", example = "5")
        private int familyCareBenefit;
        
        @ApiModelProperty(required = false, value = "Fund Strategy", example = "1")
        private int fundStrategy;
        
        @ApiModelProperty(required = false, value = "Income Payout Mode", example = "9")
        private int incomePayoutMode;
        
        @ApiModelProperty(required = false, value = "Cash Bonus Option", example = "1")
        private int cashBonusOption;
        
        @ApiModelProperty(required = false, value = "Return of Premium", example = "5")
        private int returnOfPremium;
        
        @ApiModelProperty(required = false, value = "Investment Type", example = "5")
        private int investmentType;
        
        private String benefitPayoutDate;
        private BigDecimal multiple;
        private int option;

        private Money accruedReversionaryBonusAmount;
        private Money guaranteedDeathBenefitAmount;
        private Money maturityBenefitAmount;
        private Money modalPremiumAmount;
        private Money totalPayoutAmount;
        private Money annualPremiumAmount;
        private Money serviceTaxAmount;
        private Money sumAssuredAmount;
        private Money premiumAmount;	
        private Money fundAtEndOfTheYearAmount;
        private Money fundAtEndOfTheYearFour;
        private Money maturityBenefitFour;
        private Money survivalBenefit;
        private Money guaranteedIncomeAmount;
        private Money revisionaryBonusAmount;
        private Money terminalBonusAmount;

    }
	
    @ApiModelProperty(required = true, value = "Buy Type Code", example = "2")
    @FieldMetaJson("{displayName:'Buy Type Code',validations:'greaterThan~0,lessThan~3'}")
    private int buyTypeCode;
    
    @ApiModelProperty(required = true, value = "Suitability Analysis", example = "2")
    @FieldMetaJson("{displayName:'Suitability Analysis',validations:'greaterThan~0,lessThan~3'}")
    private int suitabilityAnalysis;
    
    @ApiModelProperty(required = false, value = "Application Number", example = "150089365")
    private String applicationNumber;
    
    @ApiModelProperty(required = true, value = "Utm Source", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Source',nullable:false,validations:'notBlank'}")
    private String utmSource;

    @ApiModelProperty(required = true, value = "Utm Medium", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Medium',nullable:false,validations:'notBlank'}")
    private String utmMedium;

    @ApiModelProperty(required = true, value = "Utm Campaign", example = "Direct")
    @FieldMetaJson("{displayName:'Utm Campaign',nullable:false,validations:'notBlank'}")
    private String utmCampaign;

    @FieldMetaJson("{nullable:true,displayName: 'Name Detail',validations:'notNull',childDataValidations:[{childPath:'title',displayName:'title',nullable:true},{childPath:'firstName',displayName:'firstName',nullable:true},{childPath:'lastName',displayName:'lastName',nullable:true}]}")
    private Name name;
    
    @JsonIgnoreProperties
    private String title;
    
    @JsonIgnoreProperties
    private String leadId;
    
    @ApiModelProperty(required = true, value = "Step", example = "5")
    private int step;

    @ApiModelProperty(required = true, value = "Gender", example = "Male")
    @FieldMetaJson("{displayName:'Gender',nullable:false,validations:'notBlank'}")
    private String gender;

    @ApiModelProperty(required = true, value = "Birth Date", example = "1989-12-12")
    @FieldMetaJson("{displayName:'Birth Date',nullable:false,validations:'notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$'}")
    private String birthDate;

    private Money annualIncomeAmount;

    @ApiModelProperty(required = false, value = "Age", example = "21")
    private int age;
    
    @FieldMetaJson("{nullable:true,childDataValidations:[{childPath:'address',displayName:'Email Address'}]}")
    private Email email;
    
    @FieldMetaJson("{nullable:true,displayName: 'PhoneNumber Detail',listElementDataValidations:{childDataValidations:[{childPath:'number',displayName:'Phone Number',nullable:true}]}}")
    private List<PhoneNumber> phones;
    
    @FieldMetaJson("{nullable:true,displayName: 'Address Detail',childDataValidations:[{childPath:'postalCode',displayName:'Address postalCode',nullable:true}]}")
    private Address address;

    @ApiModelProperty(required = true, value = "Quotation Id", example = "450")
    @JsonIgnoreProperties
    private String quotationId;
    
    @FieldMetaJson("{nullable:true,displayName: 'Bank Details',childDataValidations:[{childPath:'bank',displayName:'Bank Name',nullable:true}]}")
    private BankBranchDetails bankBranchDetails;

    @ApiModelProperty(required = false, value = "Educational Qualification", example = "Graduation")
    private String educationalQualification;

    @ApiModelProperty(required = false, value = "Occupation", example = "Business")
    private String occupation;
    
    @FieldMetaJson("{nullable:false}")
    private PremiumCalculationBi premiumCalculation;
    
    private List<PremiumCalculationBi> riders;
    
    private List<Fund> funds;
    
    @ApiModelProperty(required = false, value = "Joint Life Age", example = "52")
    private int jointLifeAge;

    @ApiModelProperty(required = false, value = "Joint Life Birth Date", example = "1968-12-12")
    @FieldMetaJson("{displayName:'Birth Date',nullable:true,validations:'notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$'}")
    private String jointLifeBirthDate;
    
    private Name jointLifeName;
	private FamilyMember familyMember;
	
    @ApiModelProperty(required = true, value = "Plan Id", example = "12029")
    @FieldMetaJson("{displayName:'Plan Id',nullable:false,validations:'greaterThan~0'}")
    private int planId;
    
    @Data
    @ApiModel(description = "This is the bean conatins the address details operation")
    public static class Address {
        @ApiModelProperty(required = false, value = "Postal Code", example = "110017")
        private String postalCode;
        
        @ApiModelProperty(required = false, value = "Country", example = "India")
        private String country;
        
        @ApiModelProperty(required = false, value = "City", example = "Pune")
        private String city;
        
        @ApiModelProperty(required = false, value = "district", example = "Pune")
        private String district;
        
        @ApiModelProperty(required = false, value = "State", example = "Maharashtra")
        private String state;
        
    }
}
