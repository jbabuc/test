package com.pmli.ms.bo.customer.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.util.spring.ContextWrapper;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the request details to call the external service - 'nvest service'.
 * 
 * @author suvarna bambarse
 *
 */

public class PremiumCalcNvestRequest {

	@Data
	public static class FormInput {

		public FormInput(String key, String value) {
			this.key = key;
			this.value = value;
		}

		private String key;
		private String value;

	}
	@Data
	public static class InputOption {
		@ApiModelProperty(value = "Option Level", example = "1")
		private String optionLevel;
		@ApiModelProperty(value = "Option Id", example = "1")
		private String optionId;
		@ApiModelProperty(value = "Option Value", example = "1")
		private String optionValue;
	}

	@Data
	public  static class Fund {
		@ApiModelProperty(value = "Fund Id", example = "1")
		private int fundId;
		@ApiModelProperty(value = "Fund Percent", example = "10")
		private int fundPercent;
	}
	@Data
	public static class Rider {

		@JsonProperty("RiderId")
		private String riderId;

		private List<FormInput> formInputs;
		private List<InputOption> inputOptions;
	}

	@JsonProperty("APIKey")
	private String apiKey;

	private List<FormInput> formInputs;

	private List<Fund> funds;

	private List<Rider> riders;

	private List<InputOption> inputOptions;

	private List<FormInput> inputPartialWithdrawal;

	@JsonIgnore
	private PremiumCalcClientReq pccr;

	@JsonIgnore
	private Environment env;

	@JsonIgnore
	private String productId;

	@JsonIgnore
	private String sameProposer;

	public PremiumCalcNvestRequest(PremiumCalcClientReq pccr, String productId, String sameProposer ) {
		this.pccr = pccr;
		this.productId = productId;
		this.sameProposer = sameProposer;
		this.env = ContextWrapper.getAppEnv();
	}

	/**
	 * This method gets apiKey
	 */
	@JsonGetter
	String getApiKey() {
		return env.getProperty(Constants.NVEST_TOKEN);
	}

	/**
	 * This method gets formInputs
	 */
	@JsonGetter
	List<FormInput> getFormInputs() {
		if(formInputs != null) {
			return formInputs;
		}
		formInputs = new ArrayList<>();
		formInputs.add(new FormInput("@LI_NAME", pccr.getLiName().getTitle() + " " + pccr.getLiName().getFirstName()
				+ " " + pccr.getLiName().getMiddleName() + " " + pccr.getLiName().getLastName()));
		formInputs.add(new FormInput("@LI_ENTRY_AGE", pccr.getLiAge()));
		formInputs.add(new FormInput("@LI_DOB", pccr.getLiBirthDate()));
		formInputs.add(new FormInput("@LI_GENDER", pccr.getLiGender()));
		formInputs.add(new FormInput("@LI_STATE", "0"));
		formInputs.add(new FormInput("@PROPOSER_NAME", pccr.getName().getTitle() + " " + pccr.getName().getFirstName()
				+ " " + pccr.getName().getMiddleName() + " " + pccr.getName().getLastName()));
		formInputs.add(new FormInput("@PROPOSER_AGE", pccr.getAge()));
		formInputs.add(new FormInput("@PROPOSER_DOB", pccr.getBirthDate()));
		formInputs.add(new FormInput("@PROPOSER_GENDER", pccr.getGender()));
		formInputs.add(new FormInput("@KFD", "E"));
		formInputs.add(new FormInput("@Pincode", ""));
		formInputs.add(new FormInput("@SameProposer", sameProposer));
		formInputs.add(new FormInput("@COMPANY_STATE", "0"));
		formInputs.add(new FormInput("@GSTIN", ""));
		formInputs.add(new FormInput("@GSTIN_Number", ""));
		formInputs.add(new FormInput("@INPUT_MODE", pccr.getFrequency()));
		formInputs.add(new FormInput("@PR_PT", pccr.getCover()));
		formInputs.add(new FormInput("@PR_PPT", pccr.getPaymentTerm()));
		formInputs.add(new FormInput("@AGENT_ID", ""));
		formInputs.add(new FormInput("@LI_MOBILENO", ""));
		formInputs.add(new FormInput("@PR_ANNPREM", ""));
		formInputs.add(new FormInput("@LI_EMAILID", ""));
		formInputs.add(new FormInput("@PR_MI", "0"));
		formInputs.add(new FormInput("@PR_SA", "0"));
		formInputs.add(new FormInput("@PR_CHANNEL", env.getProperty(Constants.PRODUCT_CHANNEL)));

		if (pccr.getChildName() != null) {
			formInputs.add(
					new FormInput("@CHILD_NAME", pccr.getChildName().getTitle() + pccr.getChildName().getFirstName()
							+ pccr.getChildName().getMiddleName() + pccr.getChildName().getLastName()));
		}
		formInputs.add(new FormInput("@PR_ID", productId));
		formInputs.add(new FormInput("@BROWSERDETAILS", "")); // brouser info
		formInputs.add(new FormInput("@CLIENTIPV1", env.getProperty(Constants.CLIENT_ADDRESS))); // client IP
		
		// applicable only for PNB Metlife Guaranteed Future Plan and PNB MetLife Smart Platinum Plus
		if (ProductId.isGuaranteedFuturePlan(productId) || ProductId.isSmartPlatinumPlusPlan(productId)) {
			formInputs.add(new FormInput("@PR_ModalPrem", String.valueOf(pccr.getPremiumAmount().getAmount())));
		} else {
			formInputs.add(new FormInput("@PR_ModalPrem", ""));
		}
		// Set data on basis of plan
		setData(productId);
		return formInputs;

	}
	
	private void setData(String productId) {
		switch(productId) {
		case "12007":
			// applicable for PNB Metlife Super Saver Plan
			formInputs.add(new FormInput("@BASE_ANN_PREM", String.valueOf(pccr.getPremiumAmount().getAmount())));
			setPremiumSumAssured();
			setEmployeeInfo();
			break;
		case "12020":
			// applicable only for PNB Guaranteed Future Plan
			formInputs.add(new FormInput("@SA", String.valueOf(pccr.getSumAssuredAmount().getAmount())));
			formInputs.add(new FormInput("@Occupation_Extra", "0"));
			formInputs.add(new FormInput("@Resident_Extra", "0"));
			formInputs.add(new FormInput("@Sport_Extra", "0"));
			formInputs.add(new FormInput("@Other_Extra", "0"));
			setPremiumSumAssured();
			setEmployeeInfo();
			break;
		case "12029":
			// applicable only for PNB Metlife Immediate Annuity Plan
			formInputs.add(
					new FormInput("@GUAR_ANN_PAYABLE_ANNUAL", String.valueOf(pccr.getPremiumAmount().getAmount())));
			formInputs.add(new FormInput("@EMP_DISCOUNT", "0"));
			formInputs.add(new FormInput("@DISPLAY_OPTION_VALUE_3", ""));
			setPremiumSumAssured();
			break;
		case "12025":
			// applicable only for PNB MetLife Smart Platinum Plus
			formInputs.add(new FormInput("@PR_SAMF", pccr.getMultiple()));
			formInputs.add(new FormInput("@SA", "0"));
			formInputs.add(new FormInput("@emr_rate", "0"));
			formInputs.add(new FormInput("@Extra_Morbidity", "0"));
			formInputs.add(new FormInput("@FUNDSTRATEGYID", pccr.getFundStrategyId()));
			setEmployeeInfo();
			break;
		default:
		}

	}
	
	private void setPremiumSumAssured() {
		formInputs.add(new FormInput("@PR_SAMF", "0"));
	}
	
	private void setEmployeeInfo() {
		// Not applicable for PNB Metlife Immediate Annuity Plan
		formInputs.add(new FormInput("@Health_extra", "0"));
		if (pccr.getEmployee() != null) {
			String isStaff = pccr.getEmployee().isEmployee() ? "1" : "0";
			formInputs.add(new FormInput("@IS_STAFF", isStaff));
			formInputs.add(new FormInput("@AGE_EXTRA", "0"));
		}
	}

	/**
	 * This method gets funds
	 */
	@JsonGetter
	public List<Fund> getFunds() {

		if(funds != null) {
			return funds;
		}
		// applicable only for Smart platinum Plus
		if (!ProductId.isSmartPlatinumPlusPlan(productId)) {
			funds = new ArrayList<>();
		} else {
			funds = pccr.getFunds();
		}
		return funds;
	}

	/**
	 * This method gets riders
	 */
	@JsonGetter
	public List<Rider> getRiders() {
		
		if(riders != null) {
			return riders;
		}
		// applicable only for PNB MetLife Guaranteed Future Plan and PNB MetLife Super Saver Plan
		riders = new ArrayList<>();
		pccr.getRiders().forEach(rider -> {
			Rider riderDetail = new Rider();
			riderDetail.setRiderId(String.valueOf(rider.getRiderId()));
			List<FormInput> formInputValues = new ArrayList<>();
			formInputValues.add(new FormInput("@RD_SA", String.valueOf(rider.getRiderSumAssuredAmount().getAmount().intValue())));
			formInputValues.add(new FormInput("@RD_EMR_RATE", rider.getRiderEmrRate()));
			if (ProductId.isGuaranteedFuturePlan(productId)) {
				formInputValues.add(new FormInput("@RD_PPT", rider.getRiderPPT()));
			}
			riderDetail.setFormInputs(formInputValues);
			riderDetail.setInputOptions(new ArrayList<>());
			riders.add(riderDetail);
		});

		return riders;
	}


	/**
	 * This method gets inputOptions
	 */
	@JsonGetter
	public List<InputOption> getInputOptions() {
		if(inputOptions != null) {
			return inputOptions;
		}
		inputOptions = pccr.getInputOptions();
		return inputOptions ;
	}


	/**
	 * This method gets inputPartialWithdrawal
	 */
	@JsonGetter
	public List<FormInput> getInputPartialWithdrawal() {
		if(inputPartialWithdrawal != null) {
			return inputPartialWithdrawal;
		}
		inputPartialWithdrawal = new ArrayList<>();
		return inputPartialWithdrawal;
	}

}
