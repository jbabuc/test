package com.pmli.ms.bo.customer.helper;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.Period;

import org.apache.commons.lang3.math.NumberUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.PaymentProps;
import com.pmli.util.java.Crypto;
import com.pmli.util.java.JUtil;
import com.pmli.util.model.Money;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;
import com.pmli.util.web.client.RestConsumer;

/**
 * <p>
 * This class consists of the helper methods which common most of the API.
 * </p>
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@Component
public class CommonHelper {

    @Autowired
    private RestConsumer restConsumer;

    @Autowired
    private CommonProps commonProps;

    @Autowired
    private PaymentProps paymentProps;

    /**
     * This method is to get the token
     * 
     * @return the String contains token
     */
    public String getToken() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-IBM-Client-Id", commonProps.getApiTokenXibmClientId());
        headers.set("X-IBM-Client-Secret", commonProps.getApiTokenXibmClientSecret());
        headers.set("mettype", commonProps.getApiTokenMettype());
        headers.set("subject", commonProps.getApiTokenSubject());
        String res = restConsumer.callClientGetEndPoint(commonProps.getApiTokenUrl(), headers);
        return Document.parse(res).getString("accessToken");
    }

    /**
     * This method is use to calculate Age base on DOB
     * 
     * @param  input the String contains DOB
     * @return       the Age
     */
    public static int getAge(String input) {
        LocalDate dob = LocalDate.parse(input);
        LocalDate curDate = LocalDate.now();
        return Period.between(dob, curDate).getYears();
    }

    /**
     * This method is use to generate the Lead ID base current date and Randomn number
     * 
     * @return the String contains the Lead ID
     */
    public String generateLeadId() {
        return JUtil.getCurrentDateTime(commonProps.getLeadIdGenerationFormat())
            .concat(JUtil.generateRandomNumber(commonProps.getLeadIdRandomDigits()));
    }

    /**
     * This method is use to create the proposal form link base on Lead Id
     * 
     * @param  leadId
     * @return        the String contains the URI
     */
    public String getPropposalFormLink(String leadId) {
        String encryptLead;
        try {
            encryptLead = Crypto.encryptAES(leadId, paymentProps.getPaymentSecretKey(), commonProps.getInitVector(),
                commonProps.getAlgorithmName(), commonProps.getProviderName());
            String encodeLead = URLEncoder.encode(encryptLead, "UTF-8");
            return paymentProps.getProposalFormLink() + encodeLead;
        } catch (Exception e) {
            throw new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.INTERNAL_SERVER_ERROR_109,
                commonProps.getInternalServerError(), commonProps.getInternalServerError());
        }
    }

    /**
     * This method is use to transform Money Object to String Amount
     * 
     * @param  m   the Money Obj
     * @param  def the default value
     * @return     the String contains Amount
     */
    public static String getStrFromMoneyOrDef(Money m, String def) {
        return m != null && m.getAmount() != null ? m.getAmount().setScale(2, RoundingMode.DOWN).toString() : def;
    }

    /**
     * This method is use to transform BigDecimal Amount to String Amount
     * 
     * @param  m
     * @param  def
     * @return     the String Amount
     */
    public static String getStrFromBigDecimalOrZero(BigDecimal m, String def) {
        return m != null ? m.setScale(2, RoundingMode.DOWN).toString() : def;
    }

    /**
     * This method is use to transform Money Object to String Amount with default value 0.00
     * 
     * @param  m
     * @return   the String Amount
     */
    public static String getStrFromMoneyOrZero(Money m) { return getStrFromMoneyOrDef(m, "0.00"); }

    /**
     * This method is use to transform Integer to String
     * 
     * @param  m
     * @return   the String Amount
     */
    public static String getStrFromIntOrDef(Integer i, String def) { return i != null ? "" + i.toString() : def; }

    /**
     * This method is use to transform Integer to String with default value 0
     * 
     * @param  m
     * @return   the String Amount
     */
    public static String getStrFromIntOrZero(Integer i) { return getStrFromIntOrDef(i, "0"); }

    /**
     * This method is use to transform String to int
     * 
     * @param  m
     * @return   the int
     */
    public static int parseIntOrDef(String sval, int def) {
        return NumberUtils.isParsable(sval) ? Integer.valueOf(sval) : def;
    }

    /**
     * This method is use to transform String to int with default value 0
     * 
     * @param  m
     * @return   the String Amount
     */
    public static int parseIntOrZero(String sval) { return parseIntOrDef(sval, 0); }

    /**
     * This method is use to transform String amount to Money Obj
     * 
     * @param  m
     * @return   the Money Obj
     */
    public static Money parseMoneyOrDef(String sval, double def) {
        return new Money((NumberUtils.isParsable(sval) ? new BigDecimal(sval) : BigDecimal.valueOf(def)).setScale(2,
            RoundingMode.DOWN));
    }

    /**
     * This method is use to transform String amount to Money Obj with default value Zero
     * 
     * @param  m
     * @return   the Money Obj
     */
    public static Money parseMoneyOrZero(String sval) { return parseMoneyOrDef(sval, 0); }

}
