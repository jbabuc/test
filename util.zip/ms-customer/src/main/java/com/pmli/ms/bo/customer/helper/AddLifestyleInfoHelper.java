package com.pmli.ms.bo.customer.helper;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest.ArmedServicesQuestionnaire;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest.LifeStyleDetail;
import com.pmli.util.java.MsObject;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.ListValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.Validator;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class AddLifestyleInfoHelper extends MsObject {
	DBClient dbClient;
	CommonProps commonProps;
	LifeStyleInfoRequest lifeStyleInfoRequest;

	public void validate(LifeStyleInfoRequest lifeStyleInfoRequest) {

		new Validator(lifeStyleInfoRequest, "Life Style Info Request", false).notNull();
		new Validator(lifeStyleInfoRequest.getLifeStyleInfo(), "Life Style Info", false).notNull();
		new Validator(lifeStyleInfoRequest.getLifeStyleInfo().getLifeStyleDetail(), "Life Style Detail", false)
				.notNull();

		LifeStyleDetail lsd = lifeStyleInfoRequest.getLifeStyleInfo().getLifeStyleDetail();

		new Validator(lsd.getFlyDetail(), "Life Style Fly Detail", false).notNull();
		if (lsd.getFlyDetail().isFly()) {
			new Validator(lsd.getFlyDetail().getDetail(), "Life Style Fly Detail Detail", false).notNull();
		}

		new Validator(lsd.getEngageInAutoMobile(), "Life Style EngageInAutoMobile", false).notNull();
		if (lsd.getEngageInAutoMobile().isEngageInAutoMobile()) {
			new StringValidator(lsd.getEngageInAutoMobile().getDetail(), "Life Style EngageInAutoMobile Detail", false)
					.notNull();
		}

		new Validator(lsd.getCriminalOffence(), "Life Style CriminalOffence", false).notNull();
		if (lsd.getCriminalOffence().isCriminalOffence()) {
			new Validator(lsd.getCriminalOffence().getDetail(), "Life Style CriminalOffence Detail", false).notNull();
		}

		new Validator(lsd.getExposedPersonPEP(), "Life Style ExposedPersonPEP", false).notNull();
		if (lsd.getExposedPersonPEP().isExposedPersonPEP()) {
			new Validator(lsd.getExposedPersonPEP().getDetail(), "Life Style ExposedPersonPEP Detail", false).notNull();
		}

		new Validator(lsd.getPayerOfTrustcharityNGO(), "Life Style PayerOfTrustcharityNGO", false).notNull();
		if (lsd.getPayerOfTrustcharityNGO().isPayerOfTrustCharityNGO()) {
			new Validator(lsd.getPayerOfTrustcharityNGO().getDetail(), "Life Style PayerOfTrustcharityNGO Detail",
					false).notNull();
		}

		new Validator(lsd.getMilitaryorPoliceForce(), "Life Style MilitaryorPoliceForce", false).notNull();
		new Validator(lsd.getMilitaryorPoliceForce().getArmedServicesQuestionnaire(),
				"Life Style MilitaryorPoliceForce ArmedServicesQuestionnaire", false).notNull();
		if (lsd.getMilitaryorPoliceForce().getArmedServicesQuestionnaire().isArmedServicesQuestionnaire()) {
			armedServicesQuestionnaire(lsd.getMilitaryorPoliceForce().getArmedServicesQuestionnaire());
		}

		new Validator(lsd.getMilitaryorPoliceForce().getEngagedBombDisposalDriving(),
				"Life Style MilitaryorPoliceForce EngagedBombDisposalDriving", false).notNull();
		if (lsd.getMilitaryorPoliceForce().getEngagedBombDisposalDriving().isEngagedBombDisposalDriving()) {
			new Validator(
					lsd.getMilitaryorPoliceForce().getEngagedBombDisposalDriving()
							.getEngagedinBombDisposalDrivingInfo(),
					"Life Style EngagedinBombDisposalDrivingInfo", false).notNull();
		}

		new Validator(lsd.getMilitaryorPoliceForce().getHazardeousActivity(),
				"Life Style MilitaryorPoliceForce HazardeousActivity", false).notNull();
		if (lsd.getMilitaryorPoliceForce().getHazardeousActivity().isHazardeousActivity()) {
			new Validator(lsd.getMilitaryorPoliceForce().getHazardeousActivity().getHazardeousActivityInfo(),
					"Life Style HazardeousActivityInfo", false).notNull();
		}

		new Validator(lsd.getMilitaryorPoliceForce().getCurrentlyServingIn(),
				"Life Style MilitaryorPoliceForce CurrentlyServingIn", false).notNull();
		if (lsd.getMilitaryorPoliceForce().getCurrentlyServingIn().isCurrentlyServingIn()) {
			new Validator(lsd.getMilitaryorPoliceForce().getCurrentlyServingIn().getTroubledAreasInfo(),
					"Life Style TroubledAreasInfo", false).notNull();
		}

		new Validator(lsd.getHazard(), "Life Style Hazards", false).notNull();
		if (lsd.getHazard().isHasCorrosiveChemicalsAndHTVDrivers()) {
			new Validator(lsd.getHazard().getDetail(), "Life Style HasCorrosiveChemicalsAndHTVDrivers Detail", false)
					.notNull();
		}

		new Validator(lifeStyleInfoRequest.getLifeStyleInfo().getInsuranceDetail(), "Insurance Detail", false)
				.notNull();
		if (lifeStyleInfoRequest.getLifeStyleInfo().getInsuranceDetail().isHasInsurancePolicies()) {
			new ListValidator(lifeStyleInfoRequest.getLifeStyleInfo().getInsuranceDetail().getInsurances(),
					"Insurances", false).validate(Validator::notNull).validate(ListValidator::isMinLength, 1);
		}

		new Validator(lifeStyleInfoRequest.getLifeStyleInfo().getFamilyDetail(), "Family Detail", false).notNull();
		if (lifeStyleInfoRequest.getLifeStyleInfo().getFamilyDetail().isFamilyMedicalStatus()) {
			new ListValidator(lifeStyleInfoRequest.getLifeStyleInfo().getFamilyDetail().getFamilyMembers(),
					"Family Members Detail", false).validate(Validator::notNull).validate(ListValidator::isMinLength,
							1);
		}

		new Validator(lifeStyleInfoRequest.getLifeStyleInfo().getEInsuranceAccountDetail(), "EInsuranceAccount Detail",
				false).notNull();
		if (lifeStyleInfoRequest.getLifeStyleInfo().getEInsuranceAccountDetail().isEInsurance()) {
			new StringValidator(lifeStyleInfoRequest.getLifeStyleInfo().getEInsuranceAccountDetail().getAccountNumber(), "EInsuranceAccount Number", false)
			.notNull();
		}
	}

	private void armedServicesQuestionnaire(ArmedServicesQuestionnaire a) {
		new Validator((a.getFullnameOfTheApplicant()), "Fullname Applicant", false).notNull();
		new ComparableValidator(a.getBranchOfArmedForces(), "Branch", false).greaterThan(-1);
		new ComparableValidator(a.getRank(), "Rank", false).greaterThan(-1);
		new Validator((a.getExactNatureOfDuty()), "Nature of Duty", false).notNull();
	}
	
	public String boolToStr(boolean isValue) {
		if(isValue) {
			return "1";
		}
		return "0";
	}
}
