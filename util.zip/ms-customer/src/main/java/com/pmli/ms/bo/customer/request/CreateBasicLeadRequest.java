package com.pmli.ms.bo.customer.request;

import java.util.List;

import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Email;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the request details of 'create-basic-lead-detail' API.
 * 
 * @author Hemant Solanki
 * @version 1.0.0
 */

@Data
@ApiModel(description = "This is the request bean for create-basic-lead-detail operation")
public class CreateBasicLeadRequest {

    @FieldMetaJson("{nullable:false,displayName: 'Name Detail',childDataValidations:[{childPath:'firstName',displayName:'firstName',nullable:false,validations:'notNullNotBlank'},{childPath:'lastName',displayName:'lastName',nullable:false,validations:'notNullNotBlank'}]}")
    private Name name;

    @FieldMetaJson("{nullable:false,displayName: 'PhoneNumber Detail' , validations:'notNull',listElementDataValidations:{childDataValidations:[{childPath:'number',displayName:'Phone Number',nullable:false,validations:'notNullNotBlank,matchesRegEx~$errmsg:Mobile number should be 10 digit (e.g. 9999999999).~^([0-9]{10})$'}]}}")
    private List<PhoneNumber> phones;

    @FieldMetaJson("{nullable:false,displayName: 'Email Detail' ,validations:'notNull',childDataValidations:[{childPath:'address',displayName:'Email Address',nullable:false,validations:'notNullNotBlank,isEmail'}]}")
    private Email email;

    @FieldMetaJson("{nullable:false,displayName: 'Address Detail' ,validations:'notNull',childDataValidations:[{childPath:'postalCode',displayName:'Address postalCode',nullable:false,validations:'notNullNotBlank'}]}")
    private Addres address;

    @ApiModelProperty(required = true, value = "suitabilityAnalysis", example = "true")
    @FieldMetaJson("{displayName:'$parent suitabilityAnalysis',nullable:false,validations:'notNull'}")
    private String suitabilityAnalysis;

    @ApiModelProperty(required = true, value = "authConsent", example = "true")
    @FieldMetaJson("{displayName:'$parent authConsent',nullable:false,validations:'notNull'}")
    private String authConsent;
    
    
    @Data
    @ApiModel(description = "This is the bean conatins the address details operation")
    public static class Addres {

        @ApiModelProperty(required = true, value = "Postal Code", example = "110017")
        private String postalCode;
    }
}
