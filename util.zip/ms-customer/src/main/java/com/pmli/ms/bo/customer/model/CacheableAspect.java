package com.pmli.ms.bo.customer.model;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.util.cache.MsCache;
import com.pmli.util.cache.MsCache.ExpireAtTime;
import com.pmli.util.cache.MsCache.GetOptions;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsRuntimeException;

@Aspect
@Component
public class CacheableAspect extends MsObject {
    @Value("${" + Constants.BASE_PATH + "prefix}")
    private String keyPrefix;

    @Autowired
    private MsCache cache;

    @Around("execution(* com.pmli.ms.bo.customer.model.DBClient..*(..)) && @annotation(com.pmli.util.cache.MsCache.CacheForADay)")
    public Object wrap(ProceedingJoinPoint pJoinPoint) throws Throwable {
        Method m = ((MethodSignature) pJoinPoint.getSignature()).getMethod();
        String key = keyPrefix + m.getDeclaringClass().getName() + "-" + m.getName() + "-"
            + Arrays.asList(pJoinPoint.getArgs()).stream().map(Object::toString).collect(Collectors.joining("-"));

        return cache.get(key, k -> {
            try {
                Object ret = pJoinPoint.proceed();
                log.info("Fetched, {} --> {}", k, ret);
                return ret;
            } catch (Throwable e) {
                throw MsRuntimeException.wrap(e);
            }
        }, ExpireAtTime.AT_DAY, GetOptions.DEFAULT);
    }
}