package com.pmli.ms.bo.customer.response;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import static java.util.Optional.of;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.model.LeadDetail.Payout;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.ms.bo.customer.request.CriticalInfoRequest.CriticalInfoDetails;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest.DocumentInfoDetails;
import com.pmli.ms.bo.customer.request.FamilyMember;
import com.pmli.ms.bo.customer.request.Fund;
import com.pmli.ms.bo.customer.request.FnaRequest.Fna;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest.LifeStyleInfo;
import com.pmli.ms.bo.customer.request.PaymentRequest.Payment;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest.PersonalInfo;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.java.JUtil;
import com.pmli.util.model.Address;
import com.pmli.util.model.Email;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LeadDetailResponse extends CustomerRequest {
    private String                   leadId;
    private PremiumCalculation       premiumCalculation;
    private List<PremiumCalculation> riders;
    private PersonalInfo             personalInfo;
    private DocumentInfoDetails      documentInfoDetails;
    private Payment                  payment;
    private Fna                      fna;
    private CriticalInfoDetails      criticalInfoDetails;
    private LifeStyleInfo            lifeStyleInfo;
    @JsonProperty("isActive")
    private boolean                  active;
    private String                   utmSource;
    private String                   utmMedium;
    private String                   utmCampaign;
    private int                      fosCode;
    private int                      fosCodeType;
    private String                   transactionId;
    private String                   planId;
    private Payout                   payout;
    @JsonProperty("isCRMIntegrationCompleted")
    private boolean                  crmIntegrationCompleted;
    private String                   createdOn;
    private List<Fund>               funds;

    public LeadDetailResponse(LeadDetail leadDetail, DBClient dbClient, CommonProps commonProps) {
        this.leadId = leadDetail.getLeadId();
        this.buyTypeCode = CommonHelper.parseIntOrDef(leadDetail.getBuyType(), 0);
        this.educationalQualification = CommonHelper.parseIntOrDef(leadDetail.getEducationalQualification(), 0);
        this.occupation = CommonHelper.parseIntOrDef(leadDetail.getOccupation(), 0);
		if (!Objects.isNull(leadDetail.getName())) {
			this.name = new Name(leadDetail.getTitle(), leadDetail.getFirstName(),
					of(leadDetail.getName().split(" ")).map(ns -> ns.length > 3 ? ns[2] : "").get(),
					leadDetail.getLastName());
			name.setTitle(dbClient.getMasterValueByTypeKey(commonProps.getMasterKeyDataTypeTitle(), name.getTitle()));
		}
        this.birthDate = leadDetail.getDateOfBirth();
        if (!Objects.isNull(leadDetail.getGender())) {
            this.gender = dbClient.getMasterValueByTypeKey(commonProps.getMasterKeyDataTypeGender(),
                leadDetail.getGender());
        }
        this.age = CommonHelper.parseIntOrDef(leadDetail.getAge(), 0);
        this.suitabilityAnalysis = CommonHelper.parseIntOrDef(leadDetail.getSuitabilityAnalysis(), 0);
        this.quotationId = leadDetail.getQuotationId();
        this.proposalNumber = leadDetail.getProposalNumber();
        this.step = CommonHelper.parseIntOrDef(leadDetail.getStep(), 0);
        this.applicationNumber = leadDetail.getApplicationNumber();
        this.address = new Address("", "", "", "", "", leadDetail.getCity(), "", leadDetail.getDistrict(),
            leadDetail.getPinNo(), leadDetail.getState(), leadDetail.getCountry());
        ofNullable(leadDetail.getLovedOne())
            .ifPresent(fm -> this.familyMember = new FamilyMember(leadDetail.getLovedOne()));
        if (!Objects.isNull(familyMember)) {
            if (!Objects.isNull(familyMember.getName().getTitle())) {
                familyMember.getName().setTitle(dbClient.getMasterValueByTypeKey(
                    commonProps.getMasterKeyDataTypeTitle(), familyMember.getName().getTitle()));
            }
            if (!Objects.isNull(familyMember.getGender())) {
                familyMember.setGender(dbClient.getMasterValueByTypeKey(commonProps.getMasterKeyDataTypeGender(),
                    familyMember.getGender()));
            }
        }
        ofNullable(leadDetail.getEmailId()).ifPresent(e -> this.email = new Email(leadDetail.getEmailId(), "", true));
        ofNullable(leadDetail.getAnnualIncome()).ifPresent(ai -> this.annualIncomeAmount = new Money(
            new BigDecimal(leadDetail.getAnnualIncome() != null ? leadDetail.getAnnualIncome() : "0")));
        List<PhoneNumber> phoneList = new ArrayList<>();
        PhoneNumber phNum = new PhoneNumber();
        phNum.setNumber(leadDetail.getMobileNumber());
        phoneList.add(phNum);
        this.phoneNumbers = phoneList;
        ofNullable(leadDetail.getPremiumCalculation())
            .ifPresent(p -> this.premiumCalculation = new PremiumCalculation(p));
        ofNullable(leadDetail.getRiders())
            .ifPresent(r -> this.riders = r.stream().map(PremiumCalculation::new).collect(Collectors.toList()));
        ofNullable(leadDetail.getPersonalInfo()).ifPresent(pi -> this.personalInfo = new PersonalInfo(pi));
        ofNullable(leadDetail.getDocumentInfoDetails())
            .ifPresent(di -> this.documentInfoDetails = new DocumentInfoDetails(di));
        ofNullable(leadDetail.getPayment()).ifPresent(p -> this.payment = new Payment(p));
        fna = new Fna(leadDetail.getFna());
        ofNullable(leadDetail.getCriticalInfoDetails())
            .ifPresent(c -> this.criticalInfoDetails = new CriticalInfoDetails(c));
        ofNullable(leadDetail.getLifeStyleInfo()).ifPresent(l -> this.lifeStyleInfo = new LifeStyleInfo(l));
        this.active = leadDetail.isActive();
        this.utmSource = leadDetail.getUtmSource();
        this.utmMedium = leadDetail.getUtmMedium();
        this.utmCampaign = leadDetail.getUtmCampaign();
        ofNullable(leadDetail.getFosCode()).ifPresent(fcode -> this.fosCode = CommonHelper.parseIntOrDef(fcode, 0));
        ofNullable(leadDetail.getFosCodeType())
            .ifPresent(fcodeType -> this.fosCodeType = CommonHelper.parseIntOrDef(fcodeType, 0));
        this.payout = leadDetail.getPayout();
        this.transactionId = leadDetail.getTransactionId();
        this.planId = leadDetail.getPlanId();
        this.crmIntegrationCompleted = leadDetail.isCrmIntegrationCompleted();
        ofNullable(leadDetail.getCreatedOn()).ifPresent(pd -> this.createdOn = JUtil
            .getFormattedDateTime(leadDetail.getCreatedOn(), IsoDateDeSerializer.MONGO_DATE_FORMAT));
        this.funds = leadDetail.getFunds();
    }
}
