package com.pmli.ms.bo.customer.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the response details for add payment API
 * 
 * @author Hemant Solanki
 * @version 1.0.0
 */
@Data
@ApiModel(description = "This is the response bean for Add-Payment operation")
public class PaymentResponse {
	@ApiModelProperty(required = true, value = "Message", example = "Payment details have been saved successfully")
	private String message;
	@ApiModelProperty(required = true, value = "Proposal Form Link", example = "https://uat-ebranchnxt.pnbmetlife.com/buy-online/Pre-Payment/#/trackapplication/navigation?leadid=XPGX6OU1+jYTsz5hApXR5Q6IXThHn+POEQ1GhfQxxA8=")
	private String proposalFormLink;

}
