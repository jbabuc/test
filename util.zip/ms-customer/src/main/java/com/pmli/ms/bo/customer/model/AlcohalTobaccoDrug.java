package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class AlcohalTobaccoDrug {
    private String substanceConsumed;
    private String substanceConsumedType;
    private String perday;
    private String sinceMonth;
    private String inMlPerWeek;
    private String inpintWeek;
    private String inGMPerWeek;
}
