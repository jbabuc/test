package com.pmli.ms.bo.customer.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.java.JUtil;
import com.pmli.util.model.Email;
import com.pmli.util.model.Name;
import com.pmli.util.model.PhoneNumber;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class holds the response details for get Application api
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@Data
@NoArgsConstructor
public class GetApplicationResponse {

    private List<ApplicationDetails> applications = new ArrayList<>();

    public GetApplicationResponse(List<LeadDetail> ldList) {
        ldList.forEach(ld -> applications.add(new ApplicationDetails(ld)));
    }

    @Data
    public static class ApplicationDetails {

        @ApiModelProperty(required = true, value = "Quotation Id", example = "80000188889")
        private String            quotationId;
        @ApiModelProperty(required = true, value = "Lead Id", example = "637532985051789166")
        private String            leadId;
        @ApiModelProperty(required = true, value = "Last Updated On", example = "2020-08-17T16:39:57+05:30")
        private String            lastUpdateDate;
        @ApiModelProperty(required = true, value = "Is Active", example = "true")
        @JsonProperty("isActive")
        private boolean           isActive;
        private Name              name;
        @ApiModelProperty(required = true, value = "Product Name", example = "PNB MetLife Guaranteed Future Plan")
        private String            productName;
        @ApiModelProperty(required = true, value = "Product Id", example = "12020")
        private int               productId;
        @ApiModelProperty(required = true, value = "Plan Id", example = "1")
        private int               planId;
        @ApiModelProperty(required = true, value = "Plan Name", example = "Endowment")
        private String            planName;
        @ApiModelProperty(required = true, value = "Step", example = "6")
        private int               step;
        @ApiModelProperty(required = true, value = "Application Number", example = "150047240")
        private String            applicationNumber;
        private Email             email;
        private List<PhoneNumber> phoneNumbers = new ArrayList<>();

        public ApplicationDetails(LeadDetail ld) {
            quotationId = ld.getQuotationId();
            leadId = ld.getLeadId();
            lastUpdateDate = ld.getLastUpdatedOn() != null
                ? JUtil.getFormattedDateTime(ld.getLastUpdatedOn(), IsoDateDeSerializer.MONGO_DATE_FORMAT)
                : null;
            isActive = ld.isActive();

            name = new Name();
            String[] nameArr = ld.getName().split(" ");
            name.setTitle(nameArr[0]);
            name.setMiddleName(nameArr[2]);
            name.setFirstName(ld.getFirstName());
            name.setLastName(ld.getLastName());

            productName = ld.getPremiumCalculation().getProductName();
            productId = ld.getPremiumCalculation().getProductId();
            planId = ld.getPremiumCalculation().getPlanId();
            planName = ld.getPremiumCalculation().getPlanName();

            step = Integer.parseInt(ld.getStep());
            applicationNumber = ld.getApplicationNumber();

            email = new Email();
            email.setAddress(ld.getEmailId());

            PhoneNumber phNum = new PhoneNumber();
            phNum.setCountryCode(ld.getCountry());
            phNum.setNumber(ld.getMobileNumber());
            phoneNumbers.add(phNum);
        }
    }
}
