package com.pmli.ms.bo.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class CommonProps {

    @Value("${" + Constants.ERROR_MSG_INTERNAL_SERVER_ERROR + "}")
    private String internalServerError;

    @Value("${" + Constants.AES_ALGORTHIM + "}")
    private String algorithmName;

    @Value("${" + Constants.AES_PROVIDER + "}")
    private String providerName;

    @Value("${" + Constants.AES_INIT_VECTOR + "}")
    private String initVector;

    @Value("${" + Constants.BASE_PATH + "db.tag.mobileNum}")
    private String dbTagMobileNum;

    @Value("${" + Constants.BASE_PATH + "sms.uri}")
    private String smsURI;

    @Value("${" + Constants.BASE_PATH + "sms.flag}")
    private String smsFlag;

    @Value("${spring.application.name}")
    private String msCustomer;

    @Value("${" + Constants.BASE_PATH + "send.email.fromEmail}")
    private String fromEmail;

    @Value("${" + Constants.BASE_PATH + "send.email.uri}")
    private String emailURI;

    @Value("${" + Constants.BASE_PATH + "db.tag.emailId}")
    private String dbTagEmailId;

    @Value("${" + Constants.BASE_PATH + "emailReq}")
    private String emailReq;

    @Value("${" + Constants.DATE_FORMAT + "}")
    private String dateFromat;

    @Value("${" + Constants.EMAIL + "templateId}")
    private String templateId;

    @Value("${" + Constants.EMAIL + "emlReq}")
    private String emlReq;

    @Value("${" + Constants.EMAIL + "loginId}")
    private String loginId;

    @Value("${" + Constants.EMAIL + "loginType}")
    private String loginType;

    @Value("${" + Constants.EMAIL + "clientId}")
    private String clientId;

    @Value("${" + Constants.EMAIL + "communicationContext}")
    private String communicationContext;

    @Value("${" + Constants.EMAIL + "referenceId}")
    private String referenceId;

    @Value("${" + Constants.EMAIL + "attachments}")
    private String attachments;

    @Value("${" + Constants.EMAIL + "base64Content}")
    private String base64Content;

    @Value("${" + Constants.LEAD_ID_GENERATION_FORMAT + "}")
    private String leadId;

    @Value("${" + Constants.BASE_PATH + "fna.success" + "}")
    private String fnaSuccess;

    @Value("${" + Constants.BASE_PATH + "db.tag.productName}")
    private String dbTagProductName;

    @Value("${" + Constants.BASE_PATH + "db.tag.planId}")
    private String dbTagPlanId;

    @Value("${" + Constants.BASE_PATH + "db.tag.appNum}")
    private String dbTagAppNum;

    @Value("${" + Constants.BASE_PATH + "db.tag.name}")
    private String dbTagName;

    @Value("${" + Constants.BASE_PATH + "db.tag.premCalc}")
    private String dbTagpremCalc;

    @Value("${" + Constants.BASE_PATH + "place.holder.productName}")
    private String productName;

    @Value("${" + Constants.BASE_PATH + "place.holder.planCode}")
    private String planCode;

    @Value("${" + Constants.BASE_PATH + "place.holder.appNum}")
    private String appNo;

    @Value("${" + Constants.BASE_PATH + "place.holder.custName}")
    private String customerName;

    @Value("${" + Constants.BASE_PATH + "add.customer.success" + "}")
    private String addCustomerSuccess;

    @Value("${" + Constants.BASE_PATH + "lead.not.found}")
    private String leadNotFound;

    @Value("${" + Constants.BASE_PATH + "email.url.path}")
    private String emailUrlPath;

    @Value("${" + Constants.BASE_PATH + "add.step.success" + "}")
    private String msgAddStepSuccess;

    @Value("${" + Constants.BASE_PATH + "add.achadm.success" + "}")
    private String msgAddACHADMSuccess;

    @Value("${" + Constants.BASE_PATH + "get.application.error.msg.no.record.found" + "}")
    private String noRecordFoundMobile;

    @Value("${" + Constants.BASE_PATH + "get.application.only.10.digits" + "}")
    private String errMsgShouldBe10DigitOnly;

    @Value("${" + Constants.BASE_PATH + "add.personal.info.success" + "}")
    private String msgPersonalInfoSuccess;

    @Value("${" + Constants.BASE_PATH + "add.critical.info.success" + "}")
    private String msgCriticalInfoSuccess;

    @Value("${" + Constants.BASE_PATH + "hystrix.error.info" + "}")
    private String hystrixErrorInfo;

    @Value("${" + Constants.BASE_PATH + "hystrix.error.msg" + "}")
    private String hystrixErrorMessage;

    @Value("${" + Constants.BASE_PATH + "leadId.generation.format" + "}")
    private String leadIdGenerationFormat;

    ///// VALIDATION

    @Value("${" + Constants.VALIDATIONS + "name" + "}")
    private String nameValidations;

    @Value("${" + Constants.VALIDATIONS + "email" + "}")
    private String emailValidations;

    @Value("${" + Constants.VALIDATIONS + "address" + "}")
    private String addressValidations;

    @Value("${" + Constants.VALIDATIONS + "phoneNumber" + "}")
    private String phoneNumberValidations;

    @Value("${" + Constants.VALIDATIONS + "date" + "}")
    private String dateCheckValidations;

    @Value("${" + Constants.VALIDATIONS + "child.date" + "}")
    private String childDateCheckValidations;

    @Value("${" + Constants.VALIDATIONS + "gender" + "}")
    private String genderValidations;

    @Value("${" + Constants.VALIDATIONS + "aadhar" + "}")
    private String aadharCheckValidations;

    @Value("${" + Constants.VALIDATIONS + "pan" + "}")
    private String panCheckValidations;

    @Value("${" + Constants.BASE_PATH + "add.lifestyle.success" + "}")
    private String addLifetstyleSuccess;

    @Value("${" + Constants.BASE_PATH + "url" + "}")
    private String nVestUrl;

    @Value("${" + Constants.BASE_PATH + "donwload.bi.url" + "}")
    private String downloadBiUrl;

    @Value("${" + Constants.BASE_PATH + "error.msg.invalid.lead.id" + "}")
    private String errMsgInvalidLeadId;

    @Value("${" + Constants.BASE_PATH + "error.msg.data.not.found" + "}")
    private String errMsgDataNotFound;

    @Value("${" + Constants.BASE_PATH + "get.token.api.url" + "}")
    private String apiTokenUrl;

    @Value("${" + Constants.BASE_PATH + "get.token.api.x-ibm-client-id}")
    private String apiTokenXibmClientId;

    @Value("${" + Constants.BASE_PATH + "get.token.api.x-ibm-client-secret}")
    private String apiTokenXibmClientSecret;

    @Value("${" + Constants.BASE_PATH + "get.token.api.mettype}")
    private String apiTokenMettype;

    @Value("${" + Constants.BASE_PATH + "get.token.api.subject}")
    private String apiTokenSubject;

    @Value("${" + Constants.BASE_PATH + "error.msg.record.not.found}")
    private String errorMsgRecordNotFound;

    @Value("${" + Constants.BASE_PATH + "add.document.info.success" + "}")
    private String addDocumentInfoSuccess;

    @Value("${" + Constants.BASE_PATH + "mergepdf.filestorage.url" + "}")
    private String fileStorageUploadUrl;

    @Value("${" + Constants.BASE_PATH + "validate.otpValidate.url" + "}")
    private String otpValidateUrl;

    @Value("${" + Constants.BASE_PATH + "update.popi.success" + "}")
    private String updatePOPISuccess;

    @Value("${" + Constants.BASE_PATH + "generateotp.url" + "}")
    private String generateOtpUrl;

    @Value("${" + Constants.BASE_PATH + "generateotp.templateid" + "}")
    private String otpTemplateId;

    @Value("${" + Constants.BASE_PATH + "leadId.random.digits" + "}")
    private int leadIdRandomDigits;
    
    @Value("${" + Constants.BASE_PATH + "master.key.data.type.title" + "}")
    private String masterKeyDataTypeTitle;
    
    @Value("${" + Constants.BASE_PATH + "master.key.data.type.gender" + "}")
    private String masterKeyDataTypeGender;
    
    @Value("${" + Constants.BASE_PATH + "get.lead.list.error.msg.detail}")
	private String errorMsgDetail;

	@Value("${" + Constants.BASE_PATH + "get.lead.list.error.msg.data.not.found}")
	private String errorMsgDataNotFound;
	
	@Value("${" + Constants.BASE_PATH + "get.lead.list.key.mobileNumber}")
	private String keyMobileNumber;
	
}
