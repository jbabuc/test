package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.bson.IsoDateSerializer;
import com.pmli.util.java.JUtil;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class holds the payment details to save in MongoDB.
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@Data
@NoArgsConstructor
public class LeadDetailPayment {

    Payment payment;

    public LeadDetailPayment(PaymentRequest requestPayload) throws ParseException {
        if (requestPayload == null) return;

        payment = new Payment(requestPayload.getPayment());
    }

    @Data
    @NoArgsConstructor
    public static class Payment {

        private String  creditCardType;
        private String  totalAmount;
        @JsonSerialize(using = IsoDateSerializer.class)
        @JsonDeserialize(using = IsoDateDeSerializer.class)
        private Date    paymentDate;
        private String  responseMessage;
        private boolean statusCode;

        @JsonProperty("payment")
        private PaymentMoreInfo paymentMoreInfo;
        private Enach           enachResponse;

        public Payment(PaymentRequest.Payment payment) throws ParseException {
            if (payment == null) return;

            creditCardType = payment.getCreditCardType();
            ofNullable(payment.getTotalAmount())
                .ifPresent(a -> totalAmount = a.getAmount().setScale(2, BigDecimal.ROUND_UP).toString());
            paymentDate = JUtil.getDate(IsoDateDeSerializer.MONGO_DATE_FORMAT, payment.getPaymentDateTime());
            statusCode = Boolean.valueOf(payment.getStatusCode());
            responseMessage = payment.getResponseMessage();
            paymentMoreInfo = new PaymentMoreInfo(payment);
            enachResponse = new Enach(payment.getEnachResponse());
        }
    }

    @Data
    @NoArgsConstructor
    public static class PaymentMoreInfo {
        private String merchantID;
        private String customerID;
        private String txnReferenceNo;
        private String bankReferenceNo;

        private String txnAmount;
        private String currencyName;

        private String bankID;
        private String bankMerchantID;

        private String txnType;
        @JsonSerialize(using = IsoDateSerializer.class)
        @JsonDeserialize(using = IsoDateDeSerializer.class)
        private Date   txnDate;

        private String itemCode;

        private String securityType;
        private String securityID;
        private String securityPassword;

        private String authStatus;
        private String settlementType;

        private String errorStatus;
        private String errorDescription;
        private String checkSum;

        private String additionalInfo1;
        private String additionalInfo2;
        private String additionalInfo3;
        private String additionalInfo4;
        private String additionalInfo5;
        private String additionalInfo6;
        private String additionalInfo7;

        public PaymentMoreInfo(PaymentRequest.Payment payment) throws ParseException {
            if (payment == null) return;

            merchantID = payment.getMerchantId();
            customerID = payment.getCustomerId();
            txnReferenceNo = payment.getTransactionReferenceNumber();
            bankReferenceNo = payment.getBankReferenceNumber();
            ofNullable(payment.getTransactionAmount()).ifPresent(a -> {
                txnAmount = a.getAmount().setScale(2, BigDecimal.ROUND_UP).toString();
                currencyName = a.getCurrencyCode();
            });

            ofNullable(payment.getBank()).ifPresent(b -> {
                bankID = b.getBankId();
                bankMerchantID = b.getBankMerchantId();
            });
            txnType = payment.getTransactionType();
            txnDate = JUtil.getDate(IsoDateDeSerializer.MONGO_DATE_FORMAT, payment.getTransactionDateTime());
            itemCode = payment.getItemCode();
            ofNullable(payment.getSecurity()).ifPresent(s -> {
                securityType = s.getSecurityType();
                securityID = s.getSecurityID();
                securityPassword = s.getSecurityPassword();
            });
            authStatus = payment.getAuthStatus();
            settlementType = payment.getSettlementType();

            ofNullable(payment.getError()).ifPresent(e -> {
                errorStatus = e.getErrorStatus();
                errorDescription = e.getErrorDescription();
            });

            checkSum = payment.getCheckSum();

            additionalInfo1 = payment.getAdditionalInformation1();
            additionalInfo2 = payment.getAdditionalInformation2();
            additionalInfo3 = payment.getAdditionalInformation3();
            additionalInfo4 = payment.getAdditionalInformation4();
            additionalInfo5 = payment.getAdditionalInformation5();
            additionalInfo6 = payment.getAdditionalInformation6();
            additionalInfo7 = payment.getAdditionalInformation7();
        }
    }

    @Data
    @NoArgsConstructor
    public static class Enach {
        private String merchantId;
        private String customerId;
        private String txnReferenceNo;
        private String bankReferenceNo;
        private String txnAmount;

        private String siAmount;
        private String currencyType;

        private String accountType;
        private String accountNumber;
        private String bankName;
        private String bankId;
        private String accountHolderName;

        private String txnDate;
        private String authStatus;
        private String umrn;
        private String policyNo;
        private String applicationNumber;

        private String errorStatus;
        private String errorDescription;

        private String checksum;
        private String itemCode;

        private String additionalInfo3;
        private String additionalInfo4;
        private String additionalInfo5;
        private String additionalInfo6;
        private String additionalInfo7;

        public Enach(PaymentRequest.EnachRequest enachRequest) {
            if (enachRequest == null) return;

            merchantId = enachRequest.getMerchantId();
            customerId = enachRequest.getCustomerId();
            txnReferenceNo = enachRequest.getTransactionReferenceNumber();
            bankReferenceNo = enachRequest.getBankReferenceNumber();
            txnAmount = ofNullable(enachRequest.getTransactionAmount()).map(a -> a.getAmount().toString()).orElse(null);

            ofNullable(enachRequest.getSumInsuredAmount()).ifPresent(a -> {
                siAmount = a.getAmount().toString();
                currencyType = a.getCurrencyCode();
            });

            ofNullable(enachRequest.getBank()).ifPresent(b -> {
                accountType = b.getAccountType();
                accountNumber = b.getAccountNumber();
                bankName = b.getBankName();
                bankId = b.getBankId();
                ofNullable(b.getAccountHolderName())
                    .map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
                    .ifPresent(nl -> accountHolderName = nl.stream().collect(Collectors.joining(" ")));
            });

            txnDate = enachRequest.getTransactionDateTime();
            authStatus = enachRequest.getAuthStatus();
            umrn = enachRequest.getUniqueMemberNumber();
            policyNo = enachRequest.getPolicyNumber();
            applicationNumber = enachRequest.getApplicationNumber();

            ofNullable(enachRequest.getError()).ifPresent(e -> {
                errorStatus = e.getErrorStatus();
                errorDescription = e.getErrorDescription();
            });

            checksum = enachRequest.getChecksum();
            itemCode = enachRequest.getItemCode();

            additionalInfo3 = enachRequest.getAdditionalInformation3();
            additionalInfo4 = enachRequest.getAdditionalInformation4();
            additionalInfo5 = enachRequest.getAdditionalInformation5();
            additionalInfo6 = enachRequest.getAdditionalInformation6();
            additionalInfo7 = enachRequest.getAdditionalInformation7();
        }
    }
}
