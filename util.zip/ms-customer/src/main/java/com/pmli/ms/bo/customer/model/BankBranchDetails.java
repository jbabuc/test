package com.pmli.ms.bo.customer.model;

import java.util.List;

import lombok.Data;

@Data
public class BankBranchDetails {

	private String solid;
	private String bank;
    private List<BranchDetail> branchDetails;
}
