/**
 * 
 */
package com.pmli.ms.bo.customer.helper;

import static java.util.Optional.ofNullable;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.FamilyMember;
import com.pmli.ms.bo.customer.request.AddPOPIRequest;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.validation.DataValidations;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.validation.Validator;

import lombok.AllArgsConstructor;

/**
 * @author 3483784san
 * @since  25 August 2021
 */
@AllArgsConstructor
public class AddPOPIHelper {

    private AddPOPIRequest request;
    private DBClient          dbClient;
    private CommonProps       commonProps;

    public void validate() {
        new Validator(request, "PO PI Request", false).notNull();
        if (!request.isBuyForSelf()) {
            FamilyMember family = request.getFamilyMember();
            new Validator(family, "Family Member", false).notNull();
            new Validator(family.getName(), "Family Member Name Details", false).notNull();
            validateWithMetaJson(family.getName(), this.commonProps.getNameValidations());
            validateWithMetaJson(family.getBirthDate(), this.commonProps.getDateCheckValidations());
            validateWithMetaJson(family.getGender(), this.commonProps.getGenderValidations());
        }
    }

    public LeadDetail preparedData(LeadDetail lead) {
    	lead.setBuyType(request.isBuyForSelf() ? "1" : "2");
        if (!request.isBuyForSelf()) {
            lead.setLovedOne(new LeadDetail.LovedOne(request.getFamilyMember()));
            lead.getLovedOne().setTitle(dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeTitle(),
                request.getFamilyMember().getName().getTitle()));
            lead.getLovedOne().setGender(dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeGender(),
                lead.getLovedOne().getGender()));
        }
        lead.setTitle(
            dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeTitle(), request.getName().getTitle()));
        lead.setDateOfBirth(request.getBirthDate());
        lead.setGender(dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeGender(), request.getGender()));
        ofNullable(request.getName()).map(n -> Arrays.asList(n.getFirstName(), n.getMiddleName(), n.getLastName()))
            .ifPresent(nl -> lead
                .setName(nl.stream().filter(StringUtils::isNotEmpty).collect(Collectors.joining(" ")).trim()));
        lead.setFirstName(request.getName().getFirstName());
        lead.setLastName(request.getName().getLastName());
        lead.setAge("" + CommonHelper.getAge(request.getBirthDate()));
        return lead;
    }

    private void validateWithMetaJson(Object object, String json) {
        new ValidationHelper(object, JsonUtil.readValue(json, DataValidations.class)).validateWithMetaJson();
    }
}
