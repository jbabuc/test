package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;

import java.util.List;
import java.util.stream.Collectors;

import com.pmli.ms.bo.customer.request.CriticalInfoRequest;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class CriticalInfoDetail {

	private List<CriticalInfoDiseaseDetail> criticalInfoDiseaseDetails;
	private HeightWeightDetail heightWeightDetails;
	private BankDetail bankDetail;
	private BankDetail bankDetailJointLife;
	
	public CriticalInfoDetail(CriticalInfoRequest.CriticalInfoDetails criticalInfoDetail) {
		this.bankDetail = criticalInfoDetail.getBankDetail();
		this.bankDetailJointLife = criticalInfoDetail.getBankDetailJointLife();
		ofNullable(criticalInfoDetail.getHeightWeightDetails())
				.ifPresent(heig -> this.heightWeightDetails = new HeightWeightDetail(heig));
		ofNullable(criticalInfoDetail.getCriticalInfoDiseaseDetails())
				.ifPresent(c -> this.criticalInfoDiseaseDetails = c.stream().map(CriticalInfoDiseaseDetail::new)
						.collect(Collectors.toList()));
	}

	@Data
	@NoArgsConstructor
	public static class CriticalInfoDiseaseDetail {

		private int value;
		private String specifyDetails;
		private List<Detail> details;
		private PregnantDetail pregnantDetails;
		private List<AlcohalDetail> alcohalDetails;
		private CovidDetails covidDetails;
		private int key;
		private String name;
	
		public CriticalInfoDiseaseDetail(CriticalInfoRequest.CriticalInfoDiseaseDetail criticalInfoDiseaseDetail) {
			this.value = criticalInfoDiseaseDetail.getValue();
			this.specifyDetails = criticalInfoDiseaseDetail.getSpecifyDetails();
			this.key = criticalInfoDiseaseDetail.getKey();
			this.name = criticalInfoDiseaseDetail.getName();
			ofNullable(criticalInfoDiseaseDetail.getPregnantDetails())
					.ifPresent(preg -> this.pregnantDetails = new PregnantDetail(preg));
			ofNullable(criticalInfoDiseaseDetail.getCovidDetails())
					.ifPresent(covid -> this.covidDetails = new CovidDetails(covid));
			ofNullable(criticalInfoDiseaseDetail.getAlcoholDetails()).ifPresent(
					a -> this.alcohalDetails = a.stream().map(AlcohalDetail::new).collect(Collectors.toList()));
			ofNullable(criticalInfoDiseaseDetail.getDetails())
					.ifPresent(d -> this.details = d.stream().map(Detail::new).collect(Collectors.toList()));
		}
	}

	@Data
	@NoArgsConstructor
	public static class Detail {
		private String key;
		private String details;
	
		public Detail(CriticalInfoRequest.Details detail) {
			this.key = detail.getKey();
			this.details = detail.getValue();
		}
	}

	@Data
	@NoArgsConstructor
	public static class HeightWeightDetail {
		private String heightInFeet;
		private String heightInInch;
		private String weight;
	
		public HeightWeightDetail(CriticalInfoRequest.HeightWeightDetail heightWeightDetail) {
			this.heightInFeet = String.valueOf(heightWeightDetail.getHeightInFeet());
			this.heightInInch = String.valueOf(heightWeightDetail.getHeightInInch());
			this.weight = String.valueOf(heightWeightDetail.getWeight());
		}
	}

	@Data
	@NoArgsConstructor
	public static class AlcohalDetail {

		private String substanceConsumed;
		private String substanceConsumedType;
		private String perday;
		private String sinceMonth;
		private String inMlPerWeek;
		private String inpintWeek;
		private String inGMPerWeek;
	
		public AlcohalDetail(CriticalInfoRequest.AlcoholDetail alcoholDetail) {
			this.substanceConsumed = alcoholDetail.getSubstanceConsumed() + "";
			this.substanceConsumedType = alcoholDetail.getSubstanceConsumedType() + "";
			this.perday = alcoholDetail.getPerday() + "";
			this.sinceMonth = alcoholDetail.getSinceMonth() + "";
			this.inMlPerWeek = alcoholDetail.getInMlPerWeek() + "";
			this.inpintWeek = alcoholDetail.getInpintWeek() + "";
			this.inGMPerWeek = alcoholDetail.getInGMPerWeek() + "";
		}
	}

	@Data
	@NoArgsConstructor
	public static class PregnantDetail {
		private String currentPregnancyMonth;
		private String pregnancyComplicationDetails;
		private String pregnancyComplications;
	
		public PregnantDetail(CriticalInfoRequest.PregnantDetail pregnantDetail) {
			this.currentPregnancyMonth = pregnantDetail.getCurrentPregnancyMonth() + "";
			this.pregnancyComplicationDetails = pregnantDetail.getPregnancyComplicationDetails();
			this.pregnancyComplications = pregnantDetail.getPregnancyComplications();
		}
	}

	@Data
	@NoArgsConstructor
	public static class CovidDetails {
		private String countryVisited;
		private String durationFrom;
		private String durationTo;
	
		public CovidDetails(CriticalInfoRequest.CovidDetails covidDetail) {
			this.countryVisited = covidDetail.getCountryVisited();
			this.durationFrom = covidDetail.getDurationFrom();
			this.durationTo = covidDetail.getDurationTo();
		}
	}
	
	@Data
	@NoArgsConstructor
	public static class BankDetail {
		private String bankName;
		private String ifscCode;
		private String micrCode;
		private String accountNumber;
		private String accountType;
		private String bankProof;
	}
}
