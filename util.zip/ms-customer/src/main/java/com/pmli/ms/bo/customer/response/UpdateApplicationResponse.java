package com.pmli.ms.bo.customer.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateApplicationResponse {
	private String leadId;
	private String applicationNumber;
	private String message; 

}
