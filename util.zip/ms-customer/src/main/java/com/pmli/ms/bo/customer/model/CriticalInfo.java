package com.pmli.ms.bo.customer.model;

import java.util.List;

import lombok.Data;

@Data
public class CriticalInfo {
    private List<CriticalInfoDiseaseDetails> criticalInfoDiseaseDetails;
    private HeightWeightDetails heightWeightDetails;
    private BankModel bankDetail;
    private BankModel bankDetailJointLife;
}
