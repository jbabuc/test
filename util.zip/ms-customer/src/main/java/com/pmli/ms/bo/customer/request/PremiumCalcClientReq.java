package com.pmli.ms.bo.customer.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.request.PremiumCalcNvestRequest.Fund;
import com.pmli.ms.bo.customer.request.PremiumCalcNvestRequest.InputOption;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Money;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * This class holds the Premium Calculation request details
 * 
 * @author suvarna bambarse
 *
 */
@Data
public class PremiumCalcClientReq {

	@Data
	public static class Rider {
		@ApiModelProperty(required=true, value="Rider Id", example="13001")
		private int riderId;
		
		@ApiModelProperty(required=true, value="Rider Name", example="PNB MetLife Accidental Death Benefit Rider Plus")
		private String riderName;
		
		@ApiModelProperty(required=true, value="Rider Emr Rate", example="0")
		private String riderEmrRate;
		
		@ApiModelProperty(required=true, value="Rider PPT", example="10")
		private String riderPPT;
		
		@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'sum Assured Amount',validations:'greaterThan~-1'}]}")
		private Money riderSumAssuredAmount;
	}

	@Data
	public static class Employee {
		@ApiModelProperty(required = true, value = "Employee Id", example = "123")
		private String employeeId;
		
		@ApiModelProperty(required = true, value = "Is Employee", example = "false")
		@JsonProperty("isEmployee")
		private boolean isEmployee;
	}

	@ApiModelProperty(required = true, value = "Product Name", example = "PNB MetLife Super Saver Plan")
	@FieldMetaJson("{displayName:'Product Name', nullable:false, validations:'notBlank'}")
	private String product;
	
	@ApiModelProperty(required = true, value = "Age", example = "31")
	@FieldMetaJson("{displayName:'Age', nullable:false, validations:'notBlank'}")
	private String age;
	
	@FieldMetaJson("{nullable:false,childDataValidations:[{childPath:'firstName',displayName:'firstName',validations:'notBlank,notNull'},{childPath:'lastName',displayName:'lastName',validations:'notBlank,notNull'}]}")
	private Name name;
	
	@ApiModelProperty(required = true, value = "Birth Date", example = "1983-09-30")
	@FieldMetaJson("{displayName:'Birth Date', nullable:false, validations:'notBlank,isDate~yyyy-MM-dd~false'}")
	private String birthDate;
	
	@ApiModelProperty(required = true, value = "Cover", example = "10")
	@FieldMetaJson("{displayName:'Cover', nullable:false, validations:'notBlank'}")
	private String cover;
	
	@ApiModelProperty(required = true, value = "Payment Term", example = "5")
	@FieldMetaJson("{displayName:'Payment Term', nullable:false, validations:'notBlank'}")
	private String paymentTerm;
	
	@ApiModelProperty(required = true, value = "Frequency", example = "1")
	@FieldMetaJson("{displayName:'Frequency',nullable:false, validations:'notBlank'}")
	private String frequency;
	
	@ApiModelProperty(required = true, value = "Gender", example = "F")
	@FieldMetaJson("{displayName:'Gender', nullable:false, validations:'notBlank'}")
	private String gender;
	
	@ApiModelProperty(required = true, value = "Multiple", example = "0")
	private String multiple;
	
	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'sum Assured Amount',validations:'greaterThan~-1'}]}")
	private Money sumAssuredAmount;
	
	@FieldMetaJson("{nullable:false,validations:'notNull',childDataValidations:[{childPath:'amount',displayName:'sum Assured Amount',validations:'greaterThan~-1'}]}")
	private Money premiumAmount;
	
	@ApiModelProperty(value = "Li Age", example = "19")
	private String liAge;
	
	@ApiModelProperty(value = "Li Birth Date", example = "1983-09-30")
	private String liBirthDate;
	
	@FieldMetaJson("{childDataValidations:[{childPath:'firstName',displayName:'firstName',validations:'notBlank,notNull'},{childPath:'lastName',displayName:'lastName',validations:'notBlank,notNull'}]}")
	private Name liName;
	
	@ApiModelProperty(value = "Li Gender", example = "M")
	private String liGender;
	
	@FieldMetaJson("{ignoreValidations:true}")
	private Name childName;
	
	private List<Fund> funds;
	private List<Rider> riders;
	
	@ApiModelProperty(value = "", example = "")
	@FieldMetaJson("{nullable:false, displayName:'Options', validations:'isMinLength~1'}")
	private List<InputOption> inputOptions;
	
	@FieldMetaJson("{nullable:false}")
	private Employee employee;
	
	@ApiModelProperty(value = "Fund Strategy Id", example = "1234")
	private String fundStrategyId;
	
	@ApiModelProperty(value = "Lead Id", example = "637469424188783000")
	private String leadId;
}
