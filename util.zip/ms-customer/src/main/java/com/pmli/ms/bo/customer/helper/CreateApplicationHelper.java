package com.pmli.ms.bo.customer.helper;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.ms.bo.customer.config.CreateApplicationProps;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.ms.bo.customer.config.RiderId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetailPremium;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Money;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Product;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.SaveRider;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest.PremiumCalculation;
import com.pmli.ms.bo.customer.request.FamilyMember;
import com.pmli.ms.bo.customer.request.Fund;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.model.Name;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.ComparableValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.Validator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CreateApplicationHelper extends MsObject {

	private static final String DATE_VALIDATIONS = "notBlank,matchesRegEx~$errmsg:Invalid Birth Date format.~[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$";
	static CreateApplicationProps caprops;
	static {
		caprops = ContextWrapper.getContext().getBean(CreateApplicationProps.class);
	}

	DBClient dbClient;
	CreateApplicationRequest car;

	/**
	 * This method returns the Ispiposame value and pass it to
	 * createApplicationRequest.
	 * 
	 * @param car
	 * @return
	 */
	public static int getIspiposame(int buyType) {
		if (buyType == 1) {
			return 1;
		} else {
			return 0;
		}
	}

	/**
	 * Validates the 'Create-Application' request payload.
	 * 
	 * @param requestPayload Request details for 'Create Application', encapsulated
	 *                       in {@link createApplicationRequest}.
	 */
	public void validate(String type) {
		String productId = String.valueOf(car.getPremiumCalculation().getProductId());
		String planId = "" + car.getPlanId();

		if (type.equalsIgnoreCase("update")) {
			validateLeadIdAndApplicationNumber();
		} else {
			new StringValidator(car.getQuotationId(), "Quotation Id", false).validateEx(
					StringValidator::notNullMatchesRegEx, Constants.DIGITS_1_32_REGEX,
					"Quotation Id must not be blank with max 32 digits.");
			checkRecordAlreadyIsPresent(dbClient, car.getQuotationId());
		}
		validatePremiumProductName(dbClient, car.getPremiumCalculation());
		validatePremiumProductId(productId);
		validatePremiumPlanId(planId);
		validateAllProductMandatoryFields(car.getName(), car.getPremiumCalculation());
		validateFamilyMemberDetails();

		// Validation only for MSSP plan
		if (ProductId.isSuperSaverPlan(productId)) {
			validateMsspProductFields(car.getPremiumCalculation());
			validateBuyType();
		}

		// validation only for MGFP plan
		if (ProductId.isGuaranteedFuturePlan(productId)) {
			validateMgfpProductFields(car.getPremiumCalculation());
			validationfamilyMemberAge(car.getBuyTypeCode(), car.getFamilyMember());
		}

		// validation only for MIAP plan
		if (ProductId.isImmediataeAnuityPlan(productId)) {
			validateMiapProductFields();
		} else {
			car.setJointLifeAge(0);
			car.setJointLifeBirthDate("");
		}

		// Validation for MSPP plan
		if (ProductId.isSmartPlatinumPlusPlan(productId)) {
			validateMsppProductFields();
		} else if (null != car.getFunds()) {
			car.getFunds().clear();
		}

		// validation only for MSSP And MGFP plan
		if (ProductId.isSuperSaverPlan(productId) || ProductId.isGuaranteedFuturePlan(productId)) {
			validateMsspmgfpProductFields(car.getPremiumCalculation());
			validateRidersDetails(dbClient, car.getRiders());
		} else if (null != car.getRiders()) {
			car.getRiders().clear();
		}

		// validation only for MGFP, MSSP and MSPP only
		if (ProductId.isSuperSaverPlan(productId) || ProductId.isGuaranteedFuturePlan(productId)
				|| ProductId.isSmartPlatinumPlusPlan(productId)) {
			validateMsspMgfpMsppProductFields(car.getPremiumCalculation());
		}

		// validation only for MGFP, MSSP and MIAP only.
		if (ProductId.isSuperSaverPlan(productId) || ProductId.isGuaranteedFuturePlan(productId)
				|| ProductId.isImmediataeAnuityPlan(productId)) {
			validateMgfpMsspMiapProductFields(car.getPremiumCalculation());
		}
	}

	private void validateFamilyMemberDetails() {
		if (car.getBuyTypeCode() == 2) {
			new Validator(car.getFamilyMember(), "Family Member", false).notNull();
			new StringValidator(car.getFamilyMember().getName().getTitle(), "Family Member Title", false)
					.notNullNotBlank();
			new StringValidator(car.getFamilyMember().getName().getFirstName(), "Family Member First Name", false)
					.notNullNotBlank();
			new StringValidator(car.getFamilyMember().getName().getLastName(), "Family Member Last Name", false)
					.notNullNotBlank();
			new StringValidator(car.getFamilyMember().getGender(), "Family Member Gender", false)
					.validateAll("notBlank");
			new StringValidator(car.getFamilyMember().getBirthDate(), "Family Member BirthDate", false)
					.validateAll(DATE_VALIDATIONS);
		}
	}

	public static void validateMgfpMsspMiapProductFields(PremiumCalculation premiumCalculation) {
		new Validator(premiumCalculation.getGuaranteedDeathBenefitAmount(), AddPremiumHelper.GUARANTEED_DEATH_BENEFIT,
				false).notNull();
		new Validator(premiumCalculation.getGuaranteedDeathBenefitAmount().getAmount(),
				AddPremiumHelper.GUARANTEED_DEATH_BENEFIT, false).notNull();
		new StringValidator(premiumCalculation.getGuaranteedDeathBenefitAmount().getCurrencyCode(),
				"Guaranteed DeathBenefit Amount Currency", false).notNullNotBlank();
		new ComparableValidator(premiumCalculation.getGuaranteedDeathBenefitAmount().getAmount().doubleValue(),
				AddPremiumHelper.GUARANTEED_DEATH_BENEFIT, false).greaterThan(0.00);
	}

	public static void validateMsspMgfpMsppProductFields(PremiumCalculation premiumCalculation) {
		new ComparableValidator(premiumCalculation.getCoverTerm(), "Premium Cover Term", false).greaterThan(0);
		new ComparableValidator(premiumCalculation.getPaymentTerm(), "Premium Payment Term", false).greaterThan(0);
		new Validator(premiumCalculation.getTotalPayoutAmount(), AddPremiumHelper.TOTAL_PAYOUT, false).notNull();
		new Validator(premiumCalculation.getTotalPayoutAmount().getAmount(), AddPremiumHelper.TOTAL_PAYOUT, false)
				.notNull();
		new StringValidator(premiumCalculation.getTotalPayoutAmount().getCurrencyCode(), "TotalPayout Amount Currency",
				false).notNullNotBlank();
		new ComparableValidator(premiumCalculation.getTotalPayoutAmount().getAmount().doubleValue(),
				AddPremiumHelper.TOTAL_PAYOUT, false).greaterThan(0.00);
	}

	public static void validateMsspmgfpProductFields(PremiumCalculation premiumCalculation) {
		new Validator(premiumCalculation.getGuaranteedIncomeAmount(), AddPremiumHelper.GUARANTEED_INCOME_AMOUNT, false)
				.notNull();
		new Validator(premiumCalculation.getGuaranteedIncomeAmount().getAmount(),
				AddPremiumHelper.GUARANTEED_INCOME_AMOUNT, false).notNull();
		new StringValidator(premiumCalculation.getGuaranteedIncomeAmount().getCurrencyCode(),
				"Guaranteed Income Amount Currency", false).notNullNotBlank();
		new Validator(premiumCalculation.getMaturityBenefitAmount(), AddPremiumHelper.MATURITY_BENIFIT, false)
				.notNull();
		new Validator(premiumCalculation.getMaturityBenefitAmount().getAmount(), AddPremiumHelper.MATURITY_BENIFIT,
				false).notNull();
		new StringValidator(premiumCalculation.getMaturityBenefitAmount().getCurrencyCode(),
				"MaturityBenefit Amount Currency", false).notNullNotBlank();
		new ComparableValidator(premiumCalculation.getGuaranteedIncomeAmount().getAmount().doubleValue(),
				AddPremiumHelper.GUARANTEED_INCOME_AMOUNT, false).greaterThan(0.00);
		new ComparableValidator(premiumCalculation.getMaturityBenefitAmount().getAmount().doubleValue(),
				AddPremiumHelper.MATURITY_BENIFIT, false).greaterThan(0.00);
	}

	public static void validateRidersDetails(DBClient dbClient, List<PremiumCalculation> riders) {
		new Validator(riders, "Riders", false).notNull();
		riders.forEach(rd -> {
			new Validator(rd.getModalPremiumAmount(), AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).notNull();
			new Validator(rd.getModalPremiumAmount().getAmount(), AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false)
					.notNull();
			new StringValidator(rd.getModalPremiumAmount().getCurrencyCode(), "Rider Modal Premium Amount Currency",
					false).notNullNotBlank();
			new ComparableValidator(rd.getModalPremiumAmount().getAmount().doubleValue(),
					AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).greaterThan(0.00);

			new Validator(rd.getServiceTaxAmount(), AddPremiumHelper.SERVICE_TAX_AMOUNT, false).notNull();
			new Validator(rd.getServiceTaxAmount().getAmount(), AddPremiumHelper.SERVICE_TAX_AMOUNT, false).notNull();
			new StringValidator(rd.getServiceTaxAmount().getCurrencyCode(), "Rider ServiceTaxAmount Currency", false)
					.notNullNotBlank();
			new ComparableValidator(rd.getServiceTaxAmount().getAmount().doubleValue(),
					AddPremiumHelper.SERVICE_TAX_AMOUNT, false).greaterThan(0.00);

			new Validator(rd.getSumAssuredAmount(), AddPremiumHelper.SUM_ASSURED_AMOUNT, false).notNull();
			new Validator(rd.getSumAssuredAmount().getAmount(), AddPremiumHelper.SUM_ASSURED_AMOUNT, false).notNull();
			new StringValidator(rd.getSumAssuredAmount().getCurrencyCode(), "Rider SumAssuredAmount Currency", false)
					.notNullNotBlank();
			new ComparableValidator(rd.getSumAssuredAmount().getAmount().doubleValue(),
					AddPremiumHelper.SUM_ASSURED_AMOUNT, false).greaterThan(0.00);
			new ComparableValidator(rd.getFrequencyCode(), "Rider FrequencyCode", false).greaterThan(0);
			new StringValidator(rd.getModeDisc(), "Rider Mode Description", false).notNullNotBlank();

			if (!RiderId.isValidRiderId(rd.getProductId())) {
				throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
						caprops.getErrorRiderProductId(), caprops.getErrorRiderProductId());
			}
			if (null != dbClient.getMasterValueByTypeKey("riderShortNames", rd.getProductId() + "") && !dbClient
					.getMasterValueByTypeKey("riderShortNames", rd.getProductId() + "").equals(rd.getProductName())) {
				throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
						caprops.getInvalidProductName(), caprops.getErrorProductName());
			}
		});
	}

	private void validateMsppProductFields() {
		new ComparableValidator(car.getPremiumCalculation().getMaturityAge(), "Premium MaturityAge", false)
				.greaterThan(0);
		new Validator(car.getFunds(), "Funds", false).notNull();
		if (car.getBuyTypeCode() == 2) {
			new ComparableValidator(car.getFamilyMember().getAge(), "Age", false)
					.validate(ComparableValidator::greaterThan, -1).validate(ComparableValidator::lessThan, 71);
		} else {
			new ComparableValidator(car.getAge(), "Age", false).validate(ComparableValidator::greaterThan, 17)
					.validate(ComparableValidator::lessThan, 71);
		}
	}

	private void validateMiapProductFields() {
		new ComparableValidator(car.getJointLifeAge(), "JointLifeAge", false).greaterThan(0);
		new StringValidator(car.getJointLifeBirthDate(), "JointLifeBirthDate", false).notNullNotBlank();
		new Validator(car.getJointLifeName(), "JointLifeName", false).notNull();
		new ComparableValidator(car.getAge(), "Age", false).validate(ComparableValidator::greaterThan, 29)
				.validate(ComparableValidator::lessThan, 76);
		new ComparableValidator(car.getJointLifeAge(), "Joint Life Age\"", false)
				.validate(ComparableValidator::greaterThan, 39).validate(ComparableValidator::lessThan, 76);
	}

	public static void validateMgfpProductFields(PremiumCalculation premiumCalculation) {
		new ComparableValidator(premiumCalculation.getDeferment(), "Deferment", false).greaterThan(0);
		new StringValidator(premiumCalculation.getDefermentValue(), "DefermentValue", false).notNullNotBlank();
		new ComparableValidator(premiumCalculation.getIncomePayoutMode(), "IncomePayoutMode", false).greaterThan(0);

	}

	public void validationfamilyMemberAge(int buyTypeCode, FamilyMember fm) {
		if (buyTypeCode == 2) {
			new ComparableValidator(fm.getAge(), "Age", false).validate(ComparableValidator::greaterThan, -1)
					.validate(ComparableValidator::lessThan, 61);
		} else {
			new ComparableValidator(fm.getAge(), "Age", false).validate(ComparableValidator::greaterThan, 17)
					.validate(ComparableValidator::lessThan, 61);
		}
	}

	public static void validateMsspProductFields(PremiumCalculation premiumCalculation) {
		new Validator(premiumCalculation.getAccruedReversionaryBonusAmount(),
				AddPremiumHelper.ACCRUED_REVERSIONARY_BONUS, false).notNull();
		new Validator(premiumCalculation.getAccruedReversionaryBonusAmount().getAmount(),
				AddPremiumHelper.ACCRUED_REVERSIONARY_BONUS, false).notNull();
		new StringValidator(premiumCalculation.getAccruedReversionaryBonusAmount().getCurrencyCode(),
				"Accrued Reversionary Bonus Amount Currency", false).notNullNotBlank();
		new Validator(premiumCalculation.getRevisionaryBonusAmount(), AddPremiumHelper.REVERSIONARY_BONUS, false)
				.notNull();
		new Validator(premiumCalculation.getRevisionaryBonusAmount().getAmount(), AddPremiumHelper.REVERSIONARY_BONUS,
				false).notNull();
		new StringValidator(premiumCalculation.getRevisionaryBonusAmount().getCurrencyCode(),
				"Reversionary Bonus Amount Currency", false).notNullNotBlank();
		new Validator(premiumCalculation.getTerminalBonusAmount(), AddPremiumHelper.TERMINAL_BONUS, false).notNull();
		new Validator(premiumCalculation.getTerminalBonusAmount().getAmount(), AddPremiumHelper.TERMINAL_BONUS, false)
				.notNull();
		new StringValidator(premiumCalculation.getTerminalBonusAmount().getCurrencyCode(),
				"Terminal Bonus Amount Currency", false).notNullNotBlank();
		new ComparableValidator(premiumCalculation.getAccruedReversionaryBonusAmount().getAmount().doubleValue(),
				AddPremiumHelper.ACCRUED_REVERSIONARY_BONUS, false).greaterThan(0.00);
		new ComparableValidator(premiumCalculation.getRevisionaryBonusAmount().getAmount().doubleValue(),
				AddPremiumHelper.REVERSIONARY_BONUS, false).greaterThan(0.00);
		new ComparableValidator(premiumCalculation.getTerminalBonusAmount().getAmount().doubleValue(),
				AddPremiumHelper.TERMINAL_BONUS, false).greaterThan(0.00);

		new ComparableValidator(premiumCalculation.getCashBonusOption(), "CashBonusOption", false).greaterThan(0);
		new ComparableValidator(premiumCalculation.getFrequencyCode(), "Premium FrequencyCode", false).greaterThan(0);
		new ComparableValidator(premiumCalculation.getFundStrategy(), "Premium FundStrategy", false).greaterThan(0);

	}

	public void validateBuyType() {
		if (car.getBuyTypeCode() == 2) {
			new ComparableValidator(car.getFamilyMember().getAge(), "Age", false)
					.validate(ComparableValidator::greaterThan, -1).validate(ComparableValidator::lessThan, 61);
		} else {
			new ComparableValidator(car.getAge(), "Age", false).validate(ComparableValidator::greaterThan, 17)
					.validate(ComparableValidator::lessThan, 61);
		}
	}

	// validation for All products Mandatory Fields
	private static void validateAllProductMandatoryFields(Name name, PremiumCalculation premiumCalculation) {
		if (ProductId.isSuperSaverPlan(premiumCalculation.getProductId())
				|| ProductId.isGuaranteedFuturePlan(premiumCalculation.getProductId())
				|| ProductId.isSmartPlatinumPlusPlan(premiumCalculation.getProductId())
				|| ProductId.isImmediataeAnuityPlan(premiumCalculation.getProductId())) {

			new StringValidator(name.getTitle(), "Title", false).notNullNotBlank();
			new StringValidator(name.getFirstName(), "First Name", false).notNullNotBlank();
			new StringValidator(name.getLastName(), "Last Name", false).notNullNotBlank();
			new StringValidator(premiumCalculation.getProductName(), "Premium Product Name", false).notNullNotBlank();
			new StringValidator(premiumCalculation.getPlanName(), "Premium Plan Name", false).notNullNotBlank();
			new StringValidator(premiumCalculation.getModeDisc(), "Premium Mode Description", false).notNullNotBlank();
			new ComparableValidator(premiumCalculation.getFrequencyCode(), "Premium Frequency Code", false)
					.greaterThan(0);

			new Validator(premiumCalculation.getPremiumAmount(), AddPremiumHelper.PREMIUM_AMOUNT, false).notNull();
			new Validator(premiumCalculation.getPremiumAmount().getAmount(), AddPremiumHelper.PREMIUM_AMOUNT, false)
					.notNull();
			new ComparableValidator(premiumCalculation.getPremiumAmount().getAmount().doubleValue(),
					AddPremiumHelper.PREMIUM_AMOUNT, false).greaterThan(0.00);
			new StringValidator(premiumCalculation.getPremiumAmount().getCurrencyCode(), "Premium Amount Currency",
					false).notNullNotBlank();

			new Validator(premiumCalculation.getAnnualPremiumAmount(), AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT, false)
					.notNull();
			new Validator(premiumCalculation.getAnnualPremiumAmount().getAmount(),
					AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT, false).notNull();
			new ComparableValidator(premiumCalculation.getAnnualPremiumAmount().getAmount().doubleValue(),
					AddPremiumHelper.ANNUAL_PREMIUM_AMOUNT, false).greaterThan(0.00);
			new StringValidator(premiumCalculation.getAnnualPremiumAmount().getCurrencyCode(),
					"annual Premium Amount Currency", false).notNullNotBlank();

			new Validator(premiumCalculation.getModalPremiumAmount(), AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false)
					.notNull();
			new Validator(premiumCalculation.getModalPremiumAmount().getAmount(), AddPremiumHelper.MODAL_PREMIUM_AMOUNT,
					false).notNull();
			new ComparableValidator(premiumCalculation.getModalPremiumAmount().getAmount().doubleValue(),
					AddPremiumHelper.MODAL_PREMIUM_AMOUNT, false).greaterThan(0.00);
			new StringValidator(premiumCalculation.getModalPremiumAmount().getCurrencyCode(),
					"modal Premium Amount Currency", false).notNullNotBlank();

			new Validator(premiumCalculation.getServiceTaxAmount(), AddPremiumHelper.SERVICE_TAX_AMOUNT, false)
					.notNull();
			new Validator(premiumCalculation.getServiceTaxAmount().getAmount(), AddPremiumHelper.SERVICE_TAX_AMOUNT,
					false).notNull();
			new ComparableValidator(premiumCalculation.getServiceTaxAmount().getAmount().doubleValue(),
					AddPremiumHelper.SERVICE_TAX_AMOUNT, false).greaterThan(0.00);
			new StringValidator(premiumCalculation.getServiceTaxAmount().getCurrencyCode(),
					"service Tax Amount Currency", false).notNullNotBlank();

			new Validator(premiumCalculation.getSumAssuredAmount(), AddPremiumHelper.SUM_ASSURED_AMOUNT, false)
					.notNull();
			new Validator(premiumCalculation.getSumAssuredAmount().getAmount(), AddPremiumHelper.SUM_ASSURED_AMOUNT,
					false).notNull();
			new ComparableValidator(premiumCalculation.getSumAssuredAmount().getAmount().doubleValue(),
					AddPremiumHelper.SUM_ASSURED_AMOUNT, false).greaterThan(0.00);
			new StringValidator(premiumCalculation.getSumAssuredAmount().getCurrencyCode(),
					"sum Assured Amount Currency", false).notNullNotBlank();
		}
	}

	/**
	 * This method validates the premium plan id from createApplicationRequest.
	 */
	public static void validatePremiumPlanId(String planId) {
		if (planId == null || !ProductId.isValidProductId(planId)) {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105, caprops.getErrorPlanId(),
					caprops.getErrorPlanId());
		}
	}

	/**
	 * This method validates the premium product id from createApplicationRequest.
	 */
	public static void validatePremiumProductId(String productId) {
		if (!ProductId.isValidProductId(productId)) {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
					caprops.getErrorProductId(), caprops.getErrorProductId());
		}
	}

	/**
	 * This method validates the premium product name from createApplicationRequest.
	 */
	public static void validatePremiumProductName(DBClient dbClient, PremiumCalculation premiumCalculation) {
		if (null != dbClient.getAppConfigFieldValById(premiumCalculation.getProductId() + "", "productName")
				&& !dbClient.getAppConfigFieldValById(premiumCalculation.getProductId() + "", "productName")
						.equals(premiumCalculation.getProductName())) {
			throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
					caprops.getInvalidProductName(), caprops.getErrorProductName());
		}
	}

	/**
	 * This method validates the lead id and application number from
	 * createApplicationRequest.
	 */
	private void validateLeadIdAndApplicationNumber() {
		if (StringUtils.isEmpty(car.getLeadId()) && StringUtils.isEmpty(car.getApplicationNumber())) {
			throw new MsValidationException(caprops.getErrorMsgLeadIdAppNumberBlank());
		}

		new StringValidator(car.getLeadId(), "Lead Id", true).validateEx(StringValidator::matchesRegEx,
				Constants.DIGITS_1_32_REGEX, "Lead Id must not be blank with max 32 digits.");
		new StringValidator(car.getApplicationNumber(), "Application Number", true).validateEx(
				StringValidator::matchesRegEx, Constants.DIGITS_1_32_REGEX,
				"Application Number must not be blank with max 32 digits.");
	}

	public String getJointLifeName() {
		String jointLifeName = "";
		if (null != car.getJointLifeName() && car.getJointLifeName().getFirstName() != null
				&& car.getJointLifeName().getLastName() != null) {
			jointLifeName = car.getJointLifeName().getFirstName().concat(" ")
					.concat(car.getJointLifeName().getMiddleName()).concat(" ")
					.concat(car.getJointLifeName().getLastName().trim());
		}
		return jointLifeName;
	}

	public String getFamilyMemberAge() {
		String familyMemberAge = null;
		if (car.getFamilyMember().getAge() == 0) {
			familyMemberAge = null;
		} else {
			familyMemberAge = "" + car.getFamilyMember().getAge();
		}
		return familyMemberAge;

	}

	public String getFamilyMemberSuffix() {
		String familyMemberSuffix = null;
		if (null != car.getFamilyMember().getName() && null != car.getFamilyMember().getName().getTitle()) {
			familyMemberSuffix = car.getFamilyMember().getName().getTitle();
		}
		return familyMemberSuffix;

	}

	/**
	 * This method returns the funds value & pass to createApplicationRequest.
	 * 
	 * @param car
	 * @param fundList
	 * @return
	 */
	public List<Fund> getFunds() {
		List<Fund> funds = new ArrayList<>();
		if (car.getPremiumCalculation().getProductId() == ProductId.SPP.getValue() && car.getFunds() != null
				&& !car.getFunds().isEmpty()) {
			car.getFunds().forEach(fd -> funds.add(new Fund(fd.getFundId(), fd.getFundPercent())));

		}
		return funds;

	}

	/**
	 * This method returns the frequency value & pass to createApplicationRequest.
	 * 
	 * @param car
	 * @return
	 */
	public static String getFrequencyValue(int frequencyCode) {
		String frequencyValue = null;
		switch (frequencyCode) {
		case 12:
			if (frequencyCode == 12) {
				frequencyValue = caprops.getAnnualFrequencyValue();
			}
			break;
		case 6:
			if (frequencyCode == 6) {
				frequencyValue = caprops.getHalfFrequencyValue();
			}
			break;
		case 1:
			if (frequencyCode == 1) {
				frequencyValue = caprops.getMonthlyFrequencyValue();
			}
			break;
		default:
			frequencyValue = "";
			break;
		}
		return frequencyValue;
	}

	/**
	 * This method returns the calculation type value & pass to
	 * createApplicationRequest.
	 * 
	 * @param frequency
	 * @return
	 */
	public static String getCalculationType(Integer frequency) {
		String calculationType = null;
		switch (frequency) {
		case 12: // annual
			if (frequency == 12) {
				calculationType = caprops.getAnnualPremium();
			}
			break;
		case 6: // bi-annual
			if (frequency == 6) {
				calculationType = caprops.getHalfPremium();
			}
			break;
		case 1: // monthly
			if (frequency == 1) {
				calculationType = caprops.getMonthlyPremium();
			}
			break;
		default:
			calculationType = "";
			break;
		}
		return calculationType;
	}

	/**
	 * This method returns the plan option value & pass to createApplicationRequest.
	 * 
	 * @param planName
	 * @param productId
	 * @param planId
	 * @return
	 */
	public static String getPlanOption(String planName, Integer productId, Integer planId) {
		String planOption = planName;
		if (productId == ProductId.GFP.getValue() && planId != 2) {
			planOption = planOption.replace(" ", "");
		}
		return planOption;
	}

	/**
	 * This method returns the income payout mode value & pass to
	 * createApplicationRequest.
	 * 
	 * @param car
	 * @return
	 */
	public static String getIncomePayoutMode(DBClient dbClient, Integer productId, Integer cashBonusOption) {
		if (productId == ProductId.GFP.getValue()) {
			return dbClient.getProductOptionName(ProductId.GFP, 3, cashBonusOption);
		}
		return "";
	}

	/**
	 * This method returns the bonus option value & pass to
	 * createApplicationRequest.
	 * 
	 * @param productId
	 * @param cashBonusOption
	 * @return
	 */
	public static String getBonusOption(DBClient dbClient, Integer productId, Integer cashBonusOption) {
		if (productId == ProductId.SSP.getValue()) {
			return dbClient.getProductOptionName(ProductId.SSP, 2, cashBonusOption);
		}
		return "";
	}

	/**
	 * This method returns the deferment period value & pass to
	 * createApplicationRequest.
	 * 
	 * @param car
	 * @return
	 */
	public static String getDefermentPeriod(int productId, int deferement) {
		String defermentCode = "";
		if (productId == ProductId.GFP.getValue() && deferement > 0) {
			switch (deferement) {
			case 13:
				defermentCode = "0";
				break;
			case 14:
				defermentCode = "0";
				break;
			case 15:
				defermentCode = "1";
				break;
			case 16:
				defermentCode = "2";
				break;
			case 17:
				defermentCode = "5";
				break;
			default:
				defermentCode = "";
				break;
			}
		}
		return defermentCode;
	}

	/**
	 * This method returns the payment option value & pass to
	 * createApplicationRequest.
	 * 
	 * @param paymentTerm
	 * @param coverTerm
	 * @return
	 */
	public static String getPaymentOption(Integer paymentTerm, Integer coverTerm) {
		if (paymentTerm == 1) { // single payment
			return caprops.getSinglePay();
		} else if (coverTerm.equals(paymentTerm)) {
			return caprops.getRegularPay();
		} else {
			return caprops.getSinglePay() + paymentTerm + caprops.getAnnualFrequencyValue();
		}
	}

	/**
	 * This method returns the annuity option value & pass to
	 * createApplicationRequest.
	 * 
	 * @param productId
	 * @param planId
	 * @param paymentTerm
	 * @return
	 */
	public static String getAnnuityOption(Integer productId, Integer planId, Integer paymentTerm) {
		if (productId != ProductId.GFP.getValue())
			return "";
		else {
			if (planId == 1)
				return caprops.getSinglePay() + paymentTerm + caprops.getAnnualFrequencyValue();
			else
				return "";
		}
	}

	public static void checkRecordAlreadyIsPresent(DBClient dbClient, String quotationId) {
		if (dbClient.quotationExists(quotationId)) {
			throw new ApplicationException(HttpStatus.ALREADY_REPORTED, ErrCode.DATA_ALREADY_PRESENT_114,
					caprops.getQuotationIdExits(), caprops.getRecordAlready());
		}
	}

	public static String getProductCode(DBClient dbClient, int productId) {
		return dbClient.getProductShortName(productId);
	}

	/**
	 * This method returns the rider value & pass to createApplicationRequest.
	 * 
	 * @param riderList
	 * @param product
	 * @return
	 */
	public static List<SaveRider> getCrmRidersFromRequest(List<PremiumCalculation> riderList, Product product) {
		List<SaveRider> riders = new ArrayList<>();
		if (riderList != null && !riderList.isEmpty()) {
			riderList.forEach(rd -> {
				SaveRider rider = new SaveRider();
				rider.setSumAssured(new Money(rd.getSumAssuredAmount().getAmount() + "",
						rd.getSumAssuredAmount().getCurrencyCode()));
				rider.setTermInYears(rd.getCoverTerm());
				rider.setHealthExtra(0);

				if (rd.getProductId() == Integer.parseInt(caprops.getProductCode())) {
					rider.setId(caprops.getRiderIdAdbr());
					rider.setName(caprops.getAccidentalDeathBenifit());
					product.setAccidentalDeathBenefitRiderPremium(
							new Money("" + rd.getModalPremiumAmount().getAmount(), caprops.getCurrencyCode()));
					product.setAccidentalDeathBenefitRiderPremiumWithoutTax(
							new Money("" + rd.getServiceTaxAmount().getAmount(), caprops.getCurrencyCode()));
				} else {
					rider.setId(caprops.getRiderIdSi());
					rider.setName(caprops.getSeriousIllness());
					product.setSeriousIllnessRiderPremium(
							new Money("" + rd.getModalPremiumAmount().getAmount(), caprops.getCurrencyCode()));
					BigDecimal amount = rd.getModalPremiumAmount().getAmount()
							.subtract(rd.getServiceTaxAmount().getAmount());
					product.setSeriousIllnessRiderPremiumWithoutTax(new Money("" + amount, caprops.getCurrencyCode()));
				}
				riders.add(rider);
			});
		}
		return riders;
	}

	public static List<SaveRider> getCrmRidersFromModel(List<LeadDetailPremium> riders, Product product) {
		List<SaveRider> riderList = new ArrayList<>();
		SaveRider rider = new SaveRider();
		if (!riderList.isEmpty() && !riders.isEmpty()) {
			riders.forEach(rd -> {
				rider.setSumAssured(new Money(rd.getSumAssured() + "", caprops.getCurrencyCode()));
				rider.setTermInYears(Integer.parseInt(rd.getCoverTerms()));
				rider.setHealthExtra(0);
				if (rd.getProductId() == Integer.parseInt(caprops.getProductCode())) {
					rider.setId(caprops.getRiderIdAdbr());
					rider.setName(caprops.getAccidentalDeathBenifit());
					product.setAccidentalDeathBenefitRiderPremium(
							new Money("" + rd.getModalPremium(), caprops.getCurrencyCode()));
					product.setAccidentalDeathBenefitRiderPremiumWithoutTax(
							new Money("" + rd.getServiceTax(), caprops.getCurrencyCode()));
				} else {
					rider.setId(caprops.getRiderIdSi());
					rider.setName(caprops.getSeriousIllness());
					product.setSeriousIllnessRiderPremium(
							new Money("" + rd.getModalPremium(), caprops.getCurrencyCode()));
					BigDecimal amount = new BigDecimal(rd.getModalPremium())
							.subtract(new BigDecimal(rd.getServiceTax()));
					product.setSeriousIllnessRiderPremiumWithoutTax(new Money("" + amount, caprops.getCurrencyCode()));
				}
				riderList.add(rider);
			});
		}
		return riderList;
	}

	public static Date getExpirationDate() {
		DateFormat df = new SimpleDateFormat(caprops.getDateFromat());
		Date d = null;
		try {
			d = df.parse(JUtil.getCurrentDateTime(caprops.getDateFromat()));
			if (null != d) {
				d.setTime(d.getTime() + 30L * 24 * 60 * 60 * 1000);
			}
		} catch (ParseException e) {
			throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_FORMAT_ERROR_104, e.getMessage(),
					e.getMessage());
		}
		return d;
	}

	public static void checkValidState(DBClient dbClient, String state) {
		if (StringUtils.isEmpty(dbClient.stateExist(state))) {
			throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102,
					caprops.getErrInvalidSate(), caprops.getErrMsgInvalidState());
		}
	}
}
