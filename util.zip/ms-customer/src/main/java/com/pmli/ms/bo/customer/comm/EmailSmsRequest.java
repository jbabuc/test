package com.pmli.ms.bo.customer.comm;

import java.util.List;

import lombok.Data;

@Data
public class EmailSmsRequest {
	 String clientId;
	 String loginId;
	 Integer loginType;
	 String communicationContext;
	 String referenceId;
	 String templateId;
	 List<Metadata> metadata;
}
