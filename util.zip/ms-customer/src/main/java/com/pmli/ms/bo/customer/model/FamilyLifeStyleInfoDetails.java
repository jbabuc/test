package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class FamilyLifeStyleInfoDetails {
    private PostlifeStyleInfo lifeStyleInfo;
    private HealthFamilyAge familyMember;
}
