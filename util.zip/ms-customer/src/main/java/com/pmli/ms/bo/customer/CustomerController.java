package com.pmli.ms.bo.customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pmli.ms.bo.customer.comm.OtpClient.ValidateOtpResponse;
import com.pmli.ms.bo.customer.request.ACHADMRequest;
import com.pmli.ms.bo.customer.request.AddPremiumRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationMFGPRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.CreateBasicLeadRequest;
import com.pmli.ms.bo.customer.request.CriticalInfoRequest;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest;
import com.pmli.ms.bo.customer.request.FetchApplicationRequest;
import com.pmli.ms.bo.customer.request.FnaRequest;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest;
import com.pmli.ms.bo.customer.request.LeadListRequest;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest;
import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest;
import com.pmli.ms.bo.customer.request.PremiumCalcClientReq;
import com.pmli.ms.bo.customer.request.RidersRequest;
import com.pmli.ms.bo.customer.request.StepRequest;
import com.pmli.ms.bo.customer.request.AddPOPIRequest;
import com.pmli.ms.bo.customer.request.ValidateOtpRequest;
import com.pmli.ms.bo.customer.response.AddCustomerResponse;
import com.pmli.ms.bo.customer.response.AddPremiumResponse;
import com.pmli.ms.bo.customer.response.AddRidersResponse;
import com.pmli.ms.bo.customer.response.CreateApplicationMGFPResponse;
import com.pmli.ms.bo.customer.response.CreateApplicationResponse;
import com.pmli.ms.bo.customer.response.CreateBasicLeadDetailResponse;
import com.pmli.ms.bo.customer.response.DownloadAppFormResponse;
import com.pmli.ms.bo.customer.response.DownloadBiResponse;
import com.pmli.ms.bo.customer.response.FetchApplicationResponse;
import com.pmli.ms.bo.customer.response.GetApplicationResponse;
import com.pmli.ms.bo.customer.response.LeadDetailBiResponse;
import com.pmli.ms.bo.customer.response.LeadDetailResponse;
import com.pmli.ms.bo.customer.response.LeadListResponse;
import com.pmli.ms.bo.customer.response.MergePDFResponse;
import com.pmli.ms.bo.customer.response.MessageResponse;
import com.pmli.ms.bo.customer.response.PaymentResponse;
import com.pmli.ms.bo.customer.response.PremiumCalculationResponse;
import com.pmli.ms.bo.customer.response.UpdateApplicationResponse;
import com.pmli.ms.bo.customer.service.CustomerService;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This is a controller layer, which controls the customer related services.
 * <p>
 * customer related services are exposed as the RESTful services. <br>
 * The services implemented under this Controller are listed below:
 * </p>
 * <ul>
 * <li>Calculate Premium</li>
 * <li>Create Application</li>
 * <li>Fetch Application</li>
 * <li>Download BI</li>
 * <li>Add Payment</li>
 * <li>Add Fna</li>
 * <li>Add Customer Details</li>
 * <li>Add Riders</li>
 * <li>Add Step</li>
 * <li>Add ACHADM</li>
 * <li>Get Application</li>
 * <li>Download PDF</li>
 * <li>Add Personal Info</li>
 * <li>Add LifeStyleInfo Info</li>
 * <li>Add Critical Info</li>
 * <li>Add Document Info</li>
 * <li>Merge-PDF</li>
 * <li>Create Basic Lead Detail</li>
 * <li>MGFP Create Application</li>
 * <li>Validate OTP</li>
 * <li>Get Lead List</li>
 * </ul>
 * 
 * @author Vishal Mali
 */

@RestController
public class CustomerController extends MsObject {

    @Autowired
    private CustomerService customerService;

    /**
     * Returns premium calculation for the below products:
     * <ul>
     * <li>MetLife Super Saver Plan (MSSP)</li>
     * <li>MetLife Guaranteed Future Plan(MGFP)</li>
     * <li>MetLife Smart Platinum Plus Plan(MSPP)</li>
     * <li>Metlife Immediate Annuity Plan(MIAP)</li>
     * </ul>
     * 
     * @param  request               Request details to get Premium calculation, encapsulated in
     *                               {@link PremiumCalcClientReq}.
     * @return                       response Premium calculation, encapsulated in {@link ResponseEntity} of type
     *                               {@link PremiumCalculationResponse}.
     * @throws MsValidationException Customized exception.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "BI Generated successfully", response = PremiumCalculationResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for premium calculation.")
    @PostMapping(path = "/v1/customer/calculate-premium")
    public Object calculatePremium(
        @ApiParam(value = "Request bean contains required data for the Premium-Calculation operation", required = true) @RequestBody PremiumCalcClientReq request) {
        return customerService.calculatePremium(request);
    }

    /**
     * Downloads Benefit Illustration.
     * 
     * @param  quotationId Quotation Id.
     * @return             File content.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = DownloadBiResponse.class, message = "BI Downloaded Successfully"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for download bi.")
    @GetMapping(path = "/v1/customer/download-bi/{quotationId}")
    public Object downloadBi(@PathVariable String quotationId) { return customerService.downloadBi(quotationId); }

    /**
     * Downloads Application Form file content.
     * 
     * @param  key.
     * @return      File content.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = DownloadAppFormResponse.class, message = "App Form Downloaded Successfully"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for download Application Form.")
    @GetMapping(path = "/v1/customer/download-app-form")
    public Object downloadAppForm(
        @ApiParam(name = "leadId", value = "Lead Id", example = "26032021111431772") @RequestParam(required = false) String leadId) {
        return customerService.downloadAppForm(leadId);
    }

    /**
     * Add Payment details in database.
     * 
     * @param  requestPayload Request details for 'Add Payment', encapsulated in {@link PaymentRequest}.
     * @return                Response details of 'Add Payment', encapsulated in {@link ResponseEntity} of type
     *                        {@link PaymentResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Payment details have been saved successfully", response = PaymentResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Add Payment details in mongo db")
    @PostMapping(value = "/v1/customer/add-payment")
    public Object addPayment(
        @ApiParam(value = "Request bean contains required data for the Add-Payment operation", required = true) @RequestBody PaymentRequest requestPayload) {
        return customerService.addPayment(requestPayload);
    }

    /**
     * Add Create Application Details in database.
     * 
     * @param  createApplicationRequest Request details for 'Create Application Request', encapsulated in
     *                                  {@link createApplicationRequest}.
     * @return                          Response details of 'Create Application', encapsulated in {@link ResponseEntity}
     *                                  of type {@link CreateApplicationResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = CreateApplicationResponse.class, message = "Application created Sucessfully"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = " Add create application details in Mongo db and generates application number.")
    @PostMapping(path = "/v1/customer/create-application")
    public Object createApplication(@RequestBody CreateApplicationRequest createApplicationRequest) {
        return customerService.createApplication(createApplicationRequest);
    }

    /**
     * Add Update Application Details in database.
     * 
     * @param  createApplicationRequest Request details for 'Create Application Request', encapsulated in
     *                                  {@link createApplicationRequest}.
     * @return                          Response details of 'Update Application', encapsulated in {@link ResponseEntity}
     *                                  of type {@link UpdateApplicationResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = UpdateApplicationResponse.class, message = "Application updated Sucessfully"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "to update application details in Mongo db.")
    @PostMapping(path = "/v1/customer/update-application")
    public Object updateApplication(@RequestBody CreateApplicationRequest createApplicationRequest) {
        return customerService.updateApplication(createApplicationRequest);
    }

    /**
     * Fetch Application Details from database.
     * 
     * @param  fetchApplicationRequest Request details for 'Fetch Application', encapsulated in
     *                                 {@link fetchApplicationRequest}.
     * @return                         Response details of 'Fetch Application', encapsulated in {@link ResponseEntity}
     *                                 of type {@link FetchApplicationResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = FetchApplicationResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for fetch application.")
    @PostMapping(path = "/v1/customer/fetch-application")
    public Object fetchApplication(
        @ApiParam(value = "Request bean contains required data for the Fetch-Application operation", required = true) @RequestBody FetchApplicationRequest fetchApplicationRequest) {
        return customerService.fetchApplication(fetchApplicationRequest);
    }

    /**
     * Add Financial Need Analysis details to database
     * 
     * @param  fnaRequest Request details for 'Add Fna Request', encapsulated in {@link fnaRequest}.
     * @return            Response details of 'Add Fna', encapsulated in {@link ResponseEntity} of type
     *                    {@link MessageResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for Add Fna.")
    @PostMapping(path = { "/v1/mgfp/add-fna", "/v1/customer/add-fna" })
    public Object addFna(
        @ApiParam(value = "Request bean contains required data for the Add Fna", required = true) @RequestBody FnaRequest fnaRequest) {
        return customerService.addFna(fnaRequest);
    }

    /**
     * Add Customer details to database
     * 
     * @param  addCustomerRequest Request details for 'Add Customer Request', encapsulated in
     *                            {@link addCustomerRequest}.
     * @return                    Response details of 'Add Customer Details', encapsulated in {@link ResponseEntity} of
     *                            type {@link addCustomerDetailsResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Customer details saved successfully", response = AddCustomerResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Add Customer Details.")
    @PostMapping(path = "/v1/customer/add-customer-details")
    public Object addCustomerDetails(
        @ApiParam(value = "Request bean contains required data for the Add Customer Details", required = true) @RequestBody CustomerRequest addCustomerRequest) {
        return customerService.addCustomerDetails(addCustomerRequest);
    }

    /**
     * Add Riders details to database
     * 
     * @param  addRidersRequest Request details for 'Add Riders', encapsulated in {@link addRidersRequest}.
     * @return                  Response details of 'Add Riders', encapsulated in {@link ResponseEntity} of type
     *                          {@link AddRidersResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = AddRidersResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add riders.")
    @PostMapping(path = "/v1/customer/add-riders")
    public Object addRiders(
        @ApiParam(value = "Request bean contains required data for the Add Riders Details", required = true) @RequestBody RidersRequest addRidersRequest) {
        return customerService.addRiders(addRidersRequest);
    }

    /**
     * Add Premium details to database
     * 
     * @param  addPremiumRequest Request details for 'Add Premium Request', encapsulated in {@link addPremiumRequest}.
     * @return                   Response details of 'Add Premium Details'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = AddPremiumResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add premium.")
    @PostMapping(path = "/v1/customer/add-premium")
    public Object addPremium(
        @ApiParam(value = "Request bean contains required data for the Add Premium Details", required = true) @RequestBody AddPremiumRequest addPremiumRequest) {
        return customerService.addPremium(addPremiumRequest);
    }

    /**
     * Add Step details to database
     * 
     * @param  addStepRequest Request details for 'Add Step Request', encapsulated in {@link addStepRequest}.
     * @return                Response details of 'Add Step Details'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add Step.")
    @PostMapping(path = "/v1/customer/add-step")
    public Object addStep(
        @ApiParam(value = "Request bean contains required data for the Add Step", required = true) @RequestBody StepRequest addStepRequest) {
        return customerService.addStep(addStepRequest);
    }

    /**
     * Add isACHADM details to database
     * 
     * @param  addStepRequest Request details for 'Add isACHADM', encapsulated in {@link addACHADMRequest}.
     * @return                Response details of 'Add isACHADM'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add isACHADM.")
    @PostMapping(path = "/v1/customer/add-is-achadm")
    public Object addACHADM(
        @ApiParam(value = "Request bean contains required data for the Add isACHADM", required = true) @RequestBody ACHADMRequest addACHADMRequest) {
        return customerService.addACHADM(addACHADMRequest);
    }

    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Applications detail is fetched successfully", response = GetApplicationResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to get Applications detail based on Mobile Number")
    @GetMapping("/v1/customer/get-applications")
    public Object getApplications(
        @ApiParam(name = "mobileNo", value = "Mobile Number", example = "7387076122") @RequestParam(required = false) String mobileNo) {
        return customerService.getApplications(mobileNo);
    }

    /**
     * Add LifeStyleInfoRequest details to database
     * 
     * @param  lifeStyleInfoRequest Request details for 'Add LifeStyle Info', encapsulated in
     *                              {@link LifeStyleInfoRequest}.
     * @return                      Response details of 'success message'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add lifestyle info.")
    @PostMapping(path = "/v1/customer/add-lifestyle-info")
    public Object addLifetstyleInfo(
        @ApiParam(value = "Request bean contains required data for the Add LifeStyle Info Details", required = true) @RequestBody LifeStyleInfoRequest lifeStyleInfoRequest) {
        return customerService.addLifetstyleInfo(lifeStyleInfoRequest);
    }

    /**
     * Add PersonalInfoRequest details to database
     * 
     * @param  addPersonalInfoRequest Request details for 'Add Personal Info Request', encapsulated in
     *                                {@link PersonalInfoRequest}.
     * @return                        Response details of 'success message'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add personal info.")
    @PostMapping(path = "/v1/customer/add-personal-info")
    public Object personalInfo(
        @ApiParam(value = "Request bean contains required data for the add personal info", required = true) @RequestBody PersonalInfoRequest request) {
        return customerService.addPersonalInfo(request);
    }

    /**
     * Add critical info details to database
     * 
     * @param  CriticalInfoRequest Request details for 'Add Critical Info Request', encapsulated in
     *                             {@link CriticalInfoRequest}.
     * @return                     Response details of 'Add Critical Info', encapsulated in {@link ResponseEntity} of
     *                             type {@link CriticalInfoResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for add critical info.")
    @PostMapping(path = "/v1/customer/add-critical-info")
    public Object addCriticalInfo(
        @ApiParam(value = "Request bean contains required data for the Add Critical Info", required = true) @RequestBody CriticalInfoRequest criticalInfoRequest) {
        return customerService.addCriticalInfo(criticalInfoRequest);
    }

    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Download pdf successfully", response = DownloadBiResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to downloads the document based on Lead Id")
    @GetMapping("/v1/customer/download-pdf")
    public Object getDownloadPdf(
        @ApiParam(name = "leadId", value = "Lead Id", example = "26032021111431772") @RequestParam(required = false) String leadId) {
        return customerService.getDownloadPdf(leadId);
    }

    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Lead Details Retrived successfully", response = LeadDetailResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to get lead details")
    @GetMapping("/v1/customer/get-lead-by-application-no")
    public Object getLeadDetailByApplicationNo(
        @ApiParam(name = "applicationNo", value = "Application Number", example = "637563516990613163") @RequestParam(required = true) String applicationNo) {
        return customerService.getLeadDetails(null, applicationNo);
    }

    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Lead Details Retrived successfully", response = LeadDetailResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to get lead details")
    @GetMapping({ "/v1/mgfp/get-lead", "/v1/customer/get-lead-by-lead-id" })
    public Object getLeadDetailbyLeadId(
        @ApiParam(name = "leadId", value = "Lead Id", example = "26032021111431772") @RequestParam(required = true) String leadId) {
        return customerService.getLeadDetails(leadId, null);
    }

    /**
     * Add Document info details to database
     * 
     * @param  DocumentInfoRequest Request details for 'Add Document Info', encapsulated in
     *                             {@link DocumentInfoRequest}.
     * @return                     Response details of 'success message'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to add Document details")
    @PostMapping("/v1/customer/add-document-info")
    public Object addDocumentInfo(
        @ApiParam(value = "Request bean contains required data for the add Document info", required = true) @RequestBody DocumentInfoRequest request) {
        return customerService.addDocumentInfo(request);
    }

    /**
     * This method merge list of PDF.
     * 
     * @param  MergePDFRequest 'Merge PDF Request', encapsulated in {@link MergePDFRequest}.
     * @return                 Response details of 'merge Pdf response', encapsulated in {@link ResponseEntity} of type
     *                         {@link MergePDFResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call for merge PDF.")
    @PostMapping(path = "/v1/customer/merge-pdf", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public Object margePDF(@RequestPart String leadId, @RequestPart String fileCount, @RequestPart String customerType,
        @RequestPart(name = "IdProofFileUpload") List<MultipartFile> idProofFileUpload) {
        return customerService.mergePDF(leadId, fileCount, customerType, idProofFileUpload);
    }

    /**
     * Create Basic Lead Details in database.
     * 
     * @param  requestPayload Request details for 'Create Basic lead detail Request', encapsulated in
     *                        {@link CreateBasicLeadRequest}.
     * @return                Response details of 'Create Basic lead detail', encapsulated in {@link ResponseEntity} of
     *                        type {@link CreateBasicLeadDetailResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = CreateBasicLeadDetailResponse.class, message = "Success"),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 429, message = "Maximum generate count reached"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Created basic lead details in DB")
    @PostMapping(path = "/v1/mgfp/create-basic-lead-detail")
    public Object createBasicLead(@RequestBody CreateBasicLeadRequest requestPayload) {
        return customerService.createBasicLead(requestPayload);
    }

    /**
     * PO PI details to database
     * 
     * @param  AddPOPIRequest Request details for 'PO PI Request', encapsulated in {@link AddPOPIRequest}.
     * @return                   Response details of 'success message'
     */
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = MessageResponse.class),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "Rest Api call to update po pi details")
    @PostMapping("/v1/mgfp/add-po-pi-info")
    public Object addPOPI(
        @ApiParam(value = "Request bean contains required data for the update PO & PI", required = true) @RequestBody AddPOPIRequest request) {
        return customerService.addPOPI(request);
    }

    /**
     * This method Validate the OTP.
     * 
     * @param  validateOtpRequest Request details for 'Validate Otp', encapsulated in
     *                            {@link ValidateOtpRequest}.
     * @return                    Response details of 'Validate Otp', encapsulated in {@link ResponseEntity} of type
     *                            {@link ValidateOtpResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = String.class, message = "{\"message\":\"success\",\"counter\":\"2\",\"allowedAttempts\":\"3\"}"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "For validating the OTP")
    @PostMapping(path = "/v1/mgfp/validate-otp")
    public Object validateOtp(
        @ApiParam(value = "Request bean contains required data for validate otp", required = true) @RequestBody ValidateOtpRequest validateOtpRequest) {
        return customerService.validateOtp(validateOtpRequest);
    }

    /**
     * Add Basic Lead Details for Web BI in database.
     * 
     * @param  LeadDetailBiRequest Request details for 'Basic Lead Details For Web BI Request', encapsulated in
     *                             {@link createLeadDetail}.
     * @return                     Response details of 'Create Lead', encapsulated in {@link ResponseEntity} of type
     *                             {@link LeadDetailBiResponse}.
     */
    @ApiResponses(value = { @ApiResponse(code = 200, response = LeadDetailBiResponse.class, message = "Success"),
        @ApiResponse(code = 400, message = "Bad Request"),
        @ApiResponse(code = 404, message = "No record found in database"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "To create basic lead details for Web BI in DB")
    @PostMapping(path = "/v1/web-bi/create-lead")
    public Object createLead(@RequestBody LeadDetailBiRequest requestPayload) {
        return customerService.createLeadDetail(requestPayload);
    }

    /**
     * MGFP Create Application
     * 
     * @param  requestPayload Request details for 'Create Application Request', encapsulated in
     *                        {@link CreateApplicationMFGPRequest}.
     * @return                Response details of 'Create Application Request', encapsulated in of type
     *                        {@link CreateApplicationMGFPResponse}.
     */
    @ApiResponses(value = {
        @ApiResponse(code = 200, response = CreateApplicationMGFPResponse.class, message = "Success"),
        @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
        @ApiResponse(code = 415, message = "Unsupported Media Type"),
        @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiOperation(value = "MGFP Created Application")
    @PostMapping(path = "/v1/mgfp/create-application")
    public Object createApplicationMgfp(@RequestBody CreateApplicationMFGPRequest requestPayload) {
        return customerService.createApplicationMgfp(requestPayload);
    }
    
    /**
     * This method Get Lead List By Mobile Number.
     * 
     * @param  LeadListRequest Request details for 'Getting Lead List', encapsulated in
     *                            {@link LeadListRequest}.
     * @return                    Response details of 'Getting Lead List', encapsulated in {@link ResponseEntity} of type
     *                            {@link LeadListResponse}.
     */
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Lead Details Retrived successfully", response = LeadListResponse.class),
			@ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 404, message = "Data Not Found"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	@ApiOperation(value = "Rest Api call to get lead list by Mobile number")
	@PostMapping(path = "/v1/mgfp/lead-list")
	public Object getLeadList(@RequestBody LeadListRequest request) {
		return customerService.getLeadList(request);
	}
}
