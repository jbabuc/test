package com.pmli.ms.bo.customer.comm;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class holds the request details for SMS api
 * 
 * @author Hemant Solanki
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SmsRequest extends EmailSmsRequest{
	private String toMobileNumber;
	private String smsReq;

    public SmsRequest(String communicationContext, String toMobileNumber, String templateId, List<Metadata> metadata,
        String smsReq) {
        this.communicationContext=communicationContext;
        this.toMobileNumber=toMobileNumber;
        this.templateId=templateId;
        this.metadata=metadata;
        this.smsReq=smsReq;
    }
}