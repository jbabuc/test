package com.pmli.ms.bo.customer.helper;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Files;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.utils.PdfMerger;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.pmli.ms.bo.customer.model.FileDetail;
import com.pmli.ms.bo.customer.response.MergePDFResponse;
import com.pmli.util.java.JUtil;
import com.pmli.util.java.MsObject;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MergePdfHelper extends MsObject {

    String              quotationId;
    String              fileCount;
    String              customerType;
    List<MultipartFile> mpFiles;
    String              tempDir;
    List<PdfDocument>   pdfDocList        = new ArrayList<>();
    List<FileDetail>    base64FileDetails = new ArrayList<>();
    MergePDFResponse    mergePDFResponse;

    public MergePdfHelper(String quotationId, String fileCount, String customerType, List<MultipartFile> mpFiles) {
        this.quotationId = quotationId;
        this.fileCount = fileCount;
        this.customerType = customerType;
        this.mpFiles = mpFiles;

        tempDir = JUtil.getTmpDirNew(true);
        mergePDFResponse = new MergePDFResponse();
        mergePDFResponse.setCustomerType(customerType);
    }
    
	public void merge() {
		try {

			int totalFileUpdate = 0;
			for (MultipartFile mpf : mpFiles) {
				switch (mpf.getContentType()) {
				case "image/jpeg":
				case "image/png":
					base64FileDetails.add(FileDetail.builder().fileName(quotationId + "-"+customerType + "-" +mpf.getOriginalFilename())
							.base64(Base64.getEncoder().encodeToString(mpf.getBytes())).build());
					convertIMGToPDF(mpf);
					totalFileUpdate++;
					break;
				case "application/pdf":
					base64FileDetails.add(FileDetail.builder().fileName(quotationId + "-"+customerType+"-" + mpf.getOriginalFilename())
							.base64(Base64.getEncoder().encodeToString(mpf.getBytes())).build());
					savePdf(mpf);
					totalFileUpdate++;
					break;
				default:
					throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_FORMAT_ERROR_104,
							"The file format is not supported", "Please upload the file jpg, png and pdf");
				}

				mergePDFResponse.setCount(totalFileUpdate);
			}
			if(totalFileUpdate>1) {
				mergeMultiplePdf();
			}
			
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		} finally {
			FileSystemUtils.deleteRecursively(new File(tempDir));
		}
	}

	private void savePdf(MultipartFile mpf) throws IOException {

		PdfDocument pdfDocument = null;
		String fileLocation = tempDir + File.separator + quotationId + "-" + mpf.getOriginalFilename();
		pdfDocument = new PdfDocument(new PdfReader(new ByteArrayInputStream(mpf.getBytes())),
				new PdfWriter(fileLocation));
		pdfDocument.close();
		pdfDocList.add(new PdfDocument(new PdfReader(fileLocation)));
	}

	private void convertIMGToPDF(MultipartFile mpf) throws IOException {
		String fileLocation = tempDir + File.separator + quotationId + "-"
				+ StringUtils.stripFilenameExtension(mpf.getOriginalFilename()) + ".pdf";
		Document document = new Document(new PdfDocument(new PdfWriter(fileLocation)));
		ImageData data = ImageDataFactory.create(mpf.getBytes(), false);
		Image image = new Image(data);
		PdfDocument pdfDocument = document.add(image.setAutoScale(true)).getPdfDocument();
		document.close();
		pdfDocument.close();
		PdfDocument pdfdoc = new PdfDocument(new PdfReader(fileLocation));
		pdfDocList.add(pdfdoc);
	}

	private void mergeMultiplePdf() throws IOException {
		String mergedPath = tempDir + File.separator + quotationId + ".pdf";

		PdfDocument pdf = new PdfDocument(new PdfWriter(mergedPath));
		PdfMerger merger = new PdfMerger(pdf);
		for (PdfDocument fileData : pdfDocList) {
			merger.merge(fileData, 1, fileData.getNumberOfPages());
			fileData.close();
		}
		merger.close();
		pdf.close();
		base64FileDetails.add(FileDetail.builder().fileName(quotationId+"-"+customerType+".pdf")
				.base64(Base64.getEncoder().encodeToString(Files.toByteArray(new File(mergedPath)))).build());
	}
}
