/**
 * 
 */
package com.pmli.ms.bo.customer.response;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author 3483784san
 *
 */
@Data
@AllArgsConstructor
public class AddCustomerResponse {
	private String leadId;
	private String message;
}
