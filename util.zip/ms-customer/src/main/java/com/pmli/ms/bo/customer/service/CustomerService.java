package com.pmli.ms.bo.customer.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.pmli.ms.bo.customer.comm.OtpClient.ValidateOtpResponse;
import com.pmli.ms.bo.customer.request.ACHADMRequest;
import com.pmli.ms.bo.customer.request.AddPremiumRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationMFGPRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.CreateBasicLeadRequest;
import com.pmli.ms.bo.customer.request.CriticalInfoRequest;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest;
import com.pmli.ms.bo.customer.request.FetchApplicationRequest;
import com.pmli.ms.bo.customer.request.FnaRequest;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest;
import com.pmli.ms.bo.customer.request.LeadListRequest;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest;
import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest;
import com.pmli.ms.bo.customer.request.PremiumCalcClientReq;
import com.pmli.ms.bo.customer.request.RidersRequest;
import com.pmli.ms.bo.customer.request.StepRequest;
import com.pmli.ms.bo.customer.request.AddPOPIRequest;
import com.pmli.ms.bo.customer.request.ValidateOtpRequest;
import com.pmli.ms.bo.customer.response.AddRidersResponse;
import com.pmli.ms.bo.customer.response.CreateApplicationResponse;
import com.pmli.ms.bo.customer.response.CreateBasicLeadDetailResponse;
import com.pmli.ms.bo.customer.response.DownloadBiResponse;
import com.pmli.ms.bo.customer.response.FetchApplicationResponse;
import com.pmli.ms.bo.customer.response.GetApplicationResponse;
import com.pmli.ms.bo.customer.response.LeadDetailBiResponse;
import com.pmli.ms.bo.customer.response.LeadListResponse;
import com.pmli.ms.bo.customer.response.MessageResponse;
import com.pmli.ms.bo.customer.response.PaymentResponse;
import com.pmli.ms.bo.customer.response.PremiumCalculationResponse;
import com.pmli.ms.bo.customer.response.UpdateApplicationResponse;

/**
 * This is the service interface layer which defines the customer services.
 * <p>
 * The services defined under this interface are listed below:
 * </p>
 * <ul>
 * <li>Calculate Premium</li>
 * <li>Create Application</li>
 * <li>Fetch Application</li>
 * <li>Download BI</li>
 * <li>Add Payment</li>
 * <li>Add Fna</li>
 * <li>Add Customer Details</li>
 * <li>Add Riders</li>
 * <li>Add Step</li>
 * <li>Add ACHADM</li>
 * <li>Get Applications</li>
 * <li>Download PDF</li>
 * <li>Add Personal Info</li>
 * <li>Add LifeStyleInfo Info</li>
 * <li>Add Critical Info</li>
 * <li>Add Document Info</li>
 * <li>Merge-PDF</li>
 * <li>Create Basic Lead Detail</li>
 * <li>MGFP Create Application</li>
 * <li>Validate OTP</li>
 * <li>Get Lead List</li>
 * </ul>
 * 
 * @author Vishal Mali
 */
public interface CustomerService {
    /**
     * Returns premium calculation for the below products:
     * <ul>
     * <li>MetLife Super Saver Plan (MSSP)</li>
     * <li>MetLife Guaranteed Future Plan(MGFP)</li>
     * <li>MetLife Smart Platinum Plus Plan(MSPP)</li>
     * <li>Metlife Immediate Annuity Plan(MIAP)</li>
     * </ul>
     * 
     * @param  request Request details to get Premium calculation, encapsulated in {@link PremiumCalcClientReq}.
     * @return         response Premium calculation, encapsulated in {@link PremiumCalculationResponse}.
     */
    Object calculatePremium(PremiumCalcClientReq request);

    /**
     * @param  quotationId
     * @return             response
     */
    Object downloadBi(String quotationId);

    /**
     * Downloads Application Form file content.
     * 
     * @param  key
     * @return     response
     */
    Object downloadAppForm(String key);

    /**
     * Add Payment details in database
     * 
     * @param  requestPayload Request details for 'Add Payment', encapsulated in {@link PaymentRequest}.
     * @return                Response details of 'Add Payment', encapsulated in {@link ResponseEntity} of type
     *                        {@link PaymentResponse}.
     */
    Object addPayment(PaymentRequest requestPayload);

    /**
     * Add Create Application details in database
     * 
     * @param  requestPayload Request details for 'Create Application', encapsulated in
     *                        {@link createApplicationRequest}.
     * @return                Response details of 'Create Application', encapsulated in {@link ResponseEntity} of type
     *                        {@link CreateApplicationResponse}.
     */
    Object createApplication(CreateApplicationRequest createApplicationRequest);

    /**
     * Add update Application details in database
     * 
     * @param  requestPayload Request details for 'Create Application', encapsulated in
     *                        {@link createApplicationRequest}.
     * @return                Response details of 'Update Application', encapsulated in {@link ResponseEntity} of type
     *                        {@link UpdateApplicationResponse}.
     */
    Object updateApplication(CreateApplicationRequest createApplicationRequest);

    /**
     * Fetch Application Details from database.
     * 
     * @param  fetchApplicationRequest Request details for 'Fetch Application', encapsulated in
     *                                 {@link fetchApplicationRequest}.
     * @return                         Response details of 'Fetch Application', encapsulated in {@link ResponseEntity}
     *                                 of type {@link FetchApplicationResponse}.
     */
    Object fetchApplication(FetchApplicationRequest fetchApplicationRequest);

    /**
     * Add Financial Need Analysis details to database
     * 
     * @param  fnaRequest Request details for 'Add Financial Need Analysis details', encapsulated in {@link fnaRequest}.
     * @return            Response details of 'Add Fna', encapsulated in {@link ResponseEntity} of type
     *                    {@link MessageResponse}.
     */
    Object addFna(FnaRequest fnaRequest);

    /**
     * Add Financial Need Analysis details to database
     * 
     * @param  addCustomerRequest Request details for 'Add Financial Need Analysis details', encapsulated in
     *                            {@link fnaRequest}.
     * @return                    Response details of 'Add Customer Details', addCustomerRequest in
     *                            {@link ResponseEntity} of type {@link addCustomerDetailsResponse}.
     */
    Object addCustomerDetails(CustomerRequest addCustomerRequest);

    /**
     * Add Riders details to database
     * 
     * @param  addRidersRequest Request details for 'Add Riders', encapsulated in {@link addRidersRequest}.
     * @return                  Response details of 'Add Riders', encapsulated in {@link ResponseEntity} of type
     *                          {@link AddRidersResponse}.
     */
    Object addRiders(RidersRequest addRidersRequest);

    /**
     * Add Premium details to database
     * 
     * @param  addPremiumRequest Request details for 'Add Premium Request', encapsulated in {@link addPremiumRequest}.
     * @return                   Response details of 'Add Premium Details'.
     */
    Object addPremium(AddPremiumRequest addPremiumRequest);

    /**
     * Add Step to database
     * 
     * @param  addStepRequest Request details for 'Add Step Request', encapsulated in {@link addStepRequest}.
     * @return                Response details of 'Add Step Details'.
     */

    Object addStep(StepRequest addStepRequest);

    /**
     * Add ACHADM to database
     * 
     * @param  addACHADMRequest Request details for 'Add ACHADM', encapsulated in {@link addACHADMRequest}.
     * @return                  Response details of 'Add ACHADM'.
     */

    Object addACHADM(ACHADMRequest addACHADMRequest);

    /**
     * Get Application details based on mobile number
     * 
     * @param  mobileNum contains mobile number
     * @return           Response details for 'Get Applications', encapsulated in {@link GetApplicationResponse}..
     */
    Object getApplications(String mobileNum);

    /**
     * Add LifeStyleInfoRequest details to database
     * 
     * @param  lifeStyleInfoRequest Request details for 'Add LifeStyle Info', encapsulated in
     *                              {@link LifeStyleInfoRequest}.
     * @return                      Response details of 'success message'
     */
    Object addLifetstyleInfo(LifeStyleInfoRequest lifeStyleInfoRequest);

    /**
     * Add Personal Info to database
     * 
     * @param  PersonalInfoRequest Request details for 'Add Personal Info Request', encapsulated in
     *                             {@link addACHADMRequest}.
     * @return                     Response details of 'success message'.
     */
    Object addPersonalInfo(PersonalInfoRequest request);

    Object addCriticalInfo(CriticalInfoRequest criticalInfoRequest);

    /**
     * downloads the uploaded documents base64
     * 
     * @param  leadId the String contains Lead ID
     * @return        response encapsulated in {@link DownloadBiResponse}
     */
    Object getDownloadPdf(String leadId);

    /**
     * Returns all Lead details from DB on basis of applicationNumber or leadId
     * 
     * @param  key    : leadId or applicationNumber Or
     * @param  value: string of leadId or applicationNumber
     * @return        response encapsulated in {@link DownloadBiResponse}
     */
    Object getLeadDetails(String leadId, String applicationNo);

    /**
     * Add Document info details to database
     * 
     * @param  DocumentInfoRequest Request details for 'Add Document Info', encapsulated in
     *                             {@link DocumentInfoRequest}.
     * @return                     Response details of 'success message'
     */
    Object addDocumentInfo(DocumentInfoRequest request);

    Object mergePDF(String leadId, String fileCount, String customerType, List<MultipartFile> idProofFileUpload);

    /**
     * This method Validate the OTP.
     * 
     * @param  validateOtpRequest Request details for 'Validate Otp', encapsulated in
     *                            {@link ValidateOtpRequest}.
     * @return                    Response details of 'Validate Otp', encapsulated in {@link ResponseEntity} of type
     *                            {@link ValidateOtpResponse}.
     */
    Object validateOtp(ValidateOtpRequest validateOtpRequest);

    /**
     * Create Basic Lead Detail in database
     * 
     * @param  requestPayload Request details for 'create-basic-lead-detail', encapsulated in
     *                        {@link CreateBasicLeadRequest}.
     * @return                Response details of 'create-basic-lead-detail', encapsulated in {@link ResponseEntity} of
     *                        type {@link CreateBasicLeadDetailResponse}.
     */
    Object createBasicLead(CreateBasicLeadRequest requestPayload);

    Object addPOPI(AddPOPIRequest request);

    /**
     * Create Basic Lead Detail for web bi in database
     * 
     * @param  requestPayload Request details for 'create-lead', encapsulated in {@link LeadDetailBiRequest}.
     * @return                Response details of 'create-lead', encapsulated in {@link ResponseEntity} of type
     *                        {@link LeadDetailBiResponse}.
     */
    Object createLeadDetail(LeadDetailBiRequest requestPayload);

    /**
     * Save MGFP 'create-application' data in DB and create application in system.
     * 
     * @param  requestPayload Request details for 'create-application', encapsulated in
     *                        {@link CreateApplicationMFGPRequest}.
     * @return                Response details of 'create-application', encapsulated in of type
     *                        {@link CreateApplicationMGFPResponse}.
     */
    Object createApplicationMgfp(CreateApplicationMFGPRequest requestPayload);

    /**
     * This method Get Lead List By Mobile Number.
     * 
     * @param  LeadListRequest Request details for 'Getting Lead List', encapsulated in
     *                            {@link LeadListRequest}.
     * @return                    Response details of 'Getting Lead List', encapsulated in {@link ResponseEntity} of type
     *                            {@link LeadListResponse}.
     */
	Object getLeadList(LeadListRequest request);

}
