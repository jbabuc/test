package com.pmli.ms.bo.customer.request;

import static java.util.Optional.ofNullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.FinancialAnalysis;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.Base;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.ChildInfo;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.FinacialGoalDetail;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.FinancialAnalysisDetail;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.FnaGoal;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.FnaSummary;
import com.pmli.ms.bo.customer.model.FinancialAnalysis.LongTermSave;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Name;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the Add fna request details
 * 
 * @author suvarna bambarse
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class FnaRequest extends LeadRequest {

    @Data
    @NoArgsConstructor
    public static class Fna {
        @FieldMetaJson("{displayName:'Financials',nullable:false}")
        private List<FnaBase> financials;

        @ApiModelProperty(value = "planId", example = "12020")
        private int planId;

        @ApiModelProperty(value = "risk", example = "3")
        @FieldMetaJson("{displayName:'Risk', nullable:false, validations:'greaterThan~-0'}")
        private int risk;

        @ApiModelProperty(value = "stage", example = "3")
        @FieldMetaJson("{displayName:'Stage', nullable:false, validations:'greaterThan~-0'}")
        private int stage;

        @FieldMetaJson("{displayName:'Summary',nullable:false}")
        private Summary summary;

        @ApiModelProperty(value = "selectedGoal", example = "ChildEducation")
        private String selectedGoal;

        private List<ChildDetail> children;
        private LongTerm          longTermSavingInformation;

        public Fna(FinancialAnalysis fna) {
            if (fna == null) return;
            financials = new ArrayList<>();
            ofNullable(fna.getFinancial()).ifPresent(f -> f.forEach(fb -> financials.add(new FnaBase(fb))));
            this.planId = CommonHelper.parseIntOrDef(fna.getPlan(), 0);
            this.risk = CommonHelper.parseIntOrDef(fna.getRisk(), 0);
            this.stage = CommonHelper.parseIntOrDef(fna.getStage(), 0);
            this.summary = new Summary(fna.getSummary());
            this.selectedGoal = fna.getSelectedGoal();
            children = new ArrayList<>();
            ofNullable(fna.getChild()).ifPresent(c -> c.forEach(cd -> children.add(new ChildDetail(cd))));
            longTermSavingInformation = new LongTerm(fna.getLongTermSaving());
        }
    }

    @Data
    @NoArgsConstructor
    public static class FnaBase {
        @ApiModelProperty(value = "key", example = "ChildEducation")
        @FieldMetaJson("{displayName:'Key', nullable:false, validations:'notBlank'}")
        protected String key;

        @ApiModelProperty(value = "value", example = "5")
        @FieldMetaJson("{displayName:'Value', nullable:false, validations:'greaterThan~-0'}")
        protected int value;

        public FnaBase(Base b) { key = b.getKey(); value = CommonHelper.parseIntOrDef(b.getValue(), 0); }
    }

    @Data
    @NoArgsConstructor
    public static class ChildDetail {
        private Name name;

        @ApiModelProperty(required = true, value = "Birth Date", example = "1983-09-30")
        @FieldMetaJson("{displayName:'Birth Date', nullable:false, validations:'notBlank,isDate~yyyy-MM-dd~false'}")
        private String birthDate;

        @ApiModelProperty(value = "gender", example = "Female")
        @FieldMetaJson("{displayName:'Gender', nullable:false, validations:'notBlank'}")
        private String gender;

        @ApiModelProperty(value = "aspiration", example = "1")
        @FieldMetaJson("{displayName:'Aspiration', nullable:false, validations:'greaterThan~-0'}")
        private int aspiration;

        public ChildDetail(ChildInfo info) {
            this.name = new Name("", info.getFirstName(), info.getLastName(), "");
            this.birthDate = info.getDateOfBirth();
            this.gender = info.getGender();
            this.aspiration = Integer.valueOf(info.getAspiration());
        }
    }

    @Data
    @EqualsAndHashCode(callSuper = false)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @NoArgsConstructor
    public static class FinacialGoal {
        private GoalDetail detail;
        private String     key;

        public FinacialGoal(FnaGoal goal) { this.key = goal.getKey(); this.detail = new GoalDetail(goal.getDetails()); }
    }

    @Data
    @NoArgsConstructor
    public static class GoalDetail {

        @ApiModelProperty(position = 2, dataType = "List", example = "[\"Child Education\"]")
        private List<String>      goalNames;
        private List<ChildDetail> otherInformations;

        public GoalDetail(FinacialGoalDetail goal) {
            if (!Objects.isNull(goal)) {
                ofNullable(goal.getGoalNames()).ifPresent(gn -> goalNames = goal.getGoalNames());
                otherInformations = new ArrayList<>();
                if (goal.getOtherInfo() != null) {
                    goal.getOtherInfo().forEach(info -> otherInformations.add(new ChildDetail(info)));
                }
            }
        }
    }

    @Data
    @NoArgsConstructor
    public static class Summary {
        @FieldMetaJson("{displayName:'Stage',nullable:false}")
        private FnaDetail stage;

        @FieldMetaJson("{displayName:'Risk',nullable:false}")
        private FnaDetail risk;

        @FieldMetaJson("{displayName:'Goals',nullable:false}")
        private List<FinacialGoal> goals;

        public Summary(FnaSummary summary) {
            this.stage = new FnaDetail(summary.getStage());
            this.risk = new FnaDetail(summary.getRisk());
            goals = new ArrayList<>();
            summary.getGoals().forEach(goal -> goals.add(new FinacialGoal(goal)));
        }

    }

    @Data
    @NoArgsConstructor
    public static class LongTerm {
        private String longTermSaving;
        private String longTermSavingDetail;

        public LongTerm(LongTermSave longTerm) {
            this.longTermSaving = longTerm.getLongTermSaving();
            this.longTermSavingDetail = longTerm.getLongTermSavingDetails();
        }
    }

    @Data
    @NoArgsConstructor
    public static class FnaDetail {
        @ApiModelProperty(value = "isActive", example = "true")
        @FieldMetaJson("{displayName:'Active',nullable:false}")
        @JsonProperty("isActive")
        private boolean isActive;

        @ApiModelProperty(value = "code", example = "3")
        @FieldMetaJson("{displayName:'code', nullable:false, validations:'greaterThan~-0'}")
        private int code;

        @ApiModelProperty(value = "description", example = "You are 18 years and above, married and have children")
        @FieldMetaJson("{displayName:'description', nullable:false, validations:'notBlank'}")
        private String description;

        @ApiModelProperty(value = "key", example = "3")
        @FieldMetaJson("{displayName:'key', nullable:false, validations:'greaterThan~-0'}")
        private int key;

        @ApiModelProperty(value = "order", example = "3")
        @FieldMetaJson("{displayName:'order', nullable:false, validations:'greaterThan~-0'}")
        private int order;

        @ApiModelProperty(value = "icon", example = "tab_icon_single")
        @FieldMetaJson("{displayName:'icon', nullable:false, validations:'notBlank'}")
        private String icon;

        @ApiModelProperty(value = "value", example = "Young Parents")
        @FieldMetaJson("{displayName:'value', nullable:false, validations:'notBlank'}")
        private String value;

        public FnaDetail(FinancialAnalysisDetail detail) {
            this.isActive = detail.isActive();
            ofNullable(detail.getCode()).ifPresent(c -> this.code = Integer.valueOf(detail.getCode()));
            this.description = detail.getDescription();
            ofNullable(detail.getKey()).ifPresent(k -> this.key = Integer.valueOf(detail.getKey()));
            this.value = detail.getValue();
            this.order = detail.getOrder();
            this.icon = detail.getIcon();
        }
    }

    private Fna fna;
}
