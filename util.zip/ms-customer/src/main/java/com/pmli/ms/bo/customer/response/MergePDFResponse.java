package com.pmli.ms.bo.customer.response;

import lombok.Data;

@Data
public class MergePDFResponse {
	private String key;
	private int count;
	private String customerType;
	private String extension;
}
