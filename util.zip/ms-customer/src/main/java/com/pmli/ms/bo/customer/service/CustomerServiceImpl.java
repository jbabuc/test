package com.pmli.ms.bo.customer.service;

import static java.util.Optional.ofNullable;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.pmli.bo.cron.app.ApplicationNumberRetry;
import com.pmli.ms.bo.customer.client.FileStorageHelper;
import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.comm.OtpClient;
import com.pmli.ms.bo.customer.comm.OtpClient.GenerateOtpResponse;
import com.pmli.ms.bo.customer.comm.SmsClient;
import com.pmli.ms.bo.customer.config.AddPremiumProps;
import com.pmli.ms.bo.customer.config.AddRidersProps;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.ms.bo.customer.config.CreateApplicationProps;
import com.pmli.ms.bo.customer.config.DownloadAppFormProps;
import com.pmli.ms.bo.customer.config.FetchApplicationProps;
import com.pmli.ms.bo.customer.config.PaymentProps;
import com.pmli.ms.bo.customer.config.SaveApplicationProps;
import com.pmli.ms.bo.customer.helper.AddCustomerHelper;
import com.pmli.ms.bo.customer.helper.AddLifestyleInfoHelper;
import com.pmli.ms.bo.customer.helper.AddPremiumHelper;
import com.pmli.ms.bo.customer.helper.AddRidersHelper;
import com.pmli.ms.bo.customer.helper.ApplicationCrmHelper;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.helper.CreateApplicationHelper;
import com.pmli.ms.bo.customer.helper.CreateApplicationHelperMgfp;
import com.pmli.ms.bo.customer.helper.CreateBasicLeadHelper;
import com.pmli.ms.bo.customer.helper.CriticalInfoHelper;
import com.pmli.ms.bo.customer.helper.DocumentInfoHelper;
import com.pmli.ms.bo.customer.helper.FetchApplicationHelper;
import com.pmli.ms.bo.customer.helper.FnaHelper;
import com.pmli.ms.bo.customer.helper.LeadDetailBiHelper;
import com.pmli.ms.bo.customer.helper.MergePdfHelper;
import com.pmli.ms.bo.customer.helper.PaymentServiceHelper;
import com.pmli.ms.bo.customer.helper.PersonalInfoHelper;
import com.pmli.ms.bo.customer.helper.PremiumCalculationReqHelper;
import com.pmli.ms.bo.customer.helper.AddPOPIHelper;
import com.pmli.ms.bo.customer.model.CriticalInfoDetail;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.DocumentInfo;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.model.FinancialAnalysis;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.model.LeadDetailPayment;
import com.pmli.ms.bo.customer.model.LeadDetailPremium;
import com.pmli.ms.bo.customer.model.LifeStyleInfo;
import com.pmli.ms.bo.customer.model.PersonalInfo;
import com.pmli.ms.bo.customer.request.ACHADMRequest;
import com.pmli.ms.bo.customer.request.AddPremiumRequest;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationMFGPRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.CreateBasicLeadRequest;
import com.pmli.ms.bo.customer.request.CriticalInfoRequest;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest;
import com.pmli.ms.bo.customer.request.DownloadAppFormRequest;
import com.pmli.ms.bo.customer.request.FetchApplicationRequest;
import com.pmli.ms.bo.customer.request.FnaRequest;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest;
import com.pmli.ms.bo.customer.request.LeadListRequest;
import com.pmli.ms.bo.customer.request.LifeStyleInfoRequest;
import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.ms.bo.customer.request.PersonalInfoRequest;
import com.pmli.ms.bo.customer.request.PremiumCalcClientReq;
import com.pmli.ms.bo.customer.request.RidersRequest;
import com.pmli.ms.bo.customer.request.StepRequest;
import com.pmli.ms.bo.customer.request.AddPOPIRequest;
import com.pmli.ms.bo.customer.request.ValidateOtpRequest;
import com.pmli.ms.bo.customer.response.AddCustomerResponse;
import com.pmli.ms.bo.customer.response.ApplicationCrmResponse;
import com.pmli.ms.bo.customer.response.CreateApplicationMGFPResponse;
import com.pmli.ms.bo.customer.response.CreateApplicationResponse;
import com.pmli.ms.bo.customer.response.CreateBasicLeadDetailResponse;
import com.pmli.ms.bo.customer.response.DownloadAppFormResponse;
import com.pmli.ms.bo.customer.response.DownloadBiResponse;
import com.pmli.ms.bo.customer.response.FetchApplicationResponse;
import com.pmli.ms.bo.customer.response.GetApplicationResponse;
import com.pmli.ms.bo.customer.response.LeadDetailBiResponse;
import com.pmli.ms.bo.customer.response.LeadDetailResponse;
import com.pmli.ms.bo.customer.response.LeadListResponse;
import com.pmli.ms.bo.customer.response.MessageResponse;
import com.pmli.ms.bo.customer.response.PremiumCalculationNvestResponse;
import com.pmli.ms.bo.customer.response.PremiumCalculationNvestResponse.BIJson;
import com.pmli.ms.bo.customer.response.PremiumCalculationResponse;
import com.pmli.ms.bo.customer.response.UpdateApplicationResponse;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.validation.ListValidator;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.validation.Validator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;
import com.pmli.util.web.client.RestConsumer;

/**
 * This is the service implementation layer which implements the methods defined
 * under {@code CustomerService}.
 * <p>
 * The services implemented under this class are listed below:
 * </p>
 * <ul>
 * <li>Calculate Premium</li>
 * <li>Create Application</li>
 * <li>Download BI</li>
 * <li>Add Payment</li>
 * <li>Create Application</li>
 * <li>Update Application</li>
 * <li>Fetch Application</li>
 * <li>Add Fna</li>
 * <li>Add Customer Detail</li>
 * <li>Add Riders</li>
 * <li>Add Step</li>
 * <li>Add ACHADM</li>
 * <li>Get Applications</li>
 * <li>Add Personal Info</li>
 * <li>Add LifeStyleInfo Info</li>
 * <li>Add Critical Info</li>
 * <li>Add Document Info</li>
 * <li>Merge-PDF</li>
 * <li>Create Basic Lead Detail</li>
 * <li>Validate OTP</li>
 * <li>Create Lead Detail for Web BI
 * <li>
 * <li>Get Lead List</li>
 * </ul>
 * 
 * @author Vishal Mali
 */
@Service
@DefaultProperties(defaultFallback = "hystrixFallback")
public class CustomerServiceImpl extends MsObject implements CustomerService {

	private static final String QUOTATION_ID = "Quotation Id";

	@Autowired
	private DBClient dbClient;

	@Autowired
	private RestConsumer restConsumer;

	@Autowired
	private PaymentProps paymentProps;

	@Autowired
	private FetchApplicationProps fetchAppProps;

	@Autowired
	private CommonProps commonProps;

	@Autowired
	private AddRidersProps rdProps;

	@Autowired
	private AddPremiumProps premProps;

	@Autowired
	private CreateApplicationProps createApplicationProps;

	@Autowired
	private SaveApplicationProps saveApplicationProps;

	@Autowired
	private DownloadAppFormProps downloadAppFormProps;

	@Autowired
	private SmsClient smsClient;

	@Autowired
	private EmailClient emailClient;

	@Autowired
	private OtpClient otpClient;

	@Autowired
	private CommonHelper commonHelper;

	public Object hystrixFallback() {
		String logMessage = Arrays.asList(Thread.currentThread().getStackTrace()).stream()
				.map(StackTraceElement::toString).collect(Collectors.joining("\n"));
		log.info("Method unable to respond in the given timeout limit: {}", logMessage);

		throw new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.FALLBACK_ERROR_108,
				commonProps.getHystrixErrorMessage(), commonProps.getHystrixErrorInfo());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.calculatePremium", ignoreExceptions = { Exception.class })
	public Object calculatePremium(PremiumCalcClientReq request) {
		new ValidationHelper(request).validateWithMetaJson();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		if (!StringUtils.isEmpty(request.getLeadId())) {
			LeadDetail ld = dbClient.getLeadDetail(request.getLeadId());
			checkDataNotFound(ld, commonProps.getErrMsgInvalidLeadId(), commonProps.getErrorMsgRecordNotFound());
		}
		PremiumCalculationReqHelper premiumCalculationHelper = new PremiumCalculationReqHelper(
				createApplicationProps.getErrorProductId(), dbClient);
		String nvestResponseStr = restConsumer.callClientEndPoint(commonProps.getNVestUrl(), headers,
				JsonUtil.writeValueAsString(premiumCalculationHelper.preparePremiumCalculationRequest(request)));
		PremiumCalculationNvestResponse pcnr = JsonUtil.readValue(nvestResponseStr,
				PremiumCalculationNvestResponse.class);
		if (pcnr.getBiJson() != null && !pcnr.getBiJson().isEmpty())
			pcnr.setBiJsonList(
					JsonUtil.readArray(pcnr.getBiJson().replace("\\\"", "\""), false, false, false, BIJson.class));
		if (pcnr.getBiJson2() != null && !pcnr.getBiJson2().isEmpty())
			pcnr.setBiJson2List(
					JsonUtil.readArray(pcnr.getBiJson2().replace("\\\"", "\""), false, false, false, BIJson.class));
		// Update Quotation Id
		if (!StringUtils.isEmpty(request.getLeadId())) {
			dbClient.saveLeadDetail(request.getLeadId(), new Document("quotationId", pcnr.getQuotationId()));
			log.info("Quotation ID is updated in database against leadId :- {}", request.getLeadId());
		}
		return new PremiumCalculationResponse(pcnr);
	}

	/**
	 * @param quotationId
	 * @return String response
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.downloadBi", ignoreExceptions = { Exception.class })
	public Object downloadBi(String quotationId) {
		new StringValidator(quotationId, QUOTATION_ID, false).validateEx(StringValidator::notNullMatchesRegEx,
				Constants.DIGITS_1_32_REGEX, "Quotation Id must not be blank with max 32 digits.");
		DownloadBiResponse response = null;
		String result = restConsumer.callClientGetEndPoint(commonProps.getDownloadBiUrl() + quotationId);
		if (result != null && null != (Document.parse(result).getString("dataString"))) {
			Document doc = Document.parse(result);
			response = new DownloadBiResponse(doc.getString("dataString"));
		} else {
			checkDataNotFound(response, commonProps.getErrMsgDataNotFound(), "Data Not Found for this Quotation Id");
		}

		return response;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.downloadAppForm", ignoreExceptions = { Exception.class })
	public Object downloadAppForm(String key) {
		new StringValidator(key, "key", false).validateEx(StringValidator::notNullMatchesRegEx,
				Constants.DIGITS_1_32_REGEX, downloadAppFormProps.getErrMsgKeyLength());
		LeadDetail ld = dbClient.getLeadDetail(key);
		checkDataNotFound(ld, commonProps.getErrMsgDataNotFound(), downloadAppFormProps.getErrMsgDataNotFoundKey());
		String applicationNumber = ld.getApplicationNumber();
		if (null == applicationNumber || applicationNumber.isEmpty()) {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
					commonProps.getErrMsgDataNotFound(), downloadAppFormProps.getErrMsgAppNumNotPresent());
		}
		DownloadAppFormRequest dafr = new DownloadAppFormRequest(applicationNumber,
				downloadAppFormProps.getDocumentClass(), downloadAppFormProps.getIsWrite());

		// call to token web service to get the token
		String token = commonHelper.getToken();

		// call to download-doc external web serivce
		String json = JsonUtil.writeValueAsString(dafr);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", token);
		headers.set("X-IBM-Client-Id", downloadAppFormProps.getXIbmClientId());
		headers.set("X-IBM-Client-Secret", downloadAppFormProps.getXIbmClientSecret());
		headers.set("requestId", downloadAppFormProps.getRequestId());
		headers.set("channel", downloadAppFormProps.getChannel());
		headers.set("userId", downloadAppFormProps.getUserId());
		headers.set("source", downloadAppFormProps.getSource());
		String res = restConsumer.callClientEndPoint(downloadAppFormProps.getDownloadAppFormUrl(), headers, json);
		DownloadAppFormResponse response = null;
		if (res != null && null != (Document.parse(res).get("body"))) {
			Document body = (Document) Document.parse(res).get("body");
			if (null != body.getString("document")) {
				response = new DownloadAppFormResponse(body.getString("document"), "File Content Fetched Successfully");
			} else {
				response = new DownloadAppFormResponse("", body.getString("message"));
			}
		} else {
			checkDataNotFound(response, commonProps.getErrMsgDataNotFound(),
					downloadAppFormProps.getErrMsgDataNotFoundKey());
		}
		return response;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addPayment", ignoreExceptions = { Exception.class })
	public Object addPayment(PaymentRequest paymentRequest) {
		PaymentServiceHelper paymentServiceHelper = new PaymentServiceHelper(dbClient, paymentProps, commonProps,
				smsClient, emailClient, paymentRequest);

		paymentServiceHelper.validate();
		LeadDetailPayment paymentLeadDetail = null;
		try {
			paymentLeadDetail = new LeadDetailPayment(paymentRequest);
		} catch (ParseException e) {
			log.error("Date format is not proper :- {}", e.getMessage());
		}
		String jsonString = JsonUtil.writeValueAsString(paymentLeadDetail);
		Document documentRequest = Document.parse(jsonString);
		LeadDetail dbLeadDetail = dbClient.getLeadDetailByIdOrAppNo(paymentRequest.getLeadId(),
				paymentRequest.getApplicationNumber());
		// Checks the leadId or App Num is valid
		checkDataNotFound(dbLeadDetail, paymentProps.getErrorMsgInvalidLeadIdAppnum(),
				commonProps.getErrorMsgRecordNotFound());

		String dbjsonStr = JsonUtil.writeValueAsString(dbLeadDetail);
		Document dbDocReq = Document.parse(dbjsonStr);
		// Checks the payment object present against the leadId in DB
		if (null != dbLeadDetail.getPayment()) {
			log.error("Payment object is already present :- {}", dbLeadDetail.getPayment());
			throw new ApplicationException(HttpStatus.BAD_REQUEST, ErrCode.DATA_NOT_FOUND_105,
					paymentProps.getErrorMsgPaymentAlreadyPresent(), paymentProps.getErrorMsgPaymentAlreadyPresent());
		}
		dbClient.saveLeadDetail(dbLeadDetail.getLeadId(), documentRequest);
		paymentServiceHelper.paymentSendSMS(dbDocReq);
		paymentServiceHelper.paymentSendEmail(dbDocReq, paymentLeadDetail);
		return PaymentServiceHelper.prepareUpdatePaymentResponse(paymentProps, commonProps, dbLeadDetail.getLeadId());
	}

	@Override
	@HystrixCommand(commandKey = "bo.post.createApplication", ignoreExceptions = { Exception.class })
	public Object createApplication(CreateApplicationRequest createApplicationRequest) {
		new ValidationHelper(createApplicationRequest).validateWithMetaJson();
		CreateApplicationHelper createApplicationHelper = new CreateApplicationHelper(dbClient,
				createApplicationRequest);
		createApplicationHelper.validate("create");

		String leadId = commonHelper.generateLeadId();

		LeadDetail leadDetail = new LeadDetail(createApplicationRequest, leadId,
				dbClient.getMasterKeyByTypeValue("title", createApplicationRequest.getName().getTitle()),
				createApplicationHelper.getFamilyMemberSuffix(), createApplicationHelper.getJointLifeName());
		leadDetail.setExpiredOn(CreateApplicationHelper.getExpirationDate());

		dbClient.saveLeadDetail(leadDetail);

		String applicationNumber = null;

		ApplicationCrmRequest saveRequest = ApplicationCrmHelper
				.prepareRequestforSaveApplication(createApplicationRequest, dbClient);
		ApplicationCrmHelper applicationCrmHelper = new ApplicationCrmHelper(dbClient, emailClient, commonProps,
				restConsumer, saveApplicationProps, paymentProps, saveRequest);
		ApplicationCrmResponse saveApplicationResponse = applicationCrmHelper.saveApplicationToCrm();

		if (null != saveApplicationResponse && null != saveApplicationResponse.getBody()
				&& null != saveApplicationResponse.getBody().getApplicationNumber()) {
			leadDetail.setApplicationNumber(saveApplicationResponse.getBody().getApplicationNumber());
			applicationCrmHelper.updateApplicationNumber(leadDetail);
			applicationNumber = saveApplicationResponse.getBody().getApplicationNumber();
		}
		return new CreateApplicationResponse(leadId, applicationNumber);
	}

	@Override
	@HystrixCommand(commandKey = "bo.post.updateApplication", ignoreExceptions = { Exception.class })
	public Object updateApplication(CreateApplicationRequest createApplicationRequest) {
		new ValidationHelper(createApplicationRequest).validateWithMetaJson();
		CreateApplicationHelper createApplicationHelper = new CreateApplicationHelper(dbClient,
				createApplicationRequest);
		createApplicationHelper.validate("update");

		LeadDetail mongoTransformRequest = new LeadDetail(createApplicationRequest,
				createApplicationRequest.getLeadId(),
				dbClient.getMasterKeyByTypeValue("title", createApplicationRequest.getName().getTitle()),
				createApplicationHelper.getFamilyMemberSuffix(), createApplicationHelper.getJointLifeName());

		String json = JsonUtil.writeValueAsString(mongoTransformRequest);
		Document documentRequest = Document.parse(json);
		documentRequest.remove(FieldConstants.LD_LEADID);
		documentRequest.remove(FieldConstants.LD_QUOTATIONID);
		documentRequest.remove(FieldConstants.LD_CREATED_ON);
		documentRequest.remove(FieldConstants.LD_LAST_UPDATED_ON);
		documentRequest.remove(FieldConstants.LD_EXPIRED_ON);
		documentRequest.remove(FieldConstants.LD_APPLICATIONUMBER);
		documentRequest.remove(FieldConstants.LD_RECORD_STATUS);

		LeadDetail dbLeadDetail = dbClient.getLeadDetailByIdOrAppNo(createApplicationRequest.getLeadId(),
				createApplicationRequest.getApplicationNumber());
		Object ret = null;

		checkDataNotFound(dbLeadDetail, fetchAppProps.getErrorMsgDataNotFound(), fetchAppProps.getErrorMsgDetail());

		if (!StringUtils.isEmpty(dbLeadDetail.getApplicationNumber())) {
			createApplicationRequest.setQuotationId(dbLeadDetail.getQuotationId());
			createApplicationRequest.setApplicationNumber(dbLeadDetail.getApplicationNumber());

			ApplicationCrmRequest saveRequest = ApplicationCrmHelper
					.prepareRequestforSaveApplication(createApplicationRequest, dbClient);
			ApplicationCrmHelper applicationCrmHelper = new ApplicationCrmHelper(dbClient, emailClient, commonProps,
					restConsumer, saveApplicationProps, paymentProps, saveRequest);
			ret = applicationCrmHelper.saveApplicationToCrm();
		}
		documentRequest.append(FieldConstants.LD_RECORD_STATUS,
				dbLeadDetail.getRecordStatus().replace(ApplicationNumberRetry.RECORD_STATUS_UPDATE_FAIL, "")
						+ (ret != null ? "" : ApplicationNumberRetry.RECORD_STATUS_UPDATE_FAIL));

		long nUpdates = dbClient.saveLeadDetail(dbLeadDetail.getLeadId(), documentRequest);

		checkLeadNotFound(nUpdates);

		return new UpdateApplicationResponse(dbLeadDetail.getLeadId(), dbLeadDetail.getApplicationNumber(),
				createApplicationProps.getUpdateApplicationSuccessMessage());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.fetchApplication", ignoreExceptions = { Exception.class })
	public Object fetchApplication(FetchApplicationRequest fetchApplicationRequest) {
		String filter = new FetchApplicationHelper(fetchAppProps, fetchApplicationRequest).getFilter();
		Document doc = dbClient.fetchApplication(filter);
		checkDataNotFound(doc, fetchAppProps.getErrorMsgDataNotFound(), fetchAppProps.getErrorMsgDetail());
		return new FetchApplicationResponse(doc.getString(FieldConstants.LD_LEADID),
				doc.getString(FieldConstants.LD_QUOTATIONID), doc.getString(FieldConstants.LD_APPLICATIONUMBER));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addFna", ignoreExceptions = { Exception.class })
	public Object addFna(FnaRequest fnaRequest) {
		new FnaHelper(fnaRequest).validate();
		long updateCount = ofNullable(dbClient.getLeadDetail(fnaRequest.getLeadId())).map(lead -> {
			lead.setFna(new FinancialAnalysis(fnaRequest.getFna()));
			return dbClient.saveLeadDetail(lead);
		}).orElse(0l);
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getFnaSuccess());
	}

	/*
	 * 
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addCustomer", ignoreExceptions = { Exception.class })
	public Object addCustomerDetails(CustomerRequest addCustomerRequest) {
		new ValidationHelper(addCustomerRequest).validateWithMetaJson();
		AddCustomerHelper ach = new AddCustomerHelper(dbClient, commonProps, addCustomerRequest, commonHelper);
		return new AddCustomerResponse(ach.save(ach.prepare()), commonProps.getAddCustomerSuccess());
	}

	/**
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addRiders", ignoreExceptions = { Exception.class })
	public Object addRiders(RidersRequest addRidersRequest) {
		new AddRidersHelper(dbClient, rdProps, addRidersRequest).validate();
		LeadDetail ld = dbClient.getLeadDetail(addRidersRequest.getLeadId());
		checkDataNotFound(ld, commonProps.getErrMsgInvalidLeadId(), commonProps.getErrorMsgRecordNotFound());

		List<LeadDetailPremium> leadPremium = addRidersRequest.getRiders().stream().map(LeadDetailPremium::new)
				.collect(Collectors.toList());
		dbClient.saveLeadDetail(addRidersRequest.getLeadId(),
				Document.parse("{'riders':" + JsonUtil.writeValueAsString(leadPremium) + "}"));
		log.info("Riders details is successfully updated in database against leadId :- {}",
				addRidersRequest.getLeadId());
		if (StringUtils.isEmpty(ld.getApplicationNumber())) {
			try {
				ApplicationCrmRequest saveRequest = ApplicationCrmHelper.prepareRequestforSaveApplication(ld, dbClient);
				ApplicationCrmHelper applicationCrmHelper = new ApplicationCrmHelper(dbClient, emailClient, commonProps,
						restConsumer, saveApplicationProps, paymentProps, saveRequest);
				ApplicationCrmResponse saveApplicationResponse = applicationCrmHelper.saveApplicationToCrm();
				if (!StringUtils.isEmpty(saveApplicationResponse.getBody().getApplicationNumber())) {
					log.info("Application Number generated from API :- {}",
							saveApplicationResponse.getBody().getApplicationNumber());
					dbClient.saveLeadDetail(addRidersRequest.getLeadId(), new Document("applicationNumber",
							saveApplicationResponse.getBody().getApplicationNumber()));
					log.info("Application Number is updated in database aganist leadId :- {}",
							addRidersRequest.getLeadId());
				}
			} catch (Exception ex) {
				// application number fall back job will retry ...
				log.error("Unable to generate Application ID", ex);
			}
		}
		return new MessageResponse(rdProps.getAddRiderSuccess());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addPremium", ignoreExceptions = { Exception.class })
	public Object addPremium(AddPremiumRequest addPremiumRequest) {
		AddPremiumHelper aph = new AddPremiumHelper(dbClient, createApplicationProps, addPremiumRequest);
		aph.validate();
		long updateCount = dbClient.saveLeadDetail(addPremiumRequest.getLeadId(),
				Document.parse(aph.preparePremiumJson()));
		checkLeadNotFound(updateCount);
		return new MessageResponse(premProps.getAddPremiumSuccess());
	}

	/**
	 * Add Step for exiting lead
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addStep", ignoreExceptions = { Exception.class })
	public Object addStep(StepRequest addStepRequest) {
		new ValidationHelper(addStepRequest).validateWithMetaJson();
		long updateCount = dbClient.saveLeadDetail(addStepRequest.getLeadId(),
				new Document().append("step", addStepRequest.getStep()));
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getMsgAddStepSuccess());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addAchadm", ignoreExceptions = { Exception.class })
	public Object addACHADM(ACHADMRequest addACHADMRequest) {
		new ValidationHelper(addACHADMRequest).validateWithMetaJson();
		long updateCount = dbClient.saveLeadDetail(addACHADMRequest.getLeadId(),
				new Document().append("isACHADM", addACHADMRequest.isAchadm()));
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getMsgAddACHADMSuccess());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.getApplication", ignoreExceptions = { Exception.class })
	public Object getApplications(String mobileNum) {
		final String fieldValidations = "notBlank,notNull,matchesRegEx~$errmsg:"
				+ commonProps.getErrMsgShouldBe10DigitOnly() + "~[0-9]{10}";
		new StringValidator(mobileNum, "Mobile number ", false).validateAll(fieldValidations);
		List<LeadDetail> ld = dbClient.getLeadDetailsByAnyField(FieldConstants.LD_MOBILE_NUMBER, mobileNum);
		checkDataNotFound(ld, fetchAppProps.getErrorMsgDataNotFound(),
				commonProps.getNoRecordFoundMobile() + " " + mobileNum);
		return new GetApplicationResponse(ld);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addLifetstyleInfo", ignoreExceptions = { Exception.class })
	public Object addLifetstyleInfo(LifeStyleInfoRequest lifeStyleInfoRequest) {
		new ValidationHelper(lifeStyleInfoRequest).validateWithMetaJson();
		AddLifestyleInfoHelper addLifestyleInfoHelper = new AddLifestyleInfoHelper(dbClient, commonProps,
				lifeStyleInfoRequest);
		addLifestyleInfoHelper.validate(lifeStyleInfoRequest);
		long updateCount = ofNullable(dbClient.getLeadDetail(lifeStyleInfoRequest.getLeadId())).map(lead -> {
			lead.setLifeStyleInfo(new LifeStyleInfo(lifeStyleInfoRequest.getLifeStyleInfo(), addLifestyleInfoHelper));
			return dbClient.saveLeadDetail(lead);
		}).orElse(0l);
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getAddLifetstyleSuccess());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addPersonalInfo", ignoreExceptions = { Exception.class })
	public Object addPersonalInfo(PersonalInfoRequest personalInfoRequest) {
		new ValidationHelper(personalInfoRequest).validateWithMetaJson();
		new PersonalInfoHelper(dbClient, commonProps, personalInfoRequest).validate();
		long updateCount = ofNullable(dbClient.getLeadDetail(personalInfoRequest.getLeadId())).map(lead -> {
			lead.setPersonalInfo(new PersonalInfo(personalInfoRequest.getPersonalInfo(), dbClient));
			return dbClient.saveLeadDetail(lead);
		}).orElse(0l);
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getMsgPersonalInfoSuccess());
	}

	@Override
	@HystrixCommand(commandKey = "bo.post.addCriticalInfo", ignoreExceptions = { Exception.class })
	public Object addCriticalInfo(CriticalInfoRequest criticalInfoRequest) {
		new ValidationHelper(criticalInfoRequest).validateWithMetaJson();
		new CriticalInfoHelper().validate(criticalInfoRequest);
		long updateCount = ofNullable(dbClient.getLeadDetail(criticalInfoRequest.getLeadId())).map(lead -> {
			lead.setCriticalInfoDetails(new CriticalInfoDetail(criticalInfoRequest.getCriticalInfoDetails()));
			return dbClient.saveLeadDetail(lead);
		}).orElse(0l);
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getMsgCriticalInfoSuccess());
	}

	@Override
	@HystrixCommand(commandKey = "bo.post.downloadPdf", ignoreExceptions = { Exception.class })
	public Object getDownloadPdf(String leadId) {
		new StringValidator(leadId, "Lead Id", false).validateEx(StringValidator::notNullMatchesRegEx,
				Constants.DIGITS_1_32_REGEX, "Lead Id must not be blank with max 32 digits.");
		LeadDetail dbLeadDetail = dbClient.getLeadDetail(leadId);
		checkDataNotFound(dbLeadDetail, commonProps.getErrMsgInvalidLeadId(), commonProps.getErrorMsgRecordNotFound());
		return downloadBi(dbLeadDetail.getQuotationId());
	}

	/**
	 * common for lead not found
	 * 
	 * @param updateCount
	 */
	public void checkLeadNotFound(long updateCount) {
		if (updateCount < 1) {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
					commonProps.getErrMsgInvalidLeadId(), commonProps.getLeadNotFound());
		}
	}

	/**
	 * Data Not Found
	 * 
	 * @param obj
	 */
	public void checkDataNotFound(Object obj, String errorDetail, String errorMoreInfo) {
		if (ObjectUtils.isEmpty(obj)) {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105, errorDetail,
					errorMoreInfo);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.get.lead", ignoreExceptions = { Exception.class })
	public Object getLeadDetails(String leadId, String applicationNo) {
		LeadDetail ld = null;
		if (leadId != null) {
			this.checkValidLeadId(leadId);
			ld = dbClient.getLeadDetail(leadId);
		} else if (applicationNo != null) {
			ld = dbClient.getLeadDetailByApplicationNumber(applicationNo);
		}

		checkDataNotFound(ld, commonProps.getErrMsgInvalidLeadId(), commonProps.getErrorMsgRecordNotFound());

		return new LeadDetailResponse(ld, dbClient, commonProps);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "bo.post.addDocumentInfo", ignoreExceptions = { Exception.class })
	public Object addDocumentInfo(DocumentInfoRequest request) {
		new ValidationHelper(request).validateWithMetaJson();
		String quotationId = "1890";
		new StringValidator(quotationId, QUOTATION_ID, false).notNullNotBlank();
		DocumentInfoHelper helper = new DocumentInfoHelper(dbClient, commonProps, request);
		DocumentInfoRequest documentInfoRequest = helper.validate(quotationId);
		if (documentInfoRequest != null) {
			long updateCount = ofNullable(dbClient.getLeadDetail(request.getLeadId())).map(lead -> {
				lead.setDocumentInfoDetails(new DocumentInfo(request.getDocumentInfoDetails()));
				return dbClient.saveLeadDetail(lead);
			}).orElse(0l);
			checkLeadNotFound(updateCount);
		} else {
			throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
					commonProps.getErrMsgDataNotFound(), commonProps.getErrMsgDataNotFound());
		}
		return new MessageResponse(commonProps.getAddDocumentInfoSuccess());
	}

	@Override
	@HystrixCommand(commandKey = "bo.post.mergePDF", ignoreExceptions = { Exception.class })
	public Object mergePDF(String leadId, String fileCount, String customerType,
			List<MultipartFile> idProofFileUpload) {
		// validate
		checkValidLeadId(leadId);
		new StringValidator(customerType, "customer Type", false);
		new ListValidator(idProofFileUpload, "Files", false).validate(Validator::notNull)
				.validate(ListValidator::isMinLength, 1);
		LeadDetail ld = dbClient.getLeadDetail(leadId);
		checkLeadNotFound(ld != null ? 1 : 0);
		String quotationId = "";
		if (null != ld) {
			quotationId = ld.getQuotationId();
		}
		new StringValidator(quotationId, QUOTATION_ID, false).notNullNotBlank();
		// merge
		MergePdfHelper mph = new MergePdfHelper(quotationId, fileCount, customerType, idProofFileUpload);
		mph.merge();
		FileStorageHelper fileStorageHelper = new FileStorageHelper(restConsumer,
				commonProps.getFileStorageUploadUrl());
		ofNullable(fileStorageHelper).ifPresent(fsh -> mph.getBase64FileDetails().stream().forEach(fsh::storeFile));

		dbClient.saveMergePdfFileRef(
				new FileStorageHelper.FileRefDetails(quotationId, fileStorageHelper.getFileRefs()));
		return mph.getMergePDFResponse();

	}

	private void checkValidLeadId(String leadId) {
		new StringValidator(leadId, "Lead Id", false).validateEx(StringValidator::notNullMatchesRegEx,
				Constants.DIGITS_1_32_REGEX, "Lead Id must not be blank with max 32 digits.");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object addPOPI(AddPOPIRequest request) {
		new ValidationHelper(request).validateWithMetaJson();
		AddPOPIHelper updatePOPIHelper = new AddPOPIHelper(request, dbClient, commonProps);
		updatePOPIHelper.validate();
		long updateCount = ofNullable(dbClient.getLeadDetail(request.getLeadId()))
				.map(lead -> dbClient.saveLeadDetail(updatePOPIHelper.preparedData(lead))).orElse(0l);
		checkLeadNotFound(updateCount);
		return new MessageResponse(commonProps.getUpdatePOPISuccess());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object createBasicLead(CreateBasicLeadRequest cblr) {
		new CreateBasicLeadHelper().validateCreateBasicLeadRequest(cblr);
		String leadId = commonHelper.generateLeadId();
		LeadDetail leadDetail = new LeadDetail(cblr, leadId, dbClient, commonProps);
		dbClient.saveLeadDetail(leadDetail);
		log.info("Basic lead detail is saved in DB for lead ID :- {}", leadId);
		ResponseEntity<String> response = otpClient.generateOtp(leadDetail.getMobileNumber(), leadDetail.getEmailId());
		if (response.getStatusCode() == HttpStatus.OK) {
			LeadDetail ld = dbClient.getLeadDetail(leadId);
			GenerateOtpResponse otpResponse = JsonUtil.readValue(response.getBody(), GenerateOtpResponse.class);
			return new CreateBasicLeadDetailResponse(leadId, otpResponse.getTransactionId(), ld);
		}
		return response;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object validateOtp(ValidateOtpRequest validateOtpRequest) {
		new ValidationHelper(validateOtpRequest).validateWithMetaJson();
		ResponseEntity<String> re = otpClient.validateOtp(validateOtpRequest.getTransactionId(),
				validateOtpRequest.getOtp());
		if (re.getStatusCode() == HttpStatus.OK) {
			long updateCount = ofNullable(dbClient.getLeadDetail(validateOtpRequest.getLeadId())).map(lead -> {
				lead.setTransactionId(validateOtpRequest.getTransactionId());
				lead.setOtp(validateOtpRequest.getOtp());
				return dbClient.saveLeadDetail(lead);
			}).orElse(0l);
			checkLeadNotFound(updateCount);
		}
		return new ResponseEntity<String>(re.getBody(), re.getStatusCode());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object createLeadDetail(LeadDetailBiRequest requestPayload) {
		// validate the request payload
		new LeadDetailBiHelper().validateLeadDetailBiRequest(requestPayload);

		// calculate age from birthDate and set into request for po
		int age = CommonHelper.getAge(requestPayload.getBirthDate());
		requestPayload.setAge(age);
		// calculate age from birthDate and set into request for jontlife
		if (StringUtils.isNotBlank(requestPayload.getJointLifeBirthDate()))
			requestPayload.setJointLifeAge(CommonHelper.getAge(requestPayload.getJointLifeBirthDate()));

		// create leadId and get title from master table to save the lead in DB
		if (!ObjectUtils.isEmpty(requestPayload.getName())) {
			String title = StringUtils.isEmpty(requestPayload.getName().getTitle()) ? ""
					: dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeTitle(),
							requestPayload.getName().getTitle());
			requestPayload.setTitle(title);
		}
		// get gender value (Male/Female) from master table based on the code and set
		// into request
		String gender = StringUtils.isEmpty(requestPayload.getGender()) ? ""
				: dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeGender(),
						requestPayload.getGender());
		requestPayload.setGender(gender);
		// generate the leadId and set into request
		String leadId = commonHelper.generateLeadId();
		requestPayload.setLeadId(leadId);
		// create lead detail object based on the request inputs and set the expiry date
		LeadDetail leadDetail = new LeadDetail(requestPayload);
		leadDetail.setExpiredOn(CreateApplicationHelper.getExpirationDate());
		// save lead detail in DB and return the response object with the created leadId
		// and the continue journey link
		// the continue journey link will have the encrypted leadId
		dbClient.saveLeadDetail(leadDetail);

		log.info("Basic lead detail for web bi is saved in DB for lead ID :- {}", leadId);
		return new LeadDetailBiResponse(leadId, commonHelper.getPropposalFormLink(requestPayload.getLeadId()));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object createApplicationMgfp(CreateApplicationMFGPRequest requestPayload) {
		new ValidationHelper(requestPayload).validateWithMetaJson();
		new CreateApplicationHelperMgfp(dbClient, requestPayload).validate();

		LeadDetail dbLd = dbClient.getLeadDetail(requestPayload.getLeadId());
		checkLeadNotFound(dbLd != null ? 1 : 0);
		String appNum = null;
		try {
			LeadDetail reqLd = new LeadDetail(requestPayload);
			reqLd.setExpiredOn(CreateApplicationHelper.getExpirationDate());
			if (null != dbLd && StringUtils.isEmpty(dbLd.getApplicationNumber())) {
				ApplicationCrmRequest saveRequest = ApplicationCrmHelper.prepareRequestforSaveApplication(reqLd,
						dbClient);
				ApplicationCrmHelper applicationCrmHelper = new ApplicationCrmHelper(dbClient, emailClient, commonProps,
						restConsumer, saveApplicationProps, paymentProps, saveRequest);
				ApplicationCrmResponse saveApplicationResponse = applicationCrmHelper.saveApplicationToCrm();
				appNum = saveApplicationResponse.getBody().getApplicationNumber();
				reqLd.setApplicationNumber(saveApplicationResponse.getBody().getApplicationNumber());
			}
			dbClient.saveLeadDetail(reqLd.getLeadId(), CreateApplicationHelperMgfp.setCreateMGFPData(reqLd));
		} catch (Exception ex) {
			// application number fall back job will retry ...
			log.error("Unable to generate Application Number", ex);
		}
		return new CreateApplicationMGFPResponse(appNum, commonHelper.getPropposalFormLink(requestPayload.getLeadId()));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@HystrixCommand(commandKey = "common.timeout", ignoreExceptions = { Exception.class })
	public Object getLeadList(LeadListRequest request) {
		new ValidationHelper(request).validateWithMetaJson();
		List<LeadDetail> ld = dbClient.getLeadDetailsByAnyField(commonProps.getKeyMobileNumber(),
				request.getMobileNumber());
		checkDataNotFound(ld, commonProps.getErrorMsgDataNotFound(), commonProps.getErrorMsgDetail());
		return new LeadListResponse(request, ld, dbClient, commonProps);
	}
}
