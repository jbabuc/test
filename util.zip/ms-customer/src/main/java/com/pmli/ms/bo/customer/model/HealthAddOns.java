package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class HealthAddOns {
    private int noClaimBonusSuperPremium;
    private int unlimitedAutomaticRecharge;
    private int personalAccidentCoverId;
    private String personalAccidentCover;
    private int opdCare;
}
