package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class HealthFamilyAge {
	private String title;
	private String firstName;
    private String lastName;
    private String gender;
    private String relationShip;
    private int age;
    private String dateOfBirth;
}
