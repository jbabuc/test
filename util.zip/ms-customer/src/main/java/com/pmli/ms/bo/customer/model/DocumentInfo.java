package com.pmli.ms.bo.customer.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pmli.ms.bo.customer.request.DocumentInfoRequest;

import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.bson.IsoDateSerializer;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DocumentInfo {
    private Documents poDocuments;
    private Documents piDocuments;
    private Documents jointLifeDocuments;
    private Documents bankDocuments;
    private Documents bankJointLifeDocuments;

    @Data
    @NoArgsConstructor
    public static class Documents {
        private List<Details> details = new ArrayList<>();
    }

    public DocumentInfo(DocumentInfoRequest.DocumentInfoDetails documentInfoDetails) {
        poDocuments = new Documents();
        piDocuments = new Documents();
        jointLifeDocuments = new Documents();
        bankDocuments = new Documents();
        bankJointLifeDocuments = new Documents();

        documentInfoDetails.getPoDocuments().getDetails().stream()
        .forEach(d -> poDocuments.getDetails().add(new Details(d)));
        documentInfoDetails.getPoDocuments().getDetails().stream()
            .forEach(d -> poDocuments.getDetails().add(new Details(d)));
        documentInfoDetails.getPiDocuments().getDetails().stream()
            .forEach(d -> piDocuments.getDetails().add(new Details(d)));
        documentInfoDetails.getJointLifeDocuments().getDetails().stream()
            .forEach(d -> jointLifeDocuments.getDetails().add(new Details(d)));
        documentInfoDetails.getBankDocuments().getDetails().stream()
            .forEach(d -> bankDocuments.getDetails().add(new Details(d)));
        documentInfoDetails.getBankJointLifeDocuments().getDetails().stream()
            .forEach(d -> bankJointLifeDocuments.getDetails().add(new Details(d)));
    }

    @Data
    @NoArgsConstructor
    public static class Details {
        public Details(DocumentInfoRequest.Details d) {
            name = d.getName();
            value = d.getValue();
            proof = d.getProof();
            isFile = d.isFile();
            fileCount = d.getFileCount();
            isVerified = d.isVerified();
            isDocPushed = d.isDocPushed();
            status = d.getStatus();
            message = d.getMessage();
            path = d.getPath();
            try {
                uploadedOn = new SimpleDateFormat(IsoDateDeSerializer.MONGO_DATE_FORMAT).parse(d.getUploadedOn());
            } catch (ParseException e) {
                uploadedOn = new Date();
            }
        }

        private String  name;
        private String  value;
        private String  proof;
        private boolean isFile;
        private int     fileCount;
        private boolean isVerified;
        private boolean isDocPushed;
        private String  status;
        private String  message;
        private String  path;
        @JsonSerialize(using = IsoDateSerializer.class)
        @JsonDeserialize(using = IsoDateDeSerializer.class)
        private Date    uploadedOn;
    }
}
