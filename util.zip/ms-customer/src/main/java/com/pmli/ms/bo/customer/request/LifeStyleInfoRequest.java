package com.pmli.ms.bo.customer.request;

import java.util.List;
import java.util.Objects;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.EInsuranceAccountDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.FamilyDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.FamilyMember;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.InsuranceDetails;
import com.pmli.ms.bo.customer.model.LifeStyleInfo.LifeStyleDetails;
import com.pmli.util.java.FieldMetaJson;
import com.pmli.util.model.Money;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
public class LifeStyleInfoRequest extends LeadRequest {

    private LifeStyleInfo lifeStyleInfo;

    @Data
    @NoArgsConstructor
    public static class LifeStyleInfo {
    	private EInsuranceAccountDetail eInsuranceAccountDetail;
    	private FamilyDetail familyDetail;
    	private InsuranceDetail insuranceDetail;
    	private LifeStyleDetail lifeStyleDetail;

        public LifeStyleInfo(com.pmli.ms.bo.customer.model.LifeStyleInfo m) {
        	if(!Objects.isNull(m)) {
        		ofNullable(m.getLifeStyleDetails()).ifPresent(lsd-> this.lifeStyleDetail = new LifeStyleDetail(m.getLifeStyleDetails()));
            	ofNullable(m.getInsuranceDetails()).ifPresent(lsd-> this.insuranceDetail = new InsuranceDetail(m.getInsuranceDetails()));
            	ofNullable(m.getFamilyDetails()).ifPresent(lsd-> this.familyDetail = new FamilyDetail(m.getFamilyDetails()));
            	ofNullable(m.getEInsuranceAccountDetails()).ifPresent(lsd-> this.eInsuranceAccountDetail = new EInsuranceAccountDetail(m.getEInsuranceAccountDetails()));
        	}
        }
    }

    @Data
    @NoArgsConstructor
    public static class LifeStyleDetail {
        private FlyDetail              flyDetail;
        private EngageInAutoMobile     engageInAutoMobile;
        private CriminalOffence        criminalOffence;
        private ExposedPersonPEP       exposedPersonPEP;
        private PayerOfTrustcharityNGO payerOfTrustcharityNGO;
        private MilitaryorPoliceForce  militaryorPoliceForce;
        private Hazard                 hazard;

		public LifeStyleDetail(LifeStyleDetails lsd) {
			if (!Objects.isNull(lsd)) {
				ofNullable(lsd.getIsFlyDetails())
						.ifPresent(fd -> this.flyDetail = new FlyDetail(isConvert(fd.getIsFly()), fd.getDetail()));

				ofNullable(lsd.getIsEngageInAutoMobile())
						.ifPresent(eiam -> this.engageInAutoMobile = new EngageInAutoMobile(
								isConvert(eiam.getIsEngageInAutoMobile()), eiam.getDetail()));

				ofNullable(lsd.getIsCriminalOffence())
						.ifPresent(criminalOff -> this.criminalOffence = new CriminalOffence(
								isConvert(criminalOff.getIsCriminalOffence()), criminalOff.getDetail()));

				ofNullable(lsd.getExposedPersonPEP()).ifPresent(
						epep -> this.exposedPersonPEP = new ExposedPersonPEP(isConvert(epep.getIsExposedPersonPEP()),
								epep.getDetail()));

				ofNullable(lsd.getPayerOfTrustcharityNGO())
						.ifPresent(ptngo -> this.payerOfTrustcharityNGO = new PayerOfTrustcharityNGO(
								isConvert(ptngo.getIsPayerOfTrustCharityNGO()), ptngo.getDetail()));
				ofNullable(lsd.getHazards()).ifPresent(hzrd -> this.hazard = new Hazard(
						isConvert(lsd.getHazards().getCorrosiveChemicalsAndHTVDrivers()),
						lsd.getHazards().getDetail()));

				ofNullable(lsd.getMilitaryorPoliceForce())
						.ifPresent(mpf -> this.militaryorPoliceForce = new MilitaryorPoliceForce(
								new ArmedServicesQuestionnaire(
										isConvert(
										mpf.getArmedServicesQuestionnaire().getIsArmedServicesQuestionnaire()),
										mpf.getArmedServicesQuestionnaire().getFullnameOfTheApplicant(),
										mpf.getArmedServicesQuestionnaire().getBranchOfArmedForces(),
										mpf.getArmedServicesQuestionnaire().getRank(),
										mpf.getArmedServicesQuestionnaire().getExactNatureOfDuty()),
								new EngagedBombDisposalDriving(
										isConvert(
										mpf.getEngagedBombDisposalDriving().getIsEngagedBombDisposalDriving()),
										mpf.getEngagedBombDisposalDriving().getEngagedinBombDisposalDrivingInfo()),
								new HazardeousActivity(
										isConvert(
										mpf.getHazardeousActivity().getIsHazardeousActivity()),
										mpf.getHazardeousActivity().getHazardeousActivityInfo()),
								new CurrentlyServingIn(
										isConvert(lsd.getMilitaryorPoliceForce().getCurrentlServingIn().getIsCurrentlServingIn()),
										mpf.getCurrentlServingIn().getTroubledAreasInfo()),
								new DetailedActivitesInvolvedIn(mpf.getDetailsActivites().getDetailsActivite()),
								new BasedLocation(mpf.getBasedLocation().getBasedLocationDetail())));
				 
			}
		}
    }

    @Data
    @NoArgsConstructor
    public static class InsuranceDetail {
        @ApiModelProperty(required = true, value = "InsurancePolicies", example = "true")
        private boolean         hasInsurancePolicies;
        private List<Insurance> insurances = new ArrayList<>();

        public InsuranceDetail(InsuranceDetails insuranceDetails) {
        	if(!Objects.isNull(insuranceDetails)) {
        		 ofNullable(insuranceDetails).ifPresent(id -> {
                     this.hasInsurancePolicies = isConvert(insuranceDetails.getIsInsurancePolicies());
                     ofNullable(insuranceDetails.getInsurance())
                         .ifPresent(insurenceList -> insurenceList.forEach(ins -> insurances.add(new Insurance(ins))));
                 });
        	}
           
        }
    }

    @Data
    @NoArgsConstructor
    public static class FamilyDetail {
		@ApiModelProperty(required = true, value = "FamilyMedicalStatus", example = "true")
        @JsonProperty("isFamilyMedicalStatus")
        private boolean                   isFamilyMedicalStatus;
        private List<FamilyMemberDetails> familyMembers= new ArrayList<>();
        
        public FamilyDetail(FamilyDetails familyDetails) {
        	if(!Objects.isNull(familyDetails)){
        		ofNullable(familyDetails.getIsFamilyMedicalStatus()).ifPresent(fd->this.isFamilyMedicalStatus = isConvert(familyDetails.getIsFamilyMedicalStatus()));
        		ofNullable(familyDetails.getFamilyMembers())
				.ifPresent(fmdetailsList -> fmdetailsList.forEach(fmd -> familyMembers.add(new FamilyMemberDetails(fmd))));
        	}
		}
    }

    @Data
    @NoArgsConstructor
    public static class EInsuranceAccountDetail {
        @ApiModelProperty(required = true, value = "EInsurance", example = "true")
        @JsonProperty("isEInsurance")
        private boolean isEInsurance;
        @ApiModelProperty(required = true, value = "repository", example = "1")
        private int     repository;
        private String     accountNumber;

		public EInsuranceAccountDetail(EInsuranceAccountDetails eInsuranceAccountDetails) {
			if(!Objects.isNull(eInsuranceAccountDetails)) {
				ofNullable(eInsuranceAccountDetails.getIsEInsurance()).ifPresent(eins ->this.isEInsurance = isConvert(eInsuranceAccountDetails.getIsEInsurance()));
				ofNullable(eInsuranceAccountDetails.getRepository()).ifPresent(r ->this.repository = eInsuranceAccountDetails.getRepository() );
				ofNullable(eInsuranceAccountDetails.getAccountNumber()).ifPresent(an ->this.accountNumber = eInsuranceAccountDetails.getAccountNumber() );
			}
		}
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FlyDetail {
        @ApiModelProperty(required = true, value = "isFly", example = "true")
        @JsonProperty("isFly")
        private boolean isFly;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EngageInAutoMobile {
        @ApiModelProperty(required = true, value = "isEngageInAutoMobile", example = "true")
        @JsonProperty("isEngageInAutoMobile")
        private boolean isEngageInAutoMobile;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CriminalOffence {
        @ApiModelProperty(required = true, value = "isCriminalOffence", example = "true")
        @JsonProperty("isCriminalOffence")
        private boolean isCriminalOffence;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ExposedPersonPEP {
        @ApiModelProperty(required = true, value = "isExposedPersonPEP", example = "true")
        @JsonProperty("isExposedPersonPEP")
        private boolean isExposedPersonPEP;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PayerOfTrustcharityNGO {
        @ApiModelProperty(required = true, value = "isPayerOfTrustCharityNGO", example = "true")
        @JsonProperty("isPayerOfTrustCharityNGO")
        private boolean isPayerOfTrustCharityNGO;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MilitaryorPoliceForce {
        private ArmedServicesQuestionnaire  armedServicesQuestionnaire;
        private EngagedBombDisposalDriving  engagedBombDisposalDriving;
        private HazardeousActivity          hazardeousActivity;
        private CurrentlyServingIn          currentlyServingIn;
        private DetailedActivitesInvolvedIn detailedActivitesInvolvedIn;
        private BasedLocation               basedLocation;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Hazard {
        @ApiModelProperty(required = true, value = "hasCorrosiveChemicalsAndHTVDrivers", example = "true")
        @JsonProperty("hasCorrosiveChemicalsAndHTVDrivers")
        private boolean hasCorrosiveChemicalsAndHTVDrivers;
        private String  detail;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ArmedServicesQuestionnaire {
        @ApiModelProperty(required = true, value = "isArmedServicesQuestionnaire", example = "true")
        @JsonProperty("isArmedServicesQuestionnaire")
        private boolean isArmedServicesQuestionnaire;
        private String  fullnameOfTheApplicant;
        private int     branchOfArmedForces;
        private int     rank;
        private String  exactNatureOfDuty;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EngagedBombDisposalDriving {
        @ApiModelProperty(required = true, value = "isEngagedBombDisposalDriving", example = "true")
        @JsonProperty("isEngagedBombDisposalDriving")
        private boolean isEngagedBombDisposalDriving;
        private String  engagedinBombDisposalDrivingInfo;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HazardeousActivity {
        @ApiModelProperty(required = true, value = "isHazardeousActivity", example = "true")
        @JsonProperty("isHazardeousActivity")
        private boolean isHazardeousActivity;
        private String  hazardeousActivityInfo;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CurrentlyServingIn {
        @ApiModelProperty(required = true, value = "isCurrentlyServingIn", example = "true")
        @JsonProperty("isCurrentlyServingIn")
        private boolean isCurrentlyServingIn;
        private String  troubledAreasInfo;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DetailedActivitesInvolvedIn {
        @ApiModelProperty(required = true, value = "", example = "abcabc")
        private String detailedActivites;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BasedLocation {
        @ApiModelProperty(required = true, value = "basedLocationDetail", example = "abc")
        private String basedLocationDetail;
    }

    @Data
    @NoArgsConstructor
	public static class InsurancesDetail {
		private int insurer;
		private String coverType;
		private Money lifeCoverAmount;
		private int yearOfIssue;
		private String acceptedTerms;
		@FieldMetaJson("{displayName:'application Number',validations:'isMaxLength~32,matchesRegEx~[0-9]*'}")
		private String applicationNumber;
		private Money annualisedPremiumAmount;
		private String typeOfPolicy;
		private int policyNumber;
		private String applicationDate;
		private int relationshipProposerInsured;
		private String annualisedPremiumStatus;

		public InsurancesDetail(com.pmli.ms.bo.customer.model.LifeStyleInfo.InsurancesDetail det) {
			if (!Objects.isNull(det)) {
				ofNullable(det.getLifeCover())
						.ifPresent(lca -> this.lifeCoverAmount = new Money(new BigDecimal(det.getLifeCover())));
				this.insurer = det.getInsurer();
				this.coverType = det.getCoverType();
				this.yearOfIssue = det.getYearOfIssue();
				this.acceptedTerms = det.getAcceptedTerms();
				this.applicationNumber = det.getApplicationNumber();
				ofNullable(det.getAnnualisedPremiumAmount()).ifPresent(lca -> this.annualisedPremiumAmount = new Money(
						new BigDecimal(det.getAnnualisedPremiumAmount())));
				this.policyNumber = det.getPolicyNumber();
				this.typeOfPolicy = det.getTypeOfPolicy();
				this.applicationDate = det.getApplicationDate();
				this.relationshipProposerInsured = det.getRelationshipProposerInsured();
				this.annualisedPremiumStatus = det.getAnnualisedPremiumStatus();
			}
		}

	}

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FamilyMemberDetail {
		private int    parentsOrSiblings;
        private int    currentLiveStatus;
        private int    age;
        private int    diseaseSufferingFrom;
        private String causeOfDeath;
        private int    ageOnSet;
        
		public FamilyMemberDetail(FamilyMember fmd) {
			if (!Objects.isNull(fmd) && !Objects.isNull(fmd.getDetail())) {
				ofNullable(fmd.getDetail().getParentsOrSiblings()).ifPresent(pos->this.parentsOrSiblings = fmd.getDetail().getParentsOrSiblings());
				ofNullable(fmd.getDetail().getCurrentLiveStatus()).ifPresent(cls->this.currentLiveStatus = fmd.getDetail().getCurrentLiveStatus());
				this.age = fmd.getDetail().getAge();
				this.diseaseSufferingFrom = fmd.getDetail().getDiseaseSufferingFrom();
				this.causeOfDeath = fmd.getDetail().getCauseOfDeath();
				this.ageOnSet = fmd.getDetail().getAgeOnSet();
			}
		}
    }

    @Data
    @NoArgsConstructor
    public static class Insurance {
        private int              index;
        private InsurancesDetail detail;

        public Insurance(com.pmli.ms.bo.customer.model.LifeStyleInfo.Insurance insurance) {
        	if(!Objects.isNull(insurance) && !Objects.isNull(insurance.getDetail())) {
        		 this.index = insurance.getIndex();
        		 ofNullable(insurance.getDetail()).ifPresent(d-> this.detail = new InsurancesDetail(insurance.getDetail()));
        	}
           
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FamilyMemberDetails {
        public FamilyMemberDetails(FamilyMember fmd) {
			this.index = fmd.getIndex();
			this.detail = new FamilyMemberDetail(fmd);
		}
		private int                index;
        private FamilyMemberDetail detail;
        
        
    }

	public static boolean isConvert(String value) {
		if (!Objects.isNull(value)) {
			return value.equals("1");
		}
		else {
			return false;
		}
	}
}
