package com.pmli.ms.bo.customer.model;

import lombok.Data;

@Data
public class CovidDetails {
    private String countryVisited;
    private String durationFrom;
    private String durationTo;

}
