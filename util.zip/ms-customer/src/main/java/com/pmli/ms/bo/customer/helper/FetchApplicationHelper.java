package com.pmli.ms.bo.customer.helper;

import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.FetchApplicationProps;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.request.FetchApplicationRequest;
import com.pmli.util.java.MsObject;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class FetchApplicationHelper extends MsObject {

    private FetchApplicationProps fetchAppProps;
    FetchApplicationRequest       fetchApplicationRequest;

    public String getFilter() {
        String id = "";
        String filter = "";
        if (null != fetchApplicationRequest.getLeadId() && !fetchApplicationRequest.getLeadId().isEmpty()) {
            id = fetchApplicationRequest.getLeadId();
            filter = FieldConstants.LD_LEADID;
        } else if (null != fetchApplicationRequest.getQuotationId()
            && !fetchApplicationRequest.getQuotationId().isEmpty()) {
                id = fetchApplicationRequest.getQuotationId();
                filter = FieldConstants.LD_QUOTATIONID;
            } else if (null != fetchApplicationRequest.getApplicationNumber()
                && !fetchApplicationRequest.getApplicationNumber().isEmpty()) {
                    id = fetchApplicationRequest.getApplicationNumber();
                    filter = FieldConstants.LD_APPLICATIONUMBER;
                }
        if (id.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.MANDATORY_PARAM_MISSING_101,
                fetchAppProps.getErrorMsgMandatoryField(), fetchAppProps.getErrorMsgBlankId());
        }
        return String.format("{%s:'%s'}",filter, id);

    }
}
