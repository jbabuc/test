package com.pmli.ms.bo.customer.model;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.helper.CreateBasicLeadHelper;
import com.pmli.ms.bo.customer.model.LeadDetailPayment.Payment;
import com.pmli.ms.bo.customer.request.CreateApplicationMFGPRequest;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.CreateBasicLeadRequest;
import com.pmli.ms.bo.customer.request.CustomerRequest;
import com.pmli.ms.bo.customer.request.FamilyMember;
import com.pmli.ms.bo.customer.request.Fund;
import com.pmli.ms.bo.customer.request.LeadDetailBiRequest;
import com.pmli.util.bson.IsoDateDeSerializer;
import com.pmli.util.bson.IsoDateSerializer;
import com.pmli.util.json.JsonUtil;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
public class LeadDetail {

	private String leadId;
	private String recordStatus = "";
	@JsonSerialize(using = IsoDateSerializer.class)
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date createdOn;
	private EmployeeInfo employeeInfo;
	@JsonProperty("isACHADM")
	private boolean achadm;
	private String token;
	private PersonalInfo personalInfo;
	private CriticalInfoDetail criticalInfoDetails;
	private LifeStyleInfo lifeStyleInfo;
	@JsonProperty("isActive")
	private boolean active;
	private String buyType;
	private String name;
	private String title;
	private String firstName;
	private String lastName;
	private String gender;
	private String dateOfBirth;
	private String pinNo;
	private String annualIncome;
	private String mobileNumber;
	private String emailId;
	private String age;
	private String suitabilityAnalysis;
	private String quotationId;
	private String proposalNumber;
	private String applicationNumber;
	private String educationalQualification;
	private String occupation;
	private String step;
	private String city;
	private String state;
	private String district;
	private String country;
	@JsonSerialize(using = IsoDateSerializer.class)
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date lastUpdatedOn;
	private Action action;
	@JsonProperty("isAdded")
	private boolean added;
	private String otp;
	private String transactionId;
	private String utmSource;
	private String utmMedium;
	private String utmCampaign;
	private String fosCode;
	private String fosCodeType;
	private String planId;
	private DocumentInfo documentInfoDetails;
	@JsonProperty("isDocSubmited")
	private boolean docsubmited;
	@JsonProperty("isCRMIntegrationCompleted")
	private boolean crmIntegrationCompleted;
	@JsonSerialize(using = IsoDateSerializer.class)
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date expiredOn;
	private Payout payout;
	private String jointLifeDateOfBirth;
	private String jointLifeAge;
	private String jointLifeName;
	private LeadDetailPremium premiumCalculation;
	private List<LeadDetailPremium> riders;
	private FinancialAnalysis fna;
	private LovedOne lovedOne;
	private List<Fund> funds;
	private Payment payment;
	// added for web bi - start
	private BankBranchDetails bankBranchDetails;
	@JsonSerialize(using = IsoDateSerializer.class)
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date lastUpdateOn;
	private CustomerHealth healthInfo;
	private List<FamilyCriticalInfoDetails> familyCriticalInfoDetails;
	private List<FamilyLifeStyleInfoDetails> familyLifeStyleInfo;
	private Boolean proposalFormVerification;
	private Boolean proposalFormSent;
	@JsonSerialize(using = IsoDateSerializer.class)
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date proposalFormSentOn;

	@JsonIgnore
	private DBClient dbClient;

	@JsonIgnore
	private CommonProps commonProps;
	// added for web bi - end

	public LeadDetail() {
	}

	public LeadDetail(CreateApplicationRequest createApplicationRequest, String leadId, String title,
			String familyTitle, String jointLifeName) {
		this.leadId = leadId;
		this.achadm = false;
		this.active = true;
		this.added = false;
		this.title = title;
		this.buyType = "" + createApplicationRequest.getBuyTypeCode();

		ofNullable(createApplicationRequest.getName())
				.map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
				.ifPresent(nl -> name = nl.stream().collect(Collectors.joining(" ")));
		ofNullable(createApplicationRequest.getName()).ifPresent(n -> {
			firstName = n.getFirstName();
			lastName = n.getLastName();
		});
		this.gender = createApplicationRequest.getGender();
		this.dateOfBirth = createApplicationRequest.getBirthDate();
		this.pinNo = createApplicationRequest.getAddress().getPostalCode();
		ofNullable(createApplicationRequest.getAnnualIncomeAmount())
				.ifPresent(a -> annualIncome = "" + new BigDecimal(a.getAmount().toString()));
		this.mobileNumber = createApplicationRequest.getPhoneNumbers().get(0).getNumber();
		this.emailId = createApplicationRequest.getEmail().getAddress();
		this.age = String.valueOf(CommonHelper.getAge(String.valueOf(createApplicationRequest.getBirthDate())));
		this.suitabilityAnalysis = "" + createApplicationRequest.getSuitabilityAnalysis();
		this.quotationId = createApplicationRequest.getQuotationId();
		this.applicationNumber = ofNullable(createApplicationRequest.getApplicationNumber()).orElse("");
		this.educationalQualification = createApplicationRequest.getEducationalQualification();
		this.occupation = "" + createApplicationRequest.getOccupation();
		this.step = "6";
		this.city = createApplicationRequest.getAddress().getCity();
		this.state = createApplicationRequest.getAddress().getState();
		this.district = createApplicationRequest.getAddress().getDistrict();
		this.country = createApplicationRequest.getAddress().getCountry();
		this.utmSource = createApplicationRequest.getUtmSource();
		this.utmMedium = createApplicationRequest.getUtmMedium();
		this.utmCampaign = createApplicationRequest.getUtmCampaign();
		this.fosCode = "0";
		this.fosCodeType = "0";
		this.planId = "" + createApplicationRequest.getPlanId();
		this.docsubmited = false;
		this.crmIntegrationCompleted = false;
		ofNullable(createApplicationRequest.getRiders())
				.ifPresent(rlist -> riders = rlist.stream().map(LeadDetailPremium::new).collect(Collectors.toList()));
		this.jointLifeAge = "" + createApplicationRequest.getJointLifeAge();
		this.jointLifeDateOfBirth = createApplicationRequest.getJointLifeBirthDate();
		this.jointLifeName = jointLifeName;
		this.lovedOne = new LovedOne(createApplicationRequest.getFamilyMember());
		this.lovedOne.setTitle(familyTitle);
		ofNullable(createApplicationRequest.getFunds()).ifPresent(rdlist -> funds = rdlist.stream()
				.map(f -> new Fund(f.getFundId(), f.getFundPercent())).collect(Collectors.toList()));
		this.proposalNumber = "";
		this.premiumCalculation = new LeadDetailPremium(createApplicationRequest.getPremiumCalculation());
	}

	public LeadDetail(CustomerRequest addCustomerDetails, String leadId, String title, String familyTitle) {

		this.leadId = leadId;
		this.buyType = "" + addCustomerDetails.getBuyTypeCode();
		ofNullable(addCustomerDetails.getName())
				.map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
				.ifPresent(nl -> name = nl.stream().collect(Collectors.joining(" ")));
		this.title = title;
		ofNullable(addCustomerDetails.getName()).ifPresent(n -> {
			firstName = n.getFirstName();
			lastName = n.getLastName();
		});

		this.gender = addCustomerDetails.getGender();
		this.dateOfBirth = addCustomerDetails.getBirthDate();
		this.pinNo = addCustomerDetails.getAddress().getPostalCode();
		ofNullable(addCustomerDetails.getAnnualIncomeAmount())
				.ifPresent(a -> annualIncome = "" + new BigDecimal(a.getAmount().toString()));
		ofNullable(addCustomerDetails.getPhoneNumbers()).ifPresent(a -> mobileNumber = a.get(0).getNumber());
		this.emailId = addCustomerDetails.getEmail().getAddress();
		this.age = String.valueOf(CommonHelper.getAge(String.valueOf(addCustomerDetails.getBirthDate())));
		this.suitabilityAnalysis = "" + addCustomerDetails.getSuitabilityAnalysis();
		this.quotationId = addCustomerDetails.getQuotationId();
		this.proposalNumber = addCustomerDetails.getProposalNumber();
		this.applicationNumber = ofNullable(addCustomerDetails.getApplicationNumber()).orElse("");
		this.educationalQualification = "" + addCustomerDetails.getEducationalQualification();
		this.occupation = "" + addCustomerDetails.getOccupation();
		this.step = "" + addCustomerDetails.getStep();
		this.city = addCustomerDetails.getAddress().getCity();
		this.state = addCustomerDetails.getAddress().getState();
		this.district = addCustomerDetails.getAddress().getDistrict();
		this.country = addCustomerDetails.getAddress().getCountry();
		ofNullable(addCustomerDetails.getFamilyMember()).ifPresent(n -> {
			this.lovedOne = new LovedOne(n);
			this.lovedOne.setTitle(familyTitle);
		});
	}

	public LeadDetail(CreateBasicLeadRequest cblr, String leadId, DBClient dbClient, CommonProps commonProps) {
		this.leadId = leadId;
		this.title = dbClient.getMasterKeyByTypeValue(commonProps.getMasterKeyDataTypeTitle(),
				cblr.getName().getTitle());
		ofNullable(cblr.getName())
				.map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
				.ifPresent(nl -> name = nl.stream().collect(Collectors.joining(" ")));
		ofNullable(cblr.getName()).ifPresent(n -> {
			firstName = n.getFirstName();
			lastName = n.getLastName();
		});
		this.mobileNumber = cblr.getPhones().get(0).getNumber();
		this.emailId = cblr.getEmail().getAddress();
		this.pinNo = cblr.getAddress().getPostalCode();
		this.suitabilityAnalysis = new CreateBasicLeadHelper().getSuitabilityAnalysis(cblr.getSuitabilityAnalysis());
	}

	/**
	 * @Constructor LeadDetail constructor To create lead detail based on the web BI
	 *              request inputs
	 * @param leadDetailBiRequest
	 */
	public LeadDetail(LeadDetailBiRequest leadDetailBiRequest) {
		this.applicationNumber = leadDetailBiRequest.getApplicationNumber();
		this.buyType = CommonHelper.getStrFromIntOrZero(leadDetailBiRequest.getBuyTypeCode());
		ofNullable(leadDetailBiRequest.getAddress()).ifPresent(n -> {
			this.country = n.getCountry();
			this.city = n.getCity();
			this.pinNo = n.getPostalCode();
			this.district = n.getDistrict();
			this.state = n.getState();
		});
		ofNullable(leadDetailBiRequest.getEmail()).ifPresent(n -> this.emailId = n.getAddress());
		ofNullable(leadDetailBiRequest.getPhones())
				.ifPresent(n -> this.mobileNumber = n.get(0).getNumber() == null ? "" : n.get(0).getNumber());
		this.leadId = leadDetailBiRequest.getLeadId();
		this.title = leadDetailBiRequest.getTitle();
		ofNullable(leadDetailBiRequest.getName()).map(n -> Arrays.asList(n.getTitle() == null ? "" : n.getTitle(),
				n.getFirstName() == null ? "" : n.getFirstName(), n.getMiddleName() == null ? "" : n.getMiddleName(),
				n.getLastName() == null ? "" : n.getLastName()))
				.ifPresent(nl -> this.name = nl.stream().collect(Collectors.joining(" ")));
		if (!StringUtils.isEmpty(this.name))
			this.name = this.name.trim();
		ofNullable(leadDetailBiRequest.getName()).ifPresent(n -> {
			this.firstName = n.getFirstName();
			this.lastName = n.getLastName();
		});
		this.gender = leadDetailBiRequest.getGender();
		this.dateOfBirth = leadDetailBiRequest.getBirthDate();
		ofNullable(leadDetailBiRequest.getAnnualIncomeAmount())
				.ifPresent(a -> annualIncome = "" + new BigDecimal(a.getAmount().toString()));
		this.age = String.valueOf(CommonHelper.getAge(String.valueOf(leadDetailBiRequest.getBirthDate())));
		ofNullable(leadDetailBiRequest.getFunds()).ifPresent(rdlist -> funds = rdlist.stream()
				.map(f -> new Fund(f.getFundId(), f.getFundPercent())).collect(Collectors.toList()));
		this.quotationId = leadDetailBiRequest.getQuotationId();
		this.educationalQualification = leadDetailBiRequest.getEducationalQualification();
		this.occupation = "" + leadDetailBiRequest.getOccupation();
		this.planId = "" + leadDetailBiRequest.getPlanId();
		this.premiumCalculation = new LeadDetailPremium(leadDetailBiRequest.getPremiumCalculation());
		ofNullable(leadDetailBiRequest.getRiders())
				.ifPresent(rlist -> riders = rlist.stream().map(LeadDetailPremium::new).collect(Collectors.toList()));
		ofNullable(leadDetailBiRequest.getJointLifeName())
				.map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
				.ifPresent(nl -> this.jointLifeName = nl.stream().filter(StringUtils::isNotEmpty)
						.collect(Collectors.joining(" ")));
		ofNullable(leadDetailBiRequest.getFamilyMember()).ifPresent(n -> {
			this.lovedOne = new LovedOne(n);
			this.lovedOne.setTitle(leadDetailBiRequest.getFamilyMember().getName().getTitle());
		});
		this.action = null;
		this.criticalInfoDetails = null;
		this.documentInfoDetails = null;
		this.employeeInfo = null;
		this.lifeStyleInfo = null;
		this.fna = null;
		this.active = true;
		this.fosCode = "0";
		this.fosCodeType = "0";
		this.achadm = false;
		this.added = false;
		this.crmIntegrationCompleted = false;
		this.payout = null;
		this.personalInfo = null;
		this.docsubmited = false;
		this.otp = null;
		this.transactionId = null;
		this.proposalNumber = "";
		this.step = "" + leadDetailBiRequest.getStep();
		this.suitabilityAnalysis = "" + leadDetailBiRequest.getSuitabilityAnalysis();
		this.jointLifeAge = "" + leadDetailBiRequest.getJointLifeAge();
		this.jointLifeDateOfBirth = leadDetailBiRequest.getJointLifeBirthDate();
		this.utmSource = leadDetailBiRequest.getUtmSource();
		this.utmMedium = leadDetailBiRequest.getUtmMedium();
		this.utmCampaign = leadDetailBiRequest.getUtmCampaign();
		if (!ObjectUtils.isEmpty(leadDetailBiRequest.getBankBranchDetails())) {
			BankBranchDetails bbd = new BankBranchDetails();
			bbd.setBank(leadDetailBiRequest.getBankBranchDetails().getBank());
			bbd.setBranchDetails(leadDetailBiRequest.getBankBranchDetails().getBranchDetails());
			this.bankBranchDetails = bbd;
		}
		this.familyCriticalInfoDetails = null;
		this.familyLifeStyleInfo = null;
		this.healthInfo = null;
		this.proposalFormSent = false;
		this.proposalFormSentOn = null;
		this.proposalFormVerification = false;
	}

	public LeadDetail(CreateApplicationMFGPRequest request) {
		this.leadId = request.getLeadId();
		this.employeeInfo = null;
		this.achadm = false;
		this.token = null;
		this.personalInfo = null;
		this.criticalInfoDetails = null;
		this.lifeStyleInfo = null;
		this.active = true;
		this.action = null;
		this.added = false;
		this.otp = null;
		this.transactionId = null;

		this.annualIncome = CommonHelper.getStrFromMoneyOrZero(request.getAnnualIncomeAmount());

		this.quotationId = request.getQuotationId();
		this.educationalQualification = request.getEducationalQualification();
		this.occupation = "" + request.getOccupation();
		this.pinNo = request.getAddress().getPostalCode();
		this.city = request.getAddress().getCity();
		this.state = request.getAddress().getState();
		this.district = request.getAddress().getDistrict();
		this.country = request.getAddress().getCountry();
		this.utmSource = request.getUtmSource();
		this.utmMedium = request.getUtmMedium();
		this.utmCampaign = request.getUtmCampaign();
		this.planId = "" + request.getPlanId();
		ofNullable(request.getRiders())
				.ifPresent(rlist -> riders = rlist.stream().map(LeadDetailPremium::new).collect(Collectors.toList()));
		ofNullable(request.getFunds()).ifPresent(rdlist -> funds = rdlist.stream()
				.map(f -> new Fund(f.getFundId(), f.getFundPercent())).collect(Collectors.toList()));
		this.premiumCalculation = new LeadDetailPremium(request.getPremiumCalculation());
		this.jointLifeDateOfBirth = request.getJointLifeBirthDate();
		this.jointLifeAge = ofNullable(jointLifeDateOfBirth).map(bd -> "" + CommonHelper.getAge(bd)).orElse(null);
		ofNullable(request.getJointLifeName())
				.map(n -> Arrays.asList(n.getTitle(), n.getFirstName(), n.getMiddleName(), n.getLastName()))
				.ifPresent(nl -> this.jointLifeName = nl.stream().filter(StringUtils::isNotEmpty)
						.collect(Collectors.joining(" ")));

		this.step = "0";
		this.fosCode = "0";
		this.fosCodeType = "0";
		this.documentInfoDetails = null;
		this.docsubmited = false;
		this.crmIntegrationCompleted = false;
		this.payout = null;
		this.fna = null;
		this.proposalNumber = "";
	}

	@Data
	public static class Action {

	}

	@Data
	public static class EmployeeInfo {

	}

	@Data
	public static class Payout {

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class LovedOne {
		private String title;
		private String firstName;
		private String lastName;
		private String gender;
		private String dateOfBirth;
		private String age;

		public LovedOne(FamilyMember familyMember) {
			this.title = familyMember.getName().getTitle();
			ofNullable(familyMember.getName()).ifPresent(n -> {
				firstName = n.getFirstName();
				lastName = n.getLastName();
			});
			this.gender = familyMember.getGender();
			this.dateOfBirth = familyMember.getBirthDate();
			this.age = String.valueOf(CommonHelper.getAge(familyMember.getBirthDate()));
		}
	}

	public String toJson() {
		String str = JsonUtil.writeValueAsString(this);
		ObjectNode node = (ObjectNode) JsonUtil.readJson(str);

		SimpleDateFormat sdf = new SimpleDateFormat(IsoDateDeSerializer.MONGO_DATE_FORMAT);
		node.put(FieldConstants.LD_CREATED_ON, sdf.format(getCreatedOn()));
		node.put(FieldConstants.LD_LAST_UPDATED_ON, sdf.format(getLastUpdatedOn()));
		node.put(FieldConstants.LD_EXPIRED_ON, sdf.format(getExpiredOn()));
		node.put(FieldConstants.LD_LAST_UPDATE_ON, sdf.format(getLastUpdateOn()));

		ObjectNode paymentNode = (ObjectNode) node.get(FieldConstants.LD_PAYMENT);
		paymentNode.put(FieldConstants.LD_PAYMENT_PAYMENT_DATE, sdf.format(payment.getPaymentDate()));
		return node.toString();
	}
}
