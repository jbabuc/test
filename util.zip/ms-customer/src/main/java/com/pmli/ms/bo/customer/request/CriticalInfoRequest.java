package com.pmli.ms.bo.customer.request;

import java.util.List;
import static java.util.Optional.ofNullable;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pmli.ms.bo.customer.helper.CommonHelper;
import com.pmli.ms.bo.customer.model.CriticalInfoDetail;
import com.pmli.ms.bo.customer.model.CriticalInfoDetail.AlcohalDetail;
import com.pmli.ms.bo.customer.model.CriticalInfoDetail.BankDetail;
import com.pmli.util.java.FieldMetaJson;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * This class holds the Add Critical Info
 * 
 * @author  Vivek Gupta
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CriticalInfoRequest extends LeadRequest {
	@ApiModelProperty(required = true, value = "CriticalInfoDetails")
    @FieldMetaJson("{displayName:'critical Info Detail',nullable:false,validations:'notNull'}")
    private CriticalInfoDetails criticalInfoDetails;

    @Data
    @NoArgsConstructor
    public static class CriticalInfoDetails {

        public CriticalInfoDetails(CriticalInfoDetail criticalInfoDetail) {
            ofNullable(criticalInfoDetail.getCriticalInfoDiseaseDetails()).ifPresent(dd -> dd.forEach(detail -> criticalInfoDiseaseDetails.add(new CriticalInfoDiseaseDetail(detail))));
            
            ofNullable(criticalInfoDetail.getHeightWeightDetails()).ifPresent(hwd->  this.heightWeightDetails = new HeightWeightDetail(
                    Integer.valueOf(criticalInfoDetail.getHeightWeightDetails().getHeightInFeet()),
                    Integer.valueOf(criticalInfoDetail.getHeightWeightDetails().getHeightInInch()),
                    Integer.valueOf(criticalInfoDetail.getHeightWeightDetails().getWeight())));
            ofNullable(criticalInfoDetail.getBankDetail()).ifPresent(hwd->  this.bankDetail = criticalInfoDetail.getBankDetail());
            ofNullable(criticalInfoDetail.getBankDetailJointLife()).ifPresent(hwd->  this.bankDetailJointLife = criticalInfoDetail.getBankDetailJointLife());
        }

        private List<CriticalInfoDiseaseDetail> criticalInfoDiseaseDetails = new ArrayList<>();
        @ApiModelProperty(required = false, value = "heightWeightDetails")
        private HeightWeightDetail              heightWeightDetails;
        @ApiModelProperty(required = false, value = "bankDetail")
        private BankDetail                      bankDetail;
        @ApiModelProperty(required = false, value = "bankDetailJointLife")
        private BankDetail                      bankDetailJointLife;
    }

    @Data
    @NoArgsConstructor
    public static class CriticalInfoDiseaseDetail {
        @ApiModelProperty(required = true, value = "value", example = "1")
        @FieldMetaJson("{displayName:'value',nullable:false,validations:'greaterThan~0'}")
        private int                 value;
        @ApiModelProperty(required = true, value = "specifyDetails", example = "heart beet")
        private String              specifyDetails;
        private List<Details>       details = new ArrayList<>();
        @ApiModelProperty(required = true, value = "key", example = "1")
        @FieldMetaJson("{displayName:'key',validations:'greaterThan~-0'}")
        private int                 key;
        @ApiModelProperty(required = true, value = "name", example = "CirculatorySystem")
        @FieldMetaJson("{displayName:'name',nullable:false,validations:'notNullNotBlank'}")
        private String              name;
        private List<AlcoholDetail> alcoholDetails = new ArrayList<>();
        private CovidDetails        covidDetails;
        private PregnantDetail      pregnantDetails;
        public CriticalInfoDiseaseDetail(com.pmli.ms.bo.customer.model.CriticalInfoDetail.CriticalInfoDiseaseDetail criticalDiseaseDetail ) {
            ofNullable(criticalDiseaseDetail).ifPresent(dd -> {
                this.value = dd.getValue();
                this.key = dd.getKey();
                this.specifyDetails = dd.getSpecifyDetails();
                ofNullable(dd.getDetails()).ifPresent(l -> l.forEach(detail -> details.add(new Details(detail.getKey(), detail.getDetails()))));
                this.name = dd.getName();
                ofNullable(dd.getAlcohalDetails()).ifPresent(l -> l.forEach(ad -> alcoholDetails.add(new AlcoholDetail(ad))));
                ofNullable(dd.getCovidDetails()).ifPresent(covid -> this.covidDetails = new CovidDetails(covid.getCountryVisited(), covid.getDurationFrom(), covid.getDurationTo()));
                ofNullable(dd.getPregnantDetails()).ifPresent(pre -> this.pregnantDetails = new PregnantDetail(CommonHelper.parseIntOrZero(pre.getCurrentPregnancyMonth()) ,pre.getPregnancyComplicationDetails(), pre.getPregnancyComplications()));   
            });
            
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Details {
        @ApiModelProperty(required = false, value = "key", example = "66")
        @FieldMetaJson("{displayName:'key',nullable:false,validations:'notNullNotBlank'}")
        private String key;
        @ApiModelProperty(required = true, value = "details", example = "Some detail")
        @JsonProperty("details")
        private String value;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HeightWeightDetail {
        @ApiModelProperty(required = false, value = "heightInFeet", example = "5")
        private int heightInFeet;
        @ApiModelProperty(required = false, value = "heightInInch", example = "2")
        private int heightInInch;
        @ApiModelProperty(required = false, value = "weight", example = "45")
        private int weight;
    }

    @Data
    @NoArgsConstructor
    public static class AlcoholDetail {
        @ApiModelProperty(required = true, value = "substanceConsumed", example = "1")
        @FieldMetaJson("{displayName:'substanceConsumed',nullable:false,validations:'greaterThan~0'}")
        private int substanceConsumed;
        @ApiModelProperty(required = true, value = "substanceConsumedType", example = "1")
        @FieldMetaJson("{displayName:'substanceConsumedType',nullable:false,validations:'greaterThan~0'}")
        private int substanceConsumedType;
        @ApiModelProperty(required = false, value = "perday", example = "0")
        private int perday;
        @ApiModelProperty(required = false, value = "sinceMonth", example = "0")
        private int sinceMonth;
        @ApiModelProperty(required = false, value = "inMlPerWeek", example = "0")
        private int inMlPerWeek;
        @ApiModelProperty(required = false, value = "inpintWeek", example = "0")
        private int inpintWeek;
        @ApiModelProperty(required = false, value = "inGMPerWeek", example = "0")
        private int inGMPerWeek;
        
        public AlcoholDetail(AlcohalDetail del) {
            ofNullable(del.getSubstanceConsumed()).ifPresent(sc -> this.substanceConsumed = Integer.valueOf(sc));
            ofNullable(del.getSubstanceConsumedType()).ifPresent(sct -> this.substanceConsumedType = Integer.valueOf(sct));
            ofNullable(del.getPerday()).ifPresent(perDay ->  this.perday = Integer.valueOf(perDay));
            ofNullable(del.getSinceMonth()).ifPresent(sm -> this.sinceMonth = Integer.valueOf(sm));
            ofNullable(del.getInMlPerWeek()).ifPresent(perWeek -> this.inMlPerWeek = Integer.valueOf(perWeek));
            ofNullable(del.getInpintWeek()).ifPresent(inp -> this.inpintWeek = Integer.valueOf(inp));
            ofNullable(del.getInGMPerWeek()).ifPresent(gmPerweek -> this.inGMPerWeek = Integer.valueOf(gmPerweek));
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PregnantDetail {
        @ApiModelProperty(required = false, value = "currentPregnancyMonth", example = "")
        @FieldMetaJson("{displayName:'currentPregnancyMonth',nullable:true,validations:'greaterThan~-1,lessThan~10'}")
        private int    currentPregnancyMonth;
        @ApiModelProperty(required = false, value = "pregnancyComplicationDetails", example = "")
        private String pregnancyComplicationDetails;
        @ApiModelProperty(required = false, value = "pregnancyComplications", example = "2")
        private String pregnancyComplications;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CovidDetails {
        @ApiModelProperty(required = false, value = "countryVisited", example = "US")
        private String countryVisited;
        @ApiModelProperty(required = false, value = "durationFrom", example = "2021-06-02T18:30:00.000Z")
        private String durationFrom;
        @ApiModelProperty(required = false, value = "durationTo", example = "2021-06-29T18:30:00.000Z")
        private String durationTo;
    }
}
