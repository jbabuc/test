package com.pmli.ms.bo.customer.request;

import com.pmli.util.java.FieldMetaJson;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * 
 * @author 3483784san
 *
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class StepRequest extends LeadRequest {
	@ApiModelProperty(required = true, value = "Step", example = "1")
	@FieldMetaJson("{displayName:'Step',nullable:false,validations:'greaterThan~0'}")
	private int step;
}
