package com.pmli.ms.bo.customer.helper;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.pmli.bo.cron.app.ApplicationNumberRetry;
import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.comm.Metadata;
import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.ms.bo.customer.config.PaymentProps;
import com.pmli.ms.bo.customer.config.SaveApplicationProps;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.CreateApplicationRequest;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Body;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Product;
import com.pmli.ms.bo.customer.request.ApplicationCrmRequest.Riders;
import com.pmli.ms.bo.customer.response.ApplicationCrmResponse;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;
import com.pmli.util.web.client.RestConsumer;

import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Save application rest call for application number
 * 
 * @author 3483784san
 */
@AllArgsConstructor
public class ApplicationCrmHelper extends MsObject {
    private DBClient              dbClient;
    private EmailClient           emailClient;
    private CommonProps           commonProps;
    private RestConsumer          restConsumer;
    private SaveApplicationProps  saveApplicationProps;
    private PaymentProps          paymentProps;
    private ApplicationCrmRequest applicationCrmRequest;

    /**
     * @param  saveApplicationRequest
     * @param  leadId
     * @return
     * @throws ApplicationException
     */
    @HystrixCommand(commandKey = "save.application", fallbackMethod = "fallbackSaveApplicationToCrm")
    public ApplicationCrmResponse saveApplicationToCrm() {
        String json = JsonUtil.writeValueAsString(applicationCrmRequest);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", saveApplicationProps.getAuthorization());
        headers.set("X-IBM-Client-Id", saveApplicationProps.getXIbmClientId());
        headers.set("requestId", saveApplicationProps.getRequestId());
        headers.set("channel", saveApplicationProps.getChannel());
        headers.set("userId", saveApplicationProps.getUserId());
        headers.set("source", saveApplicationProps.getSource());
        String res = restConsumer.callClientEndPoint(saveApplicationProps.getSaveUrl(), headers, json);
        return JsonUtil.readValue(res, ApplicationCrmResponse.class);
    }

    /**
     * fallback for save application
     * 
     * @param  car
     * @return
     */
    public ApplicationCrmResponse fallbackSaveApplicationToCrm(ApplicationCrmRequest saveApplicationRequest) {
        String data = JsonUtil.writeValueAsString(saveApplicationRequest);
        log.warn("Failed to fetch application number, executing fallback {}", data);
        return null;
    }

    /**
     * This method returns the saveApplicationRequest values and pass it to createApplication.
     * 
     * @param  car
     * @return
     */
    public static ApplicationCrmRequest prepareRequestforSaveApplication(CreateApplicationRequest car,
        DBClient dbClient) {
        ApplicationCrmRequest saveApplicationRequest = new ApplicationCrmRequest();
        Body body = new Body(car.getQuotationId(), CreateApplicationHelper.getIspiposame(car.getBuyTypeCode()),
            car.getApplicationNumber());
        Product product = new Product(car, dbClient);
        Riders riders = new Riders(CreateApplicationHelper.getCrmRidersFromRequest(car.getRiders(), product));
        product.setRiders(riders);
        body.setProduct(product);
        saveApplicationRequest.setBody(body);
        return saveApplicationRequest;
    }

    /**
     * This method helps to create request for ApplicationCrm
     * 
     * @param  ld
     * @param  createApplicationHelper
     * @return
     */
    public static ApplicationCrmRequest prepareRequestforSaveApplication(LeadDetail ld, DBClient dbClient) {
        ApplicationCrmRequest saveApplicationRequest = new ApplicationCrmRequest();
        int buyType = StringUtils.isNotEmpty(ld.getBuyType())
            ? CreateApplicationHelper.getIspiposame(Integer.parseInt(ld.getBuyType()))
            : 0;
        Body body = new Body(ld, buyType);
        Product product = new Product(ld, dbClient);
        Riders riders = new Riders(CreateApplicationHelper.getCrmRidersFromModel(ld.getRiders(), product));
        product.setRiders(riders);
        body.setProduct(product);
        saveApplicationRequest.setBody(body);
        return saveApplicationRequest;
    }

    /**
     * @param  saveResponse
     * @param  quotationId
     * @return
     */
    public void updateApplicationNumber(LeadDetail ld) {
        // validate
        Objects.requireNonNull(ld.getApplicationNumber(),
            "Update application number requires non null application number.");
        Objects.requireNonNull(ld.getQuotationId(), "Update application number requires non null quotation id.");

        Document documentRequest = Document.parse("{applicationNumber:" + "'" + ld.getApplicationNumber() + "'" + "}");
        documentRequest.put(FieldConstants.LD_RECORD_STATUS, StringUtils.isEmpty(ld.getRecordStatus()) ? ""
            : ld.getRecordStatus().replace(ApplicationNumberRetry.RECORD_STATUS_UPDATE_FAIL, ""));
        long res = dbClient.saveLeadDetail(ld.getLeadId(), documentRequest);
        if (res < 1) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                commonProps.getLeadNotFound(), commonProps.getLeadNotFound());
        }

        // send email
        List<Metadata> list = new ArrayList<>();
        list.add(new Metadata("product_name", ld.getPremiumCalculation().getProductName()));
        list.add(new Metadata("quotation_id", ld.getQuotationId()));
        list.add(new Metadata("url_path", "https://online.pnbmetlife.com/NotificationImages/"));
        list.add(new Metadata("plan_url",
            dbClient.getAppConfigFieldValById("" + ld.getPremiumCalculation().getProductId(), "image")));
        list.add(new Metadata("product_url",
            dbClient.getAppConfigFieldValById("" + ld.getPremiumCalculation().getProductId(), "productUrl")));
        list.add(new Metadata("continue_url", PaymentServiceHelper
            .prepareUpdatePaymentResponse(paymentProps, commonProps, ld.getLeadId()).getProposalFormLink()));
        sendMail(list, ld.getEmailId());
    }

    public void sendMail(List<Metadata> metaData, String toMail) {
        emailClient.sendEmail(metaData, commonProps.getFromEmail(), toMail, "");
    }
}
