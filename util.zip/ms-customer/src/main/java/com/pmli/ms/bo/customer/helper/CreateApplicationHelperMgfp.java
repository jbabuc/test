package com.pmli.ms.bo.customer.helper;

import org.bson.Document;
import org.springframework.http.HttpStatus;

import com.pmli.ms.bo.customer.config.Constants;
import com.pmli.ms.bo.customer.config.CreateApplicationProps;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.request.CreateApplicationMFGPRequest;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.StringValidator;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <p>
 * This class consists of the helper methods which is use by MGFP 'create-application' API.
 * </p>
 * 
 * @author  Hemant Solanki
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
public class CreateApplicationHelperMgfp {

    DBClient                     dbClient;
    CreateApplicationMFGPRequest camr;

    static CreateApplicationProps caprops;
    static {
        caprops = ContextWrapper.getContext().getBean(CreateApplicationProps.class);
    }

    /**
     * This method is use to validate 'create-application' request
     */
    public void validate() {

        new StringValidator(camr.getQuotationId(), "Quotation Id", false).validateEx(
            StringValidator::notNullMatchesRegEx, Constants.DIGITS_1_32_REGEX,
            "Quotation Id must not be blank with max 32 digits.");

        String productId = String.valueOf(camr.getPremiumCalculation().getProductId());
        String planId = "" + camr.getPlanId();

        validateMGFPlanId(planId);
        validateMGFPproductId(productId);

        CreateApplicationHelper.validatePremiumProductName(dbClient, camr.getPremiumCalculation());
        CreateApplicationHelper.checkRecordAlreadyIsPresent(dbClient, camr.getQuotationId());

        CreateApplicationHelper.validateMsspMgfpMsppProductFields(camr.getPremiumCalculation());
        CreateApplicationHelper.validateMgfpMsspMiapProductFields(camr.getPremiumCalculation());

        CreateApplicationHelper.validateMgfpProductFields(camr.getPremiumCalculation());
        CreateApplicationHelper.validateMsspmgfpProductFields(camr.getPremiumCalculation());
        CreateApplicationHelper.validateRidersDetails(dbClient, camr.getRiders());
        CreateApplicationHelper.checkValidState(dbClient, camr.getAddress().getState());
    }

    /**
     * This method is use to create document object to be save in DB
     * 
     * @param  ld contains LeadDetails Obj
     * @return    Document Obj
     */
    public static Document setCreateMGFPData(LeadDetail ld) {
        Document doc = Document.parse("{\"riders\":" + JsonUtil.writeValueAsString(ld.getRiders())
            + ",\"premiumCalculation\":" + JsonUtil.writeValueAsString(ld.getPremiumCalculation()) + ",\"funds\":"
            + JsonUtil.writeValueAsString(ld.getFunds()) + "}");

        doc.put("annualIncome", ld.getAnnualIncome());
        doc.put("quotationId", ld.getQuotationId());
        doc.put("educationalQualification", ld.getEducationalQualification());
        doc.put("occupation", ld.getOccupation());
        doc.put("applicationNumber", ld.getApplicationNumber());

        doc.put("city", ld.getCity());
        doc.put("district", ld.getDistrict());
        doc.put("pinNo", ld.getPinNo());
        doc.put("state", ld.getState());
        doc.put("country", ld.getCountry());

        doc.put("utmSource", ld.getUtmSource());
        doc.put("utmMedium", ld.getUtmMedium());
        doc.put("utmCampaign", ld.getUtmCampaign());
        doc.put("planId", ld.getPlanId());

        doc.put("jointLifeAge", ld.getJointLifeAge());
        doc.put("jointLifeDateOfBirth", ld.getJointLifeDateOfBirth());
        doc.put("jointLifeName", ld.getJointLifeName());
        
        doc.put("expiredOn", ld.getExpiredOn());

        return doc;
    }

    /**
     * This method is use validate product ID
     * 
     * @param productId
     */
    public static void validateMGFPproductId(String productId) {
        if (productId == null || !ProductId.isGuaranteedFuturePlan(productId)) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105,
                caprops.getErrorProductId(), caprops.getErrMgfproductId());
        }
    }

    /**
     * This method is use to validate plan Id
     * 
     * @param planId
     */
    public static void validateMGFPlanId(String planId) {
        if (planId == null || !ProductId.isGuaranteedFuturePlan(planId)) {
            throw new ApplicationException(HttpStatus.NOT_FOUND, ErrCode.DATA_NOT_FOUND_105, caprops.getErrorPlanId(),
                caprops.getErrMgfplanId());
        }
    }
}
