package com.pmli.ms.bo.customer.comm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.pmli.ms.bo.customer.config.CommonProps;
import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.client.RestConsumer;

@Component
public class SmsClient extends MsObject{
    
    @Autowired
    private CommonProps commonProps;
    
    @Autowired
    private RestConsumer restConsumer;
    
    /**
     * This method will send sms as asynchronously
     * 
     * @param metadata
     */
    @Async
    public void sendSms(SmsRequest smsRequest) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        try {
            restConsumer.callClientEndPoint(commonProps.getSmsURI(), headers, JsonUtil.writeValueAsString(smsRequest));
            log.info("SMS is trigger to mobile number :- {}", smsRequest.getToMobileNumber());
        } catch (Exception e) {
            log.error("Exception occur while sending sms :- {}", e.getMessage());
        }
    }

}
