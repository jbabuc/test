package com.pmli.bo.cron.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;

import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.util.mongo.MongoClientWrapper;
import com.pmli.util.web.client.RestConsumer;

@SpringBootTest
@ActiveProfiles(profiles = { "junit", "input-payload" })
@ExtendWith(MockitoExtension.class)
class ApplicationNumberRetryTest {

	// this will load the properties and enable logging
	@ComponentScan({ "com.pmli" })
	@SpringBootConfiguration
	public static class TestConfig {
	}

	@MockBean
	private MongoClientWrapper buyOnlineMCW;

	@MockBean
	private EmailClient emailClient;

	@MockBean
	private RestConsumer restConsumer;

	@Autowired
	private DBClient dbClient;

	@Autowired
	private ApplicationNumberRetry applicationNumberRetry;

	private final String apiResponse = "{ \"head\": { \"statusCode\": 100 }, \"body\": { \"applicationNumber\": \"150048828\" } }";

	private final String query = "{ $or: [ { applicationNumber: { $exists: false } }, { applicationNumber: null }, { applicationNumber: '' }, { recordStatus: /#UPDATE_FAIL#/ }]}";

	@Test
	void test_positive_execute() throws Exception {
		commonMock();
		when(restConsumer.callClientEndPoint(any(), any(), any())).thenReturn(apiResponse);
		applicationNumberRetry.execute();
		verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getCollectionLeadDetail(), query);
		verify(restConsumer).callClientEndPoint(any(), any(), any());
	}

	@Test
	void test_missing_quotationId_execute() throws Exception {
		List<Document> lstDoc = new ArrayList<Document>();
		File rf = new File(getClass().getClassLoader().getResource("lead-detail.json").getFile());
		Document ldDoc = Document.parse(new String(Files.readAllBytes(rf.toPath())));
		ldDoc.remove("quotationId");
		ldDoc.put("quotationId", null);
		lstDoc.add(ldDoc);
		when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getCollectionLeadDetail(), query))
				.thenReturn(lstDoc);
		applicationNumberRetry.execute();
		verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getCollectionLeadDetail(), query);
	}

	@Test
	void test_exception_execute() throws Exception {
		commonMock();
		Mockito.doThrow(InternalServerError.class).when(restConsumer).callClientEndPoint(any(), any(), any());
		applicationNumberRetry.execute();
		verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getCollectionLeadDetail(), query);
	}

	private void commonMock() throws IOException {
		List<Document> lstDoc = new ArrayList<Document>();
		File rf = new File(getClass().getClassLoader().getResource("lead-detail.json").getFile());
		Document ldDoc = Document.parse(new String(Files.readAllBytes(rf.toPath())));
		lstDoc.add(ldDoc);
		when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getCollectionLeadDetail(), query))
				.thenReturn(lstDoc);
	}
}
