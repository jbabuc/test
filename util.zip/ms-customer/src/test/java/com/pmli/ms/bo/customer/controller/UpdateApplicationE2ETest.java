package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;

import org.bson.Document;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.FieldConstants;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class UpdateApplicationE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    @MockBean
    private RestConsumer mockConsumer;

    private final String apiResponse = "{ \"head\": { \"status\": 100 }, \"body\": { \"applicationNumber\": \"12345\" } }";

    private final static String UPDATE_APPLICATION_URI = "/v1/customer/update-application";

    // Negative
    @Test
     void test_validation_Negative_invalid_ApplicationNumber_Length() throws Exception {
        assertTrue(callEndPointAndAssert(UPDATE_APPLICATION_URI, ContextWrapper
            .getAppProperty("com.pmli.ms.bo.customer.uri.update.application.invalid.application.number.length"), 400));
    }

    @Test
     void test_validation_Negative_invalid_Leadid_Length() throws Exception {
        assertTrue(callEndPointAndAssert(UPDATE_APPLICATION_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.update.application.invalid.lead.id.length"),
            400));
    }

    @Test
     void test_validation_Negative_invalid_Leadid_Application_Number_Blank() throws Exception {
        assertTrue(callEndPointAndAssert(UPDATE_APPLICATION_URI, ContextWrapper.getAppProperty(
            "com.pmli.ms.bo.customer.uri.update.application.invalid.lead.id.application.number.blank"), 400));
    }

 
    // All Valid Parameters
    @Test
     void test_validation_positive_all_parameters() throws Exception {
        JsonNode din = JsonUtil.readJson(
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.update.application.valid.requst.payload"));
        Document dmodel = Document.parse(
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.update.application.valid.requst.payload.model"));

        Mockito.doReturn(getLeadDetail()).when(mockDBClient).getLeadDetailByIdOrAppNo(
            din.get(FieldConstants.LD_LEADID).asText(), din.get(FieldConstants.LD_APPLICATIONUMBER).asText());

        Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(
            eq(ContextWrapper.getAppProperty("com.pmli.bo.customer.save.application.url")), any(HttpHeaders.class),
            argThat((String request) -> {
                return ContextWrapper
                    .getAppProperty("com.pmli.ms.bo.customer.save.application.update.request.all.valid.parameters" + "")
                    .equals(request);
            }));

        Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> din.get(FieldConstants.LD_LEADID).asText().equals(leadId)),
            argThat((Document d) -> {
                return Document.parse(d.toJson()).equals(dmodel);
            }));

        MvcResult result = callPostEndpoint(UPDATE_APPLICATION_URI, din.toString());
        assertTrue(assertResponse(result, 200));
        Assertions.assertEquals(din.get(FieldConstants.LD_APPLICATIONUMBER).asText(), JsonUtil
            .readJson(result.getResponse().getContentAsString()).get("applicationNumber").toString().replace("\"", ""));
    }

    private LeadDetail getLeadDetail() {
        LeadDetail ld = new LeadDetail();
        ld.setApplicationNumber("12345");
        ld.setBuyType("2");
        ld.setDateOfBirth("1990/01/01");
        ld.setCity("test");
        ld.setLeadId("12345");
        return ld;
    }
}
