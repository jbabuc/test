package com.pmli.ms.util.validation;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.jupiter.api.Test;

import com.pmli.ms.bo.customer.request.PaymentRequest;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.validation.ValidationHelper;

 class ValidationTestAddPayment {

	@Test
	 void testValidation() throws IOException {
		File resourceFile = new File(getClass().getClassLoader().getResource("add-payment.json").getFile());
		PaymentRequest apr = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())),
				PaymentRequest.class);
		new ValidationHelper(apr).validateWithMetaJson();
	}
}