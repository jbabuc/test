package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class LeadListE2ETest extends BaseContextLoader {

	private static final String LEAD_LIST_URL = "/v1/mgfp/lead-list";

	@MockBean
	private DBClient mockDBClient;

	// Negative Case
	@Test
	void test_invalid_mobile_number() throws Exception {
		assertTrue(callEndPointAndAssert(LEAD_LIST_URL,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.lead.list.invalid.parameter"), 400));
	}

	@Test
	void test_negative_data_not_found() throws Exception {
		assertTrue(callEndPointAndAssert(LEAD_LIST_URL,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.lead.list.data.not.found"), 404));
	}

	// Positive Case
	@Test
	void test_positive() throws Exception {
		File resourceFile = getFile("lead-detail.json");
		List<LeadDetail> ldLst = new ArrayList<>();
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
		ldLst.add(ld);
		Mockito.doReturn(ldLst).when(mockDBClient).getLeadDetailsByAnyField(Mockito.any(), Mockito.any());
		assertTrue(callEndPointAndAssert(LEAD_LIST_URL,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.lead.list.valid.parameter"), 200));
	}

	private File getFile(String fileName) {
		return new File(getClass().getClassLoader().getResource(fileName).getFile());
	}
}
