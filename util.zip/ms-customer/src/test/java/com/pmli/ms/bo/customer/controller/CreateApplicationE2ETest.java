package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;

import org.bson.Document;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.RestTemplate;

import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.java.JUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.client.RestConsumer;

 class CreateApplicationE2ETest extends BaseContextLoader {

	@MockBean
	private DBClient mockDBClient;

	@MockBean
	EmailClient emailClient;

	@MockBean
	RestTemplate restTemplate;

	@MockBean
	private RestConsumer mockConsumer;

	private final String apiResponse = "{ \"head\": { \"statusCode\": 100 }, \"body\": { \"applicationNumber\": \"150048828\" } }";
	private final long res = 1;
	private String saveApplicationUrl;
	private final static String CREATE_APPLICATION_URI = "/v1/customer/create-application";

	@BeforeEach
	public void secondarySetup() {
		JUtil.setLogLevel(ValidationHelper.class, ch.qos.logback.classic.Level.INFO);
		saveApplicationUrl = ContextWrapper.getAppProperty("com.pmli.bo.customer.save.application.url");
	}

	@Test
	 void test_validation_Negative_invalid_BuyTypeCode() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.buy.type.code"),
				400));
	}

	@Test
	 void test_validation_Negative_invalid_QuotationId() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.quotation.id"),
				400));
	}

	@Test
	 void test_validation_Negative_invalid_ProductId() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.product.id"),
				404));
	}

	@Test
	 void test_validation_Negative_invalid_PlanId() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.plan.id"), 404));
	}

	@Test
	 void test_validation_Negative_Annual_Premium_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.annual.premium.amount.null"), 400));
	}

	@Test
	 void test_validation_Negative_Modal_Premium_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.modal.premium.amount.null"), 400));
	}

	@Test
	 void test_validation_Negative_Service_Tax_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.service.tax.amount.null"),
				400));
	}

	@Test
	 void test_validation_Negative_Sum_Assured_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.sum.assured.amount.null"),
				400));
	}

	@Test
	 void test_validation_Negative_Premium_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.premium.amount.null"),
				400));
	}

	@Test
	 void test_validation_Negative_Accrued_Reversionary_Bonus_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper.getAppProperty(
				"com.pmli.ms.bo.customer.uri.create.application.accrued.reversionary.bonus.amount.null"), 400));
	}

	@Test
	 void test_validation_Negative_Reversionary_Bonus_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.reversionary.bonus.amount.null"), 400));
	}

	@Test
	 void test_validation_Negative_Terminal_Bonus_Amount_Null() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.terminal.bonus.amount.null"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Deferment() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.deferment.invalid"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Deferment_Value() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.deferment.value.invalid"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Income_Payout_Mode() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.income.payout.mode.invalid"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Joint_Life_Birth_Date() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.joint.life.birth.date"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Joint_Life_Age() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.joint.life.age"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Age_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.age.mssp"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Age_Mgfp_With_Buy_Type_Two() throws Exception {
		assertTrue(
				callEndPointAndAssert(CREATE_APPLICATION_URI,
						ContextWrapper.getAppProperty(
								"com.pmli.ms.bo.customer.uri.create.application.invalid.age.mgfp.with.buy.type.two"),
						400));
	}

	@Test
	 void test_validation_Negative_Invalid_Maturiry_Age_Mspp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.maturity.age.mspp"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Funds_Mspp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.funds.mspp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Guarented_Income_Amount() throws Exception {
		assertTrue(
				callEndPointAndAssert(CREATE_APPLICATION_URI,
						ContextWrapper.getAppProperty(
								"com.pmli.ms.bo.customer.uri.create.application.invalid.guarented.income.amount"),
						400));
	}

	@Test
	 void test_validation_Negative_Invalid_Maturity_Benfit_Amount() throws Exception {
		assertTrue(
				callEndPointAndAssert(CREATE_APPLICATION_URI,
						ContextWrapper.getAppProperty(
								"com.pmli.ms.bo.customer.uri.create.application.invalid.maturity.benifit.amount"),
						400));
	}

	@Test
	 void test_validation_Negative_Invalid_Modal_Premium_Amount_In_rider_Mgfp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty(
						"com.pmli.ms.bo.customer.uri.create.application.invalid.modal.premium.amount.in.rider.mgfp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Service_Tax_Amount_In_rider_Mgfp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty(
						"com.pmli.ms.bo.customer.uri.create.application.invalid.service.tax.amount.in.rider.mgfp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Sum_Assuared_Amount_In_rider_Mgfp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty(
						"com.pmli.ms.bo.customer.uri.create.application.invalid.sum.assuared.amount.in.rider.mgfp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Total_Payout_Amount_In_Premium_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty(
						"com.pmli.ms.bo.customer.uri.create.application.invalid.total.payout.amount.in.premium.mssp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Guarented_Death_Benifit_Amount_In_Premium_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper.getAppProperty(
				"com.pmli.ms.bo.customer.uri.create.application.invalid.guarented.death.benifit.amount.in.premium.mssp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Rider_Id_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.rider.id.mssp"),
				404));
	}

	@Test
	 void test_validation_Negative_Invalid_Minimum_Age_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.minimum.age.mssp"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Joint_Life_Age_Miap() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.joint.life.age.miap"), 400));
	}

	@Test
	 void test_validation_Negative_Invalid_Age_In_Mssp() throws Exception {
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.age.in.mssp"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_ProductName() throws Exception {
		String product_Name = "PNB MetLife Guaranteed Future Plan";
		Mockito.doReturn(product_Name).when(mockDBClient).getAppConfigFieldValById(Mockito.any(), Mockito.any());
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.product.name"),
				400));
	}

	@Test
	 void test_validation_Negative_Invalid_Rider_ProductName() throws Exception {
		String rider_Product_Name = "PNB MetLife Serious Illness Rider";
		Mockito.doReturn(rider_Product_Name).when(mockDBClient).getMasterValueByTypeKey(Mockito.any(), Mockito.any());
		assertTrue(callEndPointAndAssert(CREATE_APPLICATION_URI, ContextWrapper
				.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.invalid.rider.product.name"), 400));
	}

	// All Valid Parameters
	@Test
	 void test_validation_positive_all_parameters() throws Exception {
		LeadDetail ld_save = JsonUtil.readValue(
				"{\"leadId\":\"23042021143055109\",\"recordStatus\":\"\",\"createdOn\":{ \"$date\" : 1621408810878},\"employeeInfo\":null,\"token\":null,\"personalInfo\":null,\"criticalInfoDetails\":null,\"lifeStyleInfo\":null,\"buyType\":\"2\",\"name\":\"Mr. Mohan  Jain\",\"title\":null,\"firstName\":\"Mohan\",\"lastName\":\"Jain\",\"gender\":\"M\",\"dateOfBirth\":\"1989-12-12\",\"pinNo\":\"110017\",\"annualIncome\":\"8083446.41\",\"mobileNumber\":\"9821212123\",\"emailId\":\"abc@pnbmetlife.com\",\"age\":\"21\",\"suitabilityAnalysis\":\"2\",\"quotationId\":\"875745712312\",\"proposalNumber\":\"\",\"applicationNumber\":\"\",\"educationalQualification\":\"2\",\"occupation\":\"1\",\"step\":\"6\",\"city\":\"Mumbai\",\"state\":\"MH\",\"district\":\"Mumbai Suburban\",\"country\":\"91\",\"lastUpdatedOn\":{ \"$date\" : 1621408810878},\"action\":null,\"otp\":null,\"transactionId\":null,\"utmSource\":\"Direct\",\"utmMedium\":\"Direct\",\"utmCampaign\":\"Direct\",\"fosCode\":\"0\",\"fosCodeType\":\"0\",\"planId\":\"12029\",\"documentInfoDetails\":null,\"expiredOn\":{ \"$date\" : 1621408810878},\"payout\":null,\"jointLifeDateOfBirth\":\"\",\"jointLifeAge\":\"0\",\"jointLifeName\":\"Mohan  Jain\",\"premiumCalculation\":{\"premium\":\"123.00\",\"frequency\":\"12\",\"coverTerms\":\"1\",\"paymentTerms\":\"1\",\"cashBonusOptions\":\"1\",\"productId\":12007,\"modeDisc\":\"1.0272\",\"productName\":\"PNB MetLife Super Saver Plan\",\"planId\":11,\"planName\":\"Joint Life Last Survivor Annuity with Return of Purchase Price\",\"sumAssured\":\"1.00\",\"annualPremium\":\"8083446.00\",\"modalPremium\":\"8083446.00\",\"serviceTax\":\"145502.00\",\"revisionaryBonus\":\"1000.00\",\"terminalBonus\":\"1000.00\",\"maturityBenefit\":\"1000.00\",\"guaranteedIncome\":\"1000.00\",\"accruedReversionaryBonuses\":\"1000.00\",\"incomePayoutMode\":\"9\",\"maturityAge\":\"1\",\"deferment\":1,\"defermentValue\":\"13\",\"guaranteedDeathBenefit\":\"1000.00\",\"totalPayout\":\"1000.00\",\"multiple\":\"0\",\"fundStrategy\":\"1\",\"benefitPayoutDate\":\"\",\"option\":\"0\",\"fundAtEndOfTheYear\":\"0\",\"investmentType\":null},\"riders\":[{\"premium\":\"123.00\",\"frequency\":\"12\",\"coverTerms\":\"1\",\"paymentTerms\":\"1\",\"cashBonusOptions\":\"1\",\"productId\":13001,\"modeDisc\":\"1.0272\",\"productName\":\"PNB MetLife Accidental Death Benefit Rider Plus\",\"planId\":11,\"planName\":\"Joint Life Last Survivor Annuity with Return of Purchase Price\",\"sumAssured\":\"1.00\",\"annualPremium\":\"8083446.00\",\"modalPremium\":\"8083446.00\",\"serviceTax\":\"145502.00\",\"revisionaryBonus\":\"1000.00\",\"terminalBonus\":\"1000.00\",\"maturityBenefit\":\"1000.00\",\"guaranteedIncome\":\"1000.00\",\"accruedReversionaryBonuses\":\"1000.00\",\"incomePayoutMode\":\"9\",\"maturityAge\":\"1\",\"deferment\":1,\"defermentValue\":\"1\",\"guaranteedDeathBenefit\":\"1000.00\",\"totalPayout\":\"1000.00\",\"multiple\":\"0\",\"fundStrategy\":\"1\",\"benefitPayoutDate\":\"\",\"option\":\"0\",\"fundAtEndOfTheYear\":\"0\",\"investmentType\":null}],\"fna\":null,\"lovedOne\":{\"title\":null,\"firstName\":\"Mohan\",\"lastName\":\"Jain\",\"gender\":\"M\",\"dateOfBirth\":\"1964-01-21\",\"age\":\"52\"},\"funds\":[],\"payment\":null,\"isACHADM\":false,\"isActive\":true,\"isAdded\":false,\"isDocSubmited\":false,\"isCRMIntegrationCompleted\":false}",
				LeadDetail.class);

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((LeadDetail ld) -> {
			ld_save.setLeadId(ld.getLeadId());
			ld_save.setCreatedOn(ld.getCreatedOn());
			ld_save.setExpiredOn(ld.getExpiredOn());
			ld_save.setLastUpdatedOn(ld.getLastUpdatedOn());
			return ld.equals(ld_save);
		}));

		Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(eq(saveApplicationUrl),
				any(HttpHeaders.class), argThat((String request) -> {
					return ContextWrapper
							.getAppProperty(
									"com.pmli.ms.bo.customer.save.application.request.all.valid.parameters" + "")
							.equals(request);
				}));

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((String leadId) -> leadId != null),
				argThat((Document d) -> d.getString("applicationNumber")
						.equals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString())
						&& d.getString("recordStatus").isEmpty()));
	
		MvcResult result = callPostEndpoint(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.valid.mssp"));
		assertResponse(result, 200);
		assertEquals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString(),
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("applicationNumber").toString()
						.replace("\"", ""));
	}

	@Test
	 void test_validation_positive_all_parameters_with_Frequency_Code_Half_Yearly() throws Exception {
		LeadDetail ld_save = JsonUtil.readValue(
				"{\"leadId\":\"23042021143624334\",\"recordStatus\":\"\",\"createdOn\":{ \"$date\" : 1621408810878},\"employeeInfo\":null,\"token\":null,\"personalInfo\":null,\"criticalInfoDetails\":null,\"lifeStyleInfo\":null,\"buyType\":\"2\",\"name\":\"Mr. Mohan  Jain\",\"title\":null,\"firstName\":\"Mohan\",\"lastName\":\"Jain\",\"gender\":\"Male\",\"dateOfBirth\":\"1989-12-12\",\"pinNo\":\"110017\",\"annualIncome\":\"8083446.41\",\"mobileNumber\":\"9821212123\",\"emailId\":\"abc@pnbmetlife.com\",\"suitabilityAnalysis\":\"2\",\"quotationId\":\"875745712312\",\"proposalNumber\":\"\",\"applicationNumber\":\"\",\"educationalQualification\":\"2\",\"occupation\":\"1\",\"step\":\"6\",\"city\":\"Mumbai\",\"state\":\"MH\",\"district\":\"Mumbai Suburban\",\"country\":\"91\",\"lastUpdatedOn\":{ \"$date\" : 1621408810878},\"action\":null,\"otp\":null,\"transactionId\":null,\"utmSource\":\"Direct\",\"utmMedium\":\"Direct\",\"utmCampaign\":\"Direct\",\"fosCode\":\"0\",\"fosCodeType\":\"0\",\"planId\":\"12029\",\"documentInfoDetails\":null,\"expiredOn\":{ \"$date\" : 1621408810878},\"payout\":null,\"jointLifeDateOfBirth\":\"\",\"jointLifeAge\":\"0\",\"jointLifeName\":\"Mohan  Jain\",\"premiumCalculation\":{\"premium\":\"123.00\",\"frequency\":\"6\",\"coverTerms\":\"1\",\"paymentTerms\":\"1\",\"cashBonusOptions\":\"1\",\"productId\":12007,\"modeDisc\":\"1.0272\",\"productName\":\"PNB MetLife Super Saver Plan\",\"planId\":11,\"planName\":\"Joint Life Last Survivor Annuity with Return of Purchase Price\",\"sumAssured\":\"1.00\",\"annualPremium\":\"8083446.00\",\"modalPremium\":\"8083446.00\",\"serviceTax\":\"145502.00\",\"revisionaryBonus\":\"1000.00\",\"terminalBonus\":\"1000.00\",\"maturityBenefit\":\"1000.00\",\"guaranteedIncome\":\"1000.00\",\"accruedReversionaryBonuses\":\"1000.00\",\"incomePayoutMode\":\"9\",\"maturityAge\":\"1\",\"deferment\":1,\"defermentValue\":\"1\",\"guaranteedDeathBenefit\":\"1000.00\",\"totalPayout\":\"1000.00\",\"multiple\":\"0\",\"fundStrategy\":\"1\",\"benefitPayoutDate\":\"\",\"option\":\"0\",\"fundAtEndOfTheYear\":\"0\",\"investmentType\":null},\"riders\":[{\"premium\":\"123.00\",\"frequency\":\"12\",\"coverTerms\":\"1\",\"paymentTerms\":\"1\",\"cashBonusOptions\":\"1\",\"productId\":13001,\"modeDisc\":\"1.0272\",\"productName\":\"PNB MetLife Accidental Death Benefit Rider Plus\",\"planId\":11,\"planName\":\"Joint Life Last Survivor Annuity with Return of Purchase Price\",\"sumAssured\":\"1.00\",\"annualPremium\":\"8083446.00\",\"modalPremium\":\"8083446.00\",\"serviceTax\":\"145502.00\",\"revisionaryBonus\":\"1000.00\",\"terminalBonus\":\"1000.00\",\"maturityBenefit\":\"1000.00\",\"guaranteedIncome\":\"1000.00\",\"accruedReversionaryBonuses\":\"1000.00\",\"incomePayoutMode\":\"9\",\"maturityAge\":\"1\",\"deferment\":1,\"defermentValue\":\"1\",\"guaranteedDeathBenefit\":\"1000.00\",\"totalPayout\":\"1000.00\",\"multiple\":\"0\",\"fundStrategy\":\"1\",\"benefitPayoutDate\":\"\",\"option\":\"0\",\"fundAtEndOfTheYear\":\"0\",\"investmentType\":null}],\"fna\":null,\"lovedOne\":{\"title\":null,\"firstName\":\"Mohan\",\"lastName\":\"Jain\",\"gender\":\"M\",\"dateOfBirth\":\"1964-01-21\",\"age\":\"52\"},\"funds\":[],\"payment\":null,\"isACHADM\":false,\"isActive\":true,\"isAdded\":false,\"isDocSubmited\":false,\"isCRMIntegrationCompleted\":false}\r\n"
						+ "",
				LeadDetail.class);

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((LeadDetail ld) -> {
			ld_save.setLeadId(ld.getLeadId());
			ld_save.setCreatedOn(ld.getCreatedOn());
			ld_save.setExpiredOn(ld.getExpiredOn());
			ld_save.setLastUpdatedOn(ld.getLastUpdatedOn());
			return ld.equals(ld_save);
		}));

		Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(eq(saveApplicationUrl),
				any(HttpHeaders.class), argThat((String request) -> {
					return ContextWrapper.getAppProperty(
							"com.pmli.ms.bo.customer.save.application.request.mssp.with.frequency.code.half.yearly"
									+ "")
							.equals(request);
				}));

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((String leadId) -> leadId != null),
				argThat((Document d) -> d.getString("applicationNumber")
						.equals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString())
						&& d.getString("recordStatus").isEmpty()));

		MvcResult result = callPostEndpoint(CREATE_APPLICATION_URI, ContextWrapper.getAppProperty(
				"com.pmli.ms.bo.customer.uri.create.application.valid.mssp.with.frequency.code.half.yearly"));

		assertResponse(result, 200);
		assertEquals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString(),
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("applicationNumber").toString()
						.replace("\"", ""));
	}

	@Test
	 void test_validation_positive_all_parameters_mspp_with_funds() throws Exception {
		LeadDetail ld_save = JsonUtil.readValue(
				"{'leadId':null,'recordStatus':'','createdOn':null,'employeeInfo':null,'token':null,'personalInfo':null,'criticalInfoDetails':null,'lifeStyleInfo':null,'buyType':'2','name':'Mr. Mohan  Jain','title':null,'firstName':'Mohan','lastName':'Jain','gender':'M','dateOfBirth':'1989-12-12','pinNo':'110017','annualIncome':'8083446.41','mobileNumber':'9821212123','emailId':'abc@pnbmetlife.com','age':'16','suitabilityAnalysis':'2','quotationId':'875745712312','proposalNumber':'','applicationNumber':'','educationalQualification':'2','occupation':'1','step':'6','city':'Mumbai','state':'MH','district':'Mumbai Suburban','country':'91','lastUpdatedOn':null,'action':null,'otp':null,'transactionId':null,'utmSource':'Direct','utmMedium':'Direct','utmCampaign':'Direct','fosCode':'0','fosCodeType':'0','planId':'12029','documentInfoDetails':null,'expiredOn':null,'payout':null,'jointLifeDateOfBirth':'','jointLifeAge':'0','jointLifeName':'Mohan  Jain','premiumCalculation':{'premium':'123.00','frequency':'12','coverTerms':'1','paymentTerms':'1','cashBonusOptions':'1','productId':12025,'modeDisc':'1.0272','productName':'PNB MetLife Smart Platinum Plus','planId':11,'planName':'Joint Life Last Survivor Annuity with Return of Purchase Price','sumAssured':'145502.00','annualPremium':'8083446.00','modalPremium':'8083446.00','serviceTax':'145502.00','revisionaryBonus':'145502.00','terminalBonus':'1000.00','maturityBenefit':'1000.00','guaranteedIncome':'1000.00','accruedReversionaryBonuses':'1000.00','incomePayoutMode':'9','maturityAge':'52','deferment':1,'defermentValue':'1','guaranteedDeathBenefit':'1000.00','totalPayout':'1000.00','multiple':'0','fundStrategy':'1','benefitPayoutDate':'','option':'0','fundAtEndOfTheYear':'0','investmentType':null},'riders':[],'fna':null,'lovedOne':{'title':null,'firstName':'Mohan','lastName':'Jain','gender':'M','dateOfBirth':'1964-01-21','age':'52'},'funds':[{'fundId':1,'fundPercent':10}],'payment':null,'isACHADM':false,'isActive':true,'isAdded':false,'isDocSubmited':false,'isCRMIntegrationCompleted':false}",
				LeadDetail.class);

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((LeadDetail ld) -> {
			ld_save.setLeadId(ld.getLeadId());
			ld_save.setCreatedOn(ld.getCreatedOn());
			ld_save.setExpiredOn(ld.getExpiredOn());
			ld_save.setLastUpdatedOn(ld.getLastUpdatedOn());
			return ld.equals(ld_save);
		}));

		Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(argThat((String leadId) -> leadId != null),
				argThat((Document d) -> d.getString("applicationNumber")
						.equals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString())
						&& d.getString("recordStatus").isEmpty()));

		Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(eq(saveApplicationUrl),
				any(HttpHeaders.class), argThat((String request) -> {
					return ContextWrapper
							.getAppProperty("com.pmli.ms.bo.customer.save.application.request.mssp.with.funds" + "")
							.equals(request);
				}));

		MvcResult result = callPostEndpoint(CREATE_APPLICATION_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.uri.create.application.valid.funds.mspp"));

		assertResponse(result, 200);
		Assertions.assertEquals(DocUtil.get(Document.parse(apiResponse), "body.applicationNumber").toString(),
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("applicationNumber").toString()
						.replace("\"", ""));
	}
}
