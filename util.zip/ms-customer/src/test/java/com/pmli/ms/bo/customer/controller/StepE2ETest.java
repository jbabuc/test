package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.spring.ContextWrapper;

/**
 * @author 3483784san
 */

 class StepE2ETest extends BaseContextLoader {
    private static final String BASE_PATH = "com.pmli.ms.bo.customer.add.step.";

    @MockBean
    private DBClient mockDBClient;

    @Test
     void test_positive_add_step() throws Exception {
        Document doc_save = Document.parse(ContextWrapper.getAppProperty(BASE_PATH + "valid"));
        when(mockDBClient.saveLeadDetail(argThat((String leadId) -> leadId != null),
            argThat((Document d) -> d.getInteger("step") == (doc_save.getInteger("step"))))).thenReturn(1L);
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.invalid.leadId"), 400));
    }

    @Test
     void test_no_data_add_step() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty(BASE_PATH + "valid"), 404));
    }

    @Test
     void test_empty_lead_id() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty(BASE_PATH + "empty.leadId"), 400));
    }

    @Test
     void test_invalid_length_lead_id() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty(BASE_PATH + "length.leadId"), 400));
    }

    @Test
     void test_invalid_lead_id() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty(BASE_PATH + "invalid.leadId"), 400));

    }

    @Test
     void test_invalid_step() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty(BASE_PATH + "uri"),
            ContextWrapper.getAppProperty(BASE_PATH + "invalid.step"), 400));
    }

}
