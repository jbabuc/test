package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.JUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.client.RestConsumer;

 class PremiumCalculationE2ETest extends BaseContextLoader {

	private final static String CALCULATE_PREMIUM_URI = "/v1/customer/calculate-premium";

	@MockBean
	private DBClient mockDBClient;

	@MockBean
	private RestConsumer mockConsumer;

	private String nvestUrl;

	@BeforeEach
	public void secondarySetup() throws Exception {

		LeadDetail ld = JsonUtil.readValue(new String(getResponse("lead-detail.json")), LeadDetail.class);
		Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(Mockito.any());
		JUtil.setLogLevel(ValidationHelper.class, ch.qos.logback.classic.Level.INFO);
		nvestUrl = "http://" + ContextWrapper.getAppProperty("com.pmli.nvest.hostPort")
				+ "/NsureServices.svc/GenerateBiApi";
	}

	private String getResponse(String fileName) throws IOException {
		File resourceFile = new File(getClass().getClassLoader().getResource(fileName).getFile());
		return new String(Files.readAllBytes(resourceFile.toPath()));
	}

	// All Valid Parameters of SPP
	@Test
	 void calculate_premium_SPP() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Smart Platinum Plus"))).thenReturn("12025");

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {
			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.spp")
					.equals(request);
		}))).thenReturn(getResponse("pc-nvest-response.json"));

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), Mockito.any()))
				.thenReturn(getResponse("pc-nvest-response.json"));

		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.spp"));
		assertResponse(result, 200);
		assertEquals("80000127208",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("quotationId").asText());
		assertEquals(Document.parse(getResponse("pc-spp-response.json")),
				Document.parse(result.getResponse().getContentAsString()));
	}

	// All Valid Parameters of SSP
	@Test
	 void calculate_premium_SSP() throws Exception {
		// prepare mock data

		when(mockDBClient.getProductId(eq("PNB MetLife Super Saver Plan"))).thenReturn("12007");
		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), Mockito.any()))
				.thenReturn(getResponse("pc-ssp-nvest-response.json"));

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {
			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.ssp")
					.equals(request);
		}))).thenReturn(getResponse("pc-ssp-nvest-response.json"));

		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.ssp"));
		assertResponse(result, 200);
		assertEquals("80000205558",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("quotationId").asText());
		assertEquals(Document.parse(getResponse("pc-ssp-response.json")),
				Document.parse(result.getResponse().getContentAsString()));
	}

	// All Valid Parameters of IAP
	@Test
	 void calculate_premium_IAP() throws Exception {

		when(mockDBClient.getProductId(eq("PNB MetLife Immediate Annuity Plan"))).thenReturn("12029");
		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), Mockito.any()))
				.thenReturn(getResponse("pc-iap-nvest-response.json"));

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {
			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.iap")
					.equals(request);
		}))).thenReturn(getResponse("pc-iap-nvest-response.json"));

		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.iap"));
		assertResponse(result, 200);
		assertEquals("80000205564",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("quotationId").asText());
		assertEquals(Document.parse(getResponse("pc-iap-response.json")),
				Document.parse(result.getResponse().getContentAsString()));
	}

	// All Valid Parameters of GFP
	@Test
	 void calculate_premium_GFP() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Guaranteed Future Plan"))).thenReturn("12020");

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {

			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.gfp")
					.equals(request);
		}))).thenReturn(getResponse("pc-gfp-nvest-response.json"));

		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any(), Mockito.any());
		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.gfp"));
		assertResponse(result, 200);
		assertEquals("80000205557",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("quotationId").asText());
		assertEquals(Document.parse(getResponse("pc-gfp-response.json")),
				Document.parse(result.getResponse().getContentAsString()));
	}
	// li name null
	@Test
	 void calculate_premium_liName() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Guaranteed Future Plan"))).thenReturn("12020");

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {
			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.liName")
					.equals(request);
		}))).thenReturn(getResponse("pc-gfp-nvest-response.json"));

		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any(), Mockito.any());
		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.liName"));
		assertResponse(result, 200);

		assertEquals("80000205557",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("quotationId").asText());
		assertEquals(Document.parse(getResponse("pc-gfp-response.json")),
				Document.parse(result.getResponse().getContentAsString()));

	}

	// invalid product id
	@Test
	 void invalid_productId() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Guaranteed Future Plan"))).thenReturn(null);
		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.invalid.product"));
		assertResponse(result, 404);
		assertEquals("Invalid Product Id.",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// invalid multiple
	@Test
	 void multiple_null() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Smart Platinum Plus"))).thenReturn("12025");
		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.multiple"));
		assertResponse(result, 400);
		assertEquals("multiple cannot be null",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// invalid fundStrategyId
	@Test
	 void fundStrategyId_empty() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Smart Platinum Plus"))).thenReturn("12025");
		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.fundStrategyId"));
		assertTrue(assertResponse(result, 400));
	}

	// nvest Exception
	@Test
	 void nvest_exception() throws Exception {
		// prepare mock data
		when(mockDBClient.getProductId(eq("PNB MetLife Guaranteed Future Plan"))).thenReturn("12020");

		when(mockConsumer.callClientEndPoint(eq(nvestUrl), any(HttpHeaders.class), argThat((String request) -> {
			return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.nvest.request.gfp")
					.equals(request);
		}))).thenReturn(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.response.error"));

		// call
		MvcResult result = callPostEndpoint(CALCULATE_PREMIUM_URI,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.calculate.premium.request.gfp"));
		assertTrue(assertResponse(result, 200));
	}
}
