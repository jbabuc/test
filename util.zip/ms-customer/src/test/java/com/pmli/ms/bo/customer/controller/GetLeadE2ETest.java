package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.File;
import java.nio.file.Files;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;

class GetLeadE2ETest extends BaseContextLoader {
	@MockBean
	private DBClient mockDBClient;
	private String endPoint = "/v1/customer/get-lead-by-lead-id?leadId=";
	public static final String LEAD_ID = "22072021151804292";
	public static final String GET_LEAD_BY_ID = "/v1/customer/get-lead-by-lead-id?leadId=637595401763136343";

	@Test
	void test_empty_lead_id() throws Exception {
		test_common(endPoint + "", 400, "Lead Id must not be blank with max 32 digits.", "errorMoreInfo");
	}

	@Test
	void test_validation_invalid_lead_id() throws Exception {
		test_common(endPoint + "1234543848484858484848484848484848488", 400,
				"Lead Id must not be blank with max 32 digits.", "errorMoreInfo");
	}

	@Test
	void test_get_lead_byId() throws Exception {
		LeadDetail lead = JsonUtil.readValue(
				new String(Files.readAllBytes(
						new File(getClass().getClassLoader().getResource("lead.json").getFile()).toPath())),
				LeadDetail.class);
		when(mockDBClient.getLeadDetail(eq("637595401763136343"))).thenReturn(lead);
		assertTrue(callEndPointAndAssert(GET_LEAD_BY_ID, 200));
	}

	private void test_common(String endpoint, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callGetEndPoint(endpoint);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}
}
