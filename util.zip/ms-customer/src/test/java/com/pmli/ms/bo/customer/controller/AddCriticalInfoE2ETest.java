package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

/**
 * @author VivekGupta
 * @since JUNE-2021
 * @version 1.0.0
 */

class AddCriticalInfoE2ETest extends BaseContextLoader {

	@MockBean
	private DBClient mockDBClient;

	private int SUCCESS_CODE = 200;
	private int BAD_REQUSET_CODE = 400;
	private String LEAD_ID = "26032021111431234";
	private String CRITICAL_INFO_ENDPOINT = "/v1/customer/add-critical-info";
	private String BASE_PATH = "com.pmli.ms.bo.customer.critical.info.";
	private String POSITIVE_SCENARIO = BASE_PATH + "positive.scenario.";
	private String NEGATIVE_SCENARIO = BASE_PATH + "negative.scenario.";
	private String POSITIVE_INPUTPAYLOAD = POSITIVE_SCENARIO + "input.payload";
	private String EMPTY = NEGATIVE_SCENARIO + "empty.";
	private String INVALID = NEGATIVE_SCENARIO + "invalid.";
	private String EMPTY_VALUE = EMPTY + "value";
	private String EMPTY_KEY = EMPTY + "key";
	private String EMPTY_NAME = EMPTY + "name";
	private String EMPTY_SUBSTANCE_CONSUMED = EMPTY + "substance.consumed";
	private String EMPTY_SUBSTANCE_CONSUMED_TYPE = EMPTY + "substance.consumed.type";
	private String INVALID_CURRENT_PREGNANCY_MONTH = INVALID + "current.pregnancy.month";
	private String LEAD_MONGO_DATA = POSITIVE_SCENARIO + "mongodb.lead";
	private String ERROR_MORE_INFO = "errorMoreInfo";
	private String POSITIVE_OUT_MODEL = POSITIVE_SCENARIO + "output.model";

	@Test
	void test_positive_scenario_add_critical_info() throws Exception {
		LeadDetail leadIn = JsonUtil.readValue(ContextWrapper.getAppProperty(LEAD_MONGO_DATA), LeadDetail.class);
		LeadDetail leadOut = JsonUtil.readValue(ContextWrapper.getAppProperty(POSITIVE_OUT_MODEL), LeadDetail.class);
		when(mockDBClient.getLeadDetail(eq(LEAD_ID))).thenReturn(leadIn);
		Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(leadOut)) {
				MsObject.getSL().error("Expected out: " + JsonUtil.writeValueAsString(leadOut));
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));
		resultAssertTrue(ContextWrapper.getAppProperty(POSITIVE_INPUTPAYLOAD), SUCCESS_CODE,
				"Critical Information added successfully", "message");
	}

	@Test
	void test_negative_scenario_empty_value() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(EMPTY_VALUE), BAD_REQUSET_CODE,
				"value=0, must be greater than 0.", ERROR_MORE_INFO);
	}

	@Test
	void test_negative_scenario_empty_key() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(EMPTY_KEY), BAD_REQUSET_CODE, "key=0, must be greater than 0.",
				ERROR_MORE_INFO);
	}

	@Test
	void test_negative_scenario_empty_name() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(EMPTY_NAME), BAD_REQUSET_CODE, "name=\"\", cannot be blank.",
				ERROR_MORE_INFO);
	}

	@Test
	void test_negative_scenario_empty_substance_consumed() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(EMPTY_SUBSTANCE_CONSUMED), BAD_REQUSET_CODE,
				"substanceConsumed=0, must be greater than 0.", ERROR_MORE_INFO);
	}

	@Test
	void test_negative_scenario_empty_substance_consumed_type() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(EMPTY_SUBSTANCE_CONSUMED_TYPE), BAD_REQUSET_CODE,
				"substanceConsumedType=0, must be greater than 0.", ERROR_MORE_INFO);
	}

	@Test
	void test_negative_scenario_invalid_current_pregnancy_month() throws Exception {
		resultAssertTrue(ContextWrapper.getAppProperty(INVALID_CURRENT_PREGNANCY_MONTH), BAD_REQUSET_CODE,
				"currentPregnancyMonth=24, must be less than 10.", ERROR_MORE_INFO);
	}

	private void resultAssertTrue(String inputPayload, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callPostEndpoint(CRITICAL_INFO_ENDPOINT, inputPayload);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}
}
