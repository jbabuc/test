package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class RidersE2ETest extends BaseContextLoader {

    private final static String ADD_RIDERS_URI = "/v1/customer/add-riders";
    
    private final String apiResponse = "{ \"head\": { \"statusCode\": 100 }, \"body\": { \"applicationNumber\": \"150048828\" } }";
    
    @MockBean
    private RestConsumer restConsumer;

    @MockBean
    private DBClient mockDBClient;
    // Negative Cases

    // Invalid Lead Id
    @Test
     void test_validation_invalid_leadId() throws Exception {
        assertTrue(callEndPointAndAssert(ADD_RIDERS_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.invalid.leadId"), 400));
    }

    // Invalid Product Id
    @Test
     void test_validation_invalid_productId() throws Exception {
        assertTrue(callEndPointAndAssert(ADD_RIDERS_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.invalid.productId"), 400));

    }

    // Invalid Product Name
    @Test
     void test_validation_invalid_productName() throws Exception {
        assertTrue(callEndPointAndAssert(ADD_RIDERS_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.invalid.productName"), 400));
    }

    // Positive Case
    @Test
     void test_positive() throws Exception {
        LeadDetail ld = JsonUtil.readValue(new String(getResponse("lead-detail.json")), LeadDetail.class);
        ld.setApplicationNumber("");
        Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(Mockito.any());
        Document doc_save = Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.valid"));
        Document doc_model = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.valid.model"));

        Mockito.doReturn(DocUtil.get(doc_save, "riders[0].productName").toString()).when(mockDBClient)
            .getMasterValueByTypeKey(eq("riderShortNames"),
                eq(DocUtil.get(doc_save, "riders[0].productId").toString()));

        when(restConsumer.callClientEndPoint(any(), any(), any())).thenReturn(apiResponse);
        
        Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> doc_save.getString("leadId").equals(leadId)), argThat((Document d) -> {
                return d.equals(doc_model);
            }));
        assertTrue(callEndPointAndAssert(ADD_RIDERS_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.valid"), 200));
        
    }
    
    @Test
     void test_negative_not_found() throws Exception {
        Mockito.doReturn(null).when(mockDBClient).getLeadDetail(Mockito.any());
        Document doc_save = Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.valid"));

        Mockito.doReturn(DocUtil.get(doc_save, "riders[0].productName").toString()).when(mockDBClient)
            .getMasterValueByTypeKey(eq("riderShortNames"),
                eq(DocUtil.get(doc_save, "riders[0].productId").toString()));
        MvcResult result = callPostEndpoint(ADD_RIDERS_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.riders.valid"));

        assertResponse(result, 404);
        assertEquals("No record found in database",
            JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
    }
    
    private String getResponse(String fileName) throws IOException {
        File resourceFile = new File(getClass().getClassLoader().getResource(fileName).getFile());
        return new String(Files.readAllBytes(resourceFile.toPath()));
    }
}
