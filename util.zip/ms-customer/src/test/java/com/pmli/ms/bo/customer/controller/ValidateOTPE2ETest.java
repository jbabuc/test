package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MvcResult;
import com.pmli.ms.bo.customer.comm.OtpClient;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;


/**
 * @author 3483784san
 */

 class ValidateOTPE2ETest extends BaseContextLoader {
	private static final String BASE_PATH = "com.pmli.ms.bo.customer.mgfp.validate.otp.";

	@MockBean
	OtpClient otpClient;
	
	@MockBean
	private DBClient mockDBClient;

	@Test
	 void test_positive_validate_otp() throws Exception {
		Document docModelIn = Document.parse(ContextWrapper.getAppProperty(BASE_PATH + "request"));
		Document docModelOut = Document.parse(ContextWrapper.getAppProperty(BASE_PATH + "modal"));
		
		ResponseEntity<String> responseEntity = new ResponseEntity<String>(
				"{\"message\":\"success\",\"counter\":\"1\",\"allowedAttempts\":\"3\"}\r\n" + "", HttpStatus.OK);
		when(otpClient.validateOtp(Mockito.anyString(), Mockito.anyString())).thenReturn(responseEntity);

		Mockito.doReturn(JsonUtil.readValue(docModelOut.toJson(), LeadDetail.class)).when(mockDBClient)
				.getLeadDetail(argThat(leadId -> docModelIn.getString("leadId").equals(leadId)));
		
		Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(JsonUtil.readValue(docModelOut.toJson(), LeadDetail.class))) {
				MsObject.getSL().error("Expected out: " + docModelOut.toJson());
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));

		test_common(ContextWrapper.getAppProperty(BASE_PATH + "request"), 200);
	}

	private void test_common(String inputPayload, int httpStatus) throws Exception {
		MvcResult result = callPostEndpoint(ContextWrapper.getAppProperty(BASE_PATH + "url"), inputPayload);
		assertResponse(result, httpStatus);
		assertEquals(httpStatus, result.getResponse().getStatus());
	}
}
