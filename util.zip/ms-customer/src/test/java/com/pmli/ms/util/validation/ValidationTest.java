package com.pmli.ms.util.validation;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.jupiter.api.Test;

import com.pmli.ms.bo.customer.request.PremiumCalcClientReq;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.validation.ValidationHelper;

 class ValidationTest {

    @Test
     void testValidation() throws IOException {
        File resourceFile = new File(getClass().getClassLoader().getResource("pc-request.json").getFile());
        new ValidationHelper(
            JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), PremiumCalcClientReq.class))
                .validateWithMetaJson();
    }

}
