package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.File;
import java.nio.file.Files;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;

class FetchLeadE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient           mockDBClient;
    public static final String GET_LEAD_BY_ID             = "/v1/customer/get-lead-by-lead-id?leadId=637595401763136343";
    public static final String GET_LEAD_BY_APPLICATION_NO = "/v1/customer/get-lead-by-application-no?applicationNo=150053535";

    @Test
    void test_get_lead_byId() throws Exception {
        LeadDetail lead = JsonUtil.readValue(
            new String(
                Files.readAllBytes(new File(getClass().getClassLoader().getResource("lead.json").getFile()).toPath())),
            LeadDetail.class);
        when(mockDBClient.getLeadDetail(eq("637595401763136343"))).thenReturn(lead);
        assertTrue(callEndPointAndAssert(GET_LEAD_BY_ID, 200));
    }

    @Test
    void test_get_lead_byAppNo() throws Exception {
        LeadDetail leadDetail = JsonUtil.readValue(
            new String(
                Files.readAllBytes(new File(getClass().getClassLoader().getResource("lead.json").getFile()).toPath())),
            LeadDetail.class);
        when(mockDBClient.getLeadDetailByApplicationNumber(eq("150053535"))).thenReturn(leadDetail);
        assertTrue(callEndPointAndAssert(GET_LEAD_BY_APPLICATION_NO, 200));
    }

    @Test
    void test_get_lead_notFound() throws Exception {
        when(mockDBClient.getLeadDetailByApplicationNumber(eq("637595401763136348"))).thenReturn(null);
        assertTrue(callEndPointAndAssert(GET_LEAD_BY_APPLICATION_NO, 404));
    }
}
