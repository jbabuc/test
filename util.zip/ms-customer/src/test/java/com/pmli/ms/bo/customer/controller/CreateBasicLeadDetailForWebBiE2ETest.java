package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

/**
 * To test create basic lead detail for web bi feature
 * 
 * @author 3448466ami
 */
 class CreateBasicLeadDetailForWebBiE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    @Test
     void test_validation_negative_invalid_gender() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.gender"), 400));
    }

    @Test
     void test_validation_negative_invalid_firstname() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.name.firstName.null"), 200));
    }

    @Test
     void test_validation_negative_invalid_lastname() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.name.lastName.null"), 200));
    }

    @Test
     void test_validation_negative_invalid_name() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.name.null"), 200));
    }

    @Test
     void test_validation_negative_invalid_birthdate() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.birthdate"), 400));
    }

    @Test
     void test_validation_negative_invalid_blank_birthdate() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.Invalid.birthdate.blank"), 400));
    }
    
    @Test
	 void test_validation_Negative_invalid_BuyTypeCode() throws Exception {
		assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.invalid.buy.type.code"),
				400));
	}
    
    // All Valid Parameters
    @Test
     void test_validation_positive_all_parameters() throws Exception {

        LeadDetail ld = JsonUtil.readValue(new String(getResponse("lead-detail.json")), LeadDetail.class);
        ld.setApplicationNumber("");

        Mockito.doReturn(ld.getTitle()).when(mockDBClient).getMasterKeyByTypeValue(Mockito.any(), Mockito.any());
        Mockito.doReturn(Long.valueOf(ld.getLeadId())).when(mockDBClient).saveLeadDetail(ld);
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.create.lead.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.web.bi.uri.create.lead.valid.all.parameters"), 200));
    }

    private String getResponse(String fileName) throws IOException {
        File resourceFile = new File(getClass().getClassLoader().getResource(fileName).getFile());
        return new String(Files.readAllBytes(resourceFile.toPath()));
    }

}