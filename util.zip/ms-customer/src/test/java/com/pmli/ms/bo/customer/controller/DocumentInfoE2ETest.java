package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class DocumentInfoE2ETest extends BaseContextLoader {
	private static final String DOCUMENT_INFO_URL = "/v1/customer/add-document-info";

	@MockBean
	private DBClient mockDBClient;

	// Negative Case
	@Test
	void test_invalid_lead_id() throws Exception {
		assertTrue(callEndPointAndAssert(DOCUMENT_INFO_URL,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.document.info.invalid.leadId"), 400));
	}

	// Positive Case

	@Test
	 void test_positive() throws Exception {
		Document doc_save = Document
				.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.document.info.valid.model.in"));

		Mockito.doReturn("1890-PI-math-12082021182829914.jpg").when(mockDBClient).isFileRefs(Mockito.any(),
				Mockito.any());
		Mockito.doReturn(JsonUtil.readValue(doc_save.toJson(), LeadDetail.class)).when(mockDBClient)
				.getLeadDetail(Mockito.any());
		Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(Mockito.any());
		assertTrue(callEndPointAndAssert(DOCUMENT_INFO_URL,
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.document.info.valid"), 200));
	}
}
