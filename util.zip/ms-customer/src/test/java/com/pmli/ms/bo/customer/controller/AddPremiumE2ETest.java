package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class AddPremiumE2ETest extends BaseContextLoader {

    private final long          res              = 1;
    private final static String ADD_PREMIMUM_URI = "/v1/customer/add-premium";

    @MockBean
    private DBClient mockDBClient;

    // Negative Test Case
    @Test
     void test_validation_invalid_leadId() throws Exception {
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.invalid.leadId"), 400));
    }

    // Invalid Product Id
    @Test
     void test_validation_invalid_productId() throws Exception {
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.invalid.productId"), 404));
    }

    // Invalid Product Name
    @Test
     void test_validation_invalid_productName() throws Exception {
        Document doc_save = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.invalid.productName"));
        Mockito.doReturn("PNB MetLife Super Saver Plan").when(mockDBClient).getAppConfigFieldValById(
            eq(DocUtil.get(doc_save, "premiumCalculation.productId").toString()), eq("productName"));
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.invalid.productName"), 400));
    }

    // Positive Case
    @Test
     void test_positive() throws Exception {
        Document doc_save = Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid"));
        Document doc_model = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.model"));

        Mockito.doReturn(DocUtil.get(doc_save, "premiumCalculation.productName").toString()).when(mockDBClient)
            .getAppConfigFieldValById(eq("productName"),
                eq(DocUtil.get(doc_save, "premiumCalculation.productId").toString()));

        Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> doc_save.getString("leadId").equals(leadId)), argThat((Document d) -> {
                return d.equals(doc_model);
            }));
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid"), 200));

    }

    @Test
     void test_positive_mgfp() throws Exception {
        Document doc_save = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mgfp"));
        Document doc_model = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mgfp.model"));

        Mockito.doReturn(DocUtil.get(doc_save, "premiumCalculation.productName").toString()).when(mockDBClient)
            .getAppConfigFieldValById(eq("productName"),
                eq(DocUtil.get(doc_save, "premiumCalculation.productId").toString()));

        Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> doc_save.getString("leadId").equals(leadId)), argThat((Document d) -> {
                return d.equals(doc_model);
            }));
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mgfp"), 200));
    }

    @Test
     void test_positive_miap() throws Exception {
        Document doc_save = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.miap"));
        Document doc_model = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.miap.model"));

        Mockito.doReturn(DocUtil.get(doc_save, "premiumCalculation.productName").toString()).when(mockDBClient)
            .getAppConfigFieldValById(eq("productName"),
                eq(DocUtil.get(doc_save, "premiumCalculation.productId").toString()));

        Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> doc_save.getString("leadId").equals(leadId)), argThat((Document d) -> {
            	System.out.println("1"+JsonUtil.writeValueAsString(d));
                return d.equals(doc_model);
            }));
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.miap"), 200));
    }

    @Test
     void test_positive_mspp() throws Exception {
        Document doc_save = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mspp"));
        Document doc_model = Document
            .parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mspp.model"));

        Mockito.doReturn(DocUtil.get(doc_save, "premiumCalculation.productName").toString()).when(mockDBClient)
            .getAppConfigFieldValById(eq("productName"),
                eq(DocUtil.get(doc_save, "premiumCalculation.productId").toString()));

        Mockito.doReturn(res).when(mockDBClient).saveLeadDetail(
            argThat((String leadId) -> doc_save.getString("leadId").equals(leadId)), argThat((Document d) -> {
                return d.equals(doc_model);
            }));
        assertTrue(callEndPointAndAssert(ADD_PREMIMUM_URI,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.premium.valid.mspp"), 200));
    }
}