package com.pmli.ms.bo.customer.controller;

import static org.mockito.ArgumentMatchers.endsWith;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class DownloadPdfE2ETest extends BaseContextLoader {

	@MockBean
	private DBClient mockDBClient;
	@MockBean
	private RestConsumer mockConsumer;

	private String QUOTATION_ID = "70000127856";
	private String DOWNLOAD_PDF_ENDPOINT = "/v1/customer/download-pdf?leadId=26032021111431777";
	private String LEAD_ID = "26032021111431777";
	private String BASE_PATH = "com.pmli.ms.bo.customer.download.pdf.";
	private String POSITIVE_SCENARIO = BASE_PATH + "positive.scenario.";
	private String LEAD_MONGO_DATA= POSITIVE_SCENARIO + "mongodb.lead";

	@Test
	 void test_positive_scenario_download_pdf() {
		LeadDetail leadIn = JsonUtil.readValue(ContextWrapper.getAppProperty(LEAD_MONGO_DATA), LeadDetail.class);
		when(mockDBClient.getLeadDetail(eq(LEAD_ID))).thenReturn(leadIn);
		when(mockConsumer.callClientGetEndPoint(endsWith(QUOTATION_ID)))
				.thenReturn("{'DataBytes':[1,2,3],'Status':'Success','dataString':'abc','remarks':''}");
		callEndPointAndAssert(DOWNLOAD_PDF_ENDPOINT, 200);
	}
}
