package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.endsWith;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.web.client.RestConsumer;

/**
 * @author 3483784san
 */

 class DownloadBiE2ETest extends BaseContextLoader {

    public static final String QUOTATION_ID = "80000202552";
    public static final String ENDPOINT     = "/v1/customer/download-bi/";

    @MockBean
    private RestConsumer mockConsumer;

    @Test
     void test_validation_invalid_quotationId() throws Exception {
        test_common(ENDPOINT + "800avvava", 400, "Quotation Id must not be blank with max 32 digits.", "errorMoreInfo");
    }

    @Test
     void test_download_bi_positive_all_parameters() throws Exception {
        when(mockConsumer.callClientGetEndPoint(endsWith(QUOTATION_ID)))
            .thenReturn("{'DataBytes':[1,2,3],'Status':'Success','dataString':'abc','remarks':''}");
        test_common(ENDPOINT + QUOTATION_ID, 200, "abc", "fileContent");
    }

    private void test_common(String endpoint, int httpStatus, String response, String key) throws Exception {
        MvcResult result = callGetEndPoint(endpoint);
        assertResponse(result, httpStatus);
        assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
    }
}
