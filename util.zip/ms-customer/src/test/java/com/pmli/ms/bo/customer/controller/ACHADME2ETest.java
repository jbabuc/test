package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class ACHADME2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    // negative case
    // Invalid Lead Id
    @Test
     void test_validation_invalid_leadId() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.invalid.leadId"), 400));
    }

    // Invalid lead id length
    @Test
     void test_validation_invalid_leadId_length() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.length.leadId"), 400));
    }

    // Empty lead Id
    @Test
     void test_validation_empty_leadId() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.empty.leadId"), 400));
    }

    // Invalid achadm
    @Test
     void test_validation_invalid_achadm() throws Exception {
        assertTrue(callEndPointAndAssert(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.invalid.achadm"), 404));
    }

    // positive case
    @Test
     void test_positive_add_achadm() throws Exception {
        Document doc_save = Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.valid"));
        when(mockDBClient.saveLeadDetail(argThat((String leadId) -> leadId != null),
            argThat((Document d) -> d.getBoolean("isACHADM").equals(doc_save.getBoolean("isACHADM"))))).thenReturn(1L);
        MvcResult result = callPostEndpoint(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.uri"),
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.achadm.valid"));
        assertTrue(assertResponse(result, 200));
        assertEquals("Is ACHADM Information added successfully",
            JsonUtil.readJson(result.getResponse().getContentAsString()).get("message").asText());
    }

}
