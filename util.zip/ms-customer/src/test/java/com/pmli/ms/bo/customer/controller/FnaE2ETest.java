package com.pmli.ms.bo.customer.controller;

import static com.pmli.util.spring.ContextWrapper.getAppProperty;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.service.CustomerServiceImpl;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class FnaE2ETest extends BaseContextLoader {

	@MockBean
	private DBClient spyDBClient;

	private static final String FNA_URL = "/v1/mgfp/add-fna";

	@Test
	 void test_add_fna() throws Exception {
		Document fna_model = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.model"));
		Document fna_model_in = Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.fna"));

		Mockito.doReturn(JsonUtil.readValue(fna_model_in.toJson(), LeadDetail.class)).when(spyDBClient)
				.getLeadDetail(argThat(leadId -> fna_model_in.getString("leadId").equals(leadId)));

		Mockito.doReturn(1l).when(spyDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(JsonUtil.readValue(fna_model.toJson(), LeadDetail.class))) {
				MsObject.getSL().error("Expected out: " + fna_model.toJson());
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));

		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.fna"), 200, "Fna added successfully",
				"message");
	}

	// All Valid Parameters with Goal as Child Education
	@Test
	 void test_child_education() throws Exception {
		Document fna_model = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.child.edu.model"));
		Document fna_model_in = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.child.edu"));

		Mockito.doReturn(JsonUtil.readValue(fna_model_in.toJson(), LeadDetail.class)).when(spyDBClient)
				.getLeadDetail(argThat(leadId -> fna_model_in.getString("leadId").equals(leadId)));

		Mockito.doReturn(1l).when(spyDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(JsonUtil.readValue(fna_model.toJson(), LeadDetail.class))) {
				MsObject.getSL().error("Expected out: " + fna_model.toJson());
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));

		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.fna.child.edu"), 200, "Fna added successfully",
				"message");

		
	}

	// All Valid Parameters with Goal as Long Term Saving
	@Test
	 void test_long_term() throws Exception {
		Document fna_model = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.long.term.model"));
		Document fna_model_in = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.long.term"));

		Mockito.doReturn(JsonUtil.readValue(fna_model_in.toJson(), LeadDetail.class)).when(spyDBClient)
				.getLeadDetail(argThat(leadId -> fna_model_in.getString("leadId").equals(leadId)));

		Mockito.doReturn(1l).when(spyDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(JsonUtil.readValue(fna_model.toJson(), LeadDetail.class))) {
				MsObject.getSL().error("Expected out: " + fna_model.toJson());
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));

		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.add.fna.long.term"), 200, "Fna added successfully",
				"message");

	}

	// No Lead Id Found
	@Test
	 void test_lead_id_not_found() throws Exception {
		Document fna_model = Document.parse(getAppProperty("com.pmli.ms.bo.customer.add.fna.long.term.model"));
		when(spyDBClient.saveLeadDetail(eq("26032021105113296"), eq(fna_model))).thenReturn(0l);

		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.long.term"));
		assertResponse(result, 404);
		assertEquals("Invalid Lead Id",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorDetails").asText());
	}

	// Lead Id empty
	@Test
	 void test_lead_id_empty() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.lead.empty"));
		assertResponse(result, 400);
		assertEquals("Lead Id must not be blank with max 32 digits.",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Risk null
	@Test
	 void test_risk_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.risk.null"));
		assertResponse(result, 400);
		assertEquals("Risk cannot be null.",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Summary null
	@Test
	 void test_stage_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.summary.null"));
		assertResponse(result, 400);
		assertEquals("Summary cannot be null.",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Children empty
	@Test
	 void test_children_empty() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.children.empty"));
		assertResponse(result, 400);
		assertEquals("Children =0, must contain min 1 element(s).",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// OtherInfo null
	@Test
	 void test_otherinfo_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.otherInfo.null"));
		assertResponse(result, 400);
		assertEquals("ChildrenInfo  cannot be null",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Name null
	@Test
	 void test_name_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.name.null"));
		assertResponse(result, 400);
		assertEquals("Name cannot be null",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Long Term null
	@Test
	 void test_longTerm_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL, getAppProperty("com.pmli.ms.bo.customer.add.fna.longTerm.null"));
		assertResponse(result, 400);
		assertEquals("LongTermSaving cannot be null",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	// Long Term saving null
	@Test
	 void test_longTermSaving_null() throws Exception {
		// call
		MvcResult result = callPostEndpoint(FNA_URL,
				getAppProperty("com.pmli.ms.bo.customer.add.fna.longTermSaving.null"));
		assertResponse(result, 400);
		assertEquals("LongTermSaving cannot be null",
				JsonUtil.readJson(result.getResponse().getContentAsString()).get("errorMoreInfo").asText());
	}

	private void test_common(String inputPayload, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callPostEndpoint(FNA_URL, inputPayload);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}
}
