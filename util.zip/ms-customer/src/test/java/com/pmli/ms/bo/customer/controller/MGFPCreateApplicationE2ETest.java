package com.pmli.ms.bo.customer.controller;

import java.io.File;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.RestTemplate;

import com.pmli.ms.bo.customer.comm.EmailClient;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.JUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.client.RestConsumer;

public class MGFPCreateApplicationE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    @MockBean
    EmailClient emailClient;

    @MockBean
    RestTemplate restTemplate;

    @MockBean
    private RestConsumer mockConsumer;

    private final String        apiResponse            = "{ \"head\": { \"statusCode\": 100 }, \"body\": { \"applicationNumber\": \"150048828\" } }";
    private final static String CREATE_APPLICATION_URI = "/v1/mgfp/create-application";

    @BeforeEach
    public void secondarySetup() {
        JUtil.setLogLevel(ValidationHelper.class, ch.qos.logback.classic.Level.INFO);
    }

    @Test
    public void test_postive_createApplicationMgfp() throws Exception {
        File resourceFile = getFile("lead-detail.json");
        LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
        ld.setApplicationNumber("");
        Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(Mockito.any());
        Mockito.doReturn("Maharashtra").when(mockDBClient).stateExist(Mockito.any());
        Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(Mockito.any(), Mockito.any(),
            Mockito.any());
        Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any());
        test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.mgfp.create.application.request.positive"),
            200);
    }
    
    @Test
    public void test_negative_invalid_productId() throws Exception {
        test_common(ContextWrapper
            .getAppProperty("com.pmli.ms.bo.customer.mgfp.create.application.request.negative.invalid.productId"), 404);
    }
    
    @Test
    public void test_negative_invalid_planId() throws Exception {
        test_common(ContextWrapper
            .getAppProperty("com.pmli.ms.bo.customer.mgfp.create.application.request.negative.invalid.planId"), 404);
    }
    
    @Test
    public void test_negative_blank_leadId() throws Exception {
        test_common(ContextWrapper
            .getAppProperty("com.pmli.ms.bo.customer.mgfp.create.application.request.negative.blank.leadId"), 400);
    }

    private File getFile(String fileName) {
        return new File(getClass().getClassLoader().getResource(fileName).getFile());
    }

    private void test_common(String inputPayload, int httpStatus) throws Exception {
        MvcResult result = callPostEndpoint(CREATE_APPLICATION_URI, inputPayload);
        assertResponse(result, httpStatus);
    }
}
