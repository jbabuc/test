package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;

 class GetApplicationsE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    private final static String URL_FORMAT = "/v1/customer/get-applications?mobileNo=%s";
    private final static String MOBILE_NUM = "7387076122";

    @Test
     void test_positive_getApplications() throws Exception {
        File resourceFile = getFile("lead-detail.json");
        List<LeadDetail> ldLst = new ArrayList<>();
        LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
        ldLst.add(ld);
        Mockito.doReturn(ldLst).when(mockDBClient).getLeadDetailsByAnyField(Mockito.any(), Mockito.any());

        MvcResult result = callGetEndPoint(String.format(URL_FORMAT, MOBILE_NUM));
        assertResponse(result, 200);
        verify(mockDBClient).getLeadDetailsByAnyField(Mockito.any(), Mockito.any());
        
    }

    @Test
     void test_negative_dataNotFound_getApplications() throws Exception {
        List<LeadDetail> ldLst = new ArrayList<>();
        Mockito.doReturn(ldLst).when(mockDBClient).getLeadDetailsByAnyField(Mockito.any(), Mockito.any());
        test_common(MOBILE_NUM, 404, "No record found in database for requested Mobile Number 7387076122",
            "errorMoreInfo");
    }

    @Test
     void test_negative_notBlank_getApplications() throws Exception {
        test_common("", 400, "Mobile number =\"\", cannot be blank.", "errorMoreInfo");
    }

    @Test
     void test_negative_digitOnly_getApplications() throws Exception {
        test_common("738707612r", 400, "Mobile Number should be 10 digits only.", "errorMoreInfo");
    }

    private void test_common(String mobileNum, int httpStatus, String response, String key) throws Exception {
        MvcResult result = callGetEndPoint(String.format(URL_FORMAT, mobileNum));
        assertResponse(result, httpStatus);
        assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
    }

    private File getFile(String fileName) {
        return new File(getClass().getClassLoader().getResource(fileName).getFile());
    }
}