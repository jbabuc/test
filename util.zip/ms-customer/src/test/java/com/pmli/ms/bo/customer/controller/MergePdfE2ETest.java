package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.spring.ContextWrapper;

 class MergePdfE2ETest extends BaseContextLoader {
	private static final String MERGE_PDF_URL = "/v1/customer/merge-pdf";

	@MockBean
	private DBClient mockDBClient;

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@BeforeEach
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

	}

	// Negative Case
	@Test
	 void test_invalid_lead_id() throws Exception {
		test_common_JPG(MERGE_PDF_URL, ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.merge.pdf.invalid.leadId"),
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.merge.pdf.valid.fileCount"),
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.merge.pdf.valid.customerType"), null, 400);
	} 

	// Positive Case

	/*
	 * @Test public void test_positive_jpg() throws Exception { Document doc_save =
	 * Document .parse(ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.lead.model"));
	 * 
	 * Mockito.doReturn(JsonUtil.readValue(doc_save.toJson(),
	 * LeadDetail.class)).when(mockDBClient) .getLeadDetail(Mockito.any());
	 * Mockito.doNothing().when(mockDBClient).saveMergePdfFileRef(Mockito.any());
	 * test_common_JPG(MERGE_PDF_URL, ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.leadId"),
	 * ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.fileCount"),
	 * ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.customerType"), null, 200); }
	 * 
	 * @Test public void test_positive_pdf() throws Exception {
	 * 
	 * Document doc_save = Document .parse(ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.lead.model"));
	 * Mockito.doReturn(JsonUtil.readValue(doc_save.toJson(),
	 * LeadDetail.class)).when(mockDBClient) .getLeadDetail(Mockito.any());
	 * Mockito.doNothing().when(mockDBClient).saveMergePdfFileRef(Mockito.any());
	 * test_common_PDF(MERGE_PDF_URL, ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.leadId"),
	 * ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.fileCount"),
	 * ContextWrapper.getAppProperty(
	 * "com.pmli.ms.bo.customer.merge.pdf.valid.customerType"), null, 200); }
	 */

	private MvcResult callEndpointJPG(String endpointUri, String leadId, String fileCount, String customerType,
			MultipartFile idProofFileUpload, int httpStatus) {
		MvcResult result = null;
		try {
			FileInputStream inputFile = new FileInputStream(getFile("headphone.jpg"));
			MockMultipartFile firstFile = new MockMultipartFile("leadId", leadId, "text/plain", leadId.getBytes());
			MockMultipartFile secondFile = new MockMultipartFile("fileCount", fileCount, "text/plain",
					fileCount.getBytes());
			MockMultipartFile thirdFile = new MockMultipartFile("customerType", customerType, "text/plain",
					customerType.getBytes());
			MockMultipartFile fourthFile = new MockMultipartFile("IdProofFileUpload", "headphone.jpg", "image/jpeg",
					inputFile);
			MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.multipart(endpointUri).file(firstFile)
					.file(secondFile).file(thirdFile).file(fourthFile).accept(MediaType.MULTIPART_FORM_DATA_VALUE)
					.contentType(MediaType.MULTIPART_FORM_DATA_VALUE);
			result = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception exp) {
		}
		return result;
	}

	private MvcResult callEndpointPDF(String endpointUri, String leadId, String fileCount, String customerType,
			MultipartFile idProofFileUpload, int httpStatus) {
		MvcResult result = null;
		try {
			FileInputStream pdfFile = new FileInputStream(getFile("abc.pdf"));
			MockMultipartFile firstFile = new MockMultipartFile("leadId", leadId, "text/plain", leadId.getBytes());
			MockMultipartFile secondFile = new MockMultipartFile("fileCount", fileCount, "text/plain",
					fileCount.getBytes());
			MockMultipartFile thirdFile = new MockMultipartFile("customerType", customerType, "text/plain",
					customerType.getBytes());
			MockMultipartFile fourthFile = new MockMultipartFile("IdProofFileUpload", "headphone.jpg", "application/pdf",
					pdfFile);
			MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.multipart(endpointUri).file(firstFile)
					.file(secondFile).file(thirdFile).file(fourthFile).accept(MediaType.MULTIPART_FORM_DATA_VALUE)
					.contentType(MediaType.MULTIPART_FORM_DATA_VALUE);
			result = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception exp) {
		}
		return result;
	}

	private void test_common_JPG(String endpointUri, String leadId, String fileCount, String customerType,
			MultipartFile idProofFileUpload, int httpStatus) throws Exception {
		MvcResult result = callEndpointJPG(endpointUri, leadId, fileCount, customerType, idProofFileUpload, httpStatus);
		assertResponse(result, httpStatus);
		assertEquals(httpStatus, result.getResponse().getStatus());
	}
	
	private File getFile(String fileName) {
		return new File(getClass().getClassLoader().getResource(fileName).getFile());
	}
}
