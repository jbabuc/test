package com.pmli.ms.bo.customer.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.mongo.MongoClientWrapper;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class CreateBasicLeadDetailsE2ETest extends BaseContextLoader {
    
    @MockBean
    private DBClient mockDBClient;
    
    @MockBean
    private RestConsumer mockResTConsumer;
    
    @MockBean
    private MongoClientWrapper buyOnlineMCW;
    
	private final static String CREATE_BASIC_LEAD_URI = "/v1/mgfp/create-basic-lead-detail";
	
	private final String generateOtpResponse200 = "{\"transactionId\":\"TRAN12320153744\",\"counter\":\"1\",\"allowedAttempts\":\"3\"}";
	
	private final String generateOtpResponse429="{\"errorType\":\"ERROR\",\"errorCode\":110,\"errorDetails\":\"Maximum generate count reached.\",\"errorMoreInfo\":\"Your acount has been locked for 60 minutes, Please try after that.\"}";
	
	@BeforeEach
    public void secondarySetup() throws IOException {
	    File resourceFile = getFile("lead-detail.json");
        LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
        Mockito.doReturn("Mr").when(mockDBClient).getMasterKeyByTypeValue(Mockito.any(), Mockito.any());
        Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any());
        Mockito.doReturn(1L).when(buyOnlineMCW).updateMany(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any());
        Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(Mockito.any());
	}
	
	@Test
     void test_positive_200_CreateBasicLeadDetails() throws Exception {
        ResponseEntity<String> re = new ResponseEntity<String>(generateOtpResponse200, HttpStatus.OK);
        Mockito.doReturn(re).when(mockResTConsumer).callClientEndPoint(Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any());
        test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.create.basic.lead.request.positive"), 200);
    }
	
	@Test
     void test_negative_429_CreateBasicLeadDetails() throws Exception {
        ResponseEntity<String> re = new ResponseEntity<String>(generateOtpResponse429, HttpStatus.TOO_MANY_REQUESTS);
        Mockito.doReturn(re).when(mockResTConsumer).callClientEndPoint(Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any());
        test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.create.basic.lead.request.positive"), 429);
    }
	
	@Test
     void test_negative_400_CreateBasicLeadDetails() throws Exception {
        test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.create.basic.lead.request.blank.first.name"), 400);
    }

	private void test_common(String inputPayload, int httpStatus) throws Exception {
		MvcResult result = callPostEndpoint(CREATE_BASIC_LEAD_URI, inputPayload);
		assertResponse(result, httpStatus);
	}

	private File getFile(String fileName) {
		return new File(getClass().getClassLoader().getResource(fileName).getFile());
	}
}