package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;

import java.io.File;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.JUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.validation.ValidationHelper;
import com.pmli.util.web.client.RestConsumer;

class DownloadAppFormE2ETest extends BaseContextLoader {

	public static final String KEY = "22042021211513447";
	public static final String ENDPOINT = "/v1/customer/download-app-form?leadId=";
	private String apiResponse = "{ \"head\": { \"statusCode\": 100 }, \"body\": { \"document\": \"ZSuIFJcAu/A6kGQUPwFiK6qASAV1ECk9F0QKbAKREgJA8n+6MtiE2SD1M18xAAQYACBvIa4KZW5kc3RyZWFtCmVuZG9iagpzdGFydHhyZWYKMTA1MTA5CiUlRU9GCg==\" } }";
	private String apiMessgeResponse = "{ \"head\": { \"statusCode\": 98 }, \"body\": { \"message\": \"Application processed already ....!!\" } }";
	private String apiNullResponse = "{ \"head\": { \"statusCode\": 108 }, \"body\": null }";
	private String downloadDocUrl;
	private String gettokenUrl;
	private String gettokenApiResponse = "{ \"accessToken\": \"abc\" }";

	@MockBean
	public RestConsumer mockConsumer;

	@MockBean
	private DBClient mockDBClient;

	@BeforeEach
	public void secondarySetup() {
		JUtil.setLogLevel(ValidationHelper.class, ch.qos.logback.classic.Level.INFO);
		gettokenUrl = ContextWrapper.getAppProperty("com.pmli.bo.customer.get.token.api.url");
		downloadDocUrl = ContextWrapper.getAppProperty("com.pmli.bo.customer.download.app.form.url");
	}

	@Test
	void test_validation_invalid_key() throws Exception {
		test_common(ENDPOINT + "63744avvava", 400, "Key must not be blank with maximum 32 digits only",
				"errorMoreInfo");
	}

	@Test
	void test_negative_application_number_invalid() throws Exception {
		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
		ld.setApplicationNumber("");

		Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(argThat((String leadId) -> leadId != null));

		test_common(ENDPOINT + "22042021211513447", 404, "Application Number is not present for this lead Id",
				"errorMoreInfo");
	}

	@Test
	void test_negative_data_not_found() throws Exception {
		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);

		Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(argThat((String leadId) -> leadId != null));

		Mockito.doReturn(gettokenApiResponse).when(mockConsumer).callClientGetEndPoint(eq(gettokenUrl),
				any(HttpHeaders.class));

		Mockito.doReturn(apiNullResponse).when(mockConsumer).callClientEndPoint(eq(downloadDocUrl),
				any(HttpHeaders.class), argThat((String request) -> {
					return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.download.app.form.request" + "")
							.equals(request);
				}));

		test_common(ENDPOINT + KEY, 404, "Data Not Found For The Key Provided.", "errorMoreInfo");
	}

	@Test
	void test_download_app_form_positive_all_parameters() throws Exception {
		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);

		Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(argThat((String leadId) -> leadId != null));

		Mockito.doReturn(gettokenApiResponse).when(mockConsumer).callClientGetEndPoint(eq(gettokenUrl),
				any(HttpHeaders.class));

		Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(eq(downloadDocUrl), any(HttpHeaders.class),
				argThat((String request) -> {
					return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.download.app.form.request" + "")
							.equals(request);
				}));

		test_common(ENDPOINT + KEY, 200,
				"ZSuIFJcAu/A6kGQUPwFiK6qASAV1ECk9F0QKbAKREgJA8n+6MtiE2SD1M18xAAQYACBvIa4KZW5kc3RyZWFtCmVuZG9iagpzdGFydHhyZWYKMTA1MTA5CiUlRU9GCg==",
				"fileContent");
	}

	@Test
	void test_download_app_form_positive_Message() throws Exception {
		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);

		Mockito.doReturn(ld).when(mockDBClient).getLeadDetail(argThat((String leadId) -> leadId != null));

		Mockito.doReturn(gettokenApiResponse).when(mockConsumer).callClientGetEndPoint(eq(gettokenUrl),
				any(HttpHeaders.class));

		Mockito.doReturn(apiMessgeResponse).when(mockConsumer).callClientEndPoint(eq(downloadDocUrl),
				any(HttpHeaders.class), argThat((String request) -> {
					return ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.download.app.form.request" + "")
							.equals(request);
				}));

		test_common(ENDPOINT + KEY, 200, "", "fileContent");
	}

	private void test_common(String endpoint, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callGetEndPoint(endpoint);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}

	private File getFile(String fileName) {
		return new File(getClass().getClassLoader().getResource(fileName).getFile());
	}

}