/**
 * 
 */
package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

/**
 * @author 3483784san
 *
 */
 class UpdatePOPI extends BaseContextLoader {
	
	@MockBean
	private DBClient mockDBClient;
	
	private String BASH_PATH = "com.pmli.ms.bo.customer.add.po.pi.info.";
	private String successMessage = "PO PI Info updated successfully.";
	private String endPoint = "/v1/mgfp/add-po-pi-info";
	
	@Test
	void test_positive() throws Exception {
		
		Document docModelIn = Document.parse(ContextWrapper.getAppProperty(BASH_PATH + "valid.model.in"));
		Document docModelOut = Document.parse(ContextWrapper.getAppProperty(BASH_PATH + "valid.model.out"));

		Mockito.doReturn("2").when(mockDBClient).getMasterKeyByTypeValue(Mockito.any(), Mockito.any());
		Mockito.doReturn(JsonUtil.readValue(docModelIn.toJson(), LeadDetail.class)).when(mockDBClient)
			.getLeadDetail(argThat(leadId -> docModelIn.getString("leadId").equals(leadId)));

		Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(argThat(ld -> {
			if (!ld.equals(JsonUtil.readValue(docModelOut.toJson(), LeadDetail.class))) {
				MsObject.getSL().error("Expected out: " + docModelOut.toJson());
				MsObject.getSL().error("Prepared out: " + JsonUtil.writeValueAsString(ld));
				throw new MsValidationException("Doc model out failed match.");
			}
			return true;
		}));

		test_common(ContextWrapper.getAppProperty(BASH_PATH + "request"), 200, successMessage, "message");
	}
	
	private void test_common(String inputPayload, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callPostEndpoint(endPoint, inputPayload);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}

}
