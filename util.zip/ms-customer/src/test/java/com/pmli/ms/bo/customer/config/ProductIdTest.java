package com.pmli.ms.bo.customer.config;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

 class ProductIdTest {

    @Test
     void compareProductIds() {
        assertTrue(ProductId.isValidProductId(ProductId.SSP));
        assertTrue(ProductId.isValidProductId(ProductId.SSP.getValue()));
        assertTrue(ProductId.isValidProductId("" + ProductId.SSP.getValue()));
        assertFalse(ProductId.isValidProductId(1234));
    }
}
