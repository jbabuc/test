package com.pmli.ms.bo.customer.model                                                                                                            ;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.argThat;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.mongodb.client.model.UpdateOptions;
import com.pmli.ms.bo.customer.config.ProductId;
import com.pmli.util.bson.DocUtil;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.mongo.MongoClientWrapper;

@SpringBootTest
@ActiveProfiles(profiles = { "junit" })
@ExtendWith(SpringExtension.class)
@DirtiesContext(classMode = ClassMode.BEFORE_CLASS)
 class DBClientTest {
    @MockBean
    MongoClientWrapper buyOnlineMCW;

    @Autowired
    DBClient dbClient;

    @Test
     void getAppConfigDocs() {
        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getAppConfig(), "{}", null, null, 0, 1))
            .thenReturn(new ArrayList<Document>());

        assertEquals(new ArrayList<Document>(), dbClient.getAppConfigDocs());
        verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getAppConfig(), "{}", null, null, 0, 1);
    }

    @Test
     void getAppConfigFieldValById() {
        List<Document> ret = new ArrayList<Document>();
        ret.add(new DocUtil.DocPW(new Document()).put("productNotificationSetting[]",
            new DocUtil.DocPW(new Document()).put("productId", "1234").put("fname", "fvalue").doc()).doc());

        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getAppConfig(), "{}", null, null, 0, 1))
            .thenReturn(ret);

        assertEquals("fvalue", dbClient.getAppConfigFieldValById("1234", "fname"));
        verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getAppConfig(), "{}", null, null, 0, 1);
    }

    @Test
     void getFrequencyFromPremiumCalc() {
        assertEquals("Annual Premium",
            dbClient.getFrequencyFromPremiumCalc(new DocUtil.DocPW(new Document()).put("frequency", "12").doc()));
        assertEquals("Half Yearly Premium",
            dbClient.getFrequencyFromPremiumCalc(new DocUtil.DocPW(new Document()).put("frequency", "6").doc()));
        assertEquals("Monthly Premium",
            dbClient.getFrequencyFromPremiumCalc(new DocUtil.DocPW(new Document()).put("frequency", "1").doc()));
    }

    @Test
     void getLeadDetail() {
        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_LEADID, "1234").toJson(), null)).thenReturn(new Document());

        assertEquals(JsonUtil.readValue(new Document().toJson(), LeadDetail.class), dbClient.getLeadDetail("1234"));
        verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_LEADID, "1234").toJson(), null);

        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_LEADID, "1234").toJson(), null)).thenReturn(null);
        assertNull(dbClient.getLeadDetail("1234"));
    }

    @Test
     void getLeadDetailByApplicationNumber() {
        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_APPLICATIONUMBER, "1234").toJson(), null)).thenReturn(new Document());

        assertEquals(JsonUtil.readValue(new Document().toJson(), LeadDetail.class),
            dbClient.getLeadDetailByApplicationNumber("1234"));
        verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_APPLICATIONUMBER, "1234").toJson(), null);

        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_APPLICATIONUMBER, "1234").toJson(), null)).thenReturn(null);
        assertNull(dbClient.getLeadDetailByApplicationNumber("1234"));
    }

    @Test
     void getLeadDetailByIdOrAppNo() {
        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_LEADID, "1234").toJson(), null)).thenReturn(new Document());
        assertEquals(JsonUtil.readValue(new Document().toJson(), LeadDetail.class),
            dbClient.getLeadDetailByIdOrAppNo("1234", null));
        verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_LEADID, "1234").toJson(), null);

        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_APPLICATIONUMBER, "1234").toJson(), null)).thenReturn(new Document());
        assertEquals(JsonUtil.readValue(new Document().toJson(), LeadDetail.class),
            dbClient.getLeadDetailByIdOrAppNo(null, "1234"));
        verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            new Document(FieldConstants.LD_APPLICATIONUMBER, "1234").toJson(), null);

        assertNull(dbClient.getLeadDetailByIdOrAppNo(null, null));
    }
    @Test
     void getMasterKeyByTypeValue() {
        List<Document> ret = new ArrayList<Document>();
        ret.add(
            new DocUtil.DocPW(new Document())
                .put("list[]",
                    new DocUtil.DocPW(new Document()).put("active", true).put("value", "v").put("key", "k").doc())
                .doc());

        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getMongoMstMaster(), "{type:'t'}", null, null, 0,
            1)).thenReturn(ret);

        assertEquals("k", dbClient.getMasterKeyByTypeValue("t", "v"));
        
    }

    @Test
     void getMasterValueByTypeKey() {
        List<Document> ret = new ArrayList<Document>();
        ret.add(
            new DocUtil.DocPW(new Document())
                .put("list[]",
                    new DocUtil.DocPW(new Document()).put("active", true).put("value", "v").put("key", "k").doc())
                .doc());
                                     
        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getMongoMstMaster(), "{type:'t'}", null, null, 0,
            1)).thenReturn(ret);

        assertEquals("v", dbClient.getMasterValueByTypeKey("t", "k"));
       
    }

    @Test
     void getProductId() {
        List<Document> ret = new ArrayList<Document>();
        ret.add(Document.parse("{'list':[{'key':'1234'}]}"));
        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getMongoMstMaster(),
            Document.parse("{'type':'recommendations'}"), Document.parse("{'list':{'$elemMatch':{'value':'pname'}}}"),
            null, -1, -1)).thenReturn(ret);
        assertEquals("1234", dbClient.getProductId("pname"));

        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getMongoMstMaster(),
            Document.parse("{'type':'recommendations'}"), Document.parse("{'list':{'$elemMatch':{'value':'pname1'}}}"),
            null, -1, -1)).thenReturn(new ArrayList<>());
        assertNull(dbClient.getProductId("pname1"));
    }

    @Test
     void getProductShortName() {
        doAnswer(invocation -> {
            return Document.parse("{productShortName:'mypsname'}");
        }).when(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getMongoProductPlanDetails(),
            "{productId:1234}", null);
        String ret = dbClient.getProductShortName(1234);
        assertEquals("mypsname", ret);
       //// verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getMongoProductPlanDetails(),
           // "{productId:1234}", null);

        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getMongoProductPlanDetails(),
            "{productId:12345}", null)).thenReturn(null);
        assertNull(dbClient.getProductShortName(12345));
    }
    @Test
     void getProductOptionName() {
        List<Document> ret = new ArrayList<Document>();
        ret.add(new DocUtil.DocPW(new Document())
            .put("productDetail.optionMaster[]",
                new DocUtil.DocPW(new Document()).put("LevelId", 1)
                    .put("options[]",
                        new DocUtil.DocPW(new Document()).put("optionId", 2).put("optionName", "optname").doc())
                    .doc())
            .doc());

        when(buyOnlineMCW.getDocuments(dbClient.getDbName(), dbClient.getMongoProductPlanDetails(),
            new DocUtil.DocPW(new Document()).put("productId", ProductId.SSP.getValue()).doc(),
            Document.parse("{'productDetail.optionMaster':1}"), null, -1, -1)).thenReturn(ret);

        assertEquals("optname", dbClient.getProductOptionName(ProductId.SSP, 1, 2));
        //verify(buyOnlineMCW).getDocuments(dbClient.getDbName(), dbClient.getMongoProductPlanDetails(),
          //  new DocUtil.DocPW(new Document()).put("productId", ProductId.SSP.getValue()).doc(),
            //Document.parse("{'productDetail.optionMaster':1}"), null, -1, -1);
    }

    @Test
     void quotationExists() {
        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            "{quotationId:'1234'}", null)).thenReturn(new Document());
        assertNotNull(dbClient.quotationExists("1234"));
        verify(buyOnlineMCW).getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            "{quotationId:'1234'}", null);

        when(buyOnlineMCW.getDocumentById(dbClient.getDbName(), dbClient.getCollectionLeadDetail(),
            "{quotationId:'1234'}", null)).thenReturn(null);
        assertFalse(dbClient.quotationExists("1234"));
    }

    @Test
     void saveLeadDetail() {
        when(buyOnlineMCW.updateMany(eq(dbClient.getDbName()), eq(dbClient.getCollectionLeadDetail()),
            eq(new DocUtil.DocPW(new Document()).put(FieldConstants.LD_LEADID, "1234").doc()), argThat((Document d) -> {
                return DocUtil.get(d, "$set.key").equals("val") && DocUtil.get(d, "$set.lastUpdatedOn") != null;
                // return true;
            }), argThat((UpdateOptions u) -> u.isUpsert() == false))).thenReturn(1l);

        assertEquals(1, dbClient.saveLeadDetail("1234", Document.parse("{'key':'val'}")));
    }

    @Test
     void saveLeadDetailLd() {
        when(buyOnlineMCW.updateMany(eq(dbClient.getDbName()), eq(dbClient.getCollectionLeadDetail()),
            eq(new DocUtil.DocPW(new Document()).put(FieldConstants.LD_LEADID, "1234").doc()), argThat((Document d) -> {
                return DocUtil.get(d, "$set.leadId").equals("1234") && DocUtil.get(d, "$set.recordStatus").equals("abc")
                    && DocUtil.get(d, "$set.createdOn") != null && DocUtil.get(d, "$set.lastUpdatedOn") != null;
            }), argThat((UpdateOptions u) -> u.isUpsert()))).thenReturn(1l);

        assertEquals(1,
            dbClient.saveLeadDetail(JsonUtil.readValue("{'leadId':'1234','recordStatus':'abc'}", LeadDetail.class)));
    }
}
