package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.ms.bo.customer.model.LeadDetailPayment.Payment;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class PaymentE2ETest extends BaseContextLoader {
    
    @MockBean
    private DBClient mockDBClient;
    @MockBean
    private RestConsumer mockConsumer;
    
	private final static String ADD_PAYMENT_URI = "/v1/customer/add-payment";
	private final String apiResponse = "{\"responseCode\":\"0\",\"responseMessage\":\"SUCCESS\",\"smsFile\":\"\"}";
	
	@BeforeEach
	public void secondarySetup() throws IOException {
	    File resourceFile = getFile("lead-detail.json");
        LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
        Mockito.doReturn(ld).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());

        List<Document> doclist = new ArrayList<>();
        File rf = getFile("app-config.json");
        Document appConfig = Document.parse(new String(Files.readAllBytes(rf.toPath())));
        doclist.add(appConfig);
        Mockito.doReturn(doclist).when(mockDBClient).getAppConfigDocs();
        Mockito.doReturn(apiResponse).when(mockConsumer).callClientEndPoint(Mockito.any(), Mockito.any(), Mockito.any());
	}

	@Test
	 void test_positive_payment_success_addPayment() throws Exception {
		Document request = Document.parse(
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.success"));
		Document db_doc = Document.parse(
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.date.toSave.db"));

		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(
				argThat((String leadId) -> request.getString("leadId").equals(leadId)), argThat((Document d) -> {
					return d.equals(db_doc);
				}));
		// commonMock();
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.success"),
				200, "Payment details have been saved successfully", "message");
	}

	@Test
	 void test_positive_payment_fail_addPayment() throws Exception {
		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any());
		// commonMock();
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.fail"),
				200, "Payment details have been saved successfully", "message");
	}

	@Test
	 void test_negative_invalid_leadId_Or_AppNum_addPayment() throws Exception {
		Mockito.doReturn(null).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.success"),
				404, "Invalid Lead Id or Application Number", "errorDetails");
	}

	@Test
	 void test_negative_payment_already_present_addPayment() throws Exception {
		LeadDetail ld = new LeadDetail();
		Payment payment = new Payment();
		ld.setPayment(payment);
		Mockito.doReturn(ld).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.success"),
				400, "Payment is already present", "errorDetails");
	}

	@Test
	 void test_negative_leadId_appNum_null_addPayment() throws Exception {
		test_common(
				ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.negative.leadId.appNum.null"),
				400, "Lead Id cannot be null.", "errorMoreInfo");
	}

	@Test
	 void test_negative_mobileNum_not_avaible_addPayment() throws Exception {
		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any());

		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
		ld.setMobileNumber("");
		Mockito.doReturn(ld).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.fail"),
				400, "Mobile Number is not available", "errorDetails");
	}

	@Test
	 void test_negative_emailId_not_avaibale_addPayment() throws Exception {
		Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(Mockito.any());

		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
		ld.setEmailId("");
		Mockito.doReturn(ld).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.fail"),
				400, "EmailId is not available", "errorDetails");
	}

	@Test
	 void test_exception_sms_email_addPayment() throws Exception {
		Mockito.doReturn(1l).when(mockDBClient).saveLeadDetail(Mockito.any());

		File resourceFile = getFile("lead-detail.json");
		LeadDetail ld = JsonUtil.readValue(new String(Files.readAllBytes(resourceFile.toPath())), LeadDetail.class);
		Mockito.doReturn(ld).when(mockDBClient).getLeadDetailByIdOrAppNo(Mockito.any(), Mockito.any());

		List<Document> doclist = new ArrayList<>();
		File rf = getFile("app-config.json");
		Document appConfig = Document.parse(new String(Files.readAllBytes(rf.toPath())));
		doclist.add(appConfig);
		Mockito.doReturn(doclist).when(mockDBClient).getAppConfigDocs();
		Mockito.doThrow(InternalServerError.class).when(mockConsumer).callClientEndPoint(Mockito.any(), Mockito.any(),
				Mockito.any());
		test_common(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.addPayment.request.positve.payment.success"),
				200, "Payment details have been saved successfully", "message");
	}

	private void test_common(String inputPayload, int httpStatus, String response, String key) throws Exception {
		MvcResult result = callPostEndpoint(ADD_PAYMENT_URI, inputPayload);
		assertResponse(result, httpStatus);
		assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
	}

	private File getFile(String fileName) {
		return new File(getClass().getClassLoader().getResource(fileName).getFile());
	}

}