package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.spring.ContextWrapper;
import com.pmli.util.web.client.RestConsumer;

 class FetchApplicationE2ETest extends BaseContextLoader {

    private final static String FETCH_URL = "/v1/customer/fetch-application";
    private final String        filter    = "{leadId:'637426079805737441'}";

    @MockBean
    private RestConsumer mockConsumer;

    @MockBean
    private DBClient mockDBClient;

    // Negative test cases
    // invalid leadId
    @Test
     void test_validation_invalid_leadId() throws Exception {
        assertTrue(callEndPointAndAssert(FETCH_URL,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application.leadid"), 404));
    }

    // invalid quotationId

    @Test
     void test_validation_invalid_quotationId() throws Exception {
        assertTrue(callEndPointAndAssert(FETCH_URL,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application.quotationid"), 404));
    }

    // invalid applicationId
    @Test
     void test_validation_invalid_applicationId() throws Exception {
        assertTrue(callEndPointAndAssert(FETCH_URL,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application.applicationid"), 404));
    }

    // request is blank no id is present
    @Test
     void test_validation_invalid_request() throws Exception {
        assertTrue(callEndPointAndAssert(FETCH_URL,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application.request"), 404));
    }

    // All Valid Parameters
    @Test
     void test_fetch_application() throws Exception {
        when(mockDBClient.fetchApplication(filter)).thenReturn(
            Document.parse(ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application.response")));
        assertTrue(callEndPointAndAssert(FETCH_URL,
            ContextWrapper.getAppProperty("com.pmli.ms.bo.customer.fetch.application"), 200));
    }
}
