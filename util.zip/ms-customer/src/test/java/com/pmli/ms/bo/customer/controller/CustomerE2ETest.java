package com.pmli.ms.bo.customer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.argThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.pmli.ms.bo.customer.model.DBClient;
import com.pmli.ms.bo.customer.model.LeadDetail;
import com.pmli.test.util.BaseContextLoader;
import com.pmli.util.json.JsonUtil;
import com.pmli.util.spring.ContextWrapper;

 class CustomerE2ETest extends BaseContextLoader {

    @MockBean
    private DBClient mockDBClient;

    final String BASEPATH = "com.pmli.ms.bo.customer.test.add.customer.";

    @Test
     void test_add_customer_positive() throws Exception {

        LeadDetail addLead = JsonUtil.readValue(ContextWrapper.getAppProperty(BASEPATH + "prepaired.request"),
            LeadDetail.class);

        Mockito.doReturn(1L).when(mockDBClient).saveLeadDetail(argThat((LeadDetail lead) -> {
            addLead.setLeadId(lead.getLeadId());
            addLead.setCreatedOn(lead.getCreatedOn());
            addLead.setLastUpdatedOn(lead.getLastUpdatedOn());
            return addLead.equals(lead);

        }));

        test_common(ContextWrapper.getAppProperty(BASEPATH + "details"), 200, "Customer details saved successfully",
            "message");
    }

    @Test
     void test_validation_buy_type_code() throws Exception {
        test_common(ContextWrapper.getAppProperty(BASEPATH + "buy-type"), 200, "Customer details saved successfully",
            "message");
    }

    @Test
     void test_validation_invalid_family_member_name() throws Exception {
        test_common(ContextWrapper.getAppProperty(BASEPATH + "family-member-name"), 400,
            "Family Member Name cannot be null", "errorMoreInfo");
    }

    @Test
     void test_validation_invalid_age() throws Exception {
        test_common(ContextWrapper.getAppProperty(BASEPATH + "age"), 400, "Age must be greater than or equal to 18.",
            "errorMoreInfo");
    }

    private void test_common(String inputPayload, int httpStatus, String response, String key) throws Exception {
        MvcResult result = callPostEndpoint(ContextWrapper.getAppProperty(BASEPATH + "uri"), inputPayload);
        assertResponse(result, httpStatus);
        assertEquals(response, JsonUtil.readJson(result.getResponse().getContentAsString()).get(key).asText());
    }
}