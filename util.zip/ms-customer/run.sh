#!/bin/sh
#mvn clean jacoco:prepare-agent install jacoco:report sonar:sonar
mvn clean install -DskipTests
java -Dloader.main=com.pmli.ms.bo.customer.CustomerApplication -jar target/ms-customer-1.0.0-exec.jar --spring.config.location=src/main/resources/application-local.properties
