package com.pmli.util.web;

import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.DispatcherType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.pmli.util.java.MsObject;
import com.pmli.util.web.log.HttpLoggingHelper;

/**
 * Intercepts requests to pre and post process
 * 
 * @author 3495987jan
 */
@Component
public class ServletInterceptor extends MsObject implements HandlerInterceptor {

    // for spring to use IPv4 use -Djava.net.preferIPv4Stack=true
    @Value("${com.pmli.bo.ms.config.ipFilterRegex:#{null}}")
    private String ipFilterRegex;

    public static final String PMLI_SI_START_TIME     = "PMLI_SI_START_TIME";
    public static final String PMLI_SI_REQUEST_NUMBER = "PMLI_SI_REQUEST_NUMBER";

    private static final AtomicInteger requestCounter = new AtomicInteger(0);

    @Autowired
    HttpLoggingHelper httpLoggingHelper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object object) throws Exception {
        // sonar suggestion to replace to remove taint
        String remoteAddress = request.getRemoteAddr().replaceAll("[\n|\r|\t]", "");
        if (ipFilterRegex != null && !GenericValidator.matchRegexp(remoteAddress, ipFilterRegex)) {
            response.setStatus(403);
            log.info("Illegal access from unknown IP: {}", remoteAddress);
            return false;
        }

        if (!httpLoggingHelper.skipLogging(request)) {
            request.setAttribute(PMLI_SI_REQUEST_NUMBER, requestCounter.incrementAndGet());
            request.setAttribute(PMLI_SI_START_TIME, System.currentTimeMillis());
        }

        // handle get logging
        if (DispatcherType.REQUEST.name().equals(request.getDispatcherType().name())
            && request.getMethod().equals(HttpMethod.GET.name())) {
            httpLoggingHelper.logRequest(request, "");
        }

        return true;
    }

    public static String getRequestURI(HttpServletRequest request) {
        // sonar code vulnerability prompted code to remove taint in request info
        return request.getRequestURI().replaceAll("[\n|\r|\t]", "_");
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
        @Nullable ModelAndView modelAndView) throws Exception {
        if (httpLoggingHelper.skipLogging(request)) return;

        long requestNumber = ((Integer) request.getAttribute(PMLI_SI_REQUEST_NUMBER)).intValue();
        long startTime = ((Long) request.getAttribute(PMLI_SI_START_TIME)).longValue();
        long execTime = System.currentTimeMillis() - startTime;
        if (execTime < 2000) {
            log.info("Request #{} {} completed in {} ms", requestNumber, getRequestURI(request), execTime);
        } else {
            log.warn("Request #{} {} completed in {} ms", requestNumber, getRequestURI(request), execTime);
        }
    }

}
