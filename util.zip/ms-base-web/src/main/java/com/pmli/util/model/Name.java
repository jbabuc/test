package com.pmli.util.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Name {
    @ApiModelProperty(required = true, value = "Title", example = "Mr.")
    private String title;

    @ApiModelProperty(required = true, value = "First Name", example = "Mohan")
    private String firstName;

    @ApiModelProperty(required = false, value = "Middle Name", example = " ")
    private String middleName;

    @ApiModelProperty(required = true, value = "Last Name", example = "Jain")
    private String lastName;
}