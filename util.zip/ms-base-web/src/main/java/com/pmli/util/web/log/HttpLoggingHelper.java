package com.pmli.util.web.log;

import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.pmli.util.java.MsObject;
import com.pmli.util.json.JsonUtil;

/**
 * http logging helper functions
 * 
 * @author 3495987jan
 */
@Component
public class HttpLoggingHelper extends MsObject {

    public static final String ATTR_PREFIX_PMLI = "PMLI";

    @Value("${com.pmli.bo.loggingFilter:.*}")
    private String loggingFilter;

    public boolean skipLogging(HttpServletRequest httpServletRequest) {
        return loggingFilter != null
            && !GenericValidator.matchRegexp(httpServletRequest.getRequestURI(), loggingFilter);
    }

    public void logRequest(HttpServletRequest httpServletRequest, Object body) {
        if (skipLogging(httpServletRequest)) return;

        // @formatter:off
       String requestLog = Arrays
            .asList("", 
                "===================REST Request begin========================================",
                "Remote Address  : " + httpServletRequest.getRemoteAddr(),
                "Method          : " + httpServletRequest.getMethod(), 
                "Path            : " + httpServletRequest.getRequestURI(),
                "Headers         : " + getHeadersAsString(httpServletRequest),
                "Parameters      : " + gerParametersAsString(httpServletRequest),
                "Attributes      : " + gerAttributesAsString(httpServletRequest, ATTR_PREFIX_PMLI), 
                "Request body    : " + JsonUtil.writeValueAsString(body),
                "===================REST Request end==========================================")
            .stream().collect(Collectors.joining(System.lineSeparator()));
        // @formatter:on
        log.info(requestLog);
    }

    public void logResponse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
        Object body) {
        if (skipLogging(httpServletRequest)) return;

        // @formatter:off
        String responseLog = Arrays
            .asList("",
                "===================REST Response begin=======================================",
                "Request Attributes  : " + gerAttributesAsString(httpServletRequest, ATTR_PREFIX_PMLI), 
                "Status code         : " + httpServletResponse.getStatus(), 
                "Headers             : " + getHeadersAsString(httpServletResponse),
                "Response body       : " + JsonUtil.writeValueAsString(body),
                "===================REST Response end=========================================")
            .stream().collect(Collectors.joining(System.lineSeparator()));
        // @formatter:on
        log.info(responseLog);
    }

    private String gerAttributesAsString(HttpServletRequest request, String prefix) {
        return Collections.list(request.getAttributeNames()).stream().filter(k -> k.startsWith(prefix))
            .map(k -> k + "=" + request.getAttribute(k).toString()).collect(Collectors.toList()).toString();
    }

    private String gerParametersAsString(HttpServletRequest request) {
        return Collections.list(request.getParameterNames()).stream()
            .map(k -> k + "=" + Arrays.asList(request.getParameterValues(k))).collect(Collectors.toList()).toString();
    }

    private String getHeadersAsString(HttpServletRequest request) {
        return Collections.list(request.getHeaderNames()).stream()
            .map(k -> k + "=" + Collections.list(request.getHeaders(k))).collect(Collectors.toList()).toString();
    }

    private String getHeadersAsString(HttpServletResponse response) {
        return response.getHeaderNames().stream().map(k -> k + "=" + response.getHeaders(k))
            .collect(Collectors.toList()).toString();
    }
}