package com.pmli.util.web.client;

import static java.util.Optional.ofNullable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.RestClientResponseException;

import com.pmli.util.java.MsObject;
import com.pmli.util.web.ApplicationException;
import com.pmli.util.web.ApplicationException.ErrCode;

@Component
public class RestConsumer extends MsObject {

    @Autowired
    RestTemplate restTemplate;

    /**
     * @param  method
     * @param  url
     * @param  headers
     * @param  body
     * @return         ResponseEntity<String>
     */
    public ResponseEntity<String> callClientEndPoint(HttpMethod method, String url, HttpHeaders headers, String body) {
        try {
            headers = ofNullable(headers).orElse(new HttpHeaders());
            RequestEntity<?> request = method == HttpMethod.GET ? RequestEntity.get(url).headers(headers).build()
                : RequestEntity.post(url).headers(headers).body(body);
            return restTemplate.exchange(request, String.class);
        } catch (RestClientResponseException e) {
            return ResponseEntity.status(e.getRawStatusCode()).body(e.getResponseBodyAsString());
        } catch (Exception e) {
            throw new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.INTERNAL_SERVER_ERROR_109,
                e.getMessage(), e.getMessage());
        }
    }

    /**
     * @see    callClientEndPoint(method, url, headers, body)
     * @return response string on success, otherwise null
     */
    public String callClientEndPoint(String url, HttpHeaders headers, String body) {
        ResponseEntity<String> response = callClientEndPoint(HttpMethod.POST, url, headers, body);
        return HttpStatus.OK == response.getStatusCode() ? response.getBody() : null;
    }

    /**
     * @see    callClientEndPoint(method, url, headers, body)
     * @return response string on success, otherwise null
     */
    public String callClientGetEndPoint(String url, HttpHeaders headers) {
        ResponseEntity<String> response = callClientEndPoint(HttpMethod.GET, url, headers, null);
        return HttpStatus.OK == response.getStatusCode() ? response.getBody() : null;
    }

    /**
     * @see    callClientGetEndPoint(url, headers)
     * @return response string on success, otherwise null
     */
    public String callClientGetEndPoint(String url) { return callClientGetEndPoint(url, null); }
}
