package com.pmli.util.web;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;


/**
 * Application Exception to capture additional data
 * 
 * @author 3495987jan
 */
public class ApplicationException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    // application error codes
    public enum ErrCode {

        MANDATORY_PARAM_MISSING_101(101), DATA_TYPE_MISMATCH_102(102), LENGTH_VALIDATION_FAIL_103(103),
        DATA_FORMAT_ERROR_104(104), DATA_NOT_FOUND_105(105), MEDIA_TYPE_NOT_SUPPORT_106(106),
        HTTP_CLIENT_ERROR_107(107), FALLBACK_ERROR_108(108), INTERNAL_SERVER_ERROR_109(109), MAXIMUM_LIMIT_110(110),
        AUTHENTICATION_FAILED_112(112), AUTHORIZATION_TOKEN_MISSING_113(113),DATA_ALREADY_PRESENT_114(114);

        private final int errorCode;

        private ErrCode(int errorCode) { this.errorCode = errorCode; }

        public int getErrorCode() { return this.errorCode; }
    }

    private final HttpStatus httpStatus;
    private final ErrCode    errorCode;
    private final String     errorDetails;
    private final String     errorMoreInfo;

    public ApplicationException(HttpStatus httpStatus, ErrCode errorCode, String errorDetails, String errorMoreInfo) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.errorDetails = errorDetails;
        this.errorMoreInfo = errorMoreInfo;
    }

    public ErrCode getErrorCode() { return errorCode; }

    public String getErrorDetails() { return errorDetails; }

    public String getErrorMoreInfo() { return errorMoreInfo; }

    public HttpStatus getHttpStatus() { return httpStatus; }

    @Override
    public String toString() {
        return "App Error [httpStatus=" + httpStatus + ", errorCode=" + errorCode + ", errorDetails=" + errorDetails
            + ", errorMoreInfo=" + errorMoreInfo + "]";
    }

    public static String getExceptionStackAsString(Throwable t) {
        return Arrays.asList(t.getStackTrace()).stream().map(Object::toString).collect(Collectors.joining("\n"));
    }
}
