package com.pmli.util.model;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Money {
    public static final String CURRENCY_CODE_INR = "INR";

    @ApiModelProperty(required = false, value = "Amount", example = "200000.00")
    private BigDecimal amount;
    @ApiModelProperty(required = true, value = "Currency Code", example = "INR")
    private String     currencyCode;

    public Money(BigDecimal amount, String currencyCode) { setAmount(amount); this.currencyCode = currencyCode; }

    public Money(BigDecimal amount) { this(amount, CURRENCY_CODE_INR); }

    public void setAmount(BigDecimal amount) {
        if (amount == null) amount = new BigDecimal(0);
        this.amount = amount.setScale(2, BigDecimal.ROUND_DOWN);
    }
}
