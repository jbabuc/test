package com.pmli.util.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Email {
    @ApiModelProperty(required = true, value = "Email Address", example = "abc@pnbmetlife.com")
    private String address;

    @ApiModelProperty(required = false, value = "Type Code", example = "PERSONAL")
    private String typeCode;

    @ApiModelProperty(required = false, value = "Is Primary", example = "false")
    private boolean isPrimary;

}
