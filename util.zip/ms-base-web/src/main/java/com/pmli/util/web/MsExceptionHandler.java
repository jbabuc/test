package com.pmli.util.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.HttpRequestMethodNotSupportedException;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.pmli.util.web.ApplicationException.ErrCode;
import com.pmli.util.java.MsObject;
import com.pmli.util.java.MsValidationException;
import com.pmli.util.spring.CommUtil;
import com.pmli.util.spring.ContextWrapper;

/**
 * Global Exception handling
 * 
 * @author 3495987jan
 */
@RestControllerAdvice
@EnableWebMvc
public class MsExceptionHandler extends MsObject {

    @ExceptionHandler(value = ApplicationException.class)
    public ResponseEntity<String> handleAppError(ApplicationException ae) {
        log.debug("Application error: {}", ae.getMessage());
        return prepareResponse(ae.getHttpStatus(), ae.getErrorCode(), ae.getErrorDetails(), ae.getErrorMoreInfo());
    }

    @ExceptionHandler({ MsValidationException.class })
    public ResponseEntity<String> handleMissingParameter(MsValidationException e) {
        log.debug("Validation error: {}", e.getMessage());
        return prepareResponse(HttpStatus.BAD_REQUEST, ErrCode.MANDATORY_PARAM_MISSING_101,
            HttpStatus.BAD_REQUEST.getReasonPhrase(), e.getMessage());
    }

    @ExceptionHandler({ NoHandlerFoundException.class, HttpRequestMethodNotSupportedException.class })
    public ResponseEntity<String> handleMissingHandler(Exception e) {
        log.error("Missing handler: {}", e.getMessage());
        return getResponse(HttpStatus.BAD_REQUEST, ErrCode.MANDATORY_PARAM_MISSING_101,
            HttpStatus.BAD_REQUEST.getReasonPhrase(), e.getMessage());
    }

    @ExceptionHandler({ MissingServletRequestParameterException.class, ServletRequestBindingException.class })
    public ResponseEntity<String> handleMissingParameter(Exception e) {
        return logAndResponse(HttpStatus.BAD_REQUEST, ErrCode.MANDATORY_PARAM_MISSING_101, e);
    }

    @ExceptionHandler(HttpClientErrorException.class)
    public ResponseEntity<String> handleHttpClientError(HttpClientErrorException ex) {
        return logAndResponse(HttpStatus.NOT_FOUND, ErrCode.HTTP_CLIENT_ERROR_107, ex);
    }

    @ExceptionHandler({ MethodArgumentNotValidException.class, IllegalArgumentException.class })
    public ResponseEntity<String> handleDataMismatch(Exception e) {
        return logAndResponse(HttpStatus.BAD_REQUEST, ErrCode.DATA_TYPE_MISMATCH_102, e);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<String> handleFormatError(Exception e) {
        return logAndResponse(HttpStatus.BAD_REQUEST, ErrCode.DATA_FORMAT_ERROR_104, e);

    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<String> handleMediaTypeNotSupported(Exception e) {
        return logAndResponse(HttpStatus.BAD_REQUEST, ErrCode.MEDIA_TYPE_NOT_SUPPORT_106, e);
    }

    @ExceptionHandler(HystrixRuntimeException.class)
    public ResponseEntity<String> handleFallback(HystrixRuntimeException e) {
        logError("Hystrix FallbackException: ", e.getFallbackException());
        return logAndResponse(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.FALLBACK_ERROR_108, e);
    }

    @ExceptionHandler({ Throwable.class })
    public ResponseEntity<String> handleAny(Throwable th) {
        CommUtil.sendError(th);
        return logAndResponse(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.INTERNAL_SERVER_ERROR_109, th);
    }

    public long logError(String msg, Throwable th) {
        long now = System.nanoTime();
        if (log.isErrorEnabled()) { log.error(msg); log.error(String.format("Error encountered [%d]: ", now), th); }
        return now;
    }

    public ResponseEntity<String> logAndResponse(HttpStatus httpStatus, ErrCode errorCode, Throwable th) {
        return getResponse(httpStatus, errorCode, httpStatus.getReasonPhrase(),
            "Please contact support. " + ContextWrapper.getAppProperty("HOSTNAME", "err") + "-" + logError(null, th));
    }

    public ResponseEntity<String> prepareResponse(HttpStatus httpStatus, ErrCode errorCode, String errorDetails,
        String errorMoreDetails) {
        log.error("Exception Encountered: {}", errorDetails);
        return getResponse(httpStatus, errorCode, errorDetails, errorMoreDetails);
    }

    public ResponseEntity<String> getResponse(HttpStatus httpStatus, ErrCode errorCode, String errorDetails,
        String errorMoreDetails) {
        String response = JsonNodeFactory.instance.objectNode().put("errorType", "Error")
            .put("errorCode", errorCode.getErrorCode()).put("errorDetails", errorDetails)
            .put("errorMoreInfo", errorMoreDetails).toString();
        return ResponseEntity.status(httpStatus).contentType(MediaType.APPLICATION_JSON).body(response);
    }
}
