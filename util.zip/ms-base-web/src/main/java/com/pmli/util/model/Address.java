package com.pmli.util.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Address {
	@ApiModelProperty(required = false, value = "Type Code", example = "OFFICE")
	private String typeCode;

	@ApiModelProperty(required = true, value = "Address Line1", example = "Techniplex - 1")
	private String addressLine1;

	@ApiModelProperty(required = false, value = "Address Line2", example = "Techniplex Complex")
	private String addressLine2;

	@ApiModelProperty(required = false, value = "Address Line3", example = "Goregaon East")
	private String addressLine3;

	@ApiModelProperty(required = true, value = "Landmark", example = "Off Veer Savarkar flyover")
	private String landmark;

	@ApiModelProperty(required = true, value = "City", example = "Mumbai")
	private String city;

	@ApiModelProperty(required = true, value = "Locality", example = "Mumbai")
	private String locality;
	
	@ApiModelProperty(required = true, value = "District", example = "Mumbai Suburban")
	private String district;

	@ApiModelProperty(required = true, value = "Postal Code", example = "'110017'")
	private String postalCode;

	@ApiModelProperty(required = true, value = "State", example = "Maharashtra")
	private String state;

	@ApiModelProperty(required = true, value = "Country", example = "India")
	private String country;

}
