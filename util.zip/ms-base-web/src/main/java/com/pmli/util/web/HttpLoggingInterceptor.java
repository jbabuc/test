package com.pmli.util.web;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;

import com.pmli.util.java.MsObject;

/**
 * Intercepts http requests to remote hosts and traces.
 * 
 * @author 3495987jan
 */
public class HttpLoggingInterceptor extends MsObject implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
        throws IOException {
        // using nanos for this will help id the request/response
        long startTime = System.nanoTime();
        traceRequest(request, body, startTime);
        ClientHttpResponse response = execution.execute(request, body);
        traceResponse(response, startTime);
        return response;
    }

    private String getHeadersAsString(HttpHeaders hh) {
        return hh.keySet().stream().map(k -> k + "=" + hh.getValuesAsList(k)).collect(Collectors.toList()).toString();
    }

    private void traceRequest(HttpRequest request, byte[] body, long startTime) {
        // @formatter:off
        String requestLog = Arrays
            .asList("",
                "===================Third Party Service request begin========================================",
                "Start Time   : " + startTime, 
                "Method       : " + request.getMethod(), 
                "URI          : " + request.getURI(),
                "Headers      : " + getHeadersAsString(request.getHeaders()),
                "Request body : ", new String(body),
                "===================Third Party Service request end==========================================")
            .stream().collect(Collectors.joining(System.lineSeparator()));
        // @formatter:on
        log.info(requestLog);
    }

    private void traceResponse(ClientHttpResponse response, long startTime) throws IOException {
        // @formatter:off
        String responseLog = Arrays
            .asList("",
                "===================Third Party Service response begin=======================================",
                "Start Time   : " + startTime, 
                "Status code  : " + response.getStatusCode(), 
                "Status text  : " + response.getStatusText(),
                "Headers      : " + getHeadersAsString(response.getHeaders()), 
                "Response body: ",
                StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()),
                "Time Taken   : " + (System.nanoTime() - startTime)/1000000 + "ms",
                "===================Third Party Service response end=========================================")
            .stream().collect(Collectors.joining(System.lineSeparator()));
        // @formatter:on
        log.info(responseLog);

        // reset stream for caller, else it gets no data
        response.getBody().reset();
    }
}
