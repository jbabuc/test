package com.pmli.util.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PhoneNumber {
    @ApiModelProperty(required = false, value = "Country Code", example = "'91'")
    private String countryCode;

    @ApiModelProperty(required = true, value = "Number", example = "'9821212123'")
    private String number;

    @ApiModelProperty(required = false, value = "Type Code", example = "MOBILE")
    private String typeCode;

    @ApiModelProperty(required = false, value = "Use Code", example = "HOME")
    private String useCode;

    @ApiModelProperty(required = false, value = "Is Primary", example = "true")
    private boolean isPrimary;
}
