package com.pmli.util.web;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.pmli.util.java.MsObject;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Http interceptor configuration
 * 
 * @author 3495987jan
 *
 */
@EnableWebMvc
@EnableSwagger2
@Configuration
public class MsBaseConfig extends MsObject implements WebMvcConfigurer {
    @Autowired
    private ServletInterceptor servletIntceptor;

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        RestTemplate rt = builder.setConnectTimeout(Duration.ofMillis(300000)).setReadTimeout(Duration.ofMillis(300000))
            .build();
        // need this to reset streams after tracing when enabled
        rt.setRequestFactory(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        rt.setInterceptors(Arrays.asList(new HttpLoggingInterceptor()));
        return rt;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        log.info("Registering interceptors");
        registry.addInterceptor(servletIntceptor).order(Ordered.HIGHEST_PRECEDENCE);
    }

    public static Docket productApi(String basePackage, String title, String desc, String groupName, String version) {
        Set<String> responseProduceType = new HashSet<>();
        responseProduceType.add("application/json");
        return new Docket(DocumentationType.SWAGGER_2).groupName(groupName).select()
            .apis(RequestHandlerSelectors.basePackage(basePackage)).paths(PathSelectors.regex("/v1/.*")).build()
            .useDefaultResponseMessages(false).consumes(responseProduceType)
            .apiInfo(new ApiInfoBuilder().title(title).description(desc).version(version).build());
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addRedirectViewController("/v2/api-docs", "/v2/api-docs");
        registry.addRedirectViewController("/swagger-resources/configuration/ui",
            "/swagger-resources/configuration/ui");
        registry.addRedirectViewController("/swagger-resources/configuration/security",
            "/swagger-resources/configuration/security");
        registry.addRedirectViewController("/swagger-resources", "/swagger-resources");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/swagger-ui.html**")
            .addResourceLocations("classpath:/META-INF/resources/swagger-ui.html");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}