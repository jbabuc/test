package com.pmli.util.web;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.net.URI;

import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpResponse;

import com.pmli.util.java.MsObject;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;

/**
 * @author 3495987jan
 */
public class HttpLoggingInterceptorTest extends MsObject {
    @Test
    public void test() throws Exception {
        HttpRequest mkRequest = mock(HttpRequest.class);
        when(mkRequest.getURI()).thenReturn(new URI("/testuri"));
        when(mkRequest.getMethod()).thenReturn(HttpMethod.GET);
        when(mkRequest.getHeaders()).thenReturn(new HttpHeaders());

        ClientHttpResponse mkResponse = mock(ClientHttpResponse.class);
        when(mkResponse.getStatusCode()).thenReturn(HttpStatus.OK);
        when(mkResponse.getStatusText()).thenReturn(HttpStatus.OK.getReasonPhrase());
        when(mkResponse.getHeaders()).thenReturn(new HttpHeaders());
        when(mkResponse.getBody()).thenReturn(new ByteArrayInputStream("test response".getBytes()));

        ClientHttpRequestExecution mkChre = mock(ClientHttpRequestExecution.class);
        byte[] b = "test input".getBytes();
        when(mkChre.execute(mkRequest, b)).thenReturn(mkResponse);

        HttpLoggingInterceptor spyHli = spy(new HttpLoggingInterceptor());

        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        Logger rootLogger = loggerContext.getLogger("com.pmli.util.web");

        rootLogger.setLevel(Level.TRACE);
        assertEquals(mkResponse, spyHli.intercept(mkRequest, b, mkChre));
        rootLogger.setLevel(Level.INFO);
        assertEquals(mkResponse, spyHli.intercept(mkRequest, b, mkChre));
        
        // cannot check private methods with mockito
    }
}
