package com.pmli.util.web.client;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.pmli.util.web.Application;
import com.pmli.util.web.ApplicationException;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK, classes = { Application.class })
@ComponentScan({ "com.pmli.util.web" })
public class RestConsumerTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RestConsumer restConsumer = new RestConsumer();

    @Test
    public void callClientEndPoint() {//
        Mockito.when(restTemplate.exchange(any(RequestEntity.class), eq(String.class)))
            .thenReturn(new ResponseEntity<String>("Success", HttpStatus.OK));
        restConsumer.callClientEndPoint("http://localhost:8888/test", null, "{}");

        Mockito.when(restTemplate.exchange(any(RequestEntity.class), eq(String.class)))
            .thenThrow(new RuntimeException("test"));
        assertThrows(ApplicationException.class,
            () -> restConsumer.callClientEndPoint("http://localhost:8888/test", null, "{}"));
    }

    @Test
    public void callClientGetEndPoint() {//
        Mockito.when(restTemplate.exchange(any(RequestEntity.class), eq(String.class)))
            .thenReturn(new ResponseEntity<String>("Success", HttpStatus.OK));
        restConsumer.callClientGetEndPoint("http://localhost:8888/test");

        Mockito.when(restTemplate.exchange(any(RequestEntity.class), eq(String.class)))
            .thenThrow(new RuntimeException("test"));
        assertThrows(ApplicationException.class,
            () -> restConsumer.callClientGetEndPoint("http://localhost:8888/test"));
    }
}
