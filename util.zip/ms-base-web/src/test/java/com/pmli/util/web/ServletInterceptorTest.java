package com.pmli.util.web;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pmli.util.java.MsObject;
import com.pmli.util.spring.ContextWrapper;

/**
 * @author 3495987jan
 */

@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
public class ServletInterceptorTest extends MsObject {

    // this will load the properties and enable logging
    @ComponentScan({ "com.pmli.util" })
    @SpringBootConfiguration
    public static class TestConfig {}

    @Test
    public void test() throws Exception {

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/test");
        request.setMethod("GET");
        request.setRemoteAddr("");

        MockHttpServletResponse response = new MockHttpServletResponse();
        request.setAttribute(ServletInterceptor.PMLI_SI_REQUEST_NUMBER, new Integer(1));
        request.setAttribute(ServletInterceptor.PMLI_SI_START_TIME, new Long(System.currentTimeMillis() - 1000));

        {
            ServletInterceptor si = new ServletInterceptor();
            ContextWrapper.autoWire(si);
            si.postHandle(request, response, null, null);
            request.setAttribute(ServletInterceptor.PMLI_SI_START_TIME, new Long(System.currentTimeMillis() - 5000));
        }
        {
            ServletInterceptor si = new ServletInterceptor();
            ContextWrapper.autoWire(si);
            si.postHandle(request, response, null, null);
            request.setAttribute(ServletInterceptor.PMLI_SI_START_TIME, new Long(System.currentTimeMillis() - 1000));
        }

        {
            ServletInterceptor si = new ServletInterceptor();
            ContextWrapper.autoWire(si);
            assertEquals(true, si.preHandle(request, response, null));
        }
    }
}
