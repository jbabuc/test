package com.pmli.util.web;

import java.util.concurrent.TimeUnit;

import org.awaitility.Awaitility;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.pmli.util.java.MsValidationException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.netflix.hystrix.exception.HystrixRuntimeException.FailureType;
import com.pmli.util.web.ApplicationException.ErrCode;

/**
 * @author 3495987jan
 */
@RestController
public class TestService {

    @RequestMapping(value = { "/api/throwex/{excepname}",
        "/api/throwex/{excepname}/{delay}" }, method = RequestMethod.GET)
    public String throwex(@PathVariable("excepname") String ex,
        @PathVariable(name = "delay", required = false) Integer delay) throws Exception {

        if (delay != null) Awaitility.await().atMost(delay, TimeUnit.MILLISECONDS);

        switch (ex) {
        case "appEx":
            throw new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, ErrCode.INTERNAL_SERVER_ERROR_109,
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), "This is a test message");

        case "validationfailed":
            throw new MsValidationException("Validation failed");
        case "missingParam":
            throw new MissingServletRequestParameterException("param name", "param type");
        case "bindingErr":
            throw new ServletRequestBindingException("error binding");
        case "noHandler":
            throw new NoHandlerFoundException("GET", "/api/throwex/nohandler", new HttpHeaders());

        case "httpClientError":
            throw new HttpClientErrorException(HttpStatus.NOT_FOUND);

        case "argNotValid":
            throw new MethodArgumentNotValidException(
                new MethodParameter(this.getClass().getMethod("throwex", String.class, Integer.class), 0),
                new DirectFieldBindingResult(this, "test"));
        case "illegalArg":
            throw new IllegalArgumentException("test");

        case "msgNotReadble":
            throw new HttpMessageNotReadableException(ex, null, null);

        case "mediaNotSupported":
            throw new HttpMediaTypeNotSupportedException("test");

        case "hystrixEx":
            throw new HystrixRuntimeException(FailureType.SHORTCIRCUIT, null, ex, null, null);

        case "null":
            throw new NullPointerException();

        default:
            throw new Exception("Generic exception");
        }

    }
}