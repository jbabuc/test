package com.pmli.util.web;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pmli.util.java.MsObject;
import com.pmli.util.web.ApplicationException.ErrCode;

/**
 * @author 3495987jan
 */

@SpringBootTest(webEnvironment = WebEnvironment.MOCK, classes = { Application.class })
@ContextConfiguration(classes = Application.class)
@ComponentScan({ "com.pmli.util.web" })
public class MsExceptionHandlerTest extends MsObject {
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @BeforeEach
    public void setUp() { this.mockMvc = webAppContextSetup(webApplicationContext).build(); }

    @Test
    public void testAppEx() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/appEx")).andReturn();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("109", node.get("errorCode").toString());
    }

    @Test
    public void testValidationfailed() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/validationfailed").accept(MediaType.APPLICATION_JSON))
            .andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("101", node.get("errorCode").toString());
    }

    @Test
    public void testMissingParam() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/missingParam").accept(MediaType.APPLICATION_JSON))
            .andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("101", node.get("errorCode").toString());
    }

    @Test
    public void testBindingErr() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/bindingErr").accept(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("101", node.get("errorCode").toString());
    }

    @Test
    public void testNoHandler() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/noHandler").accept(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("101", node.get("errorCode").toString());
    }

    @Test
    public void testHttpClientError() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/httpClientError").accept(MediaType.APPLICATION_JSON))
            .andReturn();
        assertEquals(HttpStatus.NOT_FOUND.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("107", node.get("errorCode").toString());
    }

    @Test
    public void testArgNotValid() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/argNotValid").accept(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("102", node.get("errorCode").toString());
    }

    @Test
    public void testIllegalArg() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/illegalArg").accept(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("102", node.get("errorCode").toString());
    }

    @Test
    public void testMessageNotReadable() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/msgNotReadble").accept(MediaType.APPLICATION_JSON))
            .andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("104", node.get("errorCode").toString());
    }

    @Test
    public void testMediaNotSupported() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/mediaNotSupported").accept(MediaType.APPLICATION_JSON))
            .andReturn();
        assertEquals(HttpStatus.BAD_REQUEST.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("106", node.get("errorCode").toString());
    }

    @Test
    public void testHystrixEx() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/hystrixEx").accept(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("108", node.get("errorCode").toString());
    }

    @Test
    public void testNull() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/null")).andReturn();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("109", node.get("errorCode").toString());
    }

    @Test
    public void testGenericEx() throws Exception {
        MvcResult res = mockMvc.perform(get("/api/throwex/generic/5000")).andReturn();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), res.getResponse().getStatus());
        JsonNode node = new ObjectMapper().readTree(res.getResponse().getContentAsString());
        assertEquals("109", node.get("errorCode").toString());
    }

    @Test
    public void appException() throws Exception {
        ApplicationException ae = new ApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,
            ErrCode.INTERNAL_SERVER_ERROR_109, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
            "This is a test message");

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ae.getHttpStatus());
        assertEquals(ErrCode.INTERNAL_SERVER_ERROR_109, ae.getErrorCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ae.getErrorDetails());
        assertEquals("This is a test message", ae.getErrorMoreInfo());
        assertTrue(ae.toString() != null);
        assertTrue(ApplicationException.getExceptionStackAsString(new Exception()) != null);
    }
}