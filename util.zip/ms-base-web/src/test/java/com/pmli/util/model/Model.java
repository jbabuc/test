package com.pmli.util.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

public class Model {

    @Test
    public void amount() {
        Money a = new Money(new BigDecimal(10.11209), "INR");
        assertEquals(10.11, a.getAmount().doubleValue());
        assertEquals(0, new Money(null, "INR").getAmount().doubleValue());
    }
}
