TEMP_CONFIG_DIR="/tmp/bo-app-config-$(date +%Y-%m-%d-%H%M%S)"
echo $TEMP_CONFIG_DIR
mkdir $TEMP_CONFIG_DIR

git -c http.extraHeader="Authorization: Basic MzQ5NTk4N2phbjpta3ZwM3ZucTJwc2I0Mms2eHh2b2ppaWlxNXFobW5pdm5kd2tuZjdpeGo1aWJmd2RuajRh" clone http://inblrprdazdv01:8080/tfs/MicroServices/Buy-Online/_git/bo-application-config $TEMP_CONFIG_DIR

if [ -d $TEMP_CONFIG_DIR/uat ]; then
    rm -rf config-files
	cp -rf $TEMP_CONFIG_DIR/uat config-files
	cp $TEMP_CONFIG_DIR/* .
	chmod +x dos2unix
	./dos2unix *.sh
	chmod +x *.sh
fi

rm -rf $TEMP_CONFIG_DIR
