restart_service()
{
	echo ""	
	echo "Restarting $1 service ..... $2"
	docker service update --force --update-parallelism 1 --update-delay 30s `docker service ls | grep $2 | cut -f 1 -d " "`
}

restart_service config 2140
restart_service ms-cron 3140
restart_service ms-customer 2142
restart_service ms-master 2144
restart_service ms-agent 3141

echo ""
echo "Buy online micro-services restart complete !!!"
echo ""
