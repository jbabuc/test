#!/bin/sh
export JOB_NAME=$1
export SERVERPORT=$2
echo Running ... $JOBNAME
export JOB_STARTTIME=$(date +"%Y%m%d_%H%M")
java -Dconfig-server-url=$CONFIG_SERVER_HOST_PORT_URL -Dloader.main=com.pmli.bo.cron.app.$JOB_NAME -DSERVERPORT=$SERVERPORT -jar /ms-customer.jar 