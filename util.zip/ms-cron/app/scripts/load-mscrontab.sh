#!/bin/sh
echo "Loading mscrontab ..." 
TMP_CRONTAB_CONF=/tmp/mscrontab.conf

cp /app/config/mscrontab.conf $TMP_CRONTAB_CONF
# if config-files/mscrontab.conf is present, use it
cp $MSCRON_STORAGE/config-files/mscrontab.conf $TMP_CRONTAB_CONF

dos2unix $TMP_CRONTAB_CONF
cat $TMP_CRONTAB_CONF | crontab -c $CRONTABS -
rm $TMP_CRONTAB_CONF
crontab -c $CRONTABS -l | tee -a $MSCRON_LOG