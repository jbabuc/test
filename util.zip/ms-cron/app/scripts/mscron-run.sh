#!/bin/sh
export JOB_NAME=$1
echo Running ... $JOB_NAME
export JOB_STARTTIME=$(date +"%Y%m%d_%H%M")
java -Dconfig-server-url=$CONFIG_SERVER_HOST_PORT_URL/ms-cron-$JOB_NAME -Dloader.main=com.pmli.bo.cron.app.$JOB_NAME -jar /ms-cron.jar 