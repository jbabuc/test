package com.pmli.bo.cron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsHelloWorldAppTest {

	//@Test
	void contextLoads() {
	}

}
