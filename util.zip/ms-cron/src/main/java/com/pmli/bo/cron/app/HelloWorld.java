package com.pmli.bo.cron.app;

import java.util.Date;

import com.pmli.util.java.MsObject;

public class HelloWorld {
    public static void main(String[] args) { MsObject.getSL().info("Hello world ... " + new Date()); }
}
