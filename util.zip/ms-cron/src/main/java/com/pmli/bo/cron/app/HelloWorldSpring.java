package com.pmli.bo.cron.app;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.pmli.util.java.MsObject;
import com.pmli.util.spring.ContextWrapper;

@SpringBootApplication(scanBasePackages = {}, exclude = { MongoAutoConfiguration.class,
    MongoDataAutoConfiguration.class, ErrorMvcAutoConfiguration.class })
@ComponentScan("com.pmli")
public class HelloWorldSpring extends MsObject {
    public static void main(String[] args) {
        try {
            SpringApplication app = new SpringApplication(HelloWorldSpring.class);
            app.setWebApplicationType(WebApplicationType.NONE);
            app.run(args);
            ContextWrapper.logAllProperties();

            getSL().info("Hello world from Spring ... " + new Date());
        } catch (Throwable th) {
            getSL().info("Error encountered,  {}", th);
        }
    }
}
