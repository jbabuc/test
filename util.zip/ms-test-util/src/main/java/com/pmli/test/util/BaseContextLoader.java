package com.pmli.test.util;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@Component
@SpringBootTest
@ActiveProfiles(profiles = { "junit", "input-payload" })
@ExtendWith(SpringExtension.class)
public class BaseContextLoader {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

    }

    /**
     * This method returns MvcResult result by calling post method
     * 
     * @param  endpointUri:  String
     * @param  inputPayload: String
     * @return               result:MvcResult
     */
    public MvcResult callPostEndpoint(String endpointUri, String inputPayload) {
        MvcResult result = null;
        try {
            MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post(endpointUri)
                .accept(MediaType.APPLICATION_JSON).content(inputPayload).contentType(MediaType.APPLICATION_JSON);
            result = mockMvc.perform(requestBuilder).andReturn();
        } catch (Exception exp) {}
        return result;
    }

    /**
     * This method returns MvcResult result by calling Get method
     * 
     * @param  endpointUri: String
     * @return              result:MvcResult
     */
    public MvcResult callGetEndPoint(String endpointUri) {
        MvcResult result = null;
        try {
            MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(endpointUri)
                .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
            result = mockMvc.perform(requestBuilder).andReturn();
        } catch (Exception exp) {}
        return result;
    }

    /**
     * This method calls post end points and asserts response code
     * 
     * @param  endpointUri:  String
     * @param  inputPayload: String
     * @param  httpStatus:   int
     * @return               boolean: true
     */
    public boolean callEndPointAndAssert(String endpointURI, String inputPayload, int httpStatus) {
        MvcResult result = callPostEndpoint(endpointURI, inputPayload);
        return assertResponse(result, httpStatus);
    }

    /**
     * This method calls Get end points and asserts response code
     * 
     * @param  endpointUri: String
     * @param  httpStatus:  int
     * @return              boolean: true
     */
    public boolean callEndPointAndAssert(String endpointURI, int httpStatus) {
        MvcResult result = callGetEndPoint(endpointURI);
        return assertResponse(result, httpStatus);
    }

    /**
     * This method calls post end points and asserts response
     * 
     * @param  endpointUri:                 String
     * @param  inputPayload:                String
     * @param  httpStatus:                  int
     * @param  expectedResponse:            String
     * @return                              boolean: true
     * @throws UnsupportedEncodingException
     */
    public boolean callEndPointAndAssert(String endpointURI, String inputPayload, int httpStatus, String expectedResponse) throws UnsupportedEncodingException {
        MvcResult result = callPostEndpoint(endpointURI, inputPayload);
        return assertResponse(result, httpStatus, expectedResponse);
    }

    /**
     * This method calls Get end points and asserts response
     * 
     * @param  endpointUri:      String
     * @param  httpStatus:       int
     * @param  expectedResponse: String
     * @return                   boolean: true
     */
    public boolean callEndPointAndAssert(String endpointURI, int httpStatus, String expectedResponse) throws UnsupportedEncodingException {
        MvcResult result = callGetEndPoint(endpointURI);
        return assertResponse(result, httpStatus, expectedResponse);
    }

    /**
     * This method asserts response code
     * 
     * @param  result:     MvcResult
     * @param  httpStatus: int
     * @return             boolean: true
     */
    public boolean assertResponse(MvcResult result, int httpStatus) {
        Assertions.assertNotNull(result.getResponse());
        Assertions.assertEquals(httpStatus, result.getResponse().getStatus());
        return true;
    }

    /**
     * This method asserts response
     * 
     * @param  result:           MvcResult
     * @param  httpStatus:       int
     * @param  expectedResponse: String
     * @return                   boolean: true
     */
    public boolean assertResponse(MvcResult result, int httpStatus, String expectedResponse)
        throws UnsupportedEncodingException {
        assertResponse(result, httpStatus);
        Assertions.assertEquals(expectedResponse, result.getResponse().getContentAsString());
        return true;
    }
}
